transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {Z:/lab/Lab1/or2in.vhd}

vsim work.or2in

add wave *

force sw0 0;
force sw1 0
run 100ns

force sw0 1
run 100ns

force sw1 1
run 100ns

force sw0 0
run 100ns

force sw1 0
run 100ns