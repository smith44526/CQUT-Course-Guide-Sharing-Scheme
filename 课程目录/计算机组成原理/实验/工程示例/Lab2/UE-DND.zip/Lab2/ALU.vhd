-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- PROGRAM		"Quartus Prime"
-- VERSION		"Version 20.1.1 Build 720 11/11/2020 SJ Lite Edition"
-- CREATED		"Sat Nov 22 17:44:15 2025"

LIBRARY ieee;
USE ieee.std_logic_1164.all; 

LIBRARY work;

ENTITY ALU IS 
	PORT
	(
		CLK :  IN  STD_LOGIC;
		SEG :  IN  STD_LOGIC;
		ALU :  IN  STD_LOGIC;
		LOAD_A :  IN  STD_LOGIC;
		LOAD_B :  IN  STD_LOGIC;
		LOAD_S :  IN  STD_LOGIC;
		DATA_IN :  IN  STD_LOGIC_VECTOR(7 DOWNTO 0);
		CF :  OUT  STD_LOGIC;
		RQA1 :  OUT  STD_LOGIC_VECTOR(6 DOWNTO 0);
		RQA2 :  OUT  STD_LOGIC_VECTOR(6 DOWNTO 0);
		RQB1 :  OUT  STD_LOGIC_VECTOR(6 DOWNTO 0);
		RQB2 :  OUT  STD_LOGIC_VECTOR(6 DOWNTO 0);
		RQF1 :  OUT  STD_LOGIC_VECTOR(6 DOWNTO 0);
		RQF2 :  OUT  STD_LOGIC_VECTOR(6 DOWNTO 0);
		S :  OUT  STD_LOGIC_VECTOR(3 DOWNTO 0)
	);
END ALU;

ARCHITECTURE bdf_type OF ALU IS 

COMPONENT ac_a
	PORT(LOAD_A : IN STD_LOGIC;
		 clk : IN STD_LOGIC;
		 Data_in : IN STD_LOGIC_VECTOR(7 DOWNTO 0);
		 A : OUT STD_LOGIC_VECTOR(7 DOWNTO 0)
	);
END COMPONENT;

COMPONENT ac_b
	PORT(LOAD_B : IN STD_LOGIC;
		 clk : IN STD_LOGIC;
		 Data_in : IN STD_LOGIC_VECTOR(7 DOWNTO 0);
		 B : OUT STD_LOGIC_VECTOR(7 DOWNTO 0)
	);
END COMPONENT;

COMPONENT ac_s
	PORT(LOAD_S : IN STD_LOGIC;
		 clk : IN STD_LOGIC;
		 S_in : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
		 S : OUT STD_LOGIC_VECTOR(3 DOWNTO 0)
	);
END COMPONENT;

COMPONENT alu_8b
	PORT(M : IN STD_LOGIC;
		 CN : IN STD_LOGIC;
		 A : IN STD_LOGIC_VECTOR(7 DOWNTO 0);
		 B : IN STD_LOGIC_VECTOR(7 DOWNTO 0);
		 S : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
		 CO : OUT STD_LOGIC;
		 F : OUT STD_LOGIC_VECTOR(7 DOWNTO 0)
	);
END COMPONENT;

COMPONENT seg7_16b
	PORT(Blank : IN STD_LOGIC;
		 Test : IN STD_LOGIC;
		 Data : IN STD_LOGIC_VECTOR(7 DOWNTO 0);
		 RQ1 : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
		 RQ2 : OUT STD_LOGIC_VECTOR(6 DOWNTO 0)
	);
END COMPONENT;

SIGNAL	A :  STD_LOGIC_VECTOR(7 DOWNTO 0);
SIGNAL	B :  STD_LOGIC_VECTOR(7 DOWNTO 0);
SIGNAL	S_ALTERA_SYNTHESIZED :  STD_LOGIC_VECTOR(3 DOWNTO 0);
SIGNAL	SYNTHESIZED_WIRE_0 :  STD_LOGIC;
SIGNAL	SYNTHESIZED_WIRE_1 :  STD_LOGIC;
SIGNAL	SYNTHESIZED_WIRE_2 :  STD_LOGIC;
SIGNAL	SYNTHESIZED_WIRE_3 :  STD_LOGIC;
SIGNAL	SYNTHESIZED_WIRE_4 :  STD_LOGIC;
SIGNAL	SYNTHESIZED_WIRE_5 :  STD_LOGIC;
SIGNAL	SYNTHESIZED_WIRE_10 :  STD_LOGIC;
SIGNAL	SYNTHESIZED_WIRE_7 :  STD_LOGIC_VECTOR(7 DOWNTO 0);


BEGIN 



SYNTHESIZED_WIRE_3 <= NOT(LOAD_B);



SYNTHESIZED_WIRE_10 <= NOT(SEG);



SYNTHESIZED_WIRE_5 <= NOT(ALU);



CF <= SYNTHESIZED_WIRE_0 XOR S_ALTERA_SYNTHESIZED(0);


SYNTHESIZED_WIRE_0 <= NOT(SYNTHESIZED_WIRE_1);



SYNTHESIZED_WIRE_2 <= NOT(LOAD_A);



SYNTHESIZED_WIRE_4 <= NOT(LOAD_S);



b2v_inst_ac_a : ac_a
PORT MAP(LOAD_A => SYNTHESIZED_WIRE_2,
		 clk => CLK,
		 Data_in => DATA_IN,
		 A => A);


b2v_inst_ac_b : ac_b
PORT MAP(LOAD_B => SYNTHESIZED_WIRE_3,
		 clk => CLK,
		 Data_in => DATA_IN,
		 B => B);


b2v_inst_ac_s : ac_s
PORT MAP(LOAD_S => SYNTHESIZED_WIRE_4,
		 clk => CLK,
		 S_in => DATA_IN(3 DOWNTO 0),
		 S => S_ALTERA_SYNTHESIZED);


b2v_inst_alu_8b : alu_8b
PORT MAP(M => SYNTHESIZED_WIRE_5,
		 CN => ALU,
		 A => A,
		 B => B,
		 S => S_ALTERA_SYNTHESIZED,
		 CO => SYNTHESIZED_WIRE_1,
		 F => SYNTHESIZED_WIRE_7);


b2v_inst_seg7 : seg7_16b
PORT MAP(Blank => SEG,
		 Test => SYNTHESIZED_WIRE_10,
		 Data => SYNTHESIZED_WIRE_7,
		 RQ1 => RQF1,
		 RQ2 => RQF2);


b2v_inst_seg7_A : seg7_16b
PORT MAP(Blank => SEG,
		 Test => SYNTHESIZED_WIRE_10,
		 Data => A,
		 RQ1 => RQA1,
		 RQ2 => RQA2);


b2v_inst_seg7_B : seg7_16b
PORT MAP(Blank => SEG,
		 Test => SYNTHESIZED_WIRE_10,
		 Data => B,
		 RQ1 => RQB1,
		 RQ2 => RQB2);

S <= S_ALTERA_SYNTHESIZED;

END bdf_type;