-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 20.1.1 Build 720 11/11/2020 SJ Lite Edition"

-- DATE "11/22/2025 17:45:29"

-- 
-- Device: Altera 5CSEMA5F31C6 Package FBGA896
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY ALTERA_LNSIM;
LIBRARY CYCLONEV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE ALTERA_LNSIM.ALTERA_LNSIM_COMPONENTS.ALL;
USE CYCLONEV.CYCLONEV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	ALU IS
    PORT (
	CLK : IN std_logic;
	SEG : IN std_logic;
	ALU : IN std_logic;
	LOAD_A : IN std_logic;
	LOAD_B : IN std_logic;
	LOAD_S : IN std_logic;
	DATA_IN : IN std_logic_vector(7 DOWNTO 0);
	CF : OUT std_logic;
	RQA1 : OUT std_logic_vector(6 DOWNTO 0);
	RQA2 : OUT std_logic_vector(6 DOWNTO 0);
	RQB1 : OUT std_logic_vector(6 DOWNTO 0);
	RQB2 : OUT std_logic_vector(6 DOWNTO 0);
	RQF1 : OUT std_logic_vector(6 DOWNTO 0);
	RQF2 : OUT std_logic_vector(6 DOWNTO 0);
	S : OUT std_logic_vector(3 DOWNTO 0)
	);
END ALU;

-- Design Ports Information
-- CF	=>  Location: PIN_V16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA1[0]	=>  Location: PIN_W25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA1[1]	=>  Location: PIN_V23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA1[2]	=>  Location: PIN_W24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA1[3]	=>  Location: PIN_W22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA1[4]	=>  Location: PIN_Y24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA1[5]	=>  Location: PIN_Y23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA1[6]	=>  Location: PIN_AA24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA2[0]	=>  Location: PIN_AA25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA2[1]	=>  Location: PIN_AA26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA2[2]	=>  Location: PIN_AB26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA2[3]	=>  Location: PIN_AB27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA2[4]	=>  Location: PIN_Y27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA2[5]	=>  Location: PIN_AA28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQA2[6]	=>  Location: PIN_V25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB1[0]	=>  Location: PIN_AC30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB1[1]	=>  Location: PIN_AC29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB1[2]	=>  Location: PIN_AD30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB1[3]	=>  Location: PIN_AC28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB1[4]	=>  Location: PIN_AD29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB1[5]	=>  Location: PIN_AE29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB1[6]	=>  Location: PIN_AB23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB2[0]	=>  Location: PIN_AB22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB2[1]	=>  Location: PIN_AB25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB2[2]	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB2[3]	=>  Location: PIN_AC25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB2[4]	=>  Location: PIN_AD25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB2[5]	=>  Location: PIN_AC27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQB2[6]	=>  Location: PIN_AD26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF1[0]	=>  Location: PIN_AH28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF1[1]	=>  Location: PIN_AG28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF1[2]	=>  Location: PIN_AF28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF1[3]	=>  Location: PIN_AG27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF1[4]	=>  Location: PIN_AE28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF1[5]	=>  Location: PIN_AE27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF1[6]	=>  Location: PIN_AE26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF2[0]	=>  Location: PIN_AD27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF2[1]	=>  Location: PIN_AF30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF2[2]	=>  Location: PIN_AF29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF2[3]	=>  Location: PIN_AG30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF2[4]	=>  Location: PIN_AH30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF2[5]	=>  Location: PIN_AH29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQF2[6]	=>  Location: PIN_AJ29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- S[0]	=>  Location: PIN_Y19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- S[1]	=>  Location: PIN_W20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- S[2]	=>  Location: PIN_W21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- S[3]	=>  Location: PIN_Y21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ALU	=>  Location: PIN_AE12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SEG	=>  Location: PIN_AD10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA_IN[0]	=>  Location: PIN_AB12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CLK	=>  Location: PIN_AA14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LOAD_S	=>  Location: PIN_Y16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA_IN[2]	=>  Location: PIN_AF9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA_IN[7]	=>  Location: PIN_AC9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LOAD_A	=>  Location: PIN_AA15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA_IN[3]	=>  Location: PIN_AF10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA_IN[1]	=>  Location: PIN_AC12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA_IN[4]	=>  Location: PIN_AD11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA_IN[5]	=>  Location: PIN_AD12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DATA_IN[6]	=>  Location: PIN_AE11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LOAD_B	=>  Location: PIN_W15,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF ALU IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_CLK : std_logic;
SIGNAL ww_SEG : std_logic;
SIGNAL ww_ALU : std_logic;
SIGNAL ww_LOAD_A : std_logic;
SIGNAL ww_LOAD_B : std_logic;
SIGNAL ww_LOAD_S : std_logic;
SIGNAL ww_DATA_IN : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_CF : std_logic;
SIGNAL ww_RQA1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQA2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQB1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQB2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQF1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQF2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_S : std_logic_vector(3 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \CLK~input_o\ : std_logic;
SIGNAL \CLK~inputCLKENA0_outclk\ : std_logic;
SIGNAL \DATA_IN[0]~input_o\ : std_logic;
SIGNAL \LOAD_S~input_o\ : std_logic;
SIGNAL \ALU~input_o\ : std_logic;
SIGNAL \DATA_IN[2]~input_o\ : std_logic;
SIGNAL \DATA_IN[7]~input_o\ : std_logic;
SIGNAL \LOAD_B~input_o\ : std_logic;
SIGNAL \b2v_inst_ac_a|A[7]~feeder_combout\ : std_logic;
SIGNAL \LOAD_A~input_o\ : std_logic;
SIGNAL \DATA_IN[6]~input_o\ : std_logic;
SIGNAL \DATA_IN[5]~input_o\ : std_logic;
SIGNAL \DATA_IN[4]~input_o\ : std_logic;
SIGNAL \b2v_inst_ac_a|A[4]~feeder_combout\ : std_logic;
SIGNAL \DATA_IN[3]~input_o\ : std_logic;
SIGNAL \DATA_IN[1]~input_o\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~6\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~10\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~14\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~18\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~22\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~26\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~30\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~34\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~6\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~10\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~14\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~18\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~22\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~26\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~30\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~34\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~6\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~10\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~14\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~18\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~22\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~26\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~30\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~34\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux0~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~6\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~7\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~10\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~11\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~14\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~15\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~18\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~19\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~22\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~23\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~26\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~27\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~30\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~31\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~34\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~35\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux0~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~6\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~10\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~14\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~18\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~22\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~26\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~30\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~34\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~6\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~10\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~14\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~18\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~22\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~26\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~30\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~34\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux0~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~6\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~10\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~14\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~18\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~22\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~26\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~30\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~34\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~6\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~10\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~14\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~18\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~22\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~26\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~30\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~34\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux0~0_combout\ : std_logic;
SIGNAL \CF~0_combout\ : std_logic;
SIGNAL \SEG~input_o\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux6~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux5~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux4~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux3~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux2~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux1~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux0~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux13~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux12~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux11~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux10~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux9~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux8~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_A|Mux7~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux6~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux5~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux4~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux3~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux2~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux1~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux0~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux13~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux12~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux11~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux10~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux9~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux8~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7_B|Mux7~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux6~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux6~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux6~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux6~10_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux6~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux7~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~8_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux6~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux6~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux6~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux8~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux8~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux8~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux8~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux8~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux7~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux7~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux7~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux7~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux7~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux7~11_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux7~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux7~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux5~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux5~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux5~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux5~10_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~9_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux5~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux5~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux5~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux5~5_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux6~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux5~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux4~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux3~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux2~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux1~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux0~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux1~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~13_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux1~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~14_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux1~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux1~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux1~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux1~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux1~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux1~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux3~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~11_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux3~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux3~10_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux3~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux3~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux3~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux3~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux3~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~11_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~10_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~12_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~19_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~8_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~9_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~10_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~15_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux4~13_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add3~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add5~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux2~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add4~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|F9~12_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux2~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add6~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add7~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux2~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add2~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add1~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Add0~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux2~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux2~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux2~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux2~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|Mux2~6_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux13~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux12~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux11~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux10~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux9~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux8~0_combout\ : std_logic;
SIGNAL \b2v_inst_seg7|Mux7~0_combout\ : std_logic;
SIGNAL \b2v_inst_ac_s|S\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \b2v_inst_ac_a|A\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \b2v_inst_ac_b|B\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add7~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add2~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add1~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add4~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add3~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add5~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add6~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add7~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add2~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add1~9_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add6~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add1~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add7~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add4~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add2~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add5~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add3~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add5~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add7~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add2~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add6~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add4~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add3~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add1~1_sumout\ : std_logic;
SIGNAL \b2v_inst_ac_b|ALT_INV_B\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \b2v_inst_ac_a|ALT_INV_A\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \b2v_inst_ac_s|ALT_INV_S\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux0~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux0~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux0~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux0~3_combout\ : std_logic;
SIGNAL \ALT_INV_CF~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux8~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux8~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux7~11_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux7~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux6~10_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux6~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux5~10_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux5~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~19_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~15_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux3~10_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux3~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux2~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux1~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add4~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add3~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add5~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add6~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add7~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add2~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add0~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add1~33_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add4~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add3~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add5~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add6~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add7~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add2~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add1~29_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add4~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add3~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add5~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add6~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add7~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add2~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add1~25_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add4~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add3~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add5~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add6~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add7~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add2~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add1~21_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add4~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add3~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add5~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add6~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add7~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add2~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add1~17_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add4~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add3~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add5~13_sumout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Add6~13_sumout\ : std_logic;
SIGNAL \ALT_INV_LOAD_S~input_o\ : std_logic;
SIGNAL \ALT_INV_SEG~input_o\ : std_logic;
SIGNAL \ALT_INV_ALU~input_o\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux1~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux1~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~13_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux1~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux1~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux1~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux1~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux1~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux2~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux2~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~12_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux2~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux2~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~14_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux2~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux2~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux2~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux3~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux3~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~11_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux3~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux3~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux3~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux3~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~13_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~12_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~10_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~11_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~10_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~9_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~8_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux5~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux5~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~9_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux5~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux5~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux5~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux5~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux6~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux6~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~8_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux6~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux6~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux6~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux7~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux7~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux7~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~7_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux7~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux7~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux7~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux7~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux4~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux8~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux8~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~6_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~5_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~4_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_Mux8~0_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~3_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~2_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~1_combout\ : std_logic;
SIGNAL \b2v_inst_alu_8b|ALT_INV_F9~0_combout\ : std_logic;
SIGNAL \ALT_INV_LOAD_B~input_o\ : std_logic;
SIGNAL \ALT_INV_DATA_IN[4]~input_o\ : std_logic;
SIGNAL \ALT_INV_LOAD_A~input_o\ : std_logic;
SIGNAL \ALT_INV_DATA_IN[7]~input_o\ : std_logic;

BEGIN

ww_CLK <= CLK;
ww_SEG <= SEG;
ww_ALU <= ALU;
ww_LOAD_A <= LOAD_A;
ww_LOAD_B <= LOAD_B;
ww_LOAD_S <= LOAD_S;
ww_DATA_IN <= DATA_IN;
CF <= ww_CF;
RQA1 <= ww_RQA1;
RQA2 <= ww_RQA2;
RQB1 <= ww_RQB1;
RQB2 <= ww_RQB2;
RQF1 <= ww_RQF1;
RQF2 <= ww_RQF2;
S <= ww_S;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\b2v_inst_alu_8b|ALT_INV_Add7~13_sumout\ <= NOT \b2v_inst_alu_8b|Add7~13_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add2~13_sumout\ <= NOT \b2v_inst_alu_8b|Add2~13_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add0~13_sumout\ <= NOT \b2v_inst_alu_8b|Add0~13_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add1~13_sumout\ <= NOT \b2v_inst_alu_8b|Add1~13_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add4~9_sumout\ <= NOT \b2v_inst_alu_8b|Add4~9_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add3~9_sumout\ <= NOT \b2v_inst_alu_8b|Add3~9_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add5~9_sumout\ <= NOT \b2v_inst_alu_8b|Add5~9_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add6~9_sumout\ <= NOT \b2v_inst_alu_8b|Add6~9_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add7~9_sumout\ <= NOT \b2v_inst_alu_8b|Add7~9_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add2~9_sumout\ <= NOT \b2v_inst_alu_8b|Add2~9_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add0~9_sumout\ <= NOT \b2v_inst_alu_8b|Add0~9_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add1~9_sumout\ <= NOT \b2v_inst_alu_8b|Add1~9_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add6~5_sumout\ <= NOT \b2v_inst_alu_8b|Add6~5_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add1~5_sumout\ <= NOT \b2v_inst_alu_8b|Add1~5_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add7~5_sumout\ <= NOT \b2v_inst_alu_8b|Add7~5_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add4~5_sumout\ <= NOT \b2v_inst_alu_8b|Add4~5_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add2~5_sumout\ <= NOT \b2v_inst_alu_8b|Add2~5_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add5~5_sumout\ <= NOT \b2v_inst_alu_8b|Add5~5_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add3~5_sumout\ <= NOT \b2v_inst_alu_8b|Add3~5_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add0~5_sumout\ <= NOT \b2v_inst_alu_8b|Add0~5_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add5~1_sumout\ <= NOT \b2v_inst_alu_8b|Add5~1_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add7~1_sumout\ <= NOT \b2v_inst_alu_8b|Add7~1_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add2~1_sumout\ <= NOT \b2v_inst_alu_8b|Add2~1_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add6~1_sumout\ <= NOT \b2v_inst_alu_8b|Add6~1_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add4~1_sumout\ <= NOT \b2v_inst_alu_8b|Add4~1_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add3~1_sumout\ <= NOT \b2v_inst_alu_8b|Add3~1_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add0~1_sumout\ <= NOT \b2v_inst_alu_8b|Add0~1_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add1~1_sumout\ <= NOT \b2v_inst_alu_8b|Add1~1_sumout\;
\b2v_inst_ac_b|ALT_INV_B\(0) <= NOT \b2v_inst_ac_b|B\(0);
\b2v_inst_ac_a|ALT_INV_A\(6) <= NOT \b2v_inst_ac_a|A\(6);
\b2v_inst_ac_a|ALT_INV_A\(5) <= NOT \b2v_inst_ac_a|A\(5);
\b2v_inst_ac_a|ALT_INV_A\(4) <= NOT \b2v_inst_ac_a|A\(4);
\b2v_inst_ac_a|ALT_INV_A\(3) <= NOT \b2v_inst_ac_a|A\(3);
\b2v_inst_ac_a|ALT_INV_A\(2) <= NOT \b2v_inst_ac_a|A\(2);
\b2v_inst_ac_a|ALT_INV_A\(1) <= NOT \b2v_inst_ac_a|A\(1);
\b2v_inst_ac_a|ALT_INV_A\(0) <= NOT \b2v_inst_ac_a|A\(0);
\b2v_inst_ac_s|ALT_INV_S\(1) <= NOT \b2v_inst_ac_s|S\(1);
\b2v_inst_ac_s|ALT_INV_S\(3) <= NOT \b2v_inst_ac_s|S\(3);
\b2v_inst_alu_8b|ALT_INV_Mux0~2_combout\ <= NOT \b2v_inst_alu_8b|Mux0~2_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux0~1_combout\ <= NOT \b2v_inst_alu_8b|Mux0~1_combout\;
\b2v_inst_ac_a|ALT_INV_A\(7) <= NOT \b2v_inst_ac_a|A\(7);
\b2v_inst_alu_8b|ALT_INV_Mux0~0_combout\ <= NOT \b2v_inst_alu_8b|Mux0~0_combout\;
\b2v_inst_ac_s|ALT_INV_S\(2) <= NOT \b2v_inst_ac_s|S\(2);
\b2v_inst_ac_s|ALT_INV_S\(0) <= NOT \b2v_inst_ac_s|S\(0);
\b2v_inst_alu_8b|ALT_INV_Mux0~3_combout\ <= NOT \b2v_inst_alu_8b|Mux0~3_combout\;
\ALT_INV_CF~0_combout\ <= NOT \CF~0_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux8~7_combout\ <= NOT \b2v_inst_alu_8b|Mux8~7_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux8~3_combout\ <= NOT \b2v_inst_alu_8b|Mux8~3_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux7~11_combout\ <= NOT \b2v_inst_alu_8b|Mux7~11_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux7~7_combout\ <= NOT \b2v_inst_alu_8b|Mux7~7_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux6~10_combout\ <= NOT \b2v_inst_alu_8b|Mux6~10_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux6~6_combout\ <= NOT \b2v_inst_alu_8b|Mux6~6_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux5~10_combout\ <= NOT \b2v_inst_alu_8b|Mux5~10_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux5~6_combout\ <= NOT \b2v_inst_alu_8b|Mux5~6_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~19_combout\ <= NOT \b2v_inst_alu_8b|Mux4~19_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~15_combout\ <= NOT \b2v_inst_alu_8b|Mux4~15_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux3~10_combout\ <= NOT \b2v_inst_alu_8b|Mux3~10_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux3~6_combout\ <= NOT \b2v_inst_alu_8b|Mux3~6_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux2~7_combout\ <= NOT \b2v_inst_alu_8b|Mux2~7_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux1~7_combout\ <= NOT \b2v_inst_alu_8b|Mux1~7_combout\;
\b2v_inst_alu_8b|ALT_INV_Add4~33_sumout\ <= NOT \b2v_inst_alu_8b|Add4~33_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add3~33_sumout\ <= NOT \b2v_inst_alu_8b|Add3~33_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add5~33_sumout\ <= NOT \b2v_inst_alu_8b|Add5~33_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add6~33_sumout\ <= NOT \b2v_inst_alu_8b|Add6~33_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add7~33_sumout\ <= NOT \b2v_inst_alu_8b|Add7~33_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add2~33_sumout\ <= NOT \b2v_inst_alu_8b|Add2~33_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add0~33_sumout\ <= NOT \b2v_inst_alu_8b|Add0~33_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add1~33_sumout\ <= NOT \b2v_inst_alu_8b|Add1~33_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add4~29_sumout\ <= NOT \b2v_inst_alu_8b|Add4~29_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add3~29_sumout\ <= NOT \b2v_inst_alu_8b|Add3~29_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add5~29_sumout\ <= NOT \b2v_inst_alu_8b|Add5~29_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add6~29_sumout\ <= NOT \b2v_inst_alu_8b|Add6~29_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add7~29_sumout\ <= NOT \b2v_inst_alu_8b|Add7~29_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add2~29_sumout\ <= NOT \b2v_inst_alu_8b|Add2~29_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add0~29_sumout\ <= NOT \b2v_inst_alu_8b|Add0~29_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add1~29_sumout\ <= NOT \b2v_inst_alu_8b|Add1~29_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add4~25_sumout\ <= NOT \b2v_inst_alu_8b|Add4~25_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add3~25_sumout\ <= NOT \b2v_inst_alu_8b|Add3~25_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add5~25_sumout\ <= NOT \b2v_inst_alu_8b|Add5~25_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add6~25_sumout\ <= NOT \b2v_inst_alu_8b|Add6~25_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add7~25_sumout\ <= NOT \b2v_inst_alu_8b|Add7~25_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add2~25_sumout\ <= NOT \b2v_inst_alu_8b|Add2~25_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add0~25_sumout\ <= NOT \b2v_inst_alu_8b|Add0~25_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add1~25_sumout\ <= NOT \b2v_inst_alu_8b|Add1~25_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add4~21_sumout\ <= NOT \b2v_inst_alu_8b|Add4~21_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add3~21_sumout\ <= NOT \b2v_inst_alu_8b|Add3~21_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add5~21_sumout\ <= NOT \b2v_inst_alu_8b|Add5~21_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add6~21_sumout\ <= NOT \b2v_inst_alu_8b|Add6~21_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add7~21_sumout\ <= NOT \b2v_inst_alu_8b|Add7~21_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add2~21_sumout\ <= NOT \b2v_inst_alu_8b|Add2~21_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add0~21_sumout\ <= NOT \b2v_inst_alu_8b|Add0~21_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add1~21_sumout\ <= NOT \b2v_inst_alu_8b|Add1~21_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add4~17_sumout\ <= NOT \b2v_inst_alu_8b|Add4~17_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add3~17_sumout\ <= NOT \b2v_inst_alu_8b|Add3~17_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add5~17_sumout\ <= NOT \b2v_inst_alu_8b|Add5~17_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add6~17_sumout\ <= NOT \b2v_inst_alu_8b|Add6~17_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add7~17_sumout\ <= NOT \b2v_inst_alu_8b|Add7~17_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add2~17_sumout\ <= NOT \b2v_inst_alu_8b|Add2~17_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add0~17_sumout\ <= NOT \b2v_inst_alu_8b|Add0~17_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add1~17_sumout\ <= NOT \b2v_inst_alu_8b|Add1~17_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add4~13_sumout\ <= NOT \b2v_inst_alu_8b|Add4~13_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add3~13_sumout\ <= NOT \b2v_inst_alu_8b|Add3~13_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add5~13_sumout\ <= NOT \b2v_inst_alu_8b|Add5~13_sumout\;
\b2v_inst_alu_8b|ALT_INV_Add6~13_sumout\ <= NOT \b2v_inst_alu_8b|Add6~13_sumout\;
\ALT_INV_LOAD_S~input_o\ <= NOT \LOAD_S~input_o\;
\ALT_INV_SEG~input_o\ <= NOT \SEG~input_o\;
\ALT_INV_ALU~input_o\ <= NOT \ALU~input_o\;
\b2v_inst_alu_8b|ALT_INV_Mux1~6_combout\ <= NOT \b2v_inst_alu_8b|Mux1~6_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux1~5_combout\ <= NOT \b2v_inst_alu_8b|Mux1~5_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~13_combout\ <= NOT \b2v_inst_alu_8b|F9~13_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux1~4_combout\ <= NOT \b2v_inst_alu_8b|Mux1~4_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux1~3_combout\ <= NOT \b2v_inst_alu_8b|Mux1~3_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux1~2_combout\ <= NOT \b2v_inst_alu_8b|Mux1~2_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux1~1_combout\ <= NOT \b2v_inst_alu_8b|Mux1~1_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux1~0_combout\ <= NOT \b2v_inst_alu_8b|Mux1~0_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux2~6_combout\ <= NOT \b2v_inst_alu_8b|Mux2~6_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux2~5_combout\ <= NOT \b2v_inst_alu_8b|Mux2~5_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~12_combout\ <= NOT \b2v_inst_alu_8b|F9~12_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux2~4_combout\ <= NOT \b2v_inst_alu_8b|Mux2~4_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux2~3_combout\ <= NOT \b2v_inst_alu_8b|Mux2~3_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~14_combout\ <= NOT \b2v_inst_alu_8b|Mux4~14_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux2~2_combout\ <= NOT \b2v_inst_alu_8b|Mux2~2_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux2~1_combout\ <= NOT \b2v_inst_alu_8b|Mux2~1_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux2~0_combout\ <= NOT \b2v_inst_alu_8b|Mux2~0_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux3~5_combout\ <= NOT \b2v_inst_alu_8b|Mux3~5_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux3~4_combout\ <= NOT \b2v_inst_alu_8b|Mux3~4_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~11_combout\ <= NOT \b2v_inst_alu_8b|F9~11_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux3~3_combout\ <= NOT \b2v_inst_alu_8b|Mux3~3_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux3~2_combout\ <= NOT \b2v_inst_alu_8b|Mux3~2_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux3~1_combout\ <= NOT \b2v_inst_alu_8b|Mux3~1_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux3~0_combout\ <= NOT \b2v_inst_alu_8b|Mux3~0_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~13_combout\ <= NOT \b2v_inst_alu_8b|Mux4~13_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~12_combout\ <= NOT \b2v_inst_alu_8b|Mux4~12_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~10_combout\ <= NOT \b2v_inst_alu_8b|F9~10_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~11_combout\ <= NOT \b2v_inst_alu_8b|Mux4~11_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~10_combout\ <= NOT \b2v_inst_alu_8b|Mux4~10_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~9_combout\ <= NOT \b2v_inst_alu_8b|Mux4~9_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~8_combout\ <= NOT \b2v_inst_alu_8b|Mux4~8_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux5~5_combout\ <= NOT \b2v_inst_alu_8b|Mux5~5_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux5~4_combout\ <= NOT \b2v_inst_alu_8b|Mux5~4_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~9_combout\ <= NOT \b2v_inst_alu_8b|F9~9_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux5~3_combout\ <= NOT \b2v_inst_alu_8b|Mux5~3_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux5~2_combout\ <= NOT \b2v_inst_alu_8b|Mux5~2_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux5~1_combout\ <= NOT \b2v_inst_alu_8b|Mux5~1_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux5~0_combout\ <= NOT \b2v_inst_alu_8b|Mux5~0_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux6~5_combout\ <= NOT \b2v_inst_alu_8b|Mux6~5_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux6~4_combout\ <= NOT \b2v_inst_alu_8b|Mux6~4_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~8_combout\ <= NOT \b2v_inst_alu_8b|F9~8_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux6~3_combout\ <= NOT \b2v_inst_alu_8b|Mux6~3_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux6~2_combout\ <= NOT \b2v_inst_alu_8b|Mux6~2_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux6~1_combout\ <= NOT \b2v_inst_alu_8b|Mux6~1_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux6~0_combout\ <= NOT \b2v_inst_alu_8b|Mux6~0_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux7~6_combout\ <= NOT \b2v_inst_alu_8b|Mux7~6_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~7_combout\ <= NOT \b2v_inst_alu_8b|Mux4~7_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~6_combout\ <= NOT \b2v_inst_alu_8b|Mux4~6_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux7~5_combout\ <= NOT \b2v_inst_alu_8b|Mux7~5_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux7~4_combout\ <= NOT \b2v_inst_alu_8b|Mux7~4_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~5_combout\ <= NOT \b2v_inst_alu_8b|Mux4~5_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~7_combout\ <= NOT \b2v_inst_alu_8b|F9~7_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux7~3_combout\ <= NOT \b2v_inst_alu_8b|Mux7~3_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux7~2_combout\ <= NOT \b2v_inst_alu_8b|Mux7~2_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux7~1_combout\ <= NOT \b2v_inst_alu_8b|Mux7~1_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux7~0_combout\ <= NOT \b2v_inst_alu_8b|Mux7~0_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~4_combout\ <= NOT \b2v_inst_alu_8b|Mux4~4_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~3_combout\ <= NOT \b2v_inst_alu_8b|Mux4~3_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~2_combout\ <= NOT \b2v_inst_alu_8b|Mux4~2_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~1_combout\ <= NOT \b2v_inst_alu_8b|Mux4~1_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux4~0_combout\ <= NOT \b2v_inst_alu_8b|Mux4~0_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux8~2_combout\ <= NOT \b2v_inst_alu_8b|Mux8~2_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux8~1_combout\ <= NOT \b2v_inst_alu_8b|Mux8~1_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~6_combout\ <= NOT \b2v_inst_alu_8b|F9~6_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~5_combout\ <= NOT \b2v_inst_alu_8b|F9~5_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~4_combout\ <= NOT \b2v_inst_alu_8b|F9~4_combout\;
\b2v_inst_alu_8b|ALT_INV_Mux8~0_combout\ <= NOT \b2v_inst_alu_8b|Mux8~0_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~3_combout\ <= NOT \b2v_inst_alu_8b|F9~3_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~2_combout\ <= NOT \b2v_inst_alu_8b|F9~2_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~1_combout\ <= NOT \b2v_inst_alu_8b|F9~1_combout\;
\b2v_inst_alu_8b|ALT_INV_F9~0_combout\ <= NOT \b2v_inst_alu_8b|F9~0_combout\;
\b2v_inst_ac_b|ALT_INV_B\(7) <= NOT \b2v_inst_ac_b|B\(7);
\b2v_inst_ac_b|ALT_INV_B\(6) <= NOT \b2v_inst_ac_b|B\(6);
\b2v_inst_ac_b|ALT_INV_B\(5) <= NOT \b2v_inst_ac_b|B\(5);
\b2v_inst_ac_b|ALT_INV_B\(4) <= NOT \b2v_inst_ac_b|B\(4);
\b2v_inst_ac_b|ALT_INV_B\(3) <= NOT \b2v_inst_ac_b|B\(3);
\b2v_inst_ac_b|ALT_INV_B\(2) <= NOT \b2v_inst_ac_b|B\(2);
\b2v_inst_ac_b|ALT_INV_B\(1) <= NOT \b2v_inst_ac_b|B\(1);
\ALT_INV_LOAD_B~input_o\ <= NOT \LOAD_B~input_o\;
\ALT_INV_DATA_IN[4]~input_o\ <= NOT \DATA_IN[4]~input_o\;
\ALT_INV_LOAD_A~input_o\ <= NOT \LOAD_A~input_o\;
\ALT_INV_DATA_IN[7]~input_o\ <= NOT \DATA_IN[7]~input_o\;

-- Location: IOOBUF_X52_Y0_N2
\CF~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_CF~0_combout\,
	devoe => ww_devoe,
	o => ww_CF);

-- Location: IOOBUF_X89_Y20_N45
\RQA1[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA1(0));

-- Location: IOOBUF_X89_Y15_N5
\RQA1[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA1(1));

-- Location: IOOBUF_X89_Y15_N22
\RQA1[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA1(2));

-- Location: IOOBUF_X89_Y8_N22
\RQA1[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA1(3));

-- Location: IOOBUF_X89_Y13_N22
\RQA1[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA1(4));

-- Location: IOOBUF_X89_Y13_N5
\RQA1[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA1(5));

-- Location: IOOBUF_X89_Y11_N45
\RQA1[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA1(6));

-- Location: IOOBUF_X89_Y9_N39
\RQA2[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux13~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA2(0));

-- Location: IOOBUF_X89_Y23_N5
\RQA2[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux12~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA2(1));

-- Location: IOOBUF_X89_Y9_N56
\RQA2[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux11~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA2(2));

-- Location: IOOBUF_X89_Y23_N22
\RQA2[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux10~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA2(3));

-- Location: IOOBUF_X89_Y25_N22
\RQA2[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux9~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA2(4));

-- Location: IOOBUF_X89_Y21_N56
\RQA2[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux8~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA2(5));

-- Location: IOOBUF_X89_Y20_N62
\RQA2[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_A|Mux7~0_combout\,
	devoe => ww_devoe,
	o => ww_RQA2(6));

-- Location: IOOBUF_X89_Y25_N56
\RQB1[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB1(0));

-- Location: IOOBUF_X89_Y20_N96
\RQB1[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB1(1));

-- Location: IOOBUF_X89_Y25_N39
\RQB1[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB1(2));

-- Location: IOOBUF_X89_Y20_N79
\RQB1[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB1(3));

-- Location: IOOBUF_X89_Y23_N56
\RQB1[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB1(4));

-- Location: IOOBUF_X89_Y23_N39
\RQB1[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB1(5));

-- Location: IOOBUF_X89_Y9_N22
\RQB1[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB1(6));

-- Location: IOOBUF_X89_Y9_N5
\RQB2[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux13~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB2(0));

-- Location: IOOBUF_X89_Y11_N62
\RQB2[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux12~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB2(1));

-- Location: IOOBUF_X89_Y21_N39
\RQB2[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux11~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB2(2));

-- Location: IOOBUF_X89_Y4_N62
\RQB2[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux10~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB2(3));

-- Location: IOOBUF_X89_Y4_N45
\RQB2[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux9~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB2(4));

-- Location: IOOBUF_X89_Y16_N22
\RQB2[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux8~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB2(5));

-- Location: IOOBUF_X89_Y16_N5
\RQB2[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7_B|Mux7~0_combout\,
	devoe => ww_devoe,
	o => ww_RQB2(6));

-- Location: IOOBUF_X89_Y4_N96
\RQF1[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF1(0));

-- Location: IOOBUF_X89_Y13_N39
\RQF1[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF1(1));

-- Location: IOOBUF_X89_Y13_N56
\RQF1[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF1(2));

-- Location: IOOBUF_X89_Y4_N79
\RQF1[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF1(3));

-- Location: IOOBUF_X89_Y11_N96
\RQF1[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF1(4));

-- Location: IOOBUF_X89_Y11_N79
\RQF1[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF1(5));

-- Location: IOOBUF_X89_Y8_N39
\RQF1[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF1(6));

-- Location: IOOBUF_X89_Y8_N56
\RQF2[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux13~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF2(0));

-- Location: IOOBUF_X89_Y15_N56
\RQF2[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux12~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF2(1));

-- Location: IOOBUF_X89_Y15_N39
\RQF2[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux11~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF2(2));

-- Location: IOOBUF_X89_Y16_N56
\RQF2[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux10~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF2(3));

-- Location: IOOBUF_X89_Y16_N39
\RQF2[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux9~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF2(4));

-- Location: IOOBUF_X89_Y6_N56
\RQF2[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux8~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF2(5));

-- Location: IOOBUF_X89_Y6_N39
\RQF2[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_seg7|Mux7~0_combout\,
	devoe => ww_devoe,
	o => ww_RQF2(6));

-- Location: IOOBUF_X84_Y0_N2
\S[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_ac_s|S\(0),
	devoe => ww_devoe,
	o => ww_S(0));

-- Location: IOOBUF_X89_Y6_N5
\S[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_ac_s|S\(1),
	devoe => ww_devoe,
	o => ww_S(1));

-- Location: IOOBUF_X89_Y8_N5
\S[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_ac_s|S\(2),
	devoe => ww_devoe,
	o => ww_S(2));

-- Location: IOOBUF_X89_Y6_N22
\S[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \b2v_inst_ac_s|S\(3),
	devoe => ww_devoe,
	o => ww_S(3));

-- Location: IOIBUF_X36_Y0_N1
\CLK~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLK,
	o => \CLK~input_o\);

-- Location: CLKCTRL_G6
\CLK~inputCLKENA0\ : cyclonev_clkena
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	disable_mode => "low",
	ena_register_mode => "always enabled",
	ena_register_power_up => "high",
	test_syn => "high")
-- pragma translate_on
PORT MAP (
	inclk => \CLK~input_o\,
	outclk => \CLK~inputCLKENA0_outclk\);

-- Location: IOIBUF_X12_Y0_N18
\DATA_IN[0]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_DATA_IN(0),
	o => \DATA_IN[0]~input_o\);

-- Location: IOIBUF_X40_Y0_N18
\LOAD_S~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_LOAD_S,
	o => \LOAD_S~input_o\);

-- Location: FF_X79_Y6_N53
\b2v_inst_ac_s|S[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[0]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_S~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_s|S\(0));

-- Location: IOIBUF_X2_Y0_N58
\ALU~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ALU,
	o => \ALU~input_o\);

-- Location: IOIBUF_X8_Y0_N35
\DATA_IN[2]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_DATA_IN(2),
	o => \DATA_IN[2]~input_o\);

-- Location: FF_X79_Y6_N59
\b2v_inst_ac_s|S[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[2]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_S~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_s|S\(2));

-- Location: IOIBUF_X4_Y0_N1
\DATA_IN[7]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_DATA_IN(7),
	o => \DATA_IN[7]~input_o\);

-- Location: IOIBUF_X40_Y0_N1
\LOAD_B~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_LOAD_B,
	o => \LOAD_B~input_o\);

-- Location: FF_X80_Y8_N32
\b2v_inst_ac_b|B[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[7]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_B~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_b|B\(7));

-- Location: LABCELL_X83_Y7_N30
\b2v_inst_ac_a|A[7]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_ac_a|A[7]~feeder_combout\ = ( \DATA_IN[7]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_DATA_IN[7]~input_o\,
	combout => \b2v_inst_ac_a|A[7]~feeder_combout\);

-- Location: IOIBUF_X36_Y0_N18
\LOAD_A~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_LOAD_A,
	o => \LOAD_A~input_o\);

-- Location: FF_X83_Y7_N32
\b2v_inst_ac_a|A[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	d => \b2v_inst_ac_a|A[7]~feeder_combout\,
	ena => \ALT_INV_LOAD_A~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_a|A\(7));

-- Location: IOIBUF_X4_Y0_N35
\DATA_IN[6]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_DATA_IN(6),
	o => \DATA_IN[6]~input_o\);

-- Location: FF_X83_Y5_N53
\b2v_inst_ac_a|A[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[6]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_A~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_a|A\(6));

-- Location: FF_X80_Y8_N29
\b2v_inst_ac_b|B[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[6]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_B~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_b|B\(6));

-- Location: IOIBUF_X16_Y0_N18
\DATA_IN[5]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_DATA_IN(5),
	o => \DATA_IN[5]~input_o\);

-- Location: FF_X80_Y8_N26
\b2v_inst_ac_b|B[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[5]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_B~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_b|B\(5));

-- Location: FF_X83_Y5_N17
\b2v_inst_ac_a|A[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[5]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_A~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_a|A\(5));

-- Location: IOIBUF_X2_Y0_N41
\DATA_IN[4]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_DATA_IN(4),
	o => \DATA_IN[4]~input_o\);

-- Location: FF_X80_Y8_N8
\b2v_inst_ac_b|B[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[4]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_B~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_b|B\(4));

-- Location: LABCELL_X83_Y7_N33
\b2v_inst_ac_a|A[4]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_ac_a|A[4]~feeder_combout\ = ( \DATA_IN[4]~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \ALT_INV_DATA_IN[4]~input_o\,
	combout => \b2v_inst_ac_a|A[4]~feeder_combout\);

-- Location: FF_X83_Y7_N35
\b2v_inst_ac_a|A[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	d => \b2v_inst_ac_a|A[4]~feeder_combout\,
	ena => \ALT_INV_LOAD_A~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_a|A\(4));

-- Location: IOIBUF_X4_Y0_N52
\DATA_IN[3]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_DATA_IN(3),
	o => \DATA_IN[3]~input_o\);

-- Location: FF_X80_Y8_N23
\b2v_inst_ac_b|B[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[3]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_B~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_b|B\(3));

-- Location: FF_X83_Y7_N47
\b2v_inst_ac_a|A[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[3]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_A~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_a|A\(3));

-- Location: FF_X83_Y7_N44
\b2v_inst_ac_a|A[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[2]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_A~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_a|A\(2));

-- Location: FF_X80_Y8_N47
\b2v_inst_ac_b|B[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[2]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_B~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_b|B\(2));

-- Location: IOIBUF_X16_Y0_N1
\DATA_IN[1]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_DATA_IN(1),
	o => \DATA_IN[1]~input_o\);

-- Location: FF_X83_Y7_N41
\b2v_inst_ac_a|A[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[1]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_A~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_a|A\(1));

-- Location: FF_X83_Y7_N5
\b2v_inst_ac_b|B[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[1]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_B~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_b|B\(1));

-- Location: FF_X80_Y8_N11
\b2v_inst_ac_b|B[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[0]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_B~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_b|B\(0));

-- Location: FF_X83_Y7_N29
\b2v_inst_ac_a|A[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[0]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_A~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_a|A\(0));

-- Location: LABCELL_X83_Y7_N0
\b2v_inst_alu_8b|Add4~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add4~5_sumout\ = SUM(( \b2v_inst_ac_b|B\(0) ) + ( \b2v_inst_ac_a|A\(0) ) + ( !VCC ))
-- \b2v_inst_alu_8b|Add4~6\ = CARRY(( \b2v_inst_ac_b|B\(0) ) + ( \b2v_inst_ac_a|A\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_ac_a|ALT_INV_A\(0),
	cin => GND,
	sumout => \b2v_inst_alu_8b|Add4~5_sumout\,
	cout => \b2v_inst_alu_8b|Add4~6\);

-- Location: LABCELL_X83_Y7_N3
\b2v_inst_alu_8b|Add4~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add4~9_sumout\ = SUM(( \b2v_inst_ac_b|B\(1) ) + ( \b2v_inst_ac_a|A\(1) ) + ( \b2v_inst_alu_8b|Add4~6\ ))
-- \b2v_inst_alu_8b|Add4~10\ = CARRY(( \b2v_inst_ac_b|B\(1) ) + ( \b2v_inst_ac_a|A\(1) ) + ( \b2v_inst_alu_8b|Add4~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_a|ALT_INV_A\(1),
	datad => \b2v_inst_ac_b|ALT_INV_B\(1),
	cin => \b2v_inst_alu_8b|Add4~6\,
	sumout => \b2v_inst_alu_8b|Add4~9_sumout\,
	cout => \b2v_inst_alu_8b|Add4~10\);

-- Location: LABCELL_X83_Y7_N6
\b2v_inst_alu_8b|Add4~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add4~13_sumout\ = SUM(( \b2v_inst_ac_b|B\(2) ) + ( \b2v_inst_ac_a|A\(2) ) + ( \b2v_inst_alu_8b|Add4~10\ ))
-- \b2v_inst_alu_8b|Add4~14\ = CARRY(( \b2v_inst_ac_b|B\(2) ) + ( \b2v_inst_ac_a|A\(2) ) + ( \b2v_inst_alu_8b|Add4~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(2),
	datac => \b2v_inst_ac_b|ALT_INV_B\(2),
	cin => \b2v_inst_alu_8b|Add4~10\,
	sumout => \b2v_inst_alu_8b|Add4~13_sumout\,
	cout => \b2v_inst_alu_8b|Add4~14\);

-- Location: LABCELL_X83_Y7_N9
\b2v_inst_alu_8b|Add4~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add4~17_sumout\ = SUM(( \b2v_inst_ac_b|B\(3) ) + ( \b2v_inst_ac_a|A\(3) ) + ( \b2v_inst_alu_8b|Add4~14\ ))
-- \b2v_inst_alu_8b|Add4~18\ = CARRY(( \b2v_inst_ac_b|B\(3) ) + ( \b2v_inst_ac_a|A\(3) ) + ( \b2v_inst_alu_8b|Add4~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(3),
	datac => \b2v_inst_ac_a|ALT_INV_A\(3),
	cin => \b2v_inst_alu_8b|Add4~14\,
	sumout => \b2v_inst_alu_8b|Add4~17_sumout\,
	cout => \b2v_inst_alu_8b|Add4~18\);

-- Location: LABCELL_X83_Y7_N12
\b2v_inst_alu_8b|Add4~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add4~21_sumout\ = SUM(( \b2v_inst_ac_b|B\(4) ) + ( \b2v_inst_ac_a|A\(4) ) + ( \b2v_inst_alu_8b|Add4~18\ ))
-- \b2v_inst_alu_8b|Add4~22\ = CARRY(( \b2v_inst_ac_b|B\(4) ) + ( \b2v_inst_ac_a|A\(4) ) + ( \b2v_inst_alu_8b|Add4~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111110000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_b|ALT_INV_B\(4),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(4),
	cin => \b2v_inst_alu_8b|Add4~18\,
	sumout => \b2v_inst_alu_8b|Add4~21_sumout\,
	cout => \b2v_inst_alu_8b|Add4~22\);

-- Location: LABCELL_X83_Y7_N15
\b2v_inst_alu_8b|Add4~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add4~25_sumout\ = SUM(( \b2v_inst_ac_b|B\(5) ) + ( \b2v_inst_ac_a|A\(5) ) + ( \b2v_inst_alu_8b|Add4~22\ ))
-- \b2v_inst_alu_8b|Add4~26\ = CARRY(( \b2v_inst_ac_b|B\(5) ) + ( \b2v_inst_ac_a|A\(5) ) + ( \b2v_inst_alu_8b|Add4~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(5),
	datac => \b2v_inst_ac_a|ALT_INV_A\(5),
	cin => \b2v_inst_alu_8b|Add4~22\,
	sumout => \b2v_inst_alu_8b|Add4~25_sumout\,
	cout => \b2v_inst_alu_8b|Add4~26\);

-- Location: LABCELL_X83_Y7_N18
\b2v_inst_alu_8b|Add4~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add4~29_sumout\ = SUM(( \b2v_inst_ac_b|B\(6) ) + ( \b2v_inst_ac_a|A\(6) ) + ( \b2v_inst_alu_8b|Add4~26\ ))
-- \b2v_inst_alu_8b|Add4~30\ = CARRY(( \b2v_inst_ac_b|B\(6) ) + ( \b2v_inst_ac_a|A\(6) ) + ( \b2v_inst_alu_8b|Add4~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(6),
	datac => \b2v_inst_ac_b|ALT_INV_B\(6),
	cin => \b2v_inst_alu_8b|Add4~26\,
	sumout => \b2v_inst_alu_8b|Add4~29_sumout\,
	cout => \b2v_inst_alu_8b|Add4~30\);

-- Location: LABCELL_X83_Y7_N21
\b2v_inst_alu_8b|Add4~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add4~33_sumout\ = SUM(( \b2v_inst_ac_b|B\(7) ) + ( \b2v_inst_ac_a|A\(7) ) + ( \b2v_inst_alu_8b|Add4~30\ ))
-- \b2v_inst_alu_8b|Add4~34\ = CARRY(( \b2v_inst_ac_b|B\(7) ) + ( \b2v_inst_ac_a|A\(7) ) + ( \b2v_inst_alu_8b|Add4~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(7),
	datac => \b2v_inst_ac_a|ALT_INV_A\(7),
	cin => \b2v_inst_alu_8b|Add4~30\,
	sumout => \b2v_inst_alu_8b|Add4~33_sumout\,
	cout => \b2v_inst_alu_8b|Add4~34\);

-- Location: LABCELL_X83_Y7_N24
\b2v_inst_alu_8b|Add4~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add4~1_sumout\ = SUM(( GND ) + ( GND ) + ( \b2v_inst_alu_8b|Add4~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	cin => \b2v_inst_alu_8b|Add4~34\,
	sumout => \b2v_inst_alu_8b|Add4~1_sumout\);

-- Location: LABCELL_X80_Y6_N30
\b2v_inst_alu_8b|Add6~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add6~5_sumout\ = SUM(( (\b2v_inst_ac_b|B\(0)) # (\b2v_inst_ac_a|A\(0)) ) + ( \b2v_inst_ac_a|A\(0) ) + ( !VCC ))
-- \b2v_inst_alu_8b|Add6~6\ = CARRY(( (\b2v_inst_ac_b|B\(0)) # (\b2v_inst_ac_a|A\(0)) ) + ( \b2v_inst_ac_a|A\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_a|ALT_INV_A\(0),
	datad => \b2v_inst_ac_b|ALT_INV_B\(0),
	cin => GND,
	sumout => \b2v_inst_alu_8b|Add6~5_sumout\,
	cout => \b2v_inst_alu_8b|Add6~6\);

-- Location: LABCELL_X80_Y6_N33
\b2v_inst_alu_8b|Add6~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add6~9_sumout\ = SUM(( (\b2v_inst_ac_a|A\(1)) # (\b2v_inst_ac_b|B\(1)) ) + ( \b2v_inst_ac_a|A\(1) ) + ( \b2v_inst_alu_8b|Add6~6\ ))
-- \b2v_inst_alu_8b|Add6~10\ = CARRY(( (\b2v_inst_ac_a|A\(1)) # (\b2v_inst_ac_b|B\(1)) ) + ( \b2v_inst_ac_a|A\(1) ) + ( \b2v_inst_alu_8b|Add6~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000101111101011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(1),
	datac => \b2v_inst_ac_a|ALT_INV_A\(1),
	cin => \b2v_inst_alu_8b|Add6~6\,
	sumout => \b2v_inst_alu_8b|Add6~9_sumout\,
	cout => \b2v_inst_alu_8b|Add6~10\);

-- Location: LABCELL_X80_Y6_N36
\b2v_inst_alu_8b|Add6~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add6~13_sumout\ = SUM(( \b2v_inst_ac_a|A\(2) ) + ( (\b2v_inst_ac_b|B\(2)) # (\b2v_inst_ac_a|A\(2)) ) + ( \b2v_inst_alu_8b|Add6~10\ ))
-- \b2v_inst_alu_8b|Add6~14\ = CARRY(( \b2v_inst_ac_a|A\(2) ) + ( (\b2v_inst_ac_b|B\(2)) # (\b2v_inst_ac_a|A\(2)) ) + ( \b2v_inst_alu_8b|Add6~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_a|ALT_INV_A\(2),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(2),
	cin => \b2v_inst_alu_8b|Add6~10\,
	sumout => \b2v_inst_alu_8b|Add6~13_sumout\,
	cout => \b2v_inst_alu_8b|Add6~14\);

-- Location: LABCELL_X80_Y6_N39
\b2v_inst_alu_8b|Add6~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add6~17_sumout\ = SUM(( (\b2v_inst_ac_b|B\(3)) # (\b2v_inst_ac_a|A\(3)) ) + ( \b2v_inst_ac_a|A\(3) ) + ( \b2v_inst_alu_8b|Add6~14\ ))
-- \b2v_inst_alu_8b|Add6~18\ = CARRY(( (\b2v_inst_ac_b|B\(3)) # (\b2v_inst_ac_a|A\(3)) ) + ( \b2v_inst_ac_a|A\(3) ) + ( \b2v_inst_alu_8b|Add6~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000111011101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(3),
	datab => \b2v_inst_ac_b|ALT_INV_B\(3),
	cin => \b2v_inst_alu_8b|Add6~14\,
	sumout => \b2v_inst_alu_8b|Add6~17_sumout\,
	cout => \b2v_inst_alu_8b|Add6~18\);

-- Location: LABCELL_X80_Y6_N42
\b2v_inst_alu_8b|Add6~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add6~21_sumout\ = SUM(( (\b2v_inst_ac_a|A\(4)) # (\b2v_inst_ac_b|B\(4)) ) + ( \b2v_inst_ac_a|A\(4) ) + ( \b2v_inst_alu_8b|Add6~18\ ))
-- \b2v_inst_alu_8b|Add6~22\ = CARRY(( (\b2v_inst_ac_a|A\(4)) # (\b2v_inst_ac_b|B\(4)) ) + ( \b2v_inst_ac_a|A\(4) ) + ( \b2v_inst_alu_8b|Add6~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(4),
	datac => \b2v_inst_ac_a|ALT_INV_A\(4),
	cin => \b2v_inst_alu_8b|Add6~18\,
	sumout => \b2v_inst_alu_8b|Add6~21_sumout\,
	cout => \b2v_inst_alu_8b|Add6~22\);

-- Location: LABCELL_X80_Y6_N45
\b2v_inst_alu_8b|Add6~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add6~25_sumout\ = SUM(( (\b2v_inst_ac_b|B\(5)) # (\b2v_inst_ac_a|A\(5)) ) + ( \b2v_inst_ac_a|A\(5) ) + ( \b2v_inst_alu_8b|Add6~22\ ))
-- \b2v_inst_alu_8b|Add6~26\ = CARRY(( (\b2v_inst_ac_b|B\(5)) # (\b2v_inst_ac_a|A\(5)) ) + ( \b2v_inst_ac_a|A\(5) ) + ( \b2v_inst_alu_8b|Add6~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000101111101011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(5),
	datac => \b2v_inst_ac_b|ALT_INV_B\(5),
	cin => \b2v_inst_alu_8b|Add6~22\,
	sumout => \b2v_inst_alu_8b|Add6~25_sumout\,
	cout => \b2v_inst_alu_8b|Add6~26\);

-- Location: LABCELL_X80_Y6_N48
\b2v_inst_alu_8b|Add6~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add6~29_sumout\ = SUM(( (\b2v_inst_ac_b|B\(6)) # (\b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_ac_a|A\(6) ) + ( \b2v_inst_alu_8b|Add6~26\ ))
-- \b2v_inst_alu_8b|Add6~30\ = CARRY(( (\b2v_inst_ac_b|B\(6)) # (\b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_ac_a|A\(6) ) + ( \b2v_inst_alu_8b|Add6~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000000011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(6),
	datac => \b2v_inst_ac_b|ALT_INV_B\(6),
	cin => \b2v_inst_alu_8b|Add6~26\,
	sumout => \b2v_inst_alu_8b|Add6~29_sumout\,
	cout => \b2v_inst_alu_8b|Add6~30\);

-- Location: LABCELL_X80_Y6_N51
\b2v_inst_alu_8b|Add6~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add6~33_sumout\ = SUM(( \b2v_inst_ac_a|A\(7) ) + ( (\b2v_inst_ac_b|B\(7)) # (\b2v_inst_ac_a|A\(7)) ) + ( \b2v_inst_alu_8b|Add6~30\ ))
-- \b2v_inst_alu_8b|Add6~34\ = CARRY(( \b2v_inst_ac_a|A\(7) ) + ( (\b2v_inst_ac_b|B\(7)) # (\b2v_inst_ac_a|A\(7)) ) + ( \b2v_inst_alu_8b|Add6~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_a|ALT_INV_A\(7),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(7),
	cin => \b2v_inst_alu_8b|Add6~30\,
	sumout => \b2v_inst_alu_8b|Add6~33_sumout\,
	cout => \b2v_inst_alu_8b|Add6~34\);

-- Location: LABCELL_X80_Y6_N54
\b2v_inst_alu_8b|Add6~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add6~1_sumout\ = SUM(( GND ) + ( GND ) + ( \b2v_inst_alu_8b|Add6~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	cin => \b2v_inst_alu_8b|Add6~34\,
	sumout => \b2v_inst_alu_8b|Add6~1_sumout\);

-- Location: LABCELL_X80_Y7_N0
\b2v_inst_alu_8b|Add3~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add3~5_sumout\ = SUM(( (\b2v_inst_ac_b|B\(0) & \b2v_inst_ac_a|A\(0)) ) + ( \b2v_inst_ac_a|A\(0) ) + ( !VCC ))
-- \b2v_inst_alu_8b|Add3~6\ = CARRY(( (\b2v_inst_ac_b|B\(0) & \b2v_inst_ac_a|A\(0)) ) + ( \b2v_inst_ac_a|A\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_ac_a|ALT_INV_A\(0),
	cin => GND,
	sumout => \b2v_inst_alu_8b|Add3~5_sumout\,
	cout => \b2v_inst_alu_8b|Add3~6\);

-- Location: LABCELL_X80_Y7_N3
\b2v_inst_alu_8b|Add3~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add3~9_sumout\ = SUM(( (\b2v_inst_ac_b|B\(1) & \b2v_inst_ac_a|A\(1)) ) + ( \b2v_inst_ac_a|A\(1) ) + ( \b2v_inst_alu_8b|Add3~6\ ))
-- \b2v_inst_alu_8b|Add3~10\ = CARRY(( (\b2v_inst_ac_b|B\(1) & \b2v_inst_ac_a|A\(1)) ) + ( \b2v_inst_ac_a|A\(1) ) + ( \b2v_inst_alu_8b|Add3~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(1),
	datac => \b2v_inst_ac_a|ALT_INV_A\(1),
	cin => \b2v_inst_alu_8b|Add3~6\,
	sumout => \b2v_inst_alu_8b|Add3~9_sumout\,
	cout => \b2v_inst_alu_8b|Add3~10\);

-- Location: LABCELL_X80_Y7_N6
\b2v_inst_alu_8b|Add3~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add3~13_sumout\ = SUM(( (\b2v_inst_ac_a|A\(2) & \b2v_inst_ac_b|B\(2)) ) + ( \b2v_inst_ac_a|A\(2) ) + ( \b2v_inst_alu_8b|Add3~10\ ))
-- \b2v_inst_alu_8b|Add3~14\ = CARRY(( (\b2v_inst_ac_a|A\(2) & \b2v_inst_ac_b|B\(2)) ) + ( \b2v_inst_ac_a|A\(2) ) + ( \b2v_inst_alu_8b|Add3~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000000000001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_a|ALT_INV_A\(2),
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	cin => \b2v_inst_alu_8b|Add3~10\,
	sumout => \b2v_inst_alu_8b|Add3~13_sumout\,
	cout => \b2v_inst_alu_8b|Add3~14\);

-- Location: LABCELL_X80_Y7_N9
\b2v_inst_alu_8b|Add3~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add3~17_sumout\ = SUM(( \b2v_inst_ac_a|A\(3) ) + ( (\b2v_inst_ac_a|A\(3) & \b2v_inst_ac_b|B\(3)) ) + ( \b2v_inst_alu_8b|Add3~14\ ))
-- \b2v_inst_alu_8b|Add3~18\ = CARRY(( \b2v_inst_ac_a|A\(3) ) + ( (\b2v_inst_ac_a|A\(3) & \b2v_inst_ac_b|B\(3)) ) + ( \b2v_inst_alu_8b|Add3~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111010101000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(3),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(3),
	cin => \b2v_inst_alu_8b|Add3~14\,
	sumout => \b2v_inst_alu_8b|Add3~17_sumout\,
	cout => \b2v_inst_alu_8b|Add3~18\);

-- Location: LABCELL_X80_Y7_N12
\b2v_inst_alu_8b|Add3~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add3~21_sumout\ = SUM(( (\b2v_inst_ac_a|A\(4) & \b2v_inst_ac_b|B\(4)) ) + ( \b2v_inst_ac_a|A\(4) ) + ( \b2v_inst_alu_8b|Add3~18\ ))
-- \b2v_inst_alu_8b|Add3~22\ = CARRY(( (\b2v_inst_ac_a|A\(4) & \b2v_inst_ac_b|B\(4)) ) + ( \b2v_inst_ac_a|A\(4) ) + ( \b2v_inst_alu_8b|Add3~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000000000000000110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(4),
	datad => \b2v_inst_ac_b|ALT_INV_B\(4),
	cin => \b2v_inst_alu_8b|Add3~18\,
	sumout => \b2v_inst_alu_8b|Add3~21_sumout\,
	cout => \b2v_inst_alu_8b|Add3~22\);

-- Location: LABCELL_X80_Y7_N15
\b2v_inst_alu_8b|Add3~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add3~25_sumout\ = SUM(( (\b2v_inst_ac_a|A\(5) & \b2v_inst_ac_b|B\(5)) ) + ( \b2v_inst_ac_a|A\(5) ) + ( \b2v_inst_alu_8b|Add3~22\ ))
-- \b2v_inst_alu_8b|Add3~26\ = CARRY(( (\b2v_inst_ac_a|A\(5) & \b2v_inst_ac_b|B\(5)) ) + ( \b2v_inst_ac_a|A\(5) ) + ( \b2v_inst_alu_8b|Add3~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(5),
	datac => \b2v_inst_ac_b|ALT_INV_B\(5),
	cin => \b2v_inst_alu_8b|Add3~22\,
	sumout => \b2v_inst_alu_8b|Add3~25_sumout\,
	cout => \b2v_inst_alu_8b|Add3~26\);

-- Location: LABCELL_X80_Y7_N18
\b2v_inst_alu_8b|Add3~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add3~29_sumout\ = SUM(( (\b2v_inst_ac_b|B\(6) & \b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_ac_a|A\(6) ) + ( \b2v_inst_alu_8b|Add3~26\ ))
-- \b2v_inst_alu_8b|Add3~30\ = CARRY(( (\b2v_inst_ac_b|B\(6) & \b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_ac_a|A\(6) ) + ( \b2v_inst_alu_8b|Add3~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(6),
	datac => \b2v_inst_ac_a|ALT_INV_A\(6),
	cin => \b2v_inst_alu_8b|Add3~26\,
	sumout => \b2v_inst_alu_8b|Add3~29_sumout\,
	cout => \b2v_inst_alu_8b|Add3~30\);

-- Location: LABCELL_X80_Y7_N21
\b2v_inst_alu_8b|Add3~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add3~33_sumout\ = SUM(( (\b2v_inst_ac_b|B\(7) & \b2v_inst_ac_a|A\(7)) ) + ( \b2v_inst_ac_a|A\(7) ) + ( \b2v_inst_alu_8b|Add3~30\ ))
-- \b2v_inst_alu_8b|Add3~34\ = CARRY(( (\b2v_inst_ac_b|B\(7) & \b2v_inst_ac_a|A\(7)) ) + ( \b2v_inst_ac_a|A\(7) ) + ( \b2v_inst_alu_8b|Add3~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(7),
	datac => \b2v_inst_ac_a|ALT_INV_A\(7),
	cin => \b2v_inst_alu_8b|Add3~30\,
	sumout => \b2v_inst_alu_8b|Add3~33_sumout\,
	cout => \b2v_inst_alu_8b|Add3~34\);

-- Location: LABCELL_X80_Y7_N24
\b2v_inst_alu_8b|Add3~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add3~1_sumout\ = SUM(( GND ) + ( GND ) + ( \b2v_inst_alu_8b|Add3~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	cin => \b2v_inst_alu_8b|Add3~34\,
	sumout => \b2v_inst_alu_8b|Add3~1_sumout\);

-- Location: LABCELL_X79_Y6_N42
\b2v_inst_alu_8b|Mux0~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux0~3_combout\ = ( !\b2v_inst_ac_s|S\(0) & ( (\ALU~input_o\ & ((!\b2v_inst_ac_s|S\(2) & (\b2v_inst_alu_8b|Add3~1_sumout\)) # (\b2v_inst_ac_s|S\(2) & (((\b2v_inst_ac_a|A\(7))))))) ) ) # ( \b2v_inst_ac_s|S\(0) & ( (!\ALU~input_o\) # 
-- ((!\b2v_inst_ac_s|S\(2) & (\b2v_inst_alu_8b|Add4~1_sumout\)) # (\b2v_inst_ac_s|S\(2) & (((\b2v_inst_alu_8b|Add6~1_sumout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0000010000000100101011101011111100010101000101011010111010111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(2),
	datac => \b2v_inst_alu_8b|ALT_INV_Add4~1_sumout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add6~1_sumout\,
	datae => \b2v_inst_ac_s|ALT_INV_S\(0),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(7),
	datag => \b2v_inst_alu_8b|ALT_INV_Add3~1_sumout\,
	combout => \b2v_inst_alu_8b|Mux0~3_combout\);

-- Location: MLABCELL_X78_Y5_N30
\b2v_inst_alu_8b|Add2~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add2~5_sumout\ = SUM(( !\b2v_inst_ac_b|B\(0) $ (!\b2v_inst_ac_a|A\(0)) ) + ( !VCC ) + ( !VCC ))
-- \b2v_inst_alu_8b|Add2~6\ = CARRY(( !\b2v_inst_ac_b|B\(0) $ (!\b2v_inst_ac_a|A\(0)) ) + ( !VCC ) + ( !VCC ))
-- \b2v_inst_alu_8b|Add2~7\ = SHARE((!\b2v_inst_ac_b|B\(0)) # (\b2v_inst_ac_a|A\(0)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011111100111100000000000000000011110000111100",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_ac_a|ALT_INV_A\(0),
	cin => GND,
	sharein => GND,
	sumout => \b2v_inst_alu_8b|Add2~5_sumout\,
	cout => \b2v_inst_alu_8b|Add2~6\,
	shareout => \b2v_inst_alu_8b|Add2~7\);

-- Location: MLABCELL_X78_Y5_N33
\b2v_inst_alu_8b|Add2~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add2~9_sumout\ = SUM(( !\b2v_inst_ac_a|A\(1) $ (\b2v_inst_ac_b|B\(1)) ) + ( \b2v_inst_alu_8b|Add2~7\ ) + ( \b2v_inst_alu_8b|Add2~6\ ))
-- \b2v_inst_alu_8b|Add2~10\ = CARRY(( !\b2v_inst_ac_a|A\(1) $ (\b2v_inst_ac_b|B\(1)) ) + ( \b2v_inst_alu_8b|Add2~7\ ) + ( \b2v_inst_alu_8b|Add2~6\ ))
-- \b2v_inst_alu_8b|Add2~11\ = SHARE((\b2v_inst_ac_a|A\(1) & !\b2v_inst_ac_b|B\(1)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000001010010110100101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(1),
	datac => \b2v_inst_ac_b|ALT_INV_B\(1),
	cin => \b2v_inst_alu_8b|Add2~6\,
	sharein => \b2v_inst_alu_8b|Add2~7\,
	sumout => \b2v_inst_alu_8b|Add2~9_sumout\,
	cout => \b2v_inst_alu_8b|Add2~10\,
	shareout => \b2v_inst_alu_8b|Add2~11\);

-- Location: MLABCELL_X78_Y5_N36
\b2v_inst_alu_8b|Add2~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add2~13_sumout\ = SUM(( !\b2v_inst_ac_b|B\(2) $ (\b2v_inst_ac_a|A\(2)) ) + ( \b2v_inst_alu_8b|Add2~11\ ) + ( \b2v_inst_alu_8b|Add2~10\ ))
-- \b2v_inst_alu_8b|Add2~14\ = CARRY(( !\b2v_inst_ac_b|B\(2) $ (\b2v_inst_ac_a|A\(2)) ) + ( \b2v_inst_alu_8b|Add2~11\ ) + ( \b2v_inst_alu_8b|Add2~10\ ))
-- \b2v_inst_alu_8b|Add2~15\ = SHARE((!\b2v_inst_ac_b|B\(2) & \b2v_inst_ac_a|A\(2)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000001100001111000011",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(2),
	datac => \b2v_inst_ac_a|ALT_INV_A\(2),
	cin => \b2v_inst_alu_8b|Add2~10\,
	sharein => \b2v_inst_alu_8b|Add2~11\,
	sumout => \b2v_inst_alu_8b|Add2~13_sumout\,
	cout => \b2v_inst_alu_8b|Add2~14\,
	shareout => \b2v_inst_alu_8b|Add2~15\);

-- Location: MLABCELL_X78_Y5_N39
\b2v_inst_alu_8b|Add2~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add2~17_sumout\ = SUM(( !\b2v_inst_ac_a|A\(3) $ (\b2v_inst_ac_b|B\(3)) ) + ( \b2v_inst_alu_8b|Add2~15\ ) + ( \b2v_inst_alu_8b|Add2~14\ ))
-- \b2v_inst_alu_8b|Add2~18\ = CARRY(( !\b2v_inst_ac_a|A\(3) $ (\b2v_inst_ac_b|B\(3)) ) + ( \b2v_inst_alu_8b|Add2~15\ ) + ( \b2v_inst_alu_8b|Add2~14\ ))
-- \b2v_inst_alu_8b|Add2~19\ = SHARE((\b2v_inst_ac_a|A\(3) & !\b2v_inst_ac_b|B\(3)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000001010010110100101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(3),
	datac => \b2v_inst_ac_b|ALT_INV_B\(3),
	cin => \b2v_inst_alu_8b|Add2~14\,
	sharein => \b2v_inst_alu_8b|Add2~15\,
	sumout => \b2v_inst_alu_8b|Add2~17_sumout\,
	cout => \b2v_inst_alu_8b|Add2~18\,
	shareout => \b2v_inst_alu_8b|Add2~19\);

-- Location: MLABCELL_X78_Y5_N42
\b2v_inst_alu_8b|Add2~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add2~21_sumout\ = SUM(( !\b2v_inst_ac_b|B\(4) $ (\b2v_inst_ac_a|A\(4)) ) + ( \b2v_inst_alu_8b|Add2~19\ ) + ( \b2v_inst_alu_8b|Add2~18\ ))
-- \b2v_inst_alu_8b|Add2~22\ = CARRY(( !\b2v_inst_ac_b|B\(4) $ (\b2v_inst_ac_a|A\(4)) ) + ( \b2v_inst_alu_8b|Add2~19\ ) + ( \b2v_inst_alu_8b|Add2~18\ ))
-- \b2v_inst_alu_8b|Add2~23\ = SHARE((!\b2v_inst_ac_b|B\(4) & \b2v_inst_ac_a|A\(4)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000001010010110100101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(4),
	datac => \b2v_inst_ac_a|ALT_INV_A\(4),
	cin => \b2v_inst_alu_8b|Add2~18\,
	sharein => \b2v_inst_alu_8b|Add2~19\,
	sumout => \b2v_inst_alu_8b|Add2~21_sumout\,
	cout => \b2v_inst_alu_8b|Add2~22\,
	shareout => \b2v_inst_alu_8b|Add2~23\);

-- Location: MLABCELL_X78_Y5_N45
\b2v_inst_alu_8b|Add2~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add2~25_sumout\ = SUM(( !\b2v_inst_ac_b|B\(5) $ (\b2v_inst_ac_a|A\(5)) ) + ( \b2v_inst_alu_8b|Add2~23\ ) + ( \b2v_inst_alu_8b|Add2~22\ ))
-- \b2v_inst_alu_8b|Add2~26\ = CARRY(( !\b2v_inst_ac_b|B\(5) $ (\b2v_inst_ac_a|A\(5)) ) + ( \b2v_inst_alu_8b|Add2~23\ ) + ( \b2v_inst_alu_8b|Add2~22\ ))
-- \b2v_inst_alu_8b|Add2~27\ = SHARE((!\b2v_inst_ac_b|B\(5) & \b2v_inst_ac_a|A\(5)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000001111000000000000000000001111000000001111",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_b|ALT_INV_B\(5),
	datad => \b2v_inst_ac_a|ALT_INV_A\(5),
	cin => \b2v_inst_alu_8b|Add2~22\,
	sharein => \b2v_inst_alu_8b|Add2~23\,
	sumout => \b2v_inst_alu_8b|Add2~25_sumout\,
	cout => \b2v_inst_alu_8b|Add2~26\,
	shareout => \b2v_inst_alu_8b|Add2~27\);

-- Location: MLABCELL_X78_Y5_N48
\b2v_inst_alu_8b|Add2~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add2~29_sumout\ = SUM(( !\b2v_inst_ac_a|A\(6) $ (\b2v_inst_ac_b|B\(6)) ) + ( \b2v_inst_alu_8b|Add2~27\ ) + ( \b2v_inst_alu_8b|Add2~26\ ))
-- \b2v_inst_alu_8b|Add2~30\ = CARRY(( !\b2v_inst_ac_a|A\(6) $ (\b2v_inst_ac_b|B\(6)) ) + ( \b2v_inst_alu_8b|Add2~27\ ) + ( \b2v_inst_alu_8b|Add2~26\ ))
-- \b2v_inst_alu_8b|Add2~31\ = SHARE((\b2v_inst_ac_a|A\(6) & !\b2v_inst_ac_b|B\(6)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100110000000000000000000000001100110000110011",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(6),
	datad => \b2v_inst_ac_b|ALT_INV_B\(6),
	cin => \b2v_inst_alu_8b|Add2~26\,
	sharein => \b2v_inst_alu_8b|Add2~27\,
	sumout => \b2v_inst_alu_8b|Add2~29_sumout\,
	cout => \b2v_inst_alu_8b|Add2~30\,
	shareout => \b2v_inst_alu_8b|Add2~31\);

-- Location: MLABCELL_X78_Y5_N51
\b2v_inst_alu_8b|Add2~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add2~33_sumout\ = SUM(( !\b2v_inst_ac_a|A\(7) $ (\b2v_inst_ac_b|B\(7)) ) + ( \b2v_inst_alu_8b|Add2~31\ ) + ( \b2v_inst_alu_8b|Add2~30\ ))
-- \b2v_inst_alu_8b|Add2~34\ = CARRY(( !\b2v_inst_ac_a|A\(7) $ (\b2v_inst_ac_b|B\(7)) ) + ( \b2v_inst_alu_8b|Add2~31\ ) + ( \b2v_inst_alu_8b|Add2~30\ ))
-- \b2v_inst_alu_8b|Add2~35\ = SHARE((\b2v_inst_ac_a|A\(7) & !\b2v_inst_ac_b|B\(7)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000001010010110100101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(7),
	datac => \b2v_inst_ac_b|ALT_INV_B\(7),
	cin => \b2v_inst_alu_8b|Add2~30\,
	sharein => \b2v_inst_alu_8b|Add2~31\,
	sumout => \b2v_inst_alu_8b|Add2~33_sumout\,
	cout => \b2v_inst_alu_8b|Add2~34\,
	shareout => \b2v_inst_alu_8b|Add2~35\);

-- Location: MLABCELL_X78_Y5_N54
\b2v_inst_alu_8b|Add2~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add2~1_sumout\ = SUM(( VCC ) + ( \b2v_inst_alu_8b|Add2~35\ ) + ( \b2v_inst_alu_8b|Add2~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000001111111111111111",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	cin => \b2v_inst_alu_8b|Add2~34\,
	sharein => \b2v_inst_alu_8b|Add2~35\,
	sumout => \b2v_inst_alu_8b|Add2~1_sumout\);

-- Location: LABCELL_X79_Y6_N36
\b2v_inst_alu_8b|Mux0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux0~1_combout\ = ( \b2v_inst_alu_8b|Add2~1_sumout\ & ( \b2v_inst_ac_s|S\(0) & ( (\b2v_inst_ac_s|S\(2) & \ALU~input_o\) ) ) ) # ( !\b2v_inst_alu_8b|Add2~1_sumout\ & ( \b2v_inst_ac_s|S\(0) & ( (\b2v_inst_ac_s|S\(2) & \ALU~input_o\) ) ) ) # 
-- ( \b2v_inst_alu_8b|Add2~1_sumout\ & ( !\b2v_inst_ac_s|S\(0) & ( \ALU~input_o\ ) ) ) # ( !\b2v_inst_alu_8b|Add2~1_sumout\ & ( !\b2v_inst_ac_s|S\(0) & ( (!\b2v_inst_ac_s|S\(2) & \ALU~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000001100000011110000111100000011000000110000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_s|ALT_INV_S\(2),
	datac => \ALT_INV_ALU~input_o\,
	datae => \b2v_inst_alu_8b|ALT_INV_Add2~1_sumout\,
	dataf => \b2v_inst_ac_s|ALT_INV_S\(0),
	combout => \b2v_inst_alu_8b|Mux0~1_combout\);

-- Location: FF_X79_Y6_N17
\b2v_inst_ac_s|S[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[3]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_S~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_s|S\(3));

-- Location: FF_X79_Y6_N56
\b2v_inst_ac_s|S[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLK~inputCLKENA0_outclk\,
	asdata => \DATA_IN[1]~input_o\,
	sload => VCC,
	ena => \ALT_INV_LOAD_S~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \b2v_inst_ac_s|S\(1));

-- Location: LABCELL_X81_Y6_N30
\b2v_inst_alu_8b|Add5~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add5~5_sumout\ = SUM(( (\b2v_inst_ac_b|B\(0) & \b2v_inst_ac_a|A\(0)) ) + ( (!\b2v_inst_ac_b|B\(0)) # (\b2v_inst_ac_a|A\(0)) ) + ( !VCC ))
-- \b2v_inst_alu_8b|Add5~6\ = CARRY(( (\b2v_inst_ac_b|B\(0) & \b2v_inst_ac_a|A\(0)) ) + ( (!\b2v_inst_ac_b|B\(0)) # (\b2v_inst_ac_a|A\(0)) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100000011000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_ac_a|ALT_INV_A\(0),
	cin => GND,
	sumout => \b2v_inst_alu_8b|Add5~5_sumout\,
	cout => \b2v_inst_alu_8b|Add5~6\);

-- Location: LABCELL_X81_Y6_N33
\b2v_inst_alu_8b|Add5~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add5~9_sumout\ = SUM(( (\b2v_inst_ac_b|B\(1) & \b2v_inst_ac_a|A\(1)) ) + ( (!\b2v_inst_ac_b|B\(1)) # (\b2v_inst_ac_a|A\(1)) ) + ( \b2v_inst_alu_8b|Add5~6\ ))
-- \b2v_inst_alu_8b|Add5~10\ = CARRY(( (\b2v_inst_ac_b|B\(1) & \b2v_inst_ac_a|A\(1)) ) + ( (!\b2v_inst_ac_b|B\(1)) # (\b2v_inst_ac_a|A\(1)) ) + ( \b2v_inst_alu_8b|Add5~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(1),
	datac => \b2v_inst_ac_a|ALT_INV_A\(1),
	cin => \b2v_inst_alu_8b|Add5~6\,
	sumout => \b2v_inst_alu_8b|Add5~9_sumout\,
	cout => \b2v_inst_alu_8b|Add5~10\);

-- Location: LABCELL_X81_Y6_N36
\b2v_inst_alu_8b|Add5~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add5~13_sumout\ = SUM(( (\b2v_inst_ac_a|A\(2) & \b2v_inst_ac_b|B\(2)) ) + ( (!\b2v_inst_ac_b|B\(2)) # (\b2v_inst_ac_a|A\(2)) ) + ( \b2v_inst_alu_8b|Add5~10\ ))
-- \b2v_inst_alu_8b|Add5~14\ = CARRY(( (\b2v_inst_ac_a|A\(2) & \b2v_inst_ac_b|B\(2)) ) + ( (!\b2v_inst_ac_b|B\(2)) # (\b2v_inst_ac_a|A\(2)) ) + ( \b2v_inst_alu_8b|Add5~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(2),
	datac => \b2v_inst_ac_b|ALT_INV_B\(2),
	cin => \b2v_inst_alu_8b|Add5~10\,
	sumout => \b2v_inst_alu_8b|Add5~13_sumout\,
	cout => \b2v_inst_alu_8b|Add5~14\);

-- Location: LABCELL_X81_Y6_N39
\b2v_inst_alu_8b|Add5~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add5~17_sumout\ = SUM(( (\b2v_inst_ac_a|A\(3) & \b2v_inst_ac_b|B\(3)) ) + ( (!\b2v_inst_ac_b|B\(3)) # (\b2v_inst_ac_a|A\(3)) ) + ( \b2v_inst_alu_8b|Add5~14\ ))
-- \b2v_inst_alu_8b|Add5~18\ = CARRY(( (\b2v_inst_ac_a|A\(3) & \b2v_inst_ac_b|B\(3)) ) + ( (!\b2v_inst_ac_b|B\(3)) # (\b2v_inst_ac_a|A\(3)) ) + ( \b2v_inst_alu_8b|Add5~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(3),
	datac => \b2v_inst_ac_b|ALT_INV_B\(3),
	cin => \b2v_inst_alu_8b|Add5~14\,
	sumout => \b2v_inst_alu_8b|Add5~17_sumout\,
	cout => \b2v_inst_alu_8b|Add5~18\);

-- Location: LABCELL_X81_Y6_N42
\b2v_inst_alu_8b|Add5~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add5~21_sumout\ = SUM(( (\b2v_inst_ac_a|A\(4) & \b2v_inst_ac_b|B\(4)) ) + ( (!\b2v_inst_ac_b|B\(4)) # (\b2v_inst_ac_a|A\(4)) ) + ( \b2v_inst_alu_8b|Add5~18\ ))
-- \b2v_inst_alu_8b|Add5~22\ = CARRY(( (\b2v_inst_ac_a|A\(4) & \b2v_inst_ac_b|B\(4)) ) + ( (!\b2v_inst_ac_b|B\(4)) # (\b2v_inst_ac_a|A\(4)) ) + ( \b2v_inst_alu_8b|Add5~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(4),
	datac => \b2v_inst_ac_b|ALT_INV_B\(4),
	cin => \b2v_inst_alu_8b|Add5~18\,
	sumout => \b2v_inst_alu_8b|Add5~21_sumout\,
	cout => \b2v_inst_alu_8b|Add5~22\);

-- Location: LABCELL_X81_Y6_N45
\b2v_inst_alu_8b|Add5~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add5~25_sumout\ = SUM(( (\b2v_inst_ac_a|A\(5) & \b2v_inst_ac_b|B\(5)) ) + ( (!\b2v_inst_ac_b|B\(5)) # (\b2v_inst_ac_a|A\(5)) ) + ( \b2v_inst_alu_8b|Add5~22\ ))
-- \b2v_inst_alu_8b|Add5~26\ = CARRY(( (\b2v_inst_ac_a|A\(5) & \b2v_inst_ac_b|B\(5)) ) + ( (!\b2v_inst_ac_b|B\(5)) # (\b2v_inst_ac_a|A\(5)) ) + ( \b2v_inst_alu_8b|Add5~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(5),
	datac => \b2v_inst_ac_b|ALT_INV_B\(5),
	cin => \b2v_inst_alu_8b|Add5~22\,
	sumout => \b2v_inst_alu_8b|Add5~25_sumout\,
	cout => \b2v_inst_alu_8b|Add5~26\);

-- Location: LABCELL_X81_Y6_N48
\b2v_inst_alu_8b|Add5~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add5~29_sumout\ = SUM(( (\b2v_inst_ac_a|A\(6) & \b2v_inst_ac_b|B\(6)) ) + ( (!\b2v_inst_ac_b|B\(6)) # (\b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_alu_8b|Add5~26\ ))
-- \b2v_inst_alu_8b|Add5~30\ = CARRY(( (\b2v_inst_ac_a|A\(6) & \b2v_inst_ac_b|B\(6)) ) + ( (!\b2v_inst_ac_b|B\(6)) # (\b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_alu_8b|Add5~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(6),
	datac => \b2v_inst_ac_b|ALT_INV_B\(6),
	cin => \b2v_inst_alu_8b|Add5~26\,
	sumout => \b2v_inst_alu_8b|Add5~29_sumout\,
	cout => \b2v_inst_alu_8b|Add5~30\);

-- Location: LABCELL_X81_Y6_N51
\b2v_inst_alu_8b|Add5~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add5~33_sumout\ = SUM(( (\b2v_inst_ac_a|A\(7) & \b2v_inst_ac_b|B\(7)) ) + ( (!\b2v_inst_ac_b|B\(7)) # (\b2v_inst_ac_a|A\(7)) ) + ( \b2v_inst_alu_8b|Add5~30\ ))
-- \b2v_inst_alu_8b|Add5~34\ = CARRY(( (\b2v_inst_ac_a|A\(7) & \b2v_inst_ac_b|B\(7)) ) + ( (!\b2v_inst_ac_b|B\(7)) # (\b2v_inst_ac_a|A\(7)) ) + ( \b2v_inst_alu_8b|Add5~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(7),
	datac => \b2v_inst_ac_b|ALT_INV_B\(7),
	cin => \b2v_inst_alu_8b|Add5~30\,
	sumout => \b2v_inst_alu_8b|Add5~33_sumout\,
	cout => \b2v_inst_alu_8b|Add5~34\);

-- Location: LABCELL_X81_Y6_N54
\b2v_inst_alu_8b|Add5~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add5~1_sumout\ = SUM(( VCC ) + ( GND ) + ( \b2v_inst_alu_8b|Add5~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	cin => \b2v_inst_alu_8b|Add5~34\,
	sumout => \b2v_inst_alu_8b|Add5~1_sumout\);

-- Location: LABCELL_X81_Y6_N0
\b2v_inst_alu_8b|Add7~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add7~5_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(0)) # (\b2v_inst_ac_a|A\(0)) ) + ( \b2v_inst_ac_a|A\(0) ) + ( !VCC ))
-- \b2v_inst_alu_8b|Add7~6\ = CARRY(( (!\b2v_inst_ac_b|B\(0)) # (\b2v_inst_ac_a|A\(0)) ) + ( \b2v_inst_ac_a|A\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000001100111111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_ac_a|ALT_INV_A\(0),
	cin => GND,
	sumout => \b2v_inst_alu_8b|Add7~5_sumout\,
	cout => \b2v_inst_alu_8b|Add7~6\);

-- Location: LABCELL_X81_Y6_N3
\b2v_inst_alu_8b|Add7~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add7~9_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(1)) # (\b2v_inst_ac_a|A\(1)) ) + ( \b2v_inst_ac_a|A\(1) ) + ( \b2v_inst_alu_8b|Add7~6\ ))
-- \b2v_inst_alu_8b|Add7~10\ = CARRY(( (!\b2v_inst_ac_b|B\(1)) # (\b2v_inst_ac_a|A\(1)) ) + ( \b2v_inst_ac_a|A\(1) ) + ( \b2v_inst_alu_8b|Add7~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000001010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(1),
	datac => \b2v_inst_ac_a|ALT_INV_A\(1),
	cin => \b2v_inst_alu_8b|Add7~6\,
	sumout => \b2v_inst_alu_8b|Add7~9_sumout\,
	cout => \b2v_inst_alu_8b|Add7~10\);

-- Location: LABCELL_X81_Y6_N6
\b2v_inst_alu_8b|Add7~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add7~13_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(2)) # (\b2v_inst_ac_a|A\(2)) ) + ( \b2v_inst_ac_a|A\(2) ) + ( \b2v_inst_alu_8b|Add7~10\ ))
-- \b2v_inst_alu_8b|Add7~14\ = CARRY(( (!\b2v_inst_ac_b|B\(2)) # (\b2v_inst_ac_a|A\(2)) ) + ( \b2v_inst_ac_a|A\(2) ) + ( \b2v_inst_alu_8b|Add7~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000001111001111110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(2),
	datac => \b2v_inst_ac_b|ALT_INV_B\(2),
	cin => \b2v_inst_alu_8b|Add7~10\,
	sumout => \b2v_inst_alu_8b|Add7~13_sumout\,
	cout => \b2v_inst_alu_8b|Add7~14\);

-- Location: LABCELL_X81_Y6_N9
\b2v_inst_alu_8b|Add7~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add7~17_sumout\ = SUM(( \b2v_inst_ac_a|A\(3) ) + ( (!\b2v_inst_ac_b|B\(3)) # (\b2v_inst_ac_a|A\(3)) ) + ( \b2v_inst_alu_8b|Add7~14\ ))
-- \b2v_inst_alu_8b|Add7~18\ = CARRY(( \b2v_inst_ac_a|A\(3) ) + ( (!\b2v_inst_ac_b|B\(3)) # (\b2v_inst_ac_a|A\(3)) ) + ( \b2v_inst_alu_8b|Add7~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000001010101000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(3),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(3),
	cin => \b2v_inst_alu_8b|Add7~14\,
	sumout => \b2v_inst_alu_8b|Add7~17_sumout\,
	cout => \b2v_inst_alu_8b|Add7~18\);

-- Location: LABCELL_X81_Y6_N12
\b2v_inst_alu_8b|Add7~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add7~21_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(4)) # (\b2v_inst_ac_a|A\(4)) ) + ( \b2v_inst_ac_a|A\(4) ) + ( \b2v_inst_alu_8b|Add7~18\ ))
-- \b2v_inst_alu_8b|Add7~22\ = CARRY(( (!\b2v_inst_ac_b|B\(4)) # (\b2v_inst_ac_a|A\(4)) ) + ( \b2v_inst_ac_a|A\(4) ) + ( \b2v_inst_alu_8b|Add7~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000001010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(4),
	datac => \b2v_inst_ac_a|ALT_INV_A\(4),
	cin => \b2v_inst_alu_8b|Add7~18\,
	sumout => \b2v_inst_alu_8b|Add7~21_sumout\,
	cout => \b2v_inst_alu_8b|Add7~22\);

-- Location: LABCELL_X81_Y6_N15
\b2v_inst_alu_8b|Add7~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add7~25_sumout\ = SUM(( \b2v_inst_ac_a|A\(5) ) + ( (!\b2v_inst_ac_b|B\(5)) # (\b2v_inst_ac_a|A\(5)) ) + ( \b2v_inst_alu_8b|Add7~22\ ))
-- \b2v_inst_alu_8b|Add7~26\ = CARRY(( \b2v_inst_ac_a|A\(5) ) + ( (!\b2v_inst_ac_b|B\(5)) # (\b2v_inst_ac_a|A\(5)) ) + ( \b2v_inst_alu_8b|Add7~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000001111000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_a|ALT_INV_A\(5),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(5),
	cin => \b2v_inst_alu_8b|Add7~22\,
	sumout => \b2v_inst_alu_8b|Add7~25_sumout\,
	cout => \b2v_inst_alu_8b|Add7~26\);

-- Location: LABCELL_X81_Y6_N18
\b2v_inst_alu_8b|Add7~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add7~29_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(6)) # (\b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_ac_a|A\(6) ) + ( \b2v_inst_alu_8b|Add7~26\ ))
-- \b2v_inst_alu_8b|Add7~30\ = CARRY(( (!\b2v_inst_ac_b|B\(6)) # (\b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_ac_a|A\(6) ) + ( \b2v_inst_alu_8b|Add7~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000001111001111110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(6),
	datac => \b2v_inst_ac_b|ALT_INV_B\(6),
	cin => \b2v_inst_alu_8b|Add7~26\,
	sumout => \b2v_inst_alu_8b|Add7~29_sumout\,
	cout => \b2v_inst_alu_8b|Add7~30\);

-- Location: LABCELL_X81_Y6_N21
\b2v_inst_alu_8b|Add7~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add7~33_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(7)) # (\b2v_inst_ac_a|A\(7)) ) + ( \b2v_inst_ac_a|A\(7) ) + ( \b2v_inst_alu_8b|Add7~30\ ))
-- \b2v_inst_alu_8b|Add7~34\ = CARRY(( (!\b2v_inst_ac_b|B\(7)) # (\b2v_inst_ac_a|A\(7)) ) + ( \b2v_inst_ac_a|A\(7) ) + ( \b2v_inst_alu_8b|Add7~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000001111111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_a|ALT_INV_A\(7),
	datad => \b2v_inst_ac_b|ALT_INV_B\(7),
	cin => \b2v_inst_alu_8b|Add7~30\,
	sumout => \b2v_inst_alu_8b|Add7~33_sumout\,
	cout => \b2v_inst_alu_8b|Add7~34\);

-- Location: LABCELL_X81_Y6_N24
\b2v_inst_alu_8b|Add7~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add7~1_sumout\ = SUM(( VCC ) + ( GND ) + ( \b2v_inst_alu_8b|Add7~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	cin => \b2v_inst_alu_8b|Add7~34\,
	sumout => \b2v_inst_alu_8b|Add7~1_sumout\);

-- Location: LABCELL_X80_Y6_N18
\b2v_inst_alu_8b|Mux0~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux0~2_combout\ = ( !\b2v_inst_ac_s|S\(0) & ( \b2v_inst_alu_8b|Add7~1_sumout\ & ( (\ALU~input_o\ & ((\b2v_inst_alu_8b|Add5~1_sumout\) # (\b2v_inst_ac_s|S\(2)))) ) ) ) # ( !\b2v_inst_ac_s|S\(0) & ( !\b2v_inst_alu_8b|Add7~1_sumout\ & ( 
-- (!\b2v_inst_ac_s|S\(2) & (\ALU~input_o\ & \b2v_inst_alu_8b|Add5~1_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001100000000000000000000000011000011110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_s|ALT_INV_S\(2),
	datac => \ALT_INV_ALU~input_o\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add5~1_sumout\,
	datae => \b2v_inst_ac_s|ALT_INV_S\(0),
	dataf => \b2v_inst_alu_8b|ALT_INV_Add7~1_sumout\,
	combout => \b2v_inst_alu_8b|Mux0~2_combout\);

-- Location: MLABCELL_X82_Y6_N0
\b2v_inst_alu_8b|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add1~5_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(0) & \b2v_inst_ac_a|A\(0)) ) + ( (\b2v_inst_ac_a|A\(0)) # (\b2v_inst_ac_b|B\(0)) ) + ( !VCC ))
-- \b2v_inst_alu_8b|Add1~6\ = CARRY(( (!\b2v_inst_ac_b|B\(0) & \b2v_inst_ac_a|A\(0)) ) + ( (\b2v_inst_ac_a|A\(0)) # (\b2v_inst_ac_b|B\(0)) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_ac_a|ALT_INV_A\(0),
	cin => GND,
	sumout => \b2v_inst_alu_8b|Add1~5_sumout\,
	cout => \b2v_inst_alu_8b|Add1~6\);

-- Location: MLABCELL_X82_Y6_N3
\b2v_inst_alu_8b|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add1~9_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(1) & \b2v_inst_ac_a|A\(1)) ) + ( (\b2v_inst_ac_a|A\(1)) # (\b2v_inst_ac_b|B\(1)) ) + ( \b2v_inst_alu_8b|Add1~6\ ))
-- \b2v_inst_alu_8b|Add1~10\ = CARRY(( (!\b2v_inst_ac_b|B\(1) & \b2v_inst_ac_a|A\(1)) ) + ( (\b2v_inst_ac_a|A\(1)) # (\b2v_inst_ac_b|B\(1)) ) + ( \b2v_inst_alu_8b|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(1),
	datac => \b2v_inst_ac_a|ALT_INV_A\(1),
	cin => \b2v_inst_alu_8b|Add1~6\,
	sumout => \b2v_inst_alu_8b|Add1~9_sumout\,
	cout => \b2v_inst_alu_8b|Add1~10\);

-- Location: MLABCELL_X82_Y6_N6
\b2v_inst_alu_8b|Add1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add1~13_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(2) & \b2v_inst_ac_a|A\(2)) ) + ( (\b2v_inst_ac_a|A\(2)) # (\b2v_inst_ac_b|B\(2)) ) + ( \b2v_inst_alu_8b|Add1~10\ ))
-- \b2v_inst_alu_8b|Add1~14\ = CARRY(( (!\b2v_inst_ac_b|B\(2) & \b2v_inst_ac_a|A\(2)) ) + ( (\b2v_inst_ac_a|A\(2)) # (\b2v_inst_ac_b|B\(2)) ) + ( \b2v_inst_alu_8b|Add1~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_b|ALT_INV_B\(2),
	datac => \b2v_inst_ac_a|ALT_INV_A\(2),
	cin => \b2v_inst_alu_8b|Add1~10\,
	sumout => \b2v_inst_alu_8b|Add1~13_sumout\,
	cout => \b2v_inst_alu_8b|Add1~14\);

-- Location: MLABCELL_X82_Y6_N9
\b2v_inst_alu_8b|Add1~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add1~17_sumout\ = SUM(( (\b2v_inst_ac_a|A\(3) & !\b2v_inst_ac_b|B\(3)) ) + ( (\b2v_inst_ac_b|B\(3)) # (\b2v_inst_ac_a|A\(3)) ) + ( \b2v_inst_alu_8b|Add1~14\ ))
-- \b2v_inst_alu_8b|Add1~18\ = CARRY(( (\b2v_inst_ac_a|A\(3) & !\b2v_inst_ac_b|B\(3)) ) + ( (\b2v_inst_ac_b|B\(3)) # (\b2v_inst_ac_a|A\(3)) ) + ( \b2v_inst_alu_8b|Add1~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(3),
	datac => \b2v_inst_ac_b|ALT_INV_B\(3),
	cin => \b2v_inst_alu_8b|Add1~14\,
	sumout => \b2v_inst_alu_8b|Add1~17_sumout\,
	cout => \b2v_inst_alu_8b|Add1~18\);

-- Location: MLABCELL_X82_Y6_N12
\b2v_inst_alu_8b|Add1~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add1~21_sumout\ = SUM(( (\b2v_inst_ac_a|A\(4) & !\b2v_inst_ac_b|B\(4)) ) + ( (\b2v_inst_ac_b|B\(4)) # (\b2v_inst_ac_a|A\(4)) ) + ( \b2v_inst_alu_8b|Add1~18\ ))
-- \b2v_inst_alu_8b|Add1~22\ = CARRY(( (\b2v_inst_ac_a|A\(4) & !\b2v_inst_ac_b|B\(4)) ) + ( (\b2v_inst_ac_b|B\(4)) # (\b2v_inst_ac_a|A\(4)) ) + ( \b2v_inst_alu_8b|Add1~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(4),
	datac => \b2v_inst_ac_b|ALT_INV_B\(4),
	cin => \b2v_inst_alu_8b|Add1~18\,
	sumout => \b2v_inst_alu_8b|Add1~21_sumout\,
	cout => \b2v_inst_alu_8b|Add1~22\);

-- Location: MLABCELL_X82_Y6_N15
\b2v_inst_alu_8b|Add1~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add1~25_sumout\ = SUM(( (\b2v_inst_ac_a|A\(5) & !\b2v_inst_ac_b|B\(5)) ) + ( (\b2v_inst_ac_b|B\(5)) # (\b2v_inst_ac_a|A\(5)) ) + ( \b2v_inst_alu_8b|Add1~22\ ))
-- \b2v_inst_alu_8b|Add1~26\ = CARRY(( (\b2v_inst_ac_a|A\(5) & !\b2v_inst_ac_b|B\(5)) ) + ( (\b2v_inst_ac_b|B\(5)) # (\b2v_inst_ac_a|A\(5)) ) + ( \b2v_inst_alu_8b|Add1~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(5),
	datac => \b2v_inst_ac_b|ALT_INV_B\(5),
	cin => \b2v_inst_alu_8b|Add1~22\,
	sumout => \b2v_inst_alu_8b|Add1~25_sumout\,
	cout => \b2v_inst_alu_8b|Add1~26\);

-- Location: MLABCELL_X82_Y6_N18
\b2v_inst_alu_8b|Add1~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add1~29_sumout\ = SUM(( (\b2v_inst_ac_a|A\(6) & !\b2v_inst_ac_b|B\(6)) ) + ( (\b2v_inst_ac_b|B\(6)) # (\b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_alu_8b|Add1~26\ ))
-- \b2v_inst_alu_8b|Add1~30\ = CARRY(( (\b2v_inst_ac_a|A\(6) & !\b2v_inst_ac_b|B\(6)) ) + ( (\b2v_inst_ac_b|B\(6)) # (\b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_alu_8b|Add1~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(6),
	datac => \b2v_inst_ac_b|ALT_INV_B\(6),
	cin => \b2v_inst_alu_8b|Add1~26\,
	sumout => \b2v_inst_alu_8b|Add1~29_sumout\,
	cout => \b2v_inst_alu_8b|Add1~30\);

-- Location: MLABCELL_X82_Y6_N21
\b2v_inst_alu_8b|Add1~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add1~33_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(7) & \b2v_inst_ac_a|A\(7)) ) + ( (\b2v_inst_ac_a|A\(7)) # (\b2v_inst_ac_b|B\(7)) ) + ( \b2v_inst_alu_8b|Add1~30\ ))
-- \b2v_inst_alu_8b|Add1~34\ = CARRY(( (!\b2v_inst_ac_b|B\(7) & \b2v_inst_ac_a|A\(7)) ) + ( (\b2v_inst_ac_a|A\(7)) # (\b2v_inst_ac_b|B\(7)) ) + ( \b2v_inst_alu_8b|Add1~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(7),
	datac => \b2v_inst_ac_a|ALT_INV_A\(7),
	cin => \b2v_inst_alu_8b|Add1~30\,
	sumout => \b2v_inst_alu_8b|Add1~33_sumout\,
	cout => \b2v_inst_alu_8b|Add1~34\);

-- Location: MLABCELL_X82_Y6_N24
\b2v_inst_alu_8b|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add1~1_sumout\ = SUM(( GND ) + ( GND ) + ( \b2v_inst_alu_8b|Add1~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	cin => \b2v_inst_alu_8b|Add1~34\,
	sumout => \b2v_inst_alu_8b|Add1~1_sumout\);

-- Location: LABCELL_X83_Y6_N30
\b2v_inst_alu_8b|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add0~5_sumout\ = SUM(( \b2v_inst_ac_a|A\(0) ) + ( (\b2v_inst_ac_a|A\(0) & !\b2v_inst_ac_b|B\(0)) ) + ( !VCC ))
-- \b2v_inst_alu_8b|Add0~6\ = CARRY(( \b2v_inst_ac_a|A\(0) ) + ( (\b2v_inst_ac_a|A\(0) & !\b2v_inst_ac_b|B\(0)) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(0),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(0),
	cin => GND,
	sumout => \b2v_inst_alu_8b|Add0~5_sumout\,
	cout => \b2v_inst_alu_8b|Add0~6\);

-- Location: LABCELL_X83_Y6_N33
\b2v_inst_alu_8b|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add0~9_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(1) & \b2v_inst_ac_a|A\(1)) ) + ( \b2v_inst_ac_a|A\(1) ) + ( \b2v_inst_alu_8b|Add0~6\ ))
-- \b2v_inst_alu_8b|Add0~10\ = CARRY(( (!\b2v_inst_ac_b|B\(1) & \b2v_inst_ac_a|A\(1)) ) + ( \b2v_inst_ac_a|A\(1) ) + ( \b2v_inst_alu_8b|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(1),
	datac => \b2v_inst_ac_a|ALT_INV_A\(1),
	cin => \b2v_inst_alu_8b|Add0~6\,
	sumout => \b2v_inst_alu_8b|Add0~9_sumout\,
	cout => \b2v_inst_alu_8b|Add0~10\);

-- Location: LABCELL_X83_Y6_N36
\b2v_inst_alu_8b|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add0~13_sumout\ = SUM(( (\b2v_inst_ac_a|A\(2) & !\b2v_inst_ac_b|B\(2)) ) + ( \b2v_inst_ac_a|A\(2) ) + ( \b2v_inst_alu_8b|Add0~10\ ))
-- \b2v_inst_alu_8b|Add0~14\ = CARRY(( (\b2v_inst_ac_a|A\(2) & !\b2v_inst_ac_b|B\(2)) ) + ( \b2v_inst_ac_a|A\(2) ) + ( \b2v_inst_alu_8b|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(2),
	datac => \b2v_inst_ac_b|ALT_INV_B\(2),
	cin => \b2v_inst_alu_8b|Add0~10\,
	sumout => \b2v_inst_alu_8b|Add0~13_sumout\,
	cout => \b2v_inst_alu_8b|Add0~14\);

-- Location: LABCELL_X83_Y6_N39
\b2v_inst_alu_8b|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add0~17_sumout\ = SUM(( (\b2v_inst_ac_a|A\(3) & !\b2v_inst_ac_b|B\(3)) ) + ( \b2v_inst_ac_a|A\(3) ) + ( \b2v_inst_alu_8b|Add0~14\ ))
-- \b2v_inst_alu_8b|Add0~18\ = CARRY(( (\b2v_inst_ac_a|A\(3) & !\b2v_inst_ac_b|B\(3)) ) + ( \b2v_inst_ac_a|A\(3) ) + ( \b2v_inst_alu_8b|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_a|ALT_INV_A\(3),
	datad => \b2v_inst_ac_b|ALT_INV_B\(3),
	cin => \b2v_inst_alu_8b|Add0~14\,
	sumout => \b2v_inst_alu_8b|Add0~17_sumout\,
	cout => \b2v_inst_alu_8b|Add0~18\);

-- Location: LABCELL_X83_Y6_N42
\b2v_inst_alu_8b|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add0~21_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(4) & \b2v_inst_ac_a|A\(4)) ) + ( \b2v_inst_ac_a|A\(4) ) + ( \b2v_inst_alu_8b|Add0~18\ ))
-- \b2v_inst_alu_8b|Add0~22\ = CARRY(( (!\b2v_inst_ac_b|B\(4) & \b2v_inst_ac_a|A\(4)) ) + ( \b2v_inst_ac_a|A\(4) ) + ( \b2v_inst_alu_8b|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(4),
	datac => \b2v_inst_ac_a|ALT_INV_A\(4),
	cin => \b2v_inst_alu_8b|Add0~18\,
	sumout => \b2v_inst_alu_8b|Add0~21_sumout\,
	cout => \b2v_inst_alu_8b|Add0~22\);

-- Location: LABCELL_X83_Y6_N45
\b2v_inst_alu_8b|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add0~25_sumout\ = SUM(( \b2v_inst_ac_a|A\(5) ) + ( (\b2v_inst_ac_a|A\(5) & !\b2v_inst_ac_b|B\(5)) ) + ( \b2v_inst_alu_8b|Add0~22\ ))
-- \b2v_inst_alu_8b|Add0~26\ = CARRY(( \b2v_inst_ac_a|A\(5) ) + ( (\b2v_inst_ac_a|A\(5) & !\b2v_inst_ac_b|B\(5)) ) + ( \b2v_inst_alu_8b|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_a|ALT_INV_A\(5),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(5),
	cin => \b2v_inst_alu_8b|Add0~22\,
	sumout => \b2v_inst_alu_8b|Add0~25_sumout\,
	cout => \b2v_inst_alu_8b|Add0~26\);

-- Location: LABCELL_X83_Y6_N48
\b2v_inst_alu_8b|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add0~29_sumout\ = SUM(( (!\b2v_inst_ac_b|B\(6) & \b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_ac_a|A\(6) ) + ( \b2v_inst_alu_8b|Add0~26\ ))
-- \b2v_inst_alu_8b|Add0~30\ = CARRY(( (!\b2v_inst_ac_b|B\(6) & \b2v_inst_ac_a|A\(6)) ) + ( \b2v_inst_ac_a|A\(6) ) + ( \b2v_inst_alu_8b|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(6),
	datac => \b2v_inst_ac_a|ALT_INV_A\(6),
	cin => \b2v_inst_alu_8b|Add0~26\,
	sumout => \b2v_inst_alu_8b|Add0~29_sumout\,
	cout => \b2v_inst_alu_8b|Add0~30\);

-- Location: LABCELL_X83_Y6_N51
\b2v_inst_alu_8b|Add0~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add0~33_sumout\ = SUM(( \b2v_inst_ac_a|A\(7) ) + ( (\b2v_inst_ac_a|A\(7) & !\b2v_inst_ac_b|B\(7)) ) + ( \b2v_inst_alu_8b|Add0~30\ ))
-- \b2v_inst_alu_8b|Add0~34\ = CARRY(( \b2v_inst_ac_a|A\(7) ) + ( (\b2v_inst_ac_a|A\(7) & !\b2v_inst_ac_b|B\(7)) ) + ( \b2v_inst_alu_8b|Add0~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_a|ALT_INV_A\(7),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(7),
	cin => \b2v_inst_alu_8b|Add0~30\,
	sumout => \b2v_inst_alu_8b|Add0~33_sumout\,
	cout => \b2v_inst_alu_8b|Add0~34\);

-- Location: LABCELL_X83_Y6_N54
\b2v_inst_alu_8b|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Add0~1_sumout\ = SUM(( GND ) + ( GND ) + ( \b2v_inst_alu_8b|Add0~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	cin => \b2v_inst_alu_8b|Add0~34\,
	sumout => \b2v_inst_alu_8b|Add0~1_sumout\);

-- Location: LABCELL_X79_Y6_N33
\b2v_inst_alu_8b|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux0~0_combout\ = ( \b2v_inst_alu_8b|Add0~1_sumout\ & ( (!\ALU~input_o\) # ((\b2v_inst_ac_s|S\(2) & ((!\b2v_inst_ac_s|S\(0)) # (\b2v_inst_alu_8b|Add1~1_sumout\)))) ) ) # ( !\b2v_inst_alu_8b|Add0~1_sumout\ & ( (!\ALU~input_o\) # 
-- ((\b2v_inst_ac_s|S\(0) & (\b2v_inst_alu_8b|Add1~1_sumout\ & \b2v_inst_ac_s|S\(2)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101010101011101010101010101110101010111011111010101011101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_alu_8b|ALT_INV_Add1~1_sumout\,
	datad => \b2v_inst_ac_s|ALT_INV_S\(2),
	dataf => \b2v_inst_alu_8b|ALT_INV_Add0~1_sumout\,
	combout => \b2v_inst_alu_8b|Mux0~0_combout\);

-- Location: LABCELL_X79_Y6_N6
\CF~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \CF~0_combout\ = ( !\b2v_inst_ac_s|S\(1) & ( !\b2v_inst_ac_s|S\(0) $ (((!\b2v_inst_ac_s|S\(3) & (((!\b2v_inst_alu_8b|Mux0~0_combout\)))) # (\b2v_inst_ac_s|S\(3) & (!\b2v_inst_alu_8b|Mux0~3_combout\)))) ) ) # ( \b2v_inst_ac_s|S\(1) & ( 
-- !\b2v_inst_ac_s|S\(0) $ ((((!\b2v_inst_ac_s|S\(3) & (!\b2v_inst_alu_8b|Mux0~1_combout\)) # (\b2v_inst_ac_s|S\(3) & ((!\b2v_inst_alu_8b|Mux0~2_combout\)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0101101001100110010110100101010101011010011001100101101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(0),
	datab => \b2v_inst_alu_8b|ALT_INV_Mux0~3_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux0~1_combout\,
	datad => \b2v_inst_ac_s|ALT_INV_S\(3),
	datae => \b2v_inst_ac_s|ALT_INV_S\(1),
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux0~2_combout\,
	datag => \b2v_inst_alu_8b|ALT_INV_Mux0~0_combout\,
	combout => \CF~0_combout\);

-- Location: IOIBUF_X4_Y0_N18
\SEG~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SEG,
	o => \SEG~input_o\);

-- Location: LABCELL_X83_Y7_N45
\b2v_inst_seg7_A|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux6~0_combout\ = ( \SEG~input_o\ ) # ( !\SEG~input_o\ & ( (!\b2v_inst_ac_a|A\(0) & (!\b2v_inst_ac_a|A\(1) & (!\b2v_inst_ac_a|A\(2) $ (\b2v_inst_ac_a|A\(3))))) # (\b2v_inst_ac_a|A\(0) & (!\b2v_inst_ac_a|A\(3) & (!\b2v_inst_ac_a|A\(1) $ 
-- (\b2v_inst_ac_a|A\(2))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100000100001000110000010000100011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(0),
	datab => \b2v_inst_ac_a|ALT_INV_A\(1),
	datac => \b2v_inst_ac_a|ALT_INV_A\(2),
	datad => \b2v_inst_ac_a|ALT_INV_A\(3),
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7_A|Mux6~0_combout\);

-- Location: LABCELL_X83_Y7_N42
\b2v_inst_seg7_A|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux5~0_combout\ = ( \b2v_inst_ac_a|A\(3) & ( ((\b2v_inst_ac_a|A\(0) & (!\b2v_inst_ac_a|A\(1) & \b2v_inst_ac_a|A\(2)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_a|A\(3) & ( ((!\b2v_inst_ac_a|A\(0) & (\b2v_inst_ac_a|A\(1) & 
-- !\b2v_inst_ac_a|A\(2))) # (\b2v_inst_ac_a|A\(0) & ((!\b2v_inst_ac_a|A\(2)) # (\b2v_inst_ac_a|A\(1))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111111100011111011111110001111100001111010011110000111101001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(0),
	datab => \b2v_inst_ac_a|ALT_INV_A\(1),
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_ac_a|ALT_INV_A\(2),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(3),
	combout => \b2v_inst_seg7_A|Mux5~0_combout\);

-- Location: LABCELL_X83_Y7_N39
\b2v_inst_seg7_A|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux4~0_combout\ = ( \SEG~input_o\ ) # ( !\SEG~input_o\ & ( (!\b2v_inst_ac_a|A\(1) & ((!\b2v_inst_ac_a|A\(2) & (\b2v_inst_ac_a|A\(0))) # (\b2v_inst_ac_a|A\(2) & ((!\b2v_inst_ac_a|A\(3)))))) # (\b2v_inst_ac_a|A\(1) & (\b2v_inst_ac_a|A\(0) & 
-- ((!\b2v_inst_ac_a|A\(3))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111010001010000011101000101000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(0),
	datab => \b2v_inst_ac_a|ALT_INV_A\(2),
	datac => \b2v_inst_ac_a|ALT_INV_A\(3),
	datad => \b2v_inst_ac_a|ALT_INV_A\(1),
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7_A|Mux4~0_combout\);

-- Location: LABCELL_X83_Y7_N36
\b2v_inst_seg7_A|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux3~0_combout\ = ( \b2v_inst_ac_a|A\(1) & ( ((!\b2v_inst_ac_a|A\(0) & (!\b2v_inst_ac_a|A\(2) & \b2v_inst_ac_a|A\(3))) # (\b2v_inst_ac_a|A\(0) & (\b2v_inst_ac_a|A\(2)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_a|A\(1) & ( 
-- ((!\b2v_inst_ac_a|A\(3) & (!\b2v_inst_ac_a|A\(0) $ (!\b2v_inst_ac_a|A\(2))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110111100001111011011110000111100011111100111110001111110011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(0),
	datab => \b2v_inst_ac_a|ALT_INV_A\(2),
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_ac_a|ALT_INV_A\(3),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(1),
	combout => \b2v_inst_seg7_A|Mux3~0_combout\);

-- Location: LABCELL_X80_Y7_N36
\b2v_inst_seg7_A|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux2~0_combout\ = ( \b2v_inst_ac_a|A\(3) & ( ((\b2v_inst_ac_a|A\(2) & ((!\b2v_inst_ac_a|A\(0)) # (\b2v_inst_ac_a|A\(1))))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_a|A\(3) & ( ((!\b2v_inst_ac_a|A\(2) & (!\b2v_inst_ac_a|A\(0) & 
-- \b2v_inst_ac_a|A\(1)))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010111010101010101011101010101110101011101110111010101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_SEG~input_o\,
	datab => \b2v_inst_ac_a|ALT_INV_A\(2),
	datac => \b2v_inst_ac_a|ALT_INV_A\(0),
	datad => \b2v_inst_ac_a|ALT_INV_A\(1),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(3),
	combout => \b2v_inst_seg7_A|Mux2~0_combout\);

-- Location: LABCELL_X83_Y7_N57
\b2v_inst_seg7_A|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux1~0_combout\ = ( \b2v_inst_ac_a|A\(1) & ( ((!\b2v_inst_ac_a|A\(0) & (\b2v_inst_ac_a|A\(2))) # (\b2v_inst_ac_a|A\(0) & ((\b2v_inst_ac_a|A\(3))))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_a|A\(1) & ( ((\b2v_inst_ac_a|A\(2) & 
-- (!\b2v_inst_ac_a|A\(3) $ (!\b2v_inst_ac_a|A\(0))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101011101110101010101110111010101110111010111110111011101011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_SEG~input_o\,
	datab => \b2v_inst_ac_a|ALT_INV_A\(2),
	datac => \b2v_inst_ac_a|ALT_INV_A\(3),
	datad => \b2v_inst_ac_a|ALT_INV_A\(0),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(1),
	combout => \b2v_inst_seg7_A|Mux1~0_combout\);

-- Location: LABCELL_X83_Y7_N54
\b2v_inst_seg7_A|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux0~0_combout\ = ( \b2v_inst_ac_a|A\(1) & ( ((!\b2v_inst_ac_a|A\(2) & (\b2v_inst_ac_a|A\(0) & \b2v_inst_ac_a|A\(3)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_a|A\(1) & ( ((!\b2v_inst_ac_a|A\(2) & (\b2v_inst_ac_a|A\(0) & 
-- !\b2v_inst_ac_a|A\(3))) # (\b2v_inst_ac_a|A\(2) & (!\b2v_inst_ac_a|A\(0) $ (\b2v_inst_ac_a|A\(3))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111110101010111011111010101011101010101010111010101010101011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_SEG~input_o\,
	datab => \b2v_inst_ac_a|ALT_INV_A\(2),
	datac => \b2v_inst_ac_a|ALT_INV_A\(0),
	datad => \b2v_inst_ac_a|ALT_INV_A\(3),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(1),
	combout => \b2v_inst_seg7_A|Mux0~0_combout\);

-- Location: LABCELL_X83_Y7_N51
\b2v_inst_seg7_A|Mux13~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux13~0_combout\ = ( \SEG~input_o\ ) # ( !\SEG~input_o\ & ( (!\b2v_inst_ac_a|A\(4) & (!\b2v_inst_ac_a|A\(5) & (!\b2v_inst_ac_a|A\(6) $ (\b2v_inst_ac_a|A\(7))))) # (\b2v_inst_ac_a|A\(4) & (!\b2v_inst_ac_a|A\(7) & (!\b2v_inst_ac_a|A\(6) $ 
-- (\b2v_inst_ac_a|A\(5))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100000100100000110000010010000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(4),
	datab => \b2v_inst_ac_a|ALT_INV_A\(6),
	datac => \b2v_inst_ac_a|ALT_INV_A\(5),
	datad => \b2v_inst_ac_a|ALT_INV_A\(7),
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7_A|Mux13~0_combout\);

-- Location: LABCELL_X83_Y5_N27
\b2v_inst_seg7_A|Mux12~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux12~0_combout\ = ( \b2v_inst_ac_a|A\(6) & ( ((\b2v_inst_ac_a|A\(4) & (!\b2v_inst_ac_a|A\(5) $ (!\b2v_inst_ac_a|A\(7))))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_a|A\(6) & ( ((!\b2v_inst_ac_a|A\(7) & ((\b2v_inst_ac_a|A\(5)) # 
-- (\b2v_inst_ac_a|A\(4))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111000011111111011100001111111100010100111111110001010011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(4),
	datab => \b2v_inst_ac_a|ALT_INV_A\(5),
	datac => \b2v_inst_ac_a|ALT_INV_A\(7),
	datad => \ALT_INV_SEG~input_o\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(6),
	combout => \b2v_inst_seg7_A|Mux12~0_combout\);

-- Location: LABCELL_X83_Y5_N24
\b2v_inst_seg7_A|Mux11~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux11~0_combout\ = ( \b2v_inst_ac_a|A\(6) & ( ((!\b2v_inst_ac_a|A\(7) & ((!\b2v_inst_ac_a|A\(5)) # (\b2v_inst_ac_a|A\(4))))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_a|A\(6) & ( ((\b2v_inst_ac_a|A\(4) & ((!\b2v_inst_ac_a|A\(5)) # 
-- (!\b2v_inst_ac_a|A\(7))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101111101001111010111110100111111011111000011111101111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(4),
	datab => \b2v_inst_ac_a|ALT_INV_A\(5),
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_ac_a|ALT_INV_A\(7),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(6),
	combout => \b2v_inst_seg7_A|Mux11~0_combout\);

-- Location: LABCELL_X83_Y7_N48
\b2v_inst_seg7_A|Mux10~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux10~0_combout\ = ( \b2v_inst_ac_a|A\(5) & ( ((!\b2v_inst_ac_a|A\(4) & (!\b2v_inst_ac_a|A\(6) & \b2v_inst_ac_a|A\(7))) # (\b2v_inst_ac_a|A\(4) & (\b2v_inst_ac_a|A\(6)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_a|A\(5) & ( 
-- ((!\b2v_inst_ac_a|A\(7) & (!\b2v_inst_ac_a|A\(4) $ (!\b2v_inst_ac_a|A\(6))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110111100001111011011110000111100011111100111110001111110011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(4),
	datab => \b2v_inst_ac_a|ALT_INV_A\(6),
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_ac_a|ALT_INV_A\(7),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(5),
	combout => \b2v_inst_seg7_A|Mux10~0_combout\);

-- Location: LABCELL_X83_Y5_N18
\b2v_inst_seg7_A|Mux9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux9~0_combout\ = ( \b2v_inst_ac_a|A\(7) & ( \b2v_inst_ac_a|A\(4) & ( ((\b2v_inst_ac_a|A\(6) & \b2v_inst_ac_a|A\(5))) # (\SEG~input_o\) ) ) ) # ( !\b2v_inst_ac_a|A\(7) & ( \b2v_inst_ac_a|A\(4) & ( \SEG~input_o\ ) ) ) # ( 
-- \b2v_inst_ac_a|A\(7) & ( !\b2v_inst_ac_a|A\(4) & ( (\SEG~input_o\) # (\b2v_inst_ac_a|A\(6)) ) ) ) # ( !\b2v_inst_ac_a|A\(7) & ( !\b2v_inst_ac_a|A\(4) & ( ((!\b2v_inst_ac_a|A\(6) & \b2v_inst_ac_a|A\(5))) # (\SEG~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010111100101111010111110101111100001111000011110001111100011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(6),
	datab => \b2v_inst_ac_a|ALT_INV_A\(5),
	datac => \ALT_INV_SEG~input_o\,
	datae => \b2v_inst_ac_a|ALT_INV_A\(7),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(4),
	combout => \b2v_inst_seg7_A|Mux9~0_combout\);

-- Location: LABCELL_X83_Y5_N45
\b2v_inst_seg7_A|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux8~0_combout\ = ( \b2v_inst_ac_a|A\(6) & ( ((!\b2v_inst_ac_a|A\(4) & ((\b2v_inst_ac_a|A\(7)) # (\b2v_inst_ac_a|A\(5)))) # (\b2v_inst_ac_a|A\(4) & (!\b2v_inst_ac_a|A\(5) $ (\b2v_inst_ac_a|A\(7))))) # (\SEG~input_o\) ) ) # ( 
-- !\b2v_inst_ac_a|A\(6) & ( ((\b2v_inst_ac_a|A\(4) & (\b2v_inst_ac_a|A\(5) & \b2v_inst_ac_a|A\(7)))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000111111111000000011111111101101011111111110110101111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(4),
	datab => \b2v_inst_ac_a|ALT_INV_A\(5),
	datac => \b2v_inst_ac_a|ALT_INV_A\(7),
	datad => \ALT_INV_SEG~input_o\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(6),
	combout => \b2v_inst_seg7_A|Mux8~0_combout\);

-- Location: LABCELL_X83_Y5_N42
\b2v_inst_seg7_A|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_A|Mux7~0_combout\ = ( \b2v_inst_ac_a|A\(6) & ( ((!\b2v_inst_ac_a|A\(5) & (!\b2v_inst_ac_a|A\(4) $ (\b2v_inst_ac_a|A\(7))))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_a|A\(6) & ( ((\b2v_inst_ac_a|A\(4) & (!\b2v_inst_ac_a|A\(5) $ 
-- (\b2v_inst_ac_a|A\(7))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100111100011111010011110001111110001111010011111000111101001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(4),
	datab => \b2v_inst_ac_a|ALT_INV_A\(5),
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_ac_a|ALT_INV_A\(7),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(6),
	combout => \b2v_inst_seg7_A|Mux7~0_combout\);

-- Location: LABCELL_X80_Y8_N57
\b2v_inst_seg7_B|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux6~0_combout\ = ( \b2v_inst_ac_b|B\(1) & ( ((!\b2v_inst_ac_b|B\(3) & (\b2v_inst_ac_b|B\(0) & \b2v_inst_ac_b|B\(2)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_b|B\(1) & ( ((!\b2v_inst_ac_b|B\(3) & ((!\b2v_inst_ac_b|B\(2)))) # 
-- (\b2v_inst_ac_b|B\(3) & (!\b2v_inst_ac_b|B\(0) & \b2v_inst_ac_b|B\(2)))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010111101001111101011110100111100001111001011110000111100101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(3),
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(1),
	combout => \b2v_inst_seg7_B|Mux6~0_combout\);

-- Location: LABCELL_X80_Y8_N54
\b2v_inst_seg7_B|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux5~0_combout\ = ( \b2v_inst_ac_b|B\(1) & ( ((!\b2v_inst_ac_b|B\(3) & ((!\b2v_inst_ac_b|B\(2)) # (\b2v_inst_ac_b|B\(0))))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_b|B\(1) & ( ((\b2v_inst_ac_b|B\(0) & (!\b2v_inst_ac_b|B\(3) $ 
-- (\b2v_inst_ac_b|B\(2))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010111100011111001011110001111110101111001011111010111100101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(3),
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(1),
	combout => \b2v_inst_seg7_B|Mux5~0_combout\);

-- Location: LABCELL_X80_Y8_N51
\b2v_inst_seg7_B|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux4~0_combout\ = ( \b2v_inst_ac_b|B\(1) & ( ((!\b2v_inst_ac_b|B\(3) & \b2v_inst_ac_b|B\(0))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_b|B\(1) & ( ((!\b2v_inst_ac_b|B\(2) & ((\b2v_inst_ac_b|B\(0)))) # (\b2v_inst_ac_b|B\(2) & 
-- (!\b2v_inst_ac_b|B\(3)))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011111110101111001111111010111100101111001011110010111100101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(3),
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(1),
	combout => \b2v_inst_seg7_B|Mux4~0_combout\);

-- Location: LABCELL_X80_Y8_N48
\b2v_inst_seg7_B|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux3~0_combout\ = ( \b2v_inst_ac_b|B\(1) & ( ((!\b2v_inst_ac_b|B\(0) & (\b2v_inst_ac_b|B\(3) & !\b2v_inst_ac_b|B\(2))) # (\b2v_inst_ac_b|B\(0) & ((\b2v_inst_ac_b|B\(2))))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_b|B\(1) & ( 
-- ((!\b2v_inst_ac_b|B\(3) & (!\b2v_inst_ac_b|B\(0) $ (!\b2v_inst_ac_b|B\(2))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010111110001111001011111000111101001111001111110100111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(3),
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(1),
	combout => \b2v_inst_seg7_B|Mux3~0_combout\);

-- Location: LABCELL_X80_Y7_N48
\b2v_inst_seg7_B|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux2~0_combout\ = ( \SEG~input_o\ ) # ( !\SEG~input_o\ & ( (!\b2v_inst_ac_b|B\(3) & (!\b2v_inst_ac_b|B\(0) & (\b2v_inst_ac_b|B\(1) & !\b2v_inst_ac_b|B\(2)))) # (\b2v_inst_ac_b|B\(3) & (\b2v_inst_ac_b|B\(2) & ((!\b2v_inst_ac_b|B\(0)) # 
-- (\b2v_inst_ac_b|B\(1))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100001000101000010000100010111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(3),
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_ac_b|ALT_INV_B\(1),
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7_B|Mux2~0_combout\);

-- Location: LABCELL_X80_Y7_N57
\b2v_inst_seg7_B|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux1~0_combout\ = ( \SEG~input_o\ ) # ( !\SEG~input_o\ & ( (!\b2v_inst_ac_b|B\(3) & (\b2v_inst_ac_b|B\(2) & (!\b2v_inst_ac_b|B\(0) $ (!\b2v_inst_ac_b|B\(1))))) # (\b2v_inst_ac_b|B\(3) & ((!\b2v_inst_ac_b|B\(0) & (\b2v_inst_ac_b|B\(2))) # 
-- (\b2v_inst_ac_b|B\(0) & ((\b2v_inst_ac_b|B\(1)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001010001010011000101000101001111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(2),
	datab => \b2v_inst_ac_b|ALT_INV_B\(3),
	datac => \b2v_inst_ac_b|ALT_INV_B\(0),
	datad => \b2v_inst_ac_b|ALT_INV_B\(1),
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7_B|Mux1~0_combout\);

-- Location: LABCELL_X80_Y7_N54
\b2v_inst_seg7_B|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux0~0_combout\ = ( \SEG~input_o\ ) # ( !\SEG~input_o\ & ( (!\b2v_inst_ac_b|B\(2) & (\b2v_inst_ac_b|B\(0) & (!\b2v_inst_ac_b|B\(3) $ (\b2v_inst_ac_b|B\(1))))) # (\b2v_inst_ac_b|B\(2) & (!\b2v_inst_ac_b|B\(1) & (!\b2v_inst_ac_b|B\(3) $ 
-- (\b2v_inst_ac_b|B\(0))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000010010010010000001001001011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(2),
	datab => \b2v_inst_ac_b|ALT_INV_B\(3),
	datac => \b2v_inst_ac_b|ALT_INV_B\(1),
	datad => \b2v_inst_ac_b|ALT_INV_B\(0),
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7_B|Mux0~0_combout\);

-- Location: LABCELL_X80_Y8_N30
\b2v_inst_seg7_B|Mux13~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux13~0_combout\ = ( \SEG~input_o\ ) # ( !\SEG~input_o\ & ( (!\b2v_inst_ac_b|B\(4) & (!\b2v_inst_ac_b|B\(5) & (!\b2v_inst_ac_b|B\(6) $ (\b2v_inst_ac_b|B\(7))))) # (\b2v_inst_ac_b|B\(4) & (!\b2v_inst_ac_b|B\(7) & (!\b2v_inst_ac_b|B\(6) $ 
-- (\b2v_inst_ac_b|B\(5))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010000101000000101000010100000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(6),
	datab => \b2v_inst_ac_b|ALT_INV_B\(4),
	datac => \b2v_inst_ac_b|ALT_INV_B\(5),
	datad => \b2v_inst_ac_b|ALT_INV_B\(7),
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7_B|Mux13~0_combout\);

-- Location: LABCELL_X80_Y8_N27
\b2v_inst_seg7_B|Mux12~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux12~0_combout\ = ( \b2v_inst_ac_b|B\(5) & ( ((!\b2v_inst_ac_b|B\(7) & ((!\b2v_inst_ac_b|B\(6)) # (\b2v_inst_ac_b|B\(4))))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_b|B\(5) & ( ((\b2v_inst_ac_b|B\(4) & (!\b2v_inst_ac_b|B\(7) $ 
-- (\b2v_inst_ac_b|B\(6))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101110101010111010111010101011111011101010111011101110101011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_SEG~input_o\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(7),
	datac => \b2v_inst_ac_b|ALT_INV_B\(4),
	datad => \b2v_inst_ac_b|ALT_INV_B\(6),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(5),
	combout => \b2v_inst_seg7_B|Mux12~0_combout\);

-- Location: LABCELL_X80_Y8_N24
\b2v_inst_seg7_B|Mux11~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux11~0_combout\ = ( \b2v_inst_ac_b|B\(4) & ( ((!\b2v_inst_ac_b|B\(7)) # ((!\b2v_inst_ac_b|B\(6) & !\b2v_inst_ac_b|B\(5)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_b|B\(4) & ( ((!\b2v_inst_ac_b|B\(7) & (\b2v_inst_ac_b|B\(6) & 
-- !\b2v_inst_ac_b|B\(5)))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101110101010101010111010101010111111101110111011111110111011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_SEG~input_o\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(7),
	datac => \b2v_inst_ac_b|ALT_INV_B\(6),
	datad => \b2v_inst_ac_b|ALT_INV_B\(5),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(4),
	combout => \b2v_inst_seg7_B|Mux11~0_combout\);

-- Location: LABCELL_X80_Y8_N6
\b2v_inst_seg7_B|Mux10~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux10~0_combout\ = ( \b2v_inst_ac_b|B\(4) & ( \SEG~input_o\ ) ) # ( !\b2v_inst_ac_b|B\(4) & ( \SEG~input_o\ ) ) # ( \b2v_inst_ac_b|B\(4) & ( !\SEG~input_o\ & ( (!\b2v_inst_ac_b|B\(6) & (!\b2v_inst_ac_b|B\(7) & !\b2v_inst_ac_b|B\(5))) # 
-- (\b2v_inst_ac_b|B\(6) & ((\b2v_inst_ac_b|B\(5)))) ) ) ) # ( !\b2v_inst_ac_b|B\(4) & ( !\SEG~input_o\ & ( (!\b2v_inst_ac_b|B\(6) & (\b2v_inst_ac_b|B\(7) & \b2v_inst_ac_b|B\(5))) # (\b2v_inst_ac_b|B\(6) & (!\b2v_inst_ac_b|B\(7) & !\b2v_inst_ac_b|B\(5))) ) ) 
-- )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100001001000010100001011000010111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(6),
	datab => \b2v_inst_ac_b|ALT_INV_B\(7),
	datac => \b2v_inst_ac_b|ALT_INV_B\(5),
	datae => \b2v_inst_ac_b|ALT_INV_B\(4),
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7_B|Mux10~0_combout\);

-- Location: LABCELL_X80_Y8_N15
\b2v_inst_seg7_B|Mux9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux9~0_combout\ = ( \SEG~input_o\ ) # ( !\SEG~input_o\ & ( (!\b2v_inst_ac_b|B\(6) & (!\b2v_inst_ac_b|B\(7) & (!\b2v_inst_ac_b|B\(4) & \b2v_inst_ac_b|B\(5)))) # (\b2v_inst_ac_b|B\(6) & (\b2v_inst_ac_b|B\(7) & ((!\b2v_inst_ac_b|B\(4)) # 
-- (\b2v_inst_ac_b|B\(5))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000010010001000100001001000111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(6),
	datab => \b2v_inst_ac_b|ALT_INV_B\(7),
	datac => \b2v_inst_ac_b|ALT_INV_B\(4),
	datad => \b2v_inst_ac_b|ALT_INV_B\(5),
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7_B|Mux9~0_combout\);

-- Location: LABCELL_X80_Y8_N12
\b2v_inst_seg7_B|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux8~0_combout\ = ( \b2v_inst_ac_b|B\(4) & ( ((!\b2v_inst_ac_b|B\(7) & (\b2v_inst_ac_b|B\(6) & !\b2v_inst_ac_b|B\(5))) # (\b2v_inst_ac_b|B\(7) & ((\b2v_inst_ac_b|B\(5))))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_ac_b|B\(4) & ( 
-- ((\b2v_inst_ac_b|B\(6) & ((\b2v_inst_ac_b|B\(5)) # (\b2v_inst_ac_b|B\(7))))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001010111111111000101011111111101000011111111110100001111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(6),
	datab => \b2v_inst_ac_b|ALT_INV_B\(7),
	datac => \b2v_inst_ac_b|ALT_INV_B\(5),
	datad => \ALT_INV_SEG~input_o\,
	dataf => \b2v_inst_ac_b|ALT_INV_B\(4),
	combout => \b2v_inst_seg7_B|Mux8~0_combout\);

-- Location: LABCELL_X80_Y8_N33
\b2v_inst_seg7_B|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7_B|Mux7~0_combout\ = ( \SEG~input_o\ ) # ( !\SEG~input_o\ & ( (!\b2v_inst_ac_b|B\(6) & (\b2v_inst_ac_b|B\(4) & (!\b2v_inst_ac_b|B\(7) $ (\b2v_inst_ac_b|B\(5))))) # (\b2v_inst_ac_b|B\(6) & (!\b2v_inst_ac_b|B\(5) & (!\b2v_inst_ac_b|B\(4) $ 
-- (\b2v_inst_ac_b|B\(7))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110000100000010011000010000001011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(6),
	datab => \b2v_inst_ac_b|ALT_INV_B\(4),
	datac => \b2v_inst_ac_b|ALT_INV_B\(7),
	datad => \b2v_inst_ac_b|ALT_INV_B\(5),
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7_B|Mux7~0_combout\);

-- Location: LABCELL_X81_Y7_N45
\b2v_inst_alu_8b|Mux4~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~1_combout\ = ( \b2v_inst_ac_s|S\(1) & ( (\b2v_inst_ac_s|S\(0) & (\b2v_inst_ac_s|S\(3) & \b2v_inst_ac_s|S\(2))) ) ) # ( !\b2v_inst_ac_s|S\(1) & ( (!\b2v_inst_ac_s|S\(0) & (\ALU~input_o\ & (!\b2v_inst_ac_s|S\(3) & 
-- !\b2v_inst_ac_s|S\(2)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010000000000000001000000000000000000000000001010000000000000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(0),
	datab => \ALT_INV_ALU~input_o\,
	datac => \b2v_inst_ac_s|ALT_INV_S\(3),
	datad => \b2v_inst_ac_s|ALT_INV_S\(2),
	dataf => \b2v_inst_ac_s|ALT_INV_S\(1),
	combout => \b2v_inst_alu_8b|Mux4~1_combout\);

-- Location: LABCELL_X79_Y6_N27
\b2v_inst_alu_8b|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~0_combout\ = ( \b2v_inst_ac_s|S\(1) & ( (!\ALU~input_o\ & ((!\b2v_inst_ac_s|S\(3) & (!\b2v_inst_ac_s|S\(0) & !\b2v_inst_ac_s|S\(2))) # (\b2v_inst_ac_s|S\(3) & ((\b2v_inst_ac_s|S\(2)))))) ) ) # ( !\b2v_inst_ac_s|S\(1) & ( 
-- (!\b2v_inst_ac_s|S\(2) & ((!\ALU~input_o\ & (\b2v_inst_ac_s|S\(3) & !\b2v_inst_ac_s|S\(0))) # (\ALU~input_o\ & (!\b2v_inst_ac_s|S\(3) & \b2v_inst_ac_s|S\(0))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010010000000000001001000000000010000000001000101000000000100010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(3),
	datac => \b2v_inst_ac_s|ALT_INV_S\(0),
	datad => \b2v_inst_ac_s|ALT_INV_S\(2),
	dataf => \b2v_inst_ac_s|ALT_INV_S\(1),
	combout => \b2v_inst_alu_8b|Mux4~0_combout\);

-- Location: LABCELL_X80_Y8_N36
\b2v_inst_alu_8b|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux6~0_combout\ = ( \b2v_inst_ac_a|A\(2) & ( \b2v_inst_alu_8b|Add0~13_sumout\ & ( (!\ALU~input_o\ & (((\b2v_inst_ac_b|B\(2))))) # (\ALU~input_o\ & (!\b2v_inst_alu_8b|Add1~13_sumout\ & (\b2v_inst_ac_s|S\(0)))) ) ) ) # ( 
-- !\b2v_inst_ac_a|A\(2) & ( \b2v_inst_alu_8b|Add0~13_sumout\ & ( (\b2v_inst_ac_s|S\(0) & ((!\ALU~input_o\ & ((\b2v_inst_ac_b|B\(2)))) # (\ALU~input_o\ & (!\b2v_inst_alu_8b|Add1~13_sumout\)))) ) ) ) # ( \b2v_inst_ac_a|A\(2) & ( 
-- !\b2v_inst_alu_8b|Add0~13_sumout\ & ( (!\ALU~input_o\ & (((\b2v_inst_ac_b|B\(2))))) # (\ALU~input_o\ & ((!\b2v_inst_alu_8b|Add1~13_sumout\) # ((!\b2v_inst_ac_s|S\(0))))) ) ) ) # ( !\b2v_inst_ac_a|A\(2) & ( !\b2v_inst_alu_8b|Add0~13_sumout\ & ( 
-- (!\b2v_inst_ac_s|S\(0) & (((\ALU~input_o\)))) # (\b2v_inst_ac_s|S\(0) & ((!\ALU~input_o\ & ((\b2v_inst_ac_b|B\(2)))) # (\ALU~input_o\ & (!\b2v_inst_alu_8b|Add1~13_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111000111110000011101111111000000010001100100000001011110010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Add1~13_sumout\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \ALT_INV_ALU~input_o\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	datae => \b2v_inst_ac_a|ALT_INV_A\(2),
	dataf => \b2v_inst_alu_8b|ALT_INV_Add0~13_sumout\,
	combout => \b2v_inst_alu_8b|Mux6~0_combout\);

-- Location: MLABCELL_X78_Y6_N15
\b2v_inst_alu_8b|Mux4~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~3_combout\ = ( \b2v_inst_ac_s|S\(1) & ( !\b2v_inst_ac_s|S\(0) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000001010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(0),
	datae => \b2v_inst_ac_s|ALT_INV_S\(1),
	combout => \b2v_inst_alu_8b|Mux4~3_combout\);

-- Location: LABCELL_X81_Y7_N57
\b2v_inst_alu_8b|Mux4~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~4_combout\ = ( \b2v_inst_ac_s|S\(1) & ( (\b2v_inst_ac_s|S\(0)) # (\ALU~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000001110111011101110111011101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	dataf => \b2v_inst_ac_s|ALT_INV_S\(1),
	combout => \b2v_inst_alu_8b|Mux4~4_combout\);

-- Location: LABCELL_X80_Y8_N42
\b2v_inst_alu_8b|Mux6~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux6~1_combout\ = ( \b2v_inst_ac_a|A\(2) & ( \b2v_inst_alu_8b|Mux4~4_combout\ & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_ac_b|B\(2)))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & (\b2v_inst_alu_8b|Add2~13_sumout\)) ) ) ) # ( 
-- !\b2v_inst_ac_a|A\(2) & ( \b2v_inst_alu_8b|Mux4~4_combout\ & ( (\b2v_inst_alu_8b|Mux4~3_combout\ & \b2v_inst_alu_8b|Add2~13_sumout\) ) ) ) # ( \b2v_inst_ac_a|A\(2) & ( !\b2v_inst_alu_8b|Mux4~4_combout\ & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & 
-- (!\b2v_inst_alu_8b|Mux6~0_combout\)) # (\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_ac_b|B\(2)))) ) ) ) # ( !\b2v_inst_ac_a|A\(2) & ( !\b2v_inst_alu_8b|Mux4~4_combout\ & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & (!\b2v_inst_alu_8b|Mux6~0_combout\)) # 
-- (\b2v_inst_alu_8b|Mux4~3_combout\ & ((\b2v_inst_ac_b|B\(2)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000100010111011101110111000100000000011000000111100111100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux6~0_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~3_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Add2~13_sumout\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	datae => \b2v_inst_ac_a|ALT_INV_A\(2),
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux4~4_combout\,
	combout => \b2v_inst_alu_8b|Mux6~1_combout\);

-- Location: LABCELL_X80_Y8_N18
\b2v_inst_alu_8b|Mux6~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux6~2_combout\ = ( \b2v_inst_ac_a|A\(2) & ( \b2v_inst_alu_8b|Mux6~1_combout\ & ( \b2v_inst_ac_s|S\(2) ) ) ) # ( !\b2v_inst_ac_a|A\(2) & ( \b2v_inst_alu_8b|Mux6~1_combout\ & ( ((!\b2v_inst_ac_s|S\(1) & ((!\b2v_inst_ac_b|B\(2)) # 
-- (!\b2v_inst_ac_s|S\(0))))) # (\b2v_inst_ac_s|S\(2)) ) ) ) # ( !\b2v_inst_ac_a|A\(2) & ( !\b2v_inst_alu_8b|Mux6~1_combout\ & ( (!\b2v_inst_ac_s|S\(1) & (!\b2v_inst_ac_s|S\(2) & ((!\b2v_inst_ac_b|B\(2)) # (!\b2v_inst_ac_s|S\(0))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010000010000000000000000000000010101111100011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(1),
	datab => \b2v_inst_ac_b|ALT_INV_B\(2),
	datac => \b2v_inst_ac_s|ALT_INV_S\(2),
	datad => \b2v_inst_ac_s|ALT_INV_S\(0),
	datae => \b2v_inst_ac_a|ALT_INV_A\(2),
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux6~1_combout\,
	combout => \b2v_inst_alu_8b|Mux6~2_combout\);

-- Location: LABCELL_X80_Y6_N15
\b2v_inst_alu_8b|Mux6~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux6~10_combout\ = ( !\b2v_inst_ac_s|S\(1) & ( (!\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_a|A\(1) & ((!\b2v_inst_ac_s|S\(2)) # (\ALU~input_o\)))))) # (\b2v_inst_ac_s|S\(0) & ((((\b2v_inst_alu_8b|Add6~13_sumout\))))) ) ) # ( 
-- \b2v_inst_ac_s|S\(1) & ( (((\b2v_inst_alu_8b|Add7~13_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0000000000110011000011110000111111000100111101110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_alu_8b|ALT_INV_Add7~13_sumout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add6~13_sumout\,
	datae => \b2v_inst_ac_s|ALT_INV_S\(1),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(1),
	datag => \b2v_inst_ac_s|ALT_INV_S\(2),
	combout => \b2v_inst_alu_8b|Mux6~10_combout\);

-- Location: LABCELL_X80_Y7_N33
\b2v_inst_alu_8b|Mux6~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux6~3_combout\ = ( \b2v_inst_ac_a|A\(2) & ( (!\ALU~input_o\ & (((\b2v_inst_ac_b|B\(2))))) # (\ALU~input_o\ & ((!\b2v_inst_ac_s|S\(0) & (\b2v_inst_alu_8b|Add5~13_sumout\)) # (\b2v_inst_ac_s|S\(0) & ((\b2v_inst_ac_b|B\(2)))))) ) ) # ( 
-- !\b2v_inst_ac_a|A\(2) & ( (!\b2v_inst_ac_s|S\(0) & ((!\ALU~input_o\ & ((\b2v_inst_ac_b|B\(2)))) # (\ALU~input_o\ & (\b2v_inst_alu_8b|Add5~13_sumout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000010110000000100001011000000010000101111110001000010111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_alu_8b|ALT_INV_Add5~13_sumout\,
	datac => \b2v_inst_ac_s|ALT_INV_S\(0),
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(2),
	combout => \b2v_inst_alu_8b|Mux6~3_combout\);

-- Location: MLABCELL_X78_Y6_N30
\b2v_inst_alu_8b|Mux4~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~5_combout\ = (!\b2v_inst_ac_s|S\(1) & ((!\b2v_inst_ac_s|S\(0)) # (\ALU~input_o\)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011101100000000101110110000000010111011000000001011101100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(0),
	datab => \ALT_INV_ALU~input_o\,
	datad => \b2v_inst_ac_s|ALT_INV_S\(1),
	combout => \b2v_inst_alu_8b|Mux4~5_combout\);

-- Location: LABCELL_X81_Y7_N42
\b2v_inst_alu_8b|Mux7~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux7~4_combout\ = ( !\b2v_inst_ac_s|S\(1) & ( \b2v_inst_ac_s|S\(0) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_s|ALT_INV_S\(0),
	dataf => \b2v_inst_ac_s|ALT_INV_S\(1),
	combout => \b2v_inst_alu_8b|Mux7~4_combout\);

-- Location: LABCELL_X80_Y7_N39
\b2v_inst_alu_8b|F9~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~8_combout\ = !\b2v_inst_ac_a|A\(2) $ (!\b2v_inst_ac_b|B\(2))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001111001100001100111100110000110011110011000011001111001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(2),
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	combout => \b2v_inst_alu_8b|F9~8_combout\);

-- Location: LABCELL_X80_Y7_N42
\b2v_inst_alu_8b|Mux6~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux6~4_combout\ = ( \b2v_inst_alu_8b|Add4~13_sumout\ & ( \b2v_inst_alu_8b|F9~8_combout\ & ( (!\b2v_inst_alu_8b|Mux4~5_combout\ & (\b2v_inst_alu_8b|Mux6~3_combout\ & (!\b2v_inst_alu_8b|Mux7~4_combout\))) # (\b2v_inst_alu_8b|Mux4~5_combout\ 
-- & (((\b2v_inst_alu_8b|Add3~13_sumout\) # (\b2v_inst_alu_8b|Mux7~4_combout\)))) ) ) ) # ( !\b2v_inst_alu_8b|Add4~13_sumout\ & ( \b2v_inst_alu_8b|F9~8_combout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & ((!\b2v_inst_alu_8b|Mux4~5_combout\ & 
-- (\b2v_inst_alu_8b|Mux6~3_combout\)) # (\b2v_inst_alu_8b|Mux4~5_combout\ & ((\b2v_inst_alu_8b|Add3~13_sumout\))))) ) ) ) # ( \b2v_inst_alu_8b|Add4~13_sumout\ & ( !\b2v_inst_alu_8b|F9~8_combout\ & ( ((!\b2v_inst_alu_8b|Mux4~5_combout\ & 
-- (\b2v_inst_alu_8b|Mux6~3_combout\)) # (\b2v_inst_alu_8b|Mux4~5_combout\ & ((\b2v_inst_alu_8b|Add3~13_sumout\)))) # (\b2v_inst_alu_8b|Mux7~4_combout\) ) ) ) # ( !\b2v_inst_alu_8b|Add4~13_sumout\ & ( !\b2v_inst_alu_8b|F9~8_combout\ & ( 
-- (!\b2v_inst_alu_8b|Mux4~5_combout\ & (((\b2v_inst_alu_8b|Mux7~4_combout\)) # (\b2v_inst_alu_8b|Mux6~3_combout\))) # (\b2v_inst_alu_8b|Mux4~5_combout\ & (((!\b2v_inst_alu_8b|Mux7~4_combout\ & \b2v_inst_alu_8b|Add3~13_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100110001111100010011110111111101000000011100000100001101110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux6~3_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~5_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux7~4_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add3~13_sumout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Add4~13_sumout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_F9~8_combout\,
	combout => \b2v_inst_alu_8b|Mux6~4_combout\);

-- Location: LABCELL_X79_Y6_N24
\b2v_inst_alu_8b|Mux4~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~7_combout\ = ( \b2v_inst_alu_8b|Mux7~4_combout\ & ( (\b2v_inst_ac_s|S\(3) & ((!\b2v_inst_ac_s|S\(2)) # (\ALU~input_o\))) ) ) # ( !\b2v_inst_alu_8b|Mux7~4_combout\ & ( \b2v_inst_ac_s|S\(3) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011000100010011001100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(3),
	datad => \b2v_inst_ac_s|ALT_INV_S\(2),
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux7~4_combout\,
	combout => \b2v_inst_alu_8b|Mux4~7_combout\);

-- Location: LABCELL_X81_Y7_N3
\b2v_inst_alu_8b|Mux4~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~6_combout\ = ( \b2v_inst_ac_s|S\(1) & ( (!\b2v_inst_ac_s|S\(0) & ((!\b2v_inst_ac_s|S\(3) $ (!\b2v_inst_ac_s|S\(2))))) # (\b2v_inst_ac_s|S\(0) & ((!\b2v_inst_ac_s|S\(2)) # ((!\ALU~input_o\ & !\b2v_inst_ac_s|S\(3))))) ) ) # ( 
-- !\b2v_inst_ac_s|S\(1) & ( (!\b2v_inst_ac_s|S\(3)) # (!\b2v_inst_ac_s|S\(2)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111110000111111111111000000111111111000000011111111100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_ac_s|ALT_INV_S\(3),
	datad => \b2v_inst_ac_s|ALT_INV_S\(2),
	dataf => \b2v_inst_ac_s|ALT_INV_S\(1),
	combout => \b2v_inst_alu_8b|Mux4~6_combout\);

-- Location: LABCELL_X80_Y8_N0
\b2v_inst_alu_8b|Mux6~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux6~6_combout\ = ( !\b2v_inst_alu_8b|Mux4~7_combout\ & ( ((!\b2v_inst_alu_8b|Mux4~6_combout\ & (((!\b2v_inst_ac_b|B\(2)) # (\b2v_inst_ac_a|A\(2))))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & (\b2v_inst_alu_8b|Mux6~2_combout\))) ) ) # ( 
-- \b2v_inst_alu_8b|Mux4~7_combout\ & ( (((!\b2v_inst_alu_8b|Mux4~6_combout\ & (\b2v_inst_alu_8b|Mux6~10_combout\)) # (\b2v_inst_alu_8b|Mux4~6_combout\ & ((\b2v_inst_alu_8b|Mux6~4_combout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1100111111001111000011110000111101010101010101010000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux6~2_combout\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(2),
	datac => \b2v_inst_alu_8b|ALT_INV_Mux6~10_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux6~4_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~7_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux4~6_combout\,
	datag => \b2v_inst_ac_a|ALT_INV_A\(2),
	combout => \b2v_inst_alu_8b|Mux6~6_combout\);

-- Location: LABCELL_X81_Y7_N51
\b2v_inst_alu_8b|Mux4~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~2_combout\ = ( \b2v_inst_ac_s|S\(1) & ( (\b2v_inst_ac_s|S\(3) & (\b2v_inst_ac_s|S\(2) & ((!\ALU~input_o\) # (\b2v_inst_ac_s|S\(0))))) ) ) # ( !\b2v_inst_ac_s|S\(1) & ( (\ALU~input_o\ & (!\b2v_inst_ac_s|S\(3) & !\b2v_inst_ac_s|S\(2))) 
-- ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000000000000010100000000000000000000000010110000000000001011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_ac_s|ALT_INV_S\(3),
	datad => \b2v_inst_ac_s|ALT_INV_S\(2),
	dataf => \b2v_inst_ac_s|ALT_INV_S\(1),
	combout => \b2v_inst_alu_8b|Mux4~2_combout\);

-- Location: LABCELL_X83_Y8_N36
\b2v_inst_alu_8b|Mux6~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux6~5_combout\ = ( \b2v_inst_alu_8b|Mux4~2_combout\ & ( \b2v_inst_ac_a|A\(2) ) ) # ( !\b2v_inst_alu_8b|Mux4~2_combout\ & ( \b2v_inst_ac_a|A\(2) & ( (\b2v_inst_alu_8b|Mux6~6_combout\ & ((!\b2v_inst_alu_8b|Mux4~0_combout\) # 
-- (\b2v_inst_alu_8b|Mux4~1_combout\))) ) ) ) # ( \b2v_inst_alu_8b|Mux4~2_combout\ & ( !\b2v_inst_ac_a|A\(2) & ( (!\b2v_inst_alu_8b|Mux4~1_combout\ & (\b2v_inst_alu_8b|Mux4~0_combout\ & \b2v_inst_ac_b|B\(2))) ) ) ) # ( !\b2v_inst_alu_8b|Mux4~2_combout\ & ( 
-- !\b2v_inst_ac_a|A\(2) & ( (!\b2v_inst_alu_8b|Mux4~1_combout\ & ((!\b2v_inst_alu_8b|Mux4~0_combout\ & (\b2v_inst_alu_8b|Mux6~6_combout\)) # (\b2v_inst_alu_8b|Mux4~0_combout\ & ((\b2v_inst_ac_b|B\(2)))))) # (\b2v_inst_alu_8b|Mux4~1_combout\ & 
-- (((\b2v_inst_alu_8b|Mux6~6_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110100101111000000000010001000001101000011011111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~1_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~0_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux6~6_combout\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(2),
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~2_combout\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(2),
	combout => \b2v_inst_alu_8b|Mux6~5_combout\);

-- Location: LABCELL_X83_Y5_N33
\b2v_inst_alu_8b|F9~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~5_combout\ = (!\ALU~input_o\ & (!\b2v_inst_ac_b|B\(0))) # (\ALU~input_o\ & ((\b2v_inst_alu_8b|Add1~5_sumout\)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000110110001101100011011000110110001101100011011000110110001101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_alu_8b|ALT_INV_Add1~5_sumout\,
	combout => \b2v_inst_alu_8b|F9~5_combout\);

-- Location: LABCELL_X83_Y5_N39
\b2v_inst_alu_8b|F9~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~4_combout\ = !\ALU~input_o\ $ (((!\b2v_inst_ac_b|B\(0) & !\b2v_inst_ac_a|A\(0))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110101001101010011010100110101001101010011010100110101001101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_ac_a|ALT_INV_A\(0),
	combout => \b2v_inst_alu_8b|F9~4_combout\);

-- Location: LABCELL_X79_Y6_N18
\b2v_inst_alu_8b|F9~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~6_combout\ = ( \b2v_inst_ac_a|A\(0) & ( (!\ALU~input_o\) # (\b2v_inst_alu_8b|Add6~5_sumout\) ) ) # ( !\b2v_inst_ac_a|A\(0) & ( (!\ALU~input_o\ & ((!\b2v_inst_ac_b|B\(0)))) # (\ALU~input_o\ & (\b2v_inst_alu_8b|Add6~5_sumout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010111100000101101011110000010110101111101011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datac => \b2v_inst_alu_8b|ALT_INV_Add6~5_sumout\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(0),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(0),
	combout => \b2v_inst_alu_8b|F9~6_combout\);

-- Location: LABCELL_X83_Y5_N0
\b2v_inst_alu_8b|Mux8~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux8~3_combout\ = ( !\b2v_inst_ac_s|S\(2) & ( (!\b2v_inst_ac_s|S\(3) & ((((!\b2v_inst_alu_8b|F9~4_combout\))))) # (\b2v_inst_ac_s|S\(3) & (!\b2v_inst_alu_8b|Add4~5_sumout\ $ ((\ALU~input_o\)))) ) ) # ( \b2v_inst_ac_s|S\(2) & ( 
-- ((!\b2v_inst_ac_s|S\(3) & (\b2v_inst_alu_8b|F9~5_combout\)) # (\b2v_inst_ac_s|S\(3) & (((\b2v_inst_alu_8b|F9~6_combout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1110110100100001000011000000110011101101001000010011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Add4~5_sumout\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(3),
	datac => \b2v_inst_alu_8b|ALT_INV_F9~5_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_F9~4_combout\,
	datae => \b2v_inst_ac_s|ALT_INV_S\(2),
	dataf => \b2v_inst_alu_8b|ALT_INV_F9~6_combout\,
	datag => \ALT_INV_ALU~input_o\,
	combout => \b2v_inst_alu_8b|Mux8~3_combout\);

-- Location: LABCELL_X83_Y5_N36
\b2v_inst_alu_8b|Mux8~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux8~1_combout\ = ( \b2v_inst_ac_a|A\(0) & ( (!\b2v_inst_ac_b|B\(0) & (((\b2v_inst_ac_s|S\(2))))) # (\b2v_inst_ac_b|B\(0) & (((\ALU~input_o\ & \b2v_inst_ac_s|S\(2))) # (\b2v_inst_ac_s|S\(3)))) ) ) # ( !\b2v_inst_ac_a|A\(0) & ( 
-- (\ALU~input_o\ & (!\b2v_inst_ac_b|B\(0) & (!\b2v_inst_ac_s|S\(3) & \b2v_inst_ac_s|S\(2)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001000000000000000100000000000011110111110000001111011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_ac_s|ALT_INV_S\(3),
	datad => \b2v_inst_ac_s|ALT_INV_S\(2),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(0),
	combout => \b2v_inst_alu_8b|Mux8~1_combout\);

-- Location: LABCELL_X83_Y5_N6
\b2v_inst_alu_8b|Mux8~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux8~7_combout\ = ( !\ALU~input_o\ & ( (!\b2v_inst_ac_s|S\(3) & (((!\b2v_inst_ac_a|A\(0)) # ((\b2v_inst_ac_s|S\(2) & !\b2v_inst_ac_b|B\(0)))))) # (\b2v_inst_ac_s|S\(3) & (!\b2v_inst_ac_s|S\(2) & (\b2v_inst_ac_b|B\(0) & 
-- ((!\b2v_inst_ac_a|A\(0)))))) ) ) # ( \ALU~input_o\ & ( (!\b2v_inst_ac_s|S\(3) & ((!\b2v_inst_ac_s|S\(2) & (((\b2v_inst_ac_a|A\(0))))) # (\b2v_inst_ac_s|S\(2) & (\b2v_inst_alu_8b|Add0~5_sumout\)))) # (\b2v_inst_ac_s|S\(3) & (!\b2v_inst_ac_s|S\(2) & 
-- (((\b2v_inst_alu_8b|Add3~5_sumout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1010111010101110000000100100011000100000001000001000101011001110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(3),
	datab => \b2v_inst_ac_s|ALT_INV_S\(2),
	datac => \b2v_inst_alu_8b|ALT_INV_Add0~5_sumout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add3~5_sumout\,
	datae => \ALT_INV_ALU~input_o\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(0),
	datag => \b2v_inst_ac_b|ALT_INV_B\(0),
	combout => \b2v_inst_alu_8b|Mux8~7_combout\);

-- Location: MLABCELL_X82_Y6_N33
\b2v_inst_alu_8b|F9~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~1_combout\ = ( \ALU~input_o\ & ( \b2v_inst_alu_8b|Add5~5_sumout\ ) ) # ( !\ALU~input_o\ & ( \b2v_inst_alu_8b|Add5~5_sumout\ & ( \b2v_inst_ac_b|B\(0) ) ) ) # ( !\ALU~input_o\ & ( !\b2v_inst_alu_8b|Add5~5_sumout\ & ( \b2v_inst_ac_b|B\(0) 
-- ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000000000000000000001111000011111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_b|ALT_INV_B\(0),
	datae => \ALT_INV_ALU~input_o\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Add5~5_sumout\,
	combout => \b2v_inst_alu_8b|F9~1_combout\);

-- Location: LABCELL_X83_Y5_N57
\b2v_inst_alu_8b|F9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~0_combout\ = !\ALU~input_o\ $ (((!\b2v_inst_ac_b|B\(0)) # (\b2v_inst_ac_a|A\(0))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101101001010101010110100101010101011010010101010101101001010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datac => \b2v_inst_ac_b|ALT_INV_B\(0),
	datad => \b2v_inst_ac_a|ALT_INV_A\(0),
	combout => \b2v_inst_alu_8b|F9~0_combout\);

-- Location: LABCELL_X83_Y5_N54
\b2v_inst_alu_8b|F9~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~2_combout\ = (!\ALU~input_o\ & (\b2v_inst_alu_8b|Add4~5_sumout\)) # (\ALU~input_o\ & ((\b2v_inst_alu_8b|Add2~5_sumout\)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101001011111000010100101111100001010010111110000101001011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datac => \b2v_inst_alu_8b|ALT_INV_Add4~5_sumout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add2~5_sumout\,
	combout => \b2v_inst_alu_8b|F9~2_combout\);

-- Location: LABCELL_X83_Y5_N30
\b2v_inst_alu_8b|F9~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~3_combout\ = (!\ALU~input_o\ & (!\b2v_inst_ac_b|B\(0) & ((!\b2v_inst_ac_a|A\(0))))) # (\ALU~input_o\ & (((!\b2v_inst_alu_8b|Add7~5_sumout\))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101100001010000110110000101000011011000010100001101100001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(0),
	datac => \b2v_inst_alu_8b|ALT_INV_Add7~5_sumout\,
	datad => \b2v_inst_ac_a|ALT_INV_A\(0),
	combout => \b2v_inst_alu_8b|F9~3_combout\);

-- Location: LABCELL_X83_Y5_N48
\b2v_inst_alu_8b|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux8~0_combout\ = ( \b2v_inst_alu_8b|F9~2_combout\ & ( \b2v_inst_alu_8b|F9~3_combout\ & ( (!\b2v_inst_ac_s|S\(3) & (((\b2v_inst_ac_s|S\(2)) # (\b2v_inst_alu_8b|F9~0_combout\)))) # (\b2v_inst_ac_s|S\(3) & (\b2v_inst_alu_8b|F9~1_combout\ & 
-- ((!\b2v_inst_ac_s|S\(2))))) ) ) ) # ( !\b2v_inst_alu_8b|F9~2_combout\ & ( \b2v_inst_alu_8b|F9~3_combout\ & ( (!\b2v_inst_ac_s|S\(2) & ((!\b2v_inst_ac_s|S\(3) & ((\b2v_inst_alu_8b|F9~0_combout\))) # (\b2v_inst_ac_s|S\(3) & 
-- (\b2v_inst_alu_8b|F9~1_combout\)))) ) ) ) # ( \b2v_inst_alu_8b|F9~2_combout\ & ( !\b2v_inst_alu_8b|F9~3_combout\ & ( ((!\b2v_inst_ac_s|S\(3) & ((\b2v_inst_alu_8b|F9~0_combout\))) # (\b2v_inst_ac_s|S\(3) & (\b2v_inst_alu_8b|F9~1_combout\))) # 
-- (\b2v_inst_ac_s|S\(2)) ) ) ) # ( !\b2v_inst_alu_8b|F9~2_combout\ & ( !\b2v_inst_alu_8b|F9~3_combout\ & ( (!\b2v_inst_ac_s|S\(3) & (((\b2v_inst_alu_8b|F9~0_combout\ & !\b2v_inst_ac_s|S\(2))))) # (\b2v_inst_ac_s|S\(3) & (((\b2v_inst_ac_s|S\(2))) # 
-- (\b2v_inst_alu_8b|F9~1_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011010100001111001101011111111100110101000000000011010111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_F9~1_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_F9~0_combout\,
	datac => \b2v_inst_ac_s|ALT_INV_S\(3),
	datad => \b2v_inst_ac_s|ALT_INV_S\(2),
	datae => \b2v_inst_alu_8b|ALT_INV_F9~2_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_F9~3_combout\,
	combout => \b2v_inst_alu_8b|Mux8~0_combout\);

-- Location: LABCELL_X83_Y5_N12
\b2v_inst_alu_8b|Mux8~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux8~2_combout\ = ( \b2v_inst_ac_s|S\(1) & ( \b2v_inst_alu_8b|Mux8~0_combout\ & ( (!\b2v_inst_ac_s|S\(0)) # (\b2v_inst_alu_8b|Mux8~1_combout\) ) ) ) # ( !\b2v_inst_ac_s|S\(1) & ( \b2v_inst_alu_8b|Mux8~0_combout\ & ( (!\b2v_inst_ac_s|S\(0) 
-- & ((\b2v_inst_alu_8b|Mux8~7_combout\))) # (\b2v_inst_ac_s|S\(0) & (\b2v_inst_alu_8b|Mux8~3_combout\)) ) ) ) # ( \b2v_inst_ac_s|S\(1) & ( !\b2v_inst_alu_8b|Mux8~0_combout\ & ( (\b2v_inst_ac_s|S\(0) & \b2v_inst_alu_8b|Mux8~1_combout\) ) ) ) # ( 
-- !\b2v_inst_ac_s|S\(1) & ( !\b2v_inst_alu_8b|Mux8~0_combout\ & ( (!\b2v_inst_ac_s|S\(0) & ((\b2v_inst_alu_8b|Mux8~7_combout\))) # (\b2v_inst_ac_s|S\(0) & (\b2v_inst_alu_8b|Mux8~3_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000111011101000000110000001100010001110111011100111111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux8~3_combout\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_alu_8b|ALT_INV_Mux8~1_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux8~7_combout\,
	datae => \b2v_inst_ac_s|ALT_INV_S\(1),
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux8~0_combout\,
	combout => \b2v_inst_alu_8b|Mux8~2_combout\);

-- Location: MLABCELL_X82_Y6_N39
\b2v_inst_alu_8b|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux7~0_combout\ = ( \b2v_inst_ac_b|B\(1) & ( \b2v_inst_ac_a|A\(1) & ( (!\ALU~input_o\) # ((!\b2v_inst_ac_s|S\(0) & (!\b2v_inst_alu_8b|Add0~9_sumout\)) # (\b2v_inst_ac_s|S\(0) & ((!\b2v_inst_alu_8b|Add1~9_sumout\)))) ) ) ) # ( 
-- !\b2v_inst_ac_b|B\(1) & ( \b2v_inst_ac_a|A\(1) & ( (\ALU~input_o\ & ((!\b2v_inst_ac_s|S\(0) & (!\b2v_inst_alu_8b|Add0~9_sumout\)) # (\b2v_inst_ac_s|S\(0) & ((!\b2v_inst_alu_8b|Add1~9_sumout\))))) ) ) ) # ( \b2v_inst_ac_b|B\(1) & ( !\b2v_inst_ac_a|A\(1) & 
-- ( (!\b2v_inst_ac_s|S\(0) & (!\b2v_inst_alu_8b|Add0~9_sumout\ & (\ALU~input_o\))) # (\b2v_inst_ac_s|S\(0) & (((!\ALU~input_o\) # (!\b2v_inst_alu_8b|Add1~9_sumout\)))) ) ) ) # ( !\b2v_inst_ac_b|B\(1) & ( !\b2v_inst_ac_a|A\(1) & ( (\ALU~input_o\ & 
-- ((!\b2v_inst_ac_s|S\(0) & (!\b2v_inst_alu_8b|Add0~9_sumout\)) # (\b2v_inst_ac_s|S\(0) & ((!\b2v_inst_alu_8b|Add1~9_sumout\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101100001000001110110011100000001011000010001111101111111000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Add0~9_sumout\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \ALT_INV_ALU~input_o\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add1~9_sumout\,
	datae => \b2v_inst_ac_b|ALT_INV_B\(1),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(1),
	combout => \b2v_inst_alu_8b|Mux7~0_combout\);

-- Location: MLABCELL_X78_Y6_N18
\b2v_inst_alu_8b|Mux7~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux7~1_combout\ = ( \b2v_inst_ac_a|A\(1) & ( \b2v_inst_ac_b|B\(1) & ( (!\b2v_inst_alu_8b|Mux4~4_combout\ & (!\b2v_inst_alu_8b|Mux4~3_combout\ & (!\b2v_inst_alu_8b|Mux7~0_combout\))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & 
-- (\b2v_inst_alu_8b|Mux4~3_combout\ & ((\b2v_inst_alu_8b|Add2~9_sumout\)))) ) ) ) # ( !\b2v_inst_ac_a|A\(1) & ( \b2v_inst_ac_b|B\(1) & ( (!\b2v_inst_alu_8b|Mux4~4_combout\ & (((!\b2v_inst_alu_8b|Mux7~0_combout\)) # (\b2v_inst_alu_8b|Mux4~3_combout\))) # 
-- (\b2v_inst_alu_8b|Mux4~4_combout\ & (\b2v_inst_alu_8b|Mux4~3_combout\ & ((\b2v_inst_alu_8b|Add2~9_sumout\)))) ) ) ) # ( \b2v_inst_ac_a|A\(1) & ( !\b2v_inst_ac_b|B\(1) & ( (!\b2v_inst_alu_8b|Mux4~4_combout\ & (((!\b2v_inst_alu_8b|Mux7~0_combout\)) # 
-- (\b2v_inst_alu_8b|Mux4~3_combout\))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & ((!\b2v_inst_alu_8b|Mux4~3_combout\) # ((\b2v_inst_alu_8b|Add2~9_sumout\)))) ) ) ) # ( !\b2v_inst_ac_a|A\(1) & ( !\b2v_inst_ac_b|B\(1) & ( (!\b2v_inst_alu_8b|Mux4~4_combout\ & 
-- (!\b2v_inst_alu_8b|Mux4~3_combout\ & (!\b2v_inst_alu_8b|Mux7~0_combout\))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & (\b2v_inst_alu_8b|Mux4~3_combout\ & ((\b2v_inst_alu_8b|Add2~9_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000010010001111001101111011110100010101100111000000010010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~4_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~3_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux7~0_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add2~9_sumout\,
	datae => \b2v_inst_ac_a|ALT_INV_A\(1),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(1),
	combout => \b2v_inst_alu_8b|Mux7~1_combout\);

-- Location: MLABCELL_X78_Y6_N24
\b2v_inst_alu_8b|Mux7~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux7~2_combout\ = ( \b2v_inst_ac_a|A\(1) & ( \b2v_inst_ac_b|B\(1) & ( (\b2v_inst_ac_s|S\(2) & \b2v_inst_alu_8b|Mux7~1_combout\) ) ) ) # ( !\b2v_inst_ac_a|A\(1) & ( \b2v_inst_ac_b|B\(1) & ( (!\b2v_inst_ac_s|S\(2) & (!\b2v_inst_ac_s|S\(0) & 
-- ((!\b2v_inst_ac_s|S\(1))))) # (\b2v_inst_ac_s|S\(2) & (((\b2v_inst_alu_8b|Mux7~1_combout\)))) ) ) ) # ( \b2v_inst_ac_a|A\(1) & ( !\b2v_inst_ac_b|B\(1) & ( (\b2v_inst_ac_s|S\(2) & \b2v_inst_alu_8b|Mux7~1_combout\) ) ) ) # ( !\b2v_inst_ac_a|A\(1) & ( 
-- !\b2v_inst_ac_b|B\(1) & ( (!\b2v_inst_ac_s|S\(2) & ((!\b2v_inst_ac_s|S\(1)))) # (\b2v_inst_ac_s|S\(2) & (\b2v_inst_alu_8b|Mux7~1_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100111100000011000000110000001110001011000000110000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(0),
	datab => \b2v_inst_ac_s|ALT_INV_S\(2),
	datac => \b2v_inst_alu_8b|ALT_INV_Mux7~1_combout\,
	datad => \b2v_inst_ac_s|ALT_INV_S\(1),
	datae => \b2v_inst_ac_a|ALT_INV_A\(1),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(1),
	combout => \b2v_inst_alu_8b|Mux7~2_combout\);

-- Location: LABCELL_X80_Y7_N30
\b2v_inst_alu_8b|F9~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~7_combout\ = !\b2v_inst_ac_b|B\(1) $ (!\b2v_inst_ac_a|A\(1))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111111110000000011111111000000001111111100000000111111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_b|ALT_INV_B\(1),
	datad => \b2v_inst_ac_a|ALT_INV_A\(1),
	combout => \b2v_inst_alu_8b|F9~7_combout\);

-- Location: MLABCELL_X78_Y6_N33
\b2v_inst_alu_8b|Mux7~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux7~3_combout\ = ( \b2v_inst_ac_b|B\(1) & ( (!\b2v_inst_ac_s|S\(0) & ((!\ALU~input_o\) # ((\b2v_inst_alu_8b|Add5~9_sumout\)))) # (\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_a|A\(1))))) ) ) # ( !\b2v_inst_ac_b|B\(1) & ( (!\b2v_inst_ac_s|S\(0) 
-- & (\ALU~input_o\ & \b2v_inst_alu_8b|Add5~9_sumout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000000010000000100000001010001010110111111000101011011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(0),
	datab => \ALT_INV_ALU~input_o\,
	datac => \b2v_inst_alu_8b|ALT_INV_Add5~9_sumout\,
	datad => \b2v_inst_ac_a|ALT_INV_A\(1),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(1),
	combout => \b2v_inst_alu_8b|Mux7~3_combout\);

-- Location: LABCELL_X79_Y7_N42
\b2v_inst_alu_8b|Mux7~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux7~5_combout\ = ( \b2v_inst_alu_8b|Add3~9_sumout\ & ( \b2v_inst_alu_8b|Mux7~4_combout\ & ( (!\b2v_inst_alu_8b|Mux4~5_combout\ & (!\b2v_inst_alu_8b|F9~7_combout\)) # (\b2v_inst_alu_8b|Mux4~5_combout\ & 
-- ((\b2v_inst_alu_8b|Add4~9_sumout\))) ) ) ) # ( !\b2v_inst_alu_8b|Add3~9_sumout\ & ( \b2v_inst_alu_8b|Mux7~4_combout\ & ( (!\b2v_inst_alu_8b|Mux4~5_combout\ & (!\b2v_inst_alu_8b|F9~7_combout\)) # (\b2v_inst_alu_8b|Mux4~5_combout\ & 
-- ((\b2v_inst_alu_8b|Add4~9_sumout\))) ) ) ) # ( \b2v_inst_alu_8b|Add3~9_sumout\ & ( !\b2v_inst_alu_8b|Mux7~4_combout\ & ( (\b2v_inst_alu_8b|Mux7~3_combout\) # (\b2v_inst_alu_8b|Mux4~5_combout\) ) ) ) # ( !\b2v_inst_alu_8b|Add3~9_sumout\ & ( 
-- !\b2v_inst_alu_8b|Mux7~4_combout\ & ( (!\b2v_inst_alu_8b|Mux4~5_combout\ & \b2v_inst_alu_8b|Mux7~3_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000001100001111110011111110001000101110111000100010111011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_F9~7_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~5_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux7~3_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add4~9_sumout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Add3~9_sumout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux7~4_combout\,
	combout => \b2v_inst_alu_8b|Mux7~5_combout\);

-- Location: MLABCELL_X78_Y6_N36
\b2v_inst_alu_8b|Mux7~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux7~11_combout\ = ( !\b2v_inst_ac_s|S\(1) & ( (!\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_a|A\(0) & ((!\b2v_inst_ac_s|S\(2)) # (\ALU~input_o\)))))) # (\b2v_inst_ac_s|S\(0) & (\b2v_inst_alu_8b|Add6~9_sumout\)) ) ) # ( \b2v_inst_ac_s|S\(1) & 
-- ( (((\b2v_inst_alu_8b|Add7~9_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0001000110110001000011110000111100010001101110110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(0),
	datab => \b2v_inst_alu_8b|ALT_INV_Add6~9_sumout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Add7~9_sumout\,
	datad => \b2v_inst_ac_a|ALT_INV_A\(0),
	datae => \b2v_inst_ac_s|ALT_INV_S\(1),
	dataf => \ALT_INV_ALU~input_o\,
	datag => \b2v_inst_ac_s|ALT_INV_S\(2),
	combout => \b2v_inst_alu_8b|Mux7~11_combout\);

-- Location: MLABCELL_X78_Y6_N0
\b2v_inst_alu_8b|Mux7~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux7~7_combout\ = ( !\b2v_inst_alu_8b|Mux4~7_combout\ & ( ((!\b2v_inst_alu_8b|Mux4~6_combout\ & (((!\b2v_inst_ac_b|B\(1)) # (\b2v_inst_ac_a|A\(1))))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & (\b2v_inst_alu_8b|Mux7~2_combout\))) ) ) # ( 
-- \b2v_inst_alu_8b|Mux4~7_combout\ & ( ((!\b2v_inst_alu_8b|Mux4~6_combout\ & (((\b2v_inst_alu_8b|Mux7~11_combout\)))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & (\b2v_inst_alu_8b|Mux7~5_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1111111101010101000011110011001100001111010101010000111100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux7~2_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux7~5_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux7~11_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~6_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~7_combout\,
	dataf => \b2v_inst_ac_b|ALT_INV_B\(1),
	datag => \b2v_inst_ac_a|ALT_INV_A\(1),
	combout => \b2v_inst_alu_8b|Mux7~7_combout\);

-- Location: LABCELL_X83_Y8_N0
\b2v_inst_alu_8b|Mux7~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux7~6_combout\ = ( \b2v_inst_alu_8b|Mux7~7_combout\ & ( \b2v_inst_ac_a|A\(1) & ( ((!\b2v_inst_alu_8b|Mux4~0_combout\) # (\b2v_inst_alu_8b|Mux4~1_combout\)) # (\b2v_inst_alu_8b|Mux4~2_combout\) ) ) ) # ( !\b2v_inst_alu_8b|Mux7~7_combout\ 
-- & ( \b2v_inst_ac_a|A\(1) & ( \b2v_inst_alu_8b|Mux4~2_combout\ ) ) ) # ( \b2v_inst_alu_8b|Mux7~7_combout\ & ( !\b2v_inst_ac_a|A\(1) & ( (!\b2v_inst_alu_8b|Mux4~1_combout\ & ((!\b2v_inst_alu_8b|Mux4~0_combout\ & (!\b2v_inst_alu_8b|Mux4~2_combout\)) # 
-- (\b2v_inst_alu_8b|Mux4~0_combout\ & ((\b2v_inst_ac_b|B\(1)))))) # (\b2v_inst_alu_8b|Mux4~1_combout\ & (!\b2v_inst_alu_8b|Mux4~2_combout\)) ) ) ) # ( !\b2v_inst_alu_8b|Mux7~7_combout\ & ( !\b2v_inst_ac_a|A\(1) & ( (\b2v_inst_ac_b|B\(1) & 
-- (!\b2v_inst_alu_8b|Mux4~1_combout\ & \b2v_inst_alu_8b|Mux4~0_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000110000101010100011101001010101010101011111111101011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~2_combout\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(1),
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~1_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~0_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux7~7_combout\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(1),
	combout => \b2v_inst_alu_8b|Mux7~6_combout\);

-- Location: LABCELL_X83_Y6_N6
\b2v_inst_alu_8b|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux5~0_combout\ = ( \b2v_inst_ac_a|A\(3) & ( \b2v_inst_alu_8b|Add0~17_sumout\ & ( (!\ALU~input_o\ & (((\b2v_inst_ac_b|B\(3))))) # (\ALU~input_o\ & (\b2v_inst_ac_s|S\(0) & ((!\b2v_inst_alu_8b|Add1~17_sumout\)))) ) ) ) # ( 
-- !\b2v_inst_ac_a|A\(3) & ( \b2v_inst_alu_8b|Add0~17_sumout\ & ( (\b2v_inst_ac_s|S\(0) & ((!\ALU~input_o\ & (\b2v_inst_ac_b|B\(3))) # (\ALU~input_o\ & ((!\b2v_inst_alu_8b|Add1~17_sumout\))))) ) ) ) # ( \b2v_inst_ac_a|A\(3) & ( 
-- !\b2v_inst_alu_8b|Add0~17_sumout\ & ( (!\ALU~input_o\ & (((\b2v_inst_ac_b|B\(3))))) # (\ALU~input_o\ & ((!\b2v_inst_ac_s|S\(0)) # ((!\b2v_inst_alu_8b|Add1~17_sumout\)))) ) ) ) # ( !\b2v_inst_ac_a|A\(3) & ( !\b2v_inst_alu_8b|Add0~17_sumout\ & ( 
-- (!\ALU~input_o\ & (\b2v_inst_ac_s|S\(0) & (\b2v_inst_ac_b|B\(3)))) # (\ALU~input_o\ & ((!\b2v_inst_ac_s|S\(0)) # ((!\b2v_inst_alu_8b|Add1~17_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101011101000110010111110100111000010011000000100001101100001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_ac_b|ALT_INV_B\(3),
	datad => \b2v_inst_alu_8b|ALT_INV_Add1~17_sumout\,
	datae => \b2v_inst_ac_a|ALT_INV_A\(3),
	dataf => \b2v_inst_alu_8b|ALT_INV_Add0~17_sumout\,
	combout => \b2v_inst_alu_8b|Mux5~0_combout\);

-- Location: MLABCELL_X78_Y5_N0
\b2v_inst_alu_8b|Mux5~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux5~1_combout\ = ( \b2v_inst_ac_b|B\(3) & ( \b2v_inst_ac_a|A\(3) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & (!\b2v_inst_alu_8b|Mux5~0_combout\ & ((!\b2v_inst_alu_8b|Mux4~4_combout\)))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & 
-- (((\b2v_inst_alu_8b|Add2~17_sumout\ & \b2v_inst_alu_8b|Mux4~4_combout\)))) ) ) ) # ( !\b2v_inst_ac_b|B\(3) & ( \b2v_inst_ac_a|A\(3) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux5~0_combout\) # ((\b2v_inst_alu_8b|Mux4~4_combout\)))) # 
-- (\b2v_inst_alu_8b|Mux4~3_combout\ & (((!\b2v_inst_alu_8b|Mux4~4_combout\) # (\b2v_inst_alu_8b|Add2~17_sumout\)))) ) ) ) # ( \b2v_inst_ac_b|B\(3) & ( !\b2v_inst_ac_a|A\(3) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & (!\b2v_inst_alu_8b|Mux5~0_combout\ & 
-- ((!\b2v_inst_alu_8b|Mux4~4_combout\)))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & (((!\b2v_inst_alu_8b|Mux4~4_combout\) # (\b2v_inst_alu_8b|Add2~17_sumout\)))) ) ) ) # ( !\b2v_inst_ac_b|B\(3) & ( !\b2v_inst_ac_a|A\(3) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & 
-- (!\b2v_inst_alu_8b|Mux5~0_combout\ & ((!\b2v_inst_alu_8b|Mux4~4_combout\)))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & (((\b2v_inst_alu_8b|Add2~17_sumout\ & \b2v_inst_alu_8b|Mux4~4_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010000000000011101011110000001110101111111100111010000000000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux5~0_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Add2~17_sumout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~3_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~4_combout\,
	datae => \b2v_inst_ac_b|ALT_INV_B\(3),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(3),
	combout => \b2v_inst_alu_8b|Mux5~1_combout\);

-- Location: LABCELL_X81_Y7_N6
\b2v_inst_alu_8b|Mux5~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux5~2_combout\ = ( \b2v_inst_alu_8b|Mux5~1_combout\ & ( \b2v_inst_ac_b|B\(3) & ( ((!\b2v_inst_ac_a|A\(3) & (!\b2v_inst_ac_s|S\(1) & !\b2v_inst_ac_s|S\(0)))) # (\b2v_inst_ac_s|S\(2)) ) ) ) # ( !\b2v_inst_alu_8b|Mux5~1_combout\ & ( 
-- \b2v_inst_ac_b|B\(3) & ( (!\b2v_inst_ac_s|S\(2) & (!\b2v_inst_ac_a|A\(3) & (!\b2v_inst_ac_s|S\(1) & !\b2v_inst_ac_s|S\(0)))) ) ) ) # ( \b2v_inst_alu_8b|Mux5~1_combout\ & ( !\b2v_inst_ac_b|B\(3) & ( ((!\b2v_inst_ac_a|A\(3) & !\b2v_inst_ac_s|S\(1))) # 
-- (\b2v_inst_ac_s|S\(2)) ) ) ) # ( !\b2v_inst_alu_8b|Mux5~1_combout\ & ( !\b2v_inst_ac_b|B\(3) & ( (!\b2v_inst_ac_s|S\(2) & (!\b2v_inst_ac_a|A\(3) & !\b2v_inst_ac_s|S\(1))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000010000000110101011101010110000000000000001101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(2),
	datab => \b2v_inst_ac_a|ALT_INV_A\(3),
	datac => \b2v_inst_ac_s|ALT_INV_S\(1),
	datad => \b2v_inst_ac_s|ALT_INV_S\(0),
	datae => \b2v_inst_alu_8b|ALT_INV_Mux5~1_combout\,
	dataf => \b2v_inst_ac_b|ALT_INV_B\(3),
	combout => \b2v_inst_alu_8b|Mux5~2_combout\);

-- Location: LABCELL_X80_Y6_N6
\b2v_inst_alu_8b|Mux5~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux5~10_combout\ = ( !\b2v_inst_ac_s|S\(1) & ( (!\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_a|A\(2) & ((!\b2v_inst_ac_s|S\(2)) # (\ALU~input_o\)))))) # (\b2v_inst_ac_s|S\(0) & ((((\b2v_inst_alu_8b|Add6~17_sumout\))))) ) ) # ( 
-- \b2v_inst_ac_s|S\(1) & ( (((\b2v_inst_alu_8b|Add7~17_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0000000000110011000011110000111111000100111101110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_alu_8b|ALT_INV_Add7~17_sumout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add6~17_sumout\,
	datae => \b2v_inst_ac_s|ALT_INV_S\(1),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(2),
	datag => \b2v_inst_ac_s|ALT_INV_S\(2),
	combout => \b2v_inst_alu_8b|Mux5~10_combout\);

-- Location: LABCELL_X80_Y7_N51
\b2v_inst_alu_8b|F9~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~9_combout\ = ( \b2v_inst_ac_a|A\(3) & ( !\b2v_inst_ac_b|B\(3) ) ) # ( !\b2v_inst_ac_a|A\(3) & ( \b2v_inst_ac_b|B\(3) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010110101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(3),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(3),
	combout => \b2v_inst_alu_8b|F9~9_combout\);

-- Location: LABCELL_X81_Y7_N54
\b2v_inst_alu_8b|Mux5~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux5~3_combout\ = ( \b2v_inst_alu_8b|Add5~17_sumout\ & ( (!\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_b|B\(3))) # (\ALU~input_o\))) # (\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_b|B\(3) & \b2v_inst_ac_a|A\(3))))) ) ) # ( 
-- !\b2v_inst_alu_8b|Add5~17_sumout\ & ( (\b2v_inst_ac_b|B\(3) & ((!\b2v_inst_ac_s|S\(0) & (!\ALU~input_o\)) # (\b2v_inst_ac_s|S\(0) & ((\b2v_inst_ac_a|A\(3)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000001011000010000000101101001100010011110100110001001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_ac_b|ALT_INV_B\(3),
	datad => \b2v_inst_ac_a|ALT_INV_A\(3),
	dataf => \b2v_inst_alu_8b|ALT_INV_Add5~17_sumout\,
	combout => \b2v_inst_alu_8b|Mux5~3_combout\);

-- Location: LABCELL_X81_Y7_N12
\b2v_inst_alu_8b|Mux5~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux5~4_combout\ = ( \b2v_inst_alu_8b|Mux5~3_combout\ & ( \b2v_inst_alu_8b|Add4~17_sumout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & (((!\b2v_inst_alu_8b|Mux4~5_combout\) # (\b2v_inst_alu_8b|Add3~17_sumout\)))) # 
-- (\b2v_inst_alu_8b|Mux7~4_combout\ & ((!\b2v_inst_alu_8b|F9~9_combout\) # ((\b2v_inst_alu_8b|Mux4~5_combout\)))) ) ) ) # ( !\b2v_inst_alu_8b|Mux5~3_combout\ & ( \b2v_inst_alu_8b|Add4~17_sumout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & 
-- (((\b2v_inst_alu_8b|Add3~17_sumout\ & \b2v_inst_alu_8b|Mux4~5_combout\)))) # (\b2v_inst_alu_8b|Mux7~4_combout\ & ((!\b2v_inst_alu_8b|F9~9_combout\) # ((\b2v_inst_alu_8b|Mux4~5_combout\)))) ) ) ) # ( \b2v_inst_alu_8b|Mux5~3_combout\ & ( 
-- !\b2v_inst_alu_8b|Add4~17_sumout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & (((!\b2v_inst_alu_8b|Mux4~5_combout\) # (\b2v_inst_alu_8b|Add3~17_sumout\)))) # (\b2v_inst_alu_8b|Mux7~4_combout\ & (!\b2v_inst_alu_8b|F9~9_combout\ & 
-- ((!\b2v_inst_alu_8b|Mux4~5_combout\)))) ) ) ) # ( !\b2v_inst_alu_8b|Mux5~3_combout\ & ( !\b2v_inst_alu_8b|Add4~17_sumout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & (((\b2v_inst_alu_8b|Add3~17_sumout\ & \b2v_inst_alu_8b|Mux4~5_combout\)))) # 
-- (\b2v_inst_alu_8b|Mux7~4_combout\ & (!\b2v_inst_alu_8b|F9~9_combout\ & ((!\b2v_inst_alu_8b|Mux4~5_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010001000001100111011100000110000100010001111111110111000111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_F9~9_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux7~4_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Add3~17_sumout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~5_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux5~3_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Add4~17_sumout\,
	combout => \b2v_inst_alu_8b|Mux5~4_combout\);

-- Location: LABCELL_X81_Y7_N36
\b2v_inst_alu_8b|Mux5~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux5~6_combout\ = ( !\b2v_inst_alu_8b|Mux4~7_combout\ & ( (!\b2v_inst_alu_8b|Mux4~6_combout\ & ((((!\b2v_inst_ac_b|B\(3))) # (\b2v_inst_ac_a|A\(3))))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & (\b2v_inst_alu_8b|Mux5~2_combout\)) ) ) # ( 
-- \b2v_inst_alu_8b|Mux4~7_combout\ & ( (!\b2v_inst_alu_8b|Mux4~6_combout\ & (((\b2v_inst_alu_8b|Mux5~10_combout\)))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & ((((\b2v_inst_alu_8b|Mux5~4_combout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1011101110111011000010100101111100011011000110110000101001011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~6_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux5~2_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux5~10_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux5~4_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~7_combout\,
	dataf => \b2v_inst_ac_b|ALT_INV_B\(3),
	datag => \b2v_inst_ac_a|ALT_INV_A\(3),
	combout => \b2v_inst_alu_8b|Mux5~6_combout\);

-- Location: LABCELL_X83_Y8_N42
\b2v_inst_alu_8b|Mux5~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux5~5_combout\ = ( \b2v_inst_alu_8b|Mux4~2_combout\ & ( \b2v_inst_ac_a|A\(3) ) ) # ( !\b2v_inst_alu_8b|Mux4~2_combout\ & ( \b2v_inst_ac_a|A\(3) & ( (\b2v_inst_alu_8b|Mux5~6_combout\ & ((!\b2v_inst_alu_8b|Mux4~0_combout\) # 
-- (\b2v_inst_alu_8b|Mux4~1_combout\))) ) ) ) # ( \b2v_inst_alu_8b|Mux4~2_combout\ & ( !\b2v_inst_ac_a|A\(3) & ( (\b2v_inst_alu_8b|Mux4~0_combout\ & (!\b2v_inst_alu_8b|Mux4~1_combout\ & \b2v_inst_ac_b|B\(3))) ) ) ) # ( !\b2v_inst_alu_8b|Mux4~2_combout\ & ( 
-- !\b2v_inst_ac_a|A\(3) & ( (!\b2v_inst_alu_8b|Mux4~0_combout\ & (\b2v_inst_alu_8b|Mux5~6_combout\)) # (\b2v_inst_alu_8b|Mux4~0_combout\ & ((!\b2v_inst_alu_8b|Mux4~1_combout\ & ((\b2v_inst_ac_b|B\(3)))) # (\b2v_inst_alu_8b|Mux4~1_combout\ & 
-- (\b2v_inst_alu_8b|Mux5~6_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100010101110101000000000011000001000101010001011111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux5~6_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~0_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~1_combout\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(3),
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~2_combout\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(3),
	combout => \b2v_inst_alu_8b|Mux5~5_combout\);

-- Location: LABCELL_X83_Y8_N24
\b2v_inst_seg7|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux6~0_combout\ = ( \SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ & ( (\b2v_inst_alu_8b|Mux6~5_combout\ & (!\b2v_inst_alu_8b|Mux8~2_combout\ & 
-- !\b2v_inst_alu_8b|Mux7~6_combout\)) ) ) ) # ( \SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ & ( (!\b2v_inst_alu_8b|Mux6~5_combout\ & ((!\b2v_inst_alu_8b|Mux7~6_combout\))) # 
-- (\b2v_inst_alu_8b|Mux6~5_combout\ & (\b2v_inst_alu_8b|Mux8~2_combout\ & \b2v_inst_alu_8b|Mux7~6_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010000110100001111111111111111101000000010000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux6~5_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux8~2_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux7~6_combout\,
	datae => \ALT_INV_SEG~input_o\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux5~5_combout\,
	combout => \b2v_inst_seg7|Mux6~0_combout\);

-- Location: LABCELL_X83_Y8_N18
\b2v_inst_seg7|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux5~0_combout\ = ( \SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ & ( (\b2v_inst_alu_8b|Mux6~5_combout\ & (\b2v_inst_alu_8b|Mux8~2_combout\ & 
-- !\b2v_inst_alu_8b|Mux7~6_combout\)) ) ) ) # ( \SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ & ( (!\b2v_inst_alu_8b|Mux6~5_combout\ & ((\b2v_inst_alu_8b|Mux7~6_combout\) # 
-- (\b2v_inst_alu_8b|Mux8~2_combout\))) # (\b2v_inst_alu_8b|Mux6~5_combout\ & (\b2v_inst_alu_8b|Mux8~2_combout\ & \b2v_inst_alu_8b|Mux7~6_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010101100101011111111111111111100010000000100001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux6~5_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux8~2_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux7~6_combout\,
	datae => \ALT_INV_SEG~input_o\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux5~5_combout\,
	combout => \b2v_inst_seg7|Mux5~0_combout\);

-- Location: LABCELL_X83_Y8_N15
\b2v_inst_seg7|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux4~0_combout\ = ( \SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ & ( (!\b2v_inst_alu_8b|Mux7~6_combout\ & (\b2v_inst_alu_8b|Mux8~2_combout\ & 
-- !\b2v_inst_alu_8b|Mux6~5_combout\)) ) ) ) # ( \SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ & ( ((!\b2v_inst_alu_8b|Mux7~6_combout\ & \b2v_inst_alu_8b|Mux6~5_combout\)) # 
-- (\b2v_inst_alu_8b|Mux8~2_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111110101111111111111111111100001010000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux7~6_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux8~2_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux6~5_combout\,
	datae => \ALT_INV_SEG~input_o\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux5~5_combout\,
	combout => \b2v_inst_seg7|Mux4~0_combout\);

-- Location: LABCELL_X83_Y8_N6
\b2v_inst_seg7|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux3~0_combout\ = ( \SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ & ( (\b2v_inst_alu_8b|Mux7~6_combout\ & (!\b2v_inst_alu_8b|Mux6~5_combout\ $ 
-- (\b2v_inst_alu_8b|Mux8~2_combout\))) ) ) ) # ( \SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ & ( (!\b2v_inst_alu_8b|Mux6~5_combout\ & (\b2v_inst_alu_8b|Mux8~2_combout\ & 
-- !\b2v_inst_alu_8b|Mux7~6_combout\)) # (\b2v_inst_alu_8b|Mux6~5_combout\ & (!\b2v_inst_alu_8b|Mux8~2_combout\ $ (\b2v_inst_alu_8b|Mux7~6_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110000101100001111111111111111100001001000010011111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux6~5_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux8~2_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux7~6_combout\,
	datae => \ALT_INV_SEG~input_o\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux5~5_combout\,
	combout => \b2v_inst_seg7|Mux3~0_combout\);

-- Location: LABCELL_X83_Y8_N33
\b2v_inst_seg7|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux2~0_combout\ = ( \SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ & ( (\b2v_inst_alu_8b|Mux6~5_combout\ & ((!\b2v_inst_alu_8b|Mux8~2_combout\) # 
-- (\b2v_inst_alu_8b|Mux7~6_combout\))) ) ) ) # ( \SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ & ( (\b2v_inst_alu_8b|Mux7~6_combout\ & (!\b2v_inst_alu_8b|Mux8~2_combout\ & 
-- !\b2v_inst_alu_8b|Mux6~5_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000000000000111111111111111100000000111101011111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux7~6_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux8~2_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux6~5_combout\,
	datae => \ALT_INV_SEG~input_o\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux5~5_combout\,
	combout => \b2v_inst_seg7|Mux2~0_combout\);

-- Location: LABCELL_X83_Y8_N54
\b2v_inst_seg7|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux1~0_combout\ = ( \SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ & ( (!\b2v_inst_alu_8b|Mux8~2_combout\ & (\b2v_inst_alu_8b|Mux6~5_combout\)) # 
-- (\b2v_inst_alu_8b|Mux8~2_combout\ & ((\b2v_inst_alu_8b|Mux7~6_combout\))) ) ) ) # ( \SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ & ( (\b2v_inst_alu_8b|Mux6~5_combout\ & 
-- (!\b2v_inst_alu_8b|Mux8~2_combout\ $ (!\b2v_inst_alu_8b|Mux7~6_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001010000010100111111111111111101000111010001111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux6~5_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux8~2_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux7~6_combout\,
	datae => \ALT_INV_SEG~input_o\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux5~5_combout\,
	combout => \b2v_inst_seg7|Mux1~0_combout\);

-- Location: LABCELL_X83_Y8_N51
\b2v_inst_seg7|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux0~0_combout\ = ( \SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( \b2v_inst_alu_8b|Mux5~5_combout\ & ( (\b2v_inst_alu_8b|Mux8~2_combout\ & (!\b2v_inst_alu_8b|Mux7~6_combout\ $ 
-- (!\b2v_inst_alu_8b|Mux6~5_combout\))) ) ) ) # ( \SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ ) ) # ( !\SEG~input_o\ & ( !\b2v_inst_alu_8b|Mux5~5_combout\ & ( (!\b2v_inst_alu_8b|Mux7~6_combout\ & (!\b2v_inst_alu_8b|Mux8~2_combout\ $ 
-- (!\b2v_inst_alu_8b|Mux6~5_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101010100000111111111111111100000101000010101111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux7~6_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux8~2_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux6~5_combout\,
	datae => \ALT_INV_SEG~input_o\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux5~5_combout\,
	combout => \b2v_inst_seg7|Mux0~0_combout\);

-- Location: LABCELL_X79_Y6_N21
\b2v_inst_alu_8b|Mux1~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux1~4_combout\ = ( \b2v_inst_alu_8b|Add5~33_sumout\ & ( (!\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_b|B\(7))) # (\ALU~input_o\))) # (\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_a|A\(7) & \b2v_inst_ac_b|B\(7))))) ) ) # ( 
-- !\b2v_inst_alu_8b|Add5~33_sumout\ & ( (\b2v_inst_ac_b|B\(7) & ((!\b2v_inst_ac_s|S\(0) & (!\ALU~input_o\)) # (\b2v_inst_ac_s|S\(0) & ((\b2v_inst_ac_a|A\(7)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010001011000000001000101101000100110011110100010011001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_ac_a|ALT_INV_A\(7),
	datad => \b2v_inst_ac_b|ALT_INV_B\(7),
	dataf => \b2v_inst_alu_8b|ALT_INV_Add5~33_sumout\,
	combout => \b2v_inst_alu_8b|Mux1~4_combout\);

-- Location: MLABCELL_X82_Y6_N57
\b2v_inst_alu_8b|F9~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~13_combout\ = ( !\b2v_inst_ac_a|A\(7) & ( \b2v_inst_ac_b|B\(7) ) ) # ( \b2v_inst_ac_a|A\(7) & ( !\b2v_inst_ac_b|B\(7) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111111111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \b2v_inst_ac_a|ALT_INV_A\(7),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(7),
	combout => \b2v_inst_alu_8b|F9~13_combout\);

-- Location: LABCELL_X79_Y6_N12
\b2v_inst_alu_8b|Mux1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux1~5_combout\ = ( \b2v_inst_alu_8b|Mux1~4_combout\ & ( \b2v_inst_alu_8b|F9~13_combout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & (((!\b2v_inst_alu_8b|Mux4~5_combout\)) # (\b2v_inst_alu_8b|Add3~33_sumout\))) # 
-- (\b2v_inst_alu_8b|Mux7~4_combout\ & (((\b2v_inst_alu_8b|Mux4~5_combout\ & \b2v_inst_alu_8b|Add4~33_sumout\)))) ) ) ) # ( !\b2v_inst_alu_8b|Mux1~4_combout\ & ( \b2v_inst_alu_8b|F9~13_combout\ & ( (\b2v_inst_alu_8b|Mux4~5_combout\ & 
-- ((!\b2v_inst_alu_8b|Mux7~4_combout\ & (\b2v_inst_alu_8b|Add3~33_sumout\)) # (\b2v_inst_alu_8b|Mux7~4_combout\ & ((\b2v_inst_alu_8b|Add4~33_sumout\))))) ) ) ) # ( \b2v_inst_alu_8b|Mux1~4_combout\ & ( !\b2v_inst_alu_8b|F9~13_combout\ & ( 
-- (!\b2v_inst_alu_8b|Mux4~5_combout\) # ((!\b2v_inst_alu_8b|Mux7~4_combout\ & (\b2v_inst_alu_8b|Add3~33_sumout\)) # (\b2v_inst_alu_8b|Mux7~4_combout\ & ((\b2v_inst_alu_8b|Add4~33_sumout\)))) ) ) ) # ( !\b2v_inst_alu_8b|Mux1~4_combout\ & ( 
-- !\b2v_inst_alu_8b|F9~13_combout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & (\b2v_inst_alu_8b|Add3~33_sumout\ & (\b2v_inst_alu_8b|Mux4~5_combout\))) # (\b2v_inst_alu_8b|Mux7~4_combout\ & (((!\b2v_inst_alu_8b|Mux4~5_combout\) # 
-- (\b2v_inst_alu_8b|Add4~33_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101001001010111111100101111011100000010000001111010001010100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux7~4_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Add3~33_sumout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~5_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add4~33_sumout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux1~4_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_F9~13_combout\,
	combout => \b2v_inst_alu_8b|Mux1~5_combout\);

-- Location: LABCELL_X79_Y6_N30
\b2v_inst_alu_8b|Mux4~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~14_combout\ = (!\b2v_inst_ac_s|S\(1) & (((!\ALU~input_o\ & \b2v_inst_ac_s|S\(2))) # (\b2v_inst_ac_s|S\(0))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000010110000001100001011000000110000101100000011000010110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_ac_s|ALT_INV_S\(1),
	datad => \b2v_inst_ac_s|ALT_INV_S\(2),
	combout => \b2v_inst_alu_8b|Mux4~14_combout\);

-- Location: LABCELL_X79_Y6_N54
\b2v_inst_alu_8b|Mux1~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux1~3_combout\ = ( \b2v_inst_ac_s|S\(1) & ( \b2v_inst_alu_8b|Add7~33_sumout\ & ( !\b2v_inst_alu_8b|Mux4~14_combout\ ) ) ) # ( !\b2v_inst_ac_s|S\(1) & ( \b2v_inst_alu_8b|Add7~33_sumout\ & ( (!\b2v_inst_alu_8b|Mux4~14_combout\ & 
-- (((\b2v_inst_ac_a|A\(6)) # (\b2v_inst_ac_s|S\(0))))) # (\b2v_inst_alu_8b|Mux4~14_combout\ & (\b2v_inst_alu_8b|Add6~33_sumout\ & (\b2v_inst_ac_s|S\(0)))) ) ) ) # ( !\b2v_inst_ac_s|S\(1) & ( !\b2v_inst_alu_8b|Add7~33_sumout\ & ( (!\b2v_inst_ac_s|S\(0) & 
-- (((!\b2v_inst_alu_8b|Mux4~14_combout\ & \b2v_inst_ac_a|A\(6))))) # (\b2v_inst_ac_s|S\(0) & (\b2v_inst_alu_8b|Add6~33_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010111000101000000000000000000001101110011011100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Add6~33_sumout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~14_combout\,
	datac => \b2v_inst_ac_s|ALT_INV_S\(0),
	datad => \b2v_inst_ac_a|ALT_INV_A\(6),
	datae => \b2v_inst_ac_s|ALT_INV_S\(1),
	dataf => \b2v_inst_alu_8b|ALT_INV_Add7~33_sumout\,
	combout => \b2v_inst_alu_8b|Mux1~3_combout\);

-- Location: MLABCELL_X82_Y6_N51
\b2v_inst_alu_8b|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux1~0_combout\ = ( \b2v_inst_ac_a|A\(7) & ( \b2v_inst_alu_8b|Add0~33_sumout\ & ( (!\ALU~input_o\ & (\b2v_inst_ac_b|B\(7))) # (\ALU~input_o\ & (((\b2v_inst_ac_s|S\(0) & !\b2v_inst_alu_8b|Add1~33_sumout\)))) ) ) ) # ( !\b2v_inst_ac_a|A\(7) 
-- & ( \b2v_inst_alu_8b|Add0~33_sumout\ & ( (\b2v_inst_ac_s|S\(0) & ((!\ALU~input_o\ & (\b2v_inst_ac_b|B\(7))) # (\ALU~input_o\ & ((!\b2v_inst_alu_8b|Add1~33_sumout\))))) ) ) ) # ( \b2v_inst_ac_a|A\(7) & ( !\b2v_inst_alu_8b|Add0~33_sumout\ & ( 
-- (!\ALU~input_o\ & (\b2v_inst_ac_b|B\(7))) # (\ALU~input_o\ & (((!\b2v_inst_ac_s|S\(0)) # (!\b2v_inst_alu_8b|Add1~33_sumout\)))) ) ) ) # ( !\b2v_inst_ac_a|A\(7) & ( !\b2v_inst_alu_8b|Add0~33_sumout\ & ( (!\b2v_inst_ac_s|S\(0) & (((\ALU~input_o\)))) # 
-- (\b2v_inst_ac_s|S\(0) & ((!\ALU~input_o\ & (\b2v_inst_ac_b|B\(7))) # (\ALU~input_o\ & ((!\b2v_inst_alu_8b|Add1~33_sumout\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001111100011100010111110101110000010011000100000101001101010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(7),
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \ALT_INV_ALU~input_o\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add1~33_sumout\,
	datae => \b2v_inst_ac_a|ALT_INV_A\(7),
	dataf => \b2v_inst_alu_8b|ALT_INV_Add0~33_sumout\,
	combout => \b2v_inst_alu_8b|Mux1~0_combout\);

-- Location: MLABCELL_X78_Y5_N24
\b2v_inst_alu_8b|Mux1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux1~1_combout\ = ( \b2v_inst_alu_8b|Mux1~0_combout\ & ( \b2v_inst_ac_a|A\(7) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & (\b2v_inst_alu_8b|Mux4~4_combout\ & ((!\b2v_inst_ac_b|B\(7))))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & 
-- ((!\b2v_inst_alu_8b|Mux4~4_combout\ & ((!\b2v_inst_ac_b|B\(7)))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & (\b2v_inst_alu_8b|Add2~33_sumout\)))) ) ) ) # ( !\b2v_inst_alu_8b|Mux1~0_combout\ & ( \b2v_inst_ac_a|A\(7) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & 
-- ((!\b2v_inst_alu_8b|Mux4~4_combout\) # ((!\b2v_inst_ac_b|B\(7))))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux4~4_combout\ & ((!\b2v_inst_ac_b|B\(7)))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & (\b2v_inst_alu_8b|Add2~33_sumout\)))) ) ) ) # ( 
-- \b2v_inst_alu_8b|Mux1~0_combout\ & ( !\b2v_inst_ac_a|A\(7) & ( (\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux4~4_combout\ & ((\b2v_inst_ac_b|B\(7)))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & (\b2v_inst_alu_8b|Add2~33_sumout\)))) ) ) ) # ( 
-- !\b2v_inst_alu_8b|Mux1~0_combout\ & ( !\b2v_inst_ac_a|A\(7) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & (!\b2v_inst_alu_8b|Mux4~4_combout\)) # (\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux4~4_combout\ & ((\b2v_inst_ac_b|B\(7)))) # 
-- (\b2v_inst_alu_8b|Mux4~4_combout\ & (\b2v_inst_alu_8b|Add2~33_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000100111001101000000010100010111101111100010010110011100000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~3_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~4_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Add2~33_sumout\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(7),
	datae => \b2v_inst_alu_8b|ALT_INV_Mux1~0_combout\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(7),
	combout => \b2v_inst_alu_8b|Mux1~1_combout\);

-- Location: LABCELL_X79_Y6_N48
\b2v_inst_alu_8b|Mux1~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux1~2_combout\ = ( \b2v_inst_ac_s|S\(2) & ( \b2v_inst_ac_a|A\(7) & ( \b2v_inst_alu_8b|Mux1~1_combout\ ) ) ) # ( \b2v_inst_ac_s|S\(2) & ( !\b2v_inst_ac_a|A\(7) & ( \b2v_inst_alu_8b|Mux1~1_combout\ ) ) ) # ( !\b2v_inst_ac_s|S\(2) & ( 
-- !\b2v_inst_ac_a|A\(7) & ( (!\b2v_inst_ac_s|S\(1) & ((!\b2v_inst_ac_b|B\(7)) # (!\b2v_inst_ac_s|S\(0)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101010100000001100110011001100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(1),
	datab => \b2v_inst_alu_8b|ALT_INV_Mux1~1_combout\,
	datac => \b2v_inst_ac_b|ALT_INV_B\(7),
	datad => \b2v_inst_ac_s|ALT_INV_S\(0),
	datae => \b2v_inst_ac_s|ALT_INV_S\(2),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(7),
	combout => \b2v_inst_alu_8b|Mux1~2_combout\);

-- Location: LABCELL_X79_Y6_N0
\b2v_inst_alu_8b|Mux1~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux1~7_combout\ = ( !\b2v_inst_alu_8b|Mux4~7_combout\ & ( (!\b2v_inst_alu_8b|Mux4~6_combout\ & ((((!\b2v_inst_ac_b|B\(7))) # (\b2v_inst_ac_a|A\(7))))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & ((((\b2v_inst_alu_8b|Mux1~2_combout\))))) ) ) # ( 
-- \b2v_inst_alu_8b|Mux4~7_combout\ & ( (!\b2v_inst_alu_8b|Mux4~6_combout\ & (((\b2v_inst_alu_8b|Mux1~3_combout\)))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & (\b2v_inst_alu_8b|Mux1~5_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1010101011111111000110110001101100001010010111110001101100011011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~6_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux1~5_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux1~3_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux1~2_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~7_combout\,
	dataf => \b2v_inst_ac_b|ALT_INV_B\(7),
	datag => \b2v_inst_ac_a|ALT_INV_A\(7),
	combout => \b2v_inst_alu_8b|Mux1~7_combout\);

-- Location: LABCELL_X85_Y6_N18
\b2v_inst_alu_8b|Mux1~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux1~6_combout\ = ( \b2v_inst_alu_8b|Mux4~0_combout\ & ( \b2v_inst_alu_8b|Mux1~7_combout\ & ( (!\b2v_inst_alu_8b|Mux4~1_combout\ & ((!\b2v_inst_ac_a|A\(7) & ((\b2v_inst_ac_b|B\(7)))) # (\b2v_inst_ac_a|A\(7) & 
-- (\b2v_inst_alu_8b|Mux4~2_combout\)))) # (\b2v_inst_alu_8b|Mux4~1_combout\ & ((!\b2v_inst_alu_8b|Mux4~2_combout\) # ((\b2v_inst_ac_a|A\(7))))) ) ) ) # ( !\b2v_inst_alu_8b|Mux4~0_combout\ & ( \b2v_inst_alu_8b|Mux1~7_combout\ & ( 
-- (!\b2v_inst_alu_8b|Mux4~2_combout\) # (\b2v_inst_ac_a|A\(7)) ) ) ) # ( \b2v_inst_alu_8b|Mux4~0_combout\ & ( !\b2v_inst_alu_8b|Mux1~7_combout\ & ( (!\b2v_inst_ac_a|A\(7) & (!\b2v_inst_alu_8b|Mux4~1_combout\ & ((\b2v_inst_ac_b|B\(7))))) # 
-- (\b2v_inst_ac_a|A\(7) & (((\b2v_inst_alu_8b|Mux4~2_combout\)))) ) ) ) # ( !\b2v_inst_alu_8b|Mux4~0_combout\ & ( !\b2v_inst_alu_8b|Mux1~7_combout\ & ( (\b2v_inst_alu_8b|Mux4~2_combout\ & \b2v_inst_ac_a|A\(7)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000110011000010100011001111001100111111110100111001110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~1_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~2_combout\,
	datac => \b2v_inst_ac_b|ALT_INV_B\(7),
	datad => \b2v_inst_ac_a|ALT_INV_A\(7),
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~0_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux1~7_combout\,
	combout => \b2v_inst_alu_8b|Mux1~6_combout\);

-- Location: LABCELL_X81_Y7_N0
\b2v_inst_alu_8b|Mux3~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux3~3_combout\ = ( \b2v_inst_ac_a|A\(5) & ( (!\ALU~input_o\ & (((\b2v_inst_ac_b|B\(5))))) # (\ALU~input_o\ & ((!\b2v_inst_ac_s|S\(0) & ((\b2v_inst_alu_8b|Add5~25_sumout\))) # (\b2v_inst_ac_s|S\(0) & (\b2v_inst_ac_b|B\(5))))) ) ) # ( 
-- !\b2v_inst_ac_a|A\(5) & ( (!\b2v_inst_ac_s|S\(0) & ((!\ALU~input_o\ & (\b2v_inst_ac_b|B\(5))) # (\ALU~input_o\ & ((\b2v_inst_alu_8b|Add5~25_sumout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100001001100000010000100110000001011010011110000101101001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_ac_b|ALT_INV_B\(5),
	datad => \b2v_inst_alu_8b|ALT_INV_Add5~25_sumout\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(5),
	combout => \b2v_inst_alu_8b|Mux3~3_combout\);

-- Location: LABCELL_X81_Y7_N48
\b2v_inst_alu_8b|F9~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~11_combout\ = ( \b2v_inst_ac_a|A\(5) & ( !\b2v_inst_ac_b|B\(5) ) ) # ( !\b2v_inst_ac_a|A\(5) & ( \b2v_inst_ac_b|B\(5) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \b2v_inst_ac_b|ALT_INV_B\(5),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(5),
	combout => \b2v_inst_alu_8b|F9~11_combout\);

-- Location: LABCELL_X81_Y7_N24
\b2v_inst_alu_8b|Mux3~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux3~4_combout\ = ( \b2v_inst_alu_8b|Mux4~5_combout\ & ( \b2v_inst_alu_8b|Add4~25_sumout\ & ( (\b2v_inst_alu_8b|Mux7~4_combout\) # (\b2v_inst_alu_8b|Add3~25_sumout\) ) ) ) # ( !\b2v_inst_alu_8b|Mux4~5_combout\ & ( 
-- \b2v_inst_alu_8b|Add4~25_sumout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & (\b2v_inst_alu_8b|Mux3~3_combout\)) # (\b2v_inst_alu_8b|Mux7~4_combout\ & ((!\b2v_inst_alu_8b|F9~11_combout\))) ) ) ) # ( \b2v_inst_alu_8b|Mux4~5_combout\ & ( 
-- !\b2v_inst_alu_8b|Add4~25_sumout\ & ( (\b2v_inst_alu_8b|Add3~25_sumout\ & !\b2v_inst_alu_8b|Mux7~4_combout\) ) ) ) # ( !\b2v_inst_alu_8b|Mux4~5_combout\ & ( !\b2v_inst_alu_8b|Add4~25_sumout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & 
-- (\b2v_inst_alu_8b|Mux3~3_combout\)) # (\b2v_inst_alu_8b|Mux7~4_combout\ & ((!\b2v_inst_alu_8b|F9~11_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010111110000001100110000000001010101111100000011001111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux3~3_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Add3~25_sumout\,
	datac => \b2v_inst_alu_8b|ALT_INV_F9~11_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux7~4_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~5_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Add4~25_sumout\,
	combout => \b2v_inst_alu_8b|Mux3~4_combout\);

-- Location: LABCELL_X80_Y6_N0
\b2v_inst_alu_8b|Mux3~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux3~10_combout\ = ( !\b2v_inst_ac_s|S\(1) & ( (!\b2v_inst_ac_s|S\(0) & (\b2v_inst_ac_a|A\(4) & ((!\b2v_inst_ac_s|S\(2)) # ((\ALU~input_o\))))) # (\b2v_inst_ac_s|S\(0) & ((((\b2v_inst_alu_8b|Add6~25_sumout\))))) ) ) # ( 
-- \b2v_inst_ac_s|S\(1) & ( (((\b2v_inst_alu_8b|Add7~25_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0100000001110011000011110000111101000100011101110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(4),
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_alu_8b|ALT_INV_Add7~25_sumout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add6~25_sumout\,
	datae => \b2v_inst_ac_s|ALT_INV_S\(1),
	dataf => \ALT_INV_ALU~input_o\,
	datag => \b2v_inst_ac_s|ALT_INV_S\(2),
	combout => \b2v_inst_alu_8b|Mux3~10_combout\);

-- Location: MLABCELL_X82_Y6_N42
\b2v_inst_alu_8b|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux3~0_combout\ = ( \ALU~input_o\ & ( \b2v_inst_ac_b|B\(5) & ( (!\b2v_inst_ac_s|S\(0) & ((!\b2v_inst_alu_8b|Add0~25_sumout\))) # (\b2v_inst_ac_s|S\(0) & (!\b2v_inst_alu_8b|Add1~25_sumout\)) ) ) ) # ( !\ALU~input_o\ & ( 
-- \b2v_inst_ac_b|B\(5) & ( (\b2v_inst_ac_s|S\(0)) # (\b2v_inst_ac_a|A\(5)) ) ) ) # ( \ALU~input_o\ & ( !\b2v_inst_ac_b|B\(5) & ( (!\b2v_inst_ac_s|S\(0) & ((!\b2v_inst_alu_8b|Add0~25_sumout\))) # (\b2v_inst_ac_s|S\(0) & (!\b2v_inst_alu_8b|Add1~25_sumout\)) ) 
-- ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001100110001010101111111111111000011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(5),
	datab => \b2v_inst_alu_8b|ALT_INV_Add1~25_sumout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Add0~25_sumout\,
	datad => \b2v_inst_ac_s|ALT_INV_S\(0),
	datae => \ALT_INV_ALU~input_o\,
	dataf => \b2v_inst_ac_b|ALT_INV_B\(5),
	combout => \b2v_inst_alu_8b|Mux3~0_combout\);

-- Location: MLABCELL_X78_Y5_N12
\b2v_inst_alu_8b|Mux3~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux3~1_combout\ = ( \b2v_inst_ac_a|A\(5) & ( \b2v_inst_alu_8b|Mux3~0_combout\ & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & (!\b2v_inst_ac_b|B\(5) & ((\b2v_inst_alu_8b|Mux4~4_combout\)))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & 
-- ((!\b2v_inst_alu_8b|Mux4~4_combout\ & (!\b2v_inst_ac_b|B\(5))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & ((\b2v_inst_alu_8b|Add2~25_sumout\))))) ) ) ) # ( !\b2v_inst_ac_a|A\(5) & ( \b2v_inst_alu_8b|Mux3~0_combout\ & ( (\b2v_inst_alu_8b|Mux4~3_combout\ & 
-- ((!\b2v_inst_alu_8b|Mux4~4_combout\ & (\b2v_inst_ac_b|B\(5))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & ((\b2v_inst_alu_8b|Add2~25_sumout\))))) ) ) ) # ( \b2v_inst_ac_a|A\(5) & ( !\b2v_inst_alu_8b|Mux3~0_combout\ & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & 
-- ((!\b2v_inst_ac_b|B\(5)) # ((!\b2v_inst_alu_8b|Mux4~4_combout\)))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux4~4_combout\ & (!\b2v_inst_ac_b|B\(5))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & ((\b2v_inst_alu_8b|Add2~25_sumout\))))) ) ) ) # ( 
-- !\b2v_inst_ac_a|A\(5) & ( !\b2v_inst_alu_8b|Mux3~0_combout\ & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & (((!\b2v_inst_alu_8b|Mux4~4_combout\)))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux4~4_combout\ & (\b2v_inst_ac_b|B\(5))) # 
-- (\b2v_inst_alu_8b|Mux4~4_combout\ & ((\b2v_inst_alu_8b|Add2~25_sumout\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111010100000011111110101010001100000101000000110000101010100011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(5),
	datab => \b2v_inst_alu_8b|ALT_INV_Add2~25_sumout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~3_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~4_combout\,
	datae => \b2v_inst_ac_a|ALT_INV_A\(5),
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux3~0_combout\,
	combout => \b2v_inst_alu_8b|Mux3~1_combout\);

-- Location: LABCELL_X81_Y7_N18
\b2v_inst_alu_8b|Mux3~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux3~2_combout\ = ( \b2v_inst_ac_b|B\(5) & ( \b2v_inst_ac_a|A\(5) & ( (\b2v_inst_ac_s|S\(2) & \b2v_inst_alu_8b|Mux3~1_combout\) ) ) ) # ( !\b2v_inst_ac_b|B\(5) & ( \b2v_inst_ac_a|A\(5) & ( (\b2v_inst_ac_s|S\(2) & 
-- \b2v_inst_alu_8b|Mux3~1_combout\) ) ) ) # ( \b2v_inst_ac_b|B\(5) & ( !\b2v_inst_ac_a|A\(5) & ( (!\b2v_inst_ac_s|S\(2) & (((!\b2v_inst_ac_s|S\(1) & !\b2v_inst_ac_s|S\(0))))) # (\b2v_inst_ac_s|S\(2) & (\b2v_inst_alu_8b|Mux3~1_combout\)) ) ) ) # ( 
-- !\b2v_inst_ac_b|B\(5) & ( !\b2v_inst_ac_a|A\(5) & ( (!\b2v_inst_ac_s|S\(2) & ((!\b2v_inst_ac_s|S\(1)))) # (\b2v_inst_ac_s|S\(2) & (\b2v_inst_alu_8b|Mux3~1_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011000110110001101100010001000100010001000100010001000100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(2),
	datab => \b2v_inst_alu_8b|ALT_INV_Mux3~1_combout\,
	datac => \b2v_inst_ac_s|ALT_INV_S\(1),
	datad => \b2v_inst_ac_s|ALT_INV_S\(0),
	datae => \b2v_inst_ac_b|ALT_INV_B\(5),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(5),
	combout => \b2v_inst_alu_8b|Mux3~2_combout\);

-- Location: LABCELL_X81_Y7_N30
\b2v_inst_alu_8b|Mux3~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux3~6_combout\ = ( !\b2v_inst_alu_8b|Mux4~7_combout\ & ( (!\b2v_inst_alu_8b|Mux4~6_combout\ & ((((!\b2v_inst_ac_b|B\(5))) # (\b2v_inst_ac_a|A\(5))))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & ((((\b2v_inst_alu_8b|Mux3~2_combout\))))) ) ) # ( 
-- \b2v_inst_alu_8b|Mux4~7_combout\ & ( (!\b2v_inst_alu_8b|Mux4~6_combout\ & (((\b2v_inst_alu_8b|Mux3~10_combout\)))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & (\b2v_inst_alu_8b|Mux3~4_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1010101000001010000110110001101111111111010111110001101100011011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~6_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux3~4_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux3~10_combout\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(5),
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~7_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux3~2_combout\,
	datag => \b2v_inst_ac_a|ALT_INV_A\(5),
	combout => \b2v_inst_alu_8b|Mux3~6_combout\);

-- Location: LABCELL_X85_Y6_N6
\b2v_inst_alu_8b|Mux3~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux3~5_combout\ = ( \b2v_inst_alu_8b|Mux4~0_combout\ & ( \b2v_inst_ac_a|A\(5) & ( ((\b2v_inst_alu_8b|Mux3~6_combout\ & \b2v_inst_alu_8b|Mux4~1_combout\)) # (\b2v_inst_alu_8b|Mux4~2_combout\) ) ) ) # ( !\b2v_inst_alu_8b|Mux4~0_combout\ & ( 
-- \b2v_inst_ac_a|A\(5) & ( (\b2v_inst_alu_8b|Mux4~2_combout\) # (\b2v_inst_alu_8b|Mux3~6_combout\) ) ) ) # ( \b2v_inst_alu_8b|Mux4~0_combout\ & ( !\b2v_inst_ac_a|A\(5) & ( (!\b2v_inst_alu_8b|Mux4~1_combout\ & (((\b2v_inst_ac_b|B\(5))))) # 
-- (\b2v_inst_alu_8b|Mux4~1_combout\ & (\b2v_inst_alu_8b|Mux3~6_combout\ & ((!\b2v_inst_alu_8b|Mux4~2_combout\)))) ) ) ) # ( !\b2v_inst_alu_8b|Mux4~0_combout\ & ( !\b2v_inst_ac_a|A\(5) & ( (\b2v_inst_alu_8b|Mux3~6_combout\ & 
-- !\b2v_inst_alu_8b|Mux4~2_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010100000000001101010011000001010101111111110000010111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux3~6_combout\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(5),
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~1_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~2_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~0_combout\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(5),
	combout => \b2v_inst_alu_8b|Mux3~5_combout\);

-- Location: LABCELL_X79_Y7_N57
\b2v_inst_alu_8b|Mux4~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~11_combout\ = ( \ALU~input_o\ & ( (!\b2v_inst_ac_s|S\(0) & (((\b2v_inst_alu_8b|Add5~21_sumout\)))) # (\b2v_inst_ac_s|S\(0) & (\b2v_inst_ac_a|A\(4) & (\b2v_inst_ac_b|B\(4)))) ) ) # ( !\ALU~input_o\ & ( (\b2v_inst_ac_b|B\(4) & 
-- ((!\b2v_inst_ac_s|S\(0)) # (\b2v_inst_ac_a|A\(4)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000100110001001100010011000100000001111100010000000111110001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(4),
	datab => \b2v_inst_ac_b|ALT_INV_B\(4),
	datac => \b2v_inst_ac_s|ALT_INV_S\(0),
	datad => \b2v_inst_alu_8b|ALT_INV_Add5~21_sumout\,
	dataf => \ALT_INV_ALU~input_o\,
	combout => \b2v_inst_alu_8b|Mux4~11_combout\);

-- Location: LABCELL_X79_Y7_N54
\b2v_inst_alu_8b|F9~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~10_combout\ = !\b2v_inst_ac_a|A\(4) $ (!\b2v_inst_ac_b|B\(4))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110011001100110011001100110011001100110011001100110011001100110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(4),
	datab => \b2v_inst_ac_b|ALT_INV_B\(4),
	combout => \b2v_inst_alu_8b|F9~10_combout\);

-- Location: LABCELL_X79_Y7_N0
\b2v_inst_alu_8b|Mux4~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~12_combout\ = ( \b2v_inst_alu_8b|Mux4~5_combout\ & ( \b2v_inst_alu_8b|Mux7~4_combout\ & ( \b2v_inst_alu_8b|Add4~21_sumout\ ) ) ) # ( !\b2v_inst_alu_8b|Mux4~5_combout\ & ( \b2v_inst_alu_8b|Mux7~4_combout\ & ( 
-- !\b2v_inst_alu_8b|F9~10_combout\ ) ) ) # ( \b2v_inst_alu_8b|Mux4~5_combout\ & ( !\b2v_inst_alu_8b|Mux7~4_combout\ & ( \b2v_inst_alu_8b|Add3~21_sumout\ ) ) ) # ( !\b2v_inst_alu_8b|Mux4~5_combout\ & ( !\b2v_inst_alu_8b|Mux7~4_combout\ & ( 
-- \b2v_inst_alu_8b|Mux4~11_combout\ ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011010101010101010111110000111100000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Add3~21_sumout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~11_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_F9~10_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add4~21_sumout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~5_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux7~4_combout\,
	combout => \b2v_inst_alu_8b|Mux4~12_combout\);

-- Location: LABCELL_X83_Y6_N0
\b2v_inst_alu_8b|Mux4~19\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~19_combout\ = ( !\b2v_inst_ac_s|S\(1) & ( (!\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_a|A\(3) & ((!\b2v_inst_ac_s|S\(2)) # (\ALU~input_o\)))))) # (\b2v_inst_ac_s|S\(0) & (\b2v_inst_alu_8b|Add6~21_sumout\)) ) ) # ( \b2v_inst_ac_s|S\(1) & 
-- ( (((\b2v_inst_alu_8b|Add7~21_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0000000001010101000011110000111111110011010101010000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Add6~21_sumout\,
	datab => \ALT_INV_ALU~input_o\,
	datac => \b2v_inst_alu_8b|ALT_INV_Add7~21_sumout\,
	datad => \b2v_inst_ac_s|ALT_INV_S\(0),
	datae => \b2v_inst_ac_s|ALT_INV_S\(1),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(3),
	datag => \b2v_inst_ac_s|ALT_INV_S\(2),
	combout => \b2v_inst_alu_8b|Mux4~19_combout\);

-- Location: LABCELL_X83_Y6_N12
\b2v_inst_alu_8b|Mux4~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~8_combout\ = ( \b2v_inst_ac_s|S\(0) & ( \b2v_inst_ac_a|A\(4) & ( (!\ALU~input_o\ & ((\b2v_inst_ac_b|B\(4)))) # (\ALU~input_o\ & (!\b2v_inst_alu_8b|Add1~21_sumout\)) ) ) ) # ( !\b2v_inst_ac_s|S\(0) & ( \b2v_inst_ac_a|A\(4) & ( 
-- (!\ALU~input_o\ & (\b2v_inst_ac_b|B\(4))) # (\ALU~input_o\ & ((!\b2v_inst_alu_8b|Add0~21_sumout\))) ) ) ) # ( \b2v_inst_ac_s|S\(0) & ( !\b2v_inst_ac_a|A\(4) & ( (!\ALU~input_o\ & ((\b2v_inst_ac_b|B\(4)))) # (\ALU~input_o\ & 
-- (!\b2v_inst_alu_8b|Add1~21_sumout\)) ) ) ) # ( !\b2v_inst_ac_s|S\(0) & ( !\b2v_inst_ac_a|A\(4) & ( (\ALU~input_o\ & !\b2v_inst_alu_8b|Add0~21_sumout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100000000001011100010111000111111000011000010111000101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Add1~21_sumout\,
	datab => \ALT_INV_ALU~input_o\,
	datac => \b2v_inst_ac_b|ALT_INV_B\(4),
	datad => \b2v_inst_alu_8b|ALT_INV_Add0~21_sumout\,
	datae => \b2v_inst_ac_s|ALT_INV_S\(0),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(4),
	combout => \b2v_inst_alu_8b|Mux4~8_combout\);

-- Location: MLABCELL_X78_Y5_N6
\b2v_inst_alu_8b|Mux4~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~9_combout\ = ( \b2v_inst_alu_8b|Mux4~4_combout\ & ( \b2v_inst_ac_a|A\(4) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & (!\b2v_inst_ac_b|B\(4))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & ((\b2v_inst_alu_8b|Add2~21_sumout\))) ) ) ) # ( 
-- !\b2v_inst_alu_8b|Mux4~4_combout\ & ( \b2v_inst_ac_a|A\(4) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux4~8_combout\))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & (!\b2v_inst_ac_b|B\(4))) ) ) ) # ( \b2v_inst_alu_8b|Mux4~4_combout\ & ( 
-- !\b2v_inst_ac_a|A\(4) & ( (\b2v_inst_alu_8b|Add2~21_sumout\ & \b2v_inst_alu_8b|Mux4~3_combout\) ) ) ) # ( !\b2v_inst_alu_8b|Mux4~4_combout\ & ( !\b2v_inst_ac_a|A\(4) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux4~8_combout\))) # 
-- (\b2v_inst_alu_8b|Mux4~3_combout\ & (\b2v_inst_ac_b|B\(4))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111010100000101000000110000001111111010000010101010001110100011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(4),
	datab => \b2v_inst_alu_8b|ALT_INV_Add2~21_sumout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~3_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~8_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~4_combout\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(4),
	combout => \b2v_inst_alu_8b|Mux4~9_combout\);

-- Location: LABCELL_X79_Y7_N48
\b2v_inst_alu_8b|Mux4~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~10_combout\ = ( \b2v_inst_ac_s|S\(2) & ( \b2v_inst_ac_b|B\(4) & ( \b2v_inst_alu_8b|Mux4~9_combout\ ) ) ) # ( !\b2v_inst_ac_s|S\(2) & ( \b2v_inst_ac_b|B\(4) & ( (!\b2v_inst_ac_a|A\(4) & (!\b2v_inst_ac_s|S\(0) & !\b2v_inst_ac_s|S\(1))) 
-- ) ) ) # ( \b2v_inst_ac_s|S\(2) & ( !\b2v_inst_ac_b|B\(4) & ( \b2v_inst_alu_8b|Mux4~9_combout\ ) ) ) # ( !\b2v_inst_ac_s|S\(2) & ( !\b2v_inst_ac_b|B\(4) & ( (!\b2v_inst_ac_a|A\(4) & !\b2v_inst_ac_s|S\(1)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101000000000000011110000111110001000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(4),
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~9_combout\,
	datad => \b2v_inst_ac_s|ALT_INV_S\(1),
	datae => \b2v_inst_ac_s|ALT_INV_S\(2),
	dataf => \b2v_inst_ac_b|ALT_INV_B\(4),
	combout => \b2v_inst_alu_8b|Mux4~10_combout\);

-- Location: LABCELL_X79_Y7_N36
\b2v_inst_alu_8b|Mux4~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~15_combout\ = ( !\b2v_inst_alu_8b|Mux4~7_combout\ & ( ((!\b2v_inst_alu_8b|Mux4~6_combout\ & (((!\b2v_inst_ac_b|B\(4))) # (\b2v_inst_ac_a|A\(4)))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & (((\b2v_inst_alu_8b|Mux4~10_combout\))))) ) ) # ( 
-- \b2v_inst_alu_8b|Mux4~7_combout\ & ( (!\b2v_inst_alu_8b|Mux4~6_combout\ & (((\b2v_inst_alu_8b|Mux4~19_combout\)))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & (\b2v_inst_alu_8b|Mux4~12_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1100110000001100000111010001110111111111001111110001110100011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~12_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~6_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~19_combout\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(4),
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~7_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux4~10_combout\,
	datag => \b2v_inst_ac_a|ALT_INV_A\(4),
	combout => \b2v_inst_alu_8b|Mux4~15_combout\);

-- Location: LABCELL_X85_Y6_N30
\b2v_inst_alu_8b|Mux4~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux4~13_combout\ = ( \b2v_inst_ac_a|A\(4) & ( \b2v_inst_alu_8b|Mux4~15_combout\ & ( (!\b2v_inst_alu_8b|Mux4~0_combout\) # ((\b2v_inst_alu_8b|Mux4~1_combout\) # (\b2v_inst_alu_8b|Mux4~2_combout\)) ) ) ) # ( !\b2v_inst_ac_a|A\(4) & ( 
-- \b2v_inst_alu_8b|Mux4~15_combout\ & ( (!\b2v_inst_alu_8b|Mux4~0_combout\ & (!\b2v_inst_alu_8b|Mux4~2_combout\)) # (\b2v_inst_alu_8b|Mux4~0_combout\ & ((!\b2v_inst_alu_8b|Mux4~1_combout\ & ((\b2v_inst_ac_b|B\(4)))) # (\b2v_inst_alu_8b|Mux4~1_combout\ & 
-- (!\b2v_inst_alu_8b|Mux4~2_combout\)))) ) ) ) # ( \b2v_inst_ac_a|A\(4) & ( !\b2v_inst_alu_8b|Mux4~15_combout\ & ( \b2v_inst_alu_8b|Mux4~2_combout\ ) ) ) # ( !\b2v_inst_ac_a|A\(4) & ( !\b2v_inst_alu_8b|Mux4~15_combout\ & ( (\b2v_inst_alu_8b|Mux4~0_combout\ 
-- & (!\b2v_inst_alu_8b|Mux4~1_combout\ & \b2v_inst_ac_b|B\(4))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001010000001100110011001110001100110111001011111110111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~0_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~2_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~1_combout\,
	datad => \b2v_inst_ac_b|ALT_INV_B\(4),
	datae => \b2v_inst_ac_a|ALT_INV_A\(4),
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux4~15_combout\,
	combout => \b2v_inst_alu_8b|Mux4~13_combout\);

-- Location: LABCELL_X79_Y7_N15
\b2v_inst_alu_8b|Mux2~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux2~4_combout\ = ( \b2v_inst_alu_8b|Add5~29_sumout\ & ( (!\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_b|B\(6))) # (\ALU~input_o\))) # (\b2v_inst_ac_s|S\(0) & (((\b2v_inst_ac_a|A\(6) & \b2v_inst_ac_b|B\(6))))) ) ) # ( 
-- !\b2v_inst_alu_8b|Add5~29_sumout\ & ( (\b2v_inst_ac_b|B\(6) & ((!\b2v_inst_ac_s|S\(0) & (!\ALU~input_o\)) # (\b2v_inst_ac_s|S\(0) & ((\b2v_inst_ac_a|A\(6)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010100011000000001010001101010000111100110101000011110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_ALU~input_o\,
	datab => \b2v_inst_ac_a|ALT_INV_A\(6),
	datac => \b2v_inst_ac_s|ALT_INV_S\(0),
	datad => \b2v_inst_ac_b|ALT_INV_B\(6),
	dataf => \b2v_inst_alu_8b|ALT_INV_Add5~29_sumout\,
	combout => \b2v_inst_alu_8b|Mux2~4_combout\);

-- Location: LABCELL_X79_Y7_N12
\b2v_inst_alu_8b|F9~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|F9~12_combout\ = !\b2v_inst_ac_a|A\(6) $ (!\b2v_inst_ac_b|B\(6))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001111001100001100111100110000110011110011000011001111001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \b2v_inst_ac_a|ALT_INV_A\(6),
	datad => \b2v_inst_ac_b|ALT_INV_B\(6),
	combout => \b2v_inst_alu_8b|F9~12_combout\);

-- Location: LABCELL_X79_Y7_N18
\b2v_inst_alu_8b|Mux2~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux2~5_combout\ = ( \b2v_inst_alu_8b|Add4~29_sumout\ & ( \b2v_inst_alu_8b|F9~12_combout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & ((!\b2v_inst_alu_8b|Mux4~5_combout\ & ((\b2v_inst_alu_8b|Mux2~4_combout\))) # 
-- (\b2v_inst_alu_8b|Mux4~5_combout\ & (\b2v_inst_alu_8b|Add3~29_sumout\)))) # (\b2v_inst_alu_8b|Mux7~4_combout\ & (\b2v_inst_alu_8b|Mux4~5_combout\)) ) ) ) # ( !\b2v_inst_alu_8b|Add4~29_sumout\ & ( \b2v_inst_alu_8b|F9~12_combout\ & ( 
-- (!\b2v_inst_alu_8b|Mux7~4_combout\ & ((!\b2v_inst_alu_8b|Mux4~5_combout\ & ((\b2v_inst_alu_8b|Mux2~4_combout\))) # (\b2v_inst_alu_8b|Mux4~5_combout\ & (\b2v_inst_alu_8b|Add3~29_sumout\)))) ) ) ) # ( \b2v_inst_alu_8b|Add4~29_sumout\ & ( 
-- !\b2v_inst_alu_8b|F9~12_combout\ & ( ((!\b2v_inst_alu_8b|Mux4~5_combout\ & ((\b2v_inst_alu_8b|Mux2~4_combout\))) # (\b2v_inst_alu_8b|Mux4~5_combout\ & (\b2v_inst_alu_8b|Add3~29_sumout\))) # (\b2v_inst_alu_8b|Mux7~4_combout\) ) ) ) # ( 
-- !\b2v_inst_alu_8b|Add4~29_sumout\ & ( !\b2v_inst_alu_8b|F9~12_combout\ & ( (!\b2v_inst_alu_8b|Mux7~4_combout\ & ((!\b2v_inst_alu_8b|Mux4~5_combout\ & ((\b2v_inst_alu_8b|Mux2~4_combout\))) # (\b2v_inst_alu_8b|Mux4~5_combout\ & 
-- (\b2v_inst_alu_8b|Add3~29_sumout\)))) # (\b2v_inst_alu_8b|Mux7~4_combout\ & (!\b2v_inst_alu_8b|Mux4~5_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100011011001110010101111101111100000010100010100001001110011011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux7~4_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~5_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Add3~29_sumout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux2~4_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Add4~29_sumout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_F9~12_combout\,
	combout => \b2v_inst_alu_8b|Mux2~5_combout\);

-- Location: LABCELL_X80_Y6_N24
\b2v_inst_alu_8b|Mux2~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux2~3_combout\ = ( \b2v_inst_ac_s|S\(1) & ( \b2v_inst_ac_a|A\(5) & ( (!\b2v_inst_alu_8b|Mux4~14_combout\ & \b2v_inst_alu_8b|Add7~29_sumout\) ) ) ) # ( !\b2v_inst_ac_s|S\(1) & ( \b2v_inst_ac_a|A\(5) & ( (!\b2v_inst_ac_s|S\(0) & 
-- (((!\b2v_inst_alu_8b|Mux4~14_combout\)))) # (\b2v_inst_ac_s|S\(0) & (((!\b2v_inst_alu_8b|Mux4~14_combout\ & \b2v_inst_alu_8b|Add7~29_sumout\)) # (\b2v_inst_alu_8b|Add6~29_sumout\))) ) ) ) # ( \b2v_inst_ac_s|S\(1) & ( !\b2v_inst_ac_a|A\(5) & ( 
-- (!\b2v_inst_alu_8b|Mux4~14_combout\ & \b2v_inst_alu_8b|Add7~29_sumout\) ) ) ) # ( !\b2v_inst_ac_s|S\(1) & ( !\b2v_inst_ac_a|A\(5) & ( (\b2v_inst_ac_s|S\(0) & (((!\b2v_inst_alu_8b|Mux4~14_combout\ & \b2v_inst_alu_8b|Add7~29_sumout\)) # 
-- (\b2v_inst_alu_8b|Add6~29_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100110001000000001111000011010001111100010000000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Add6~29_sumout\,
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~14_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Add7~29_sumout\,
	datae => \b2v_inst_ac_s|ALT_INV_S\(1),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(5),
	combout => \b2v_inst_alu_8b|Mux2~3_combout\);

-- Location: LABCELL_X83_Y6_N18
\b2v_inst_alu_8b|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux2~0_combout\ = ( \ALU~input_o\ & ( \b2v_inst_alu_8b|Add0~29_sumout\ & ( (\b2v_inst_ac_s|S\(0) & !\b2v_inst_alu_8b|Add1~29_sumout\) ) ) ) # ( !\ALU~input_o\ & ( \b2v_inst_alu_8b|Add0~29_sumout\ & ( (\b2v_inst_ac_b|B\(6) & 
-- ((\b2v_inst_ac_s|S\(0)) # (\b2v_inst_ac_a|A\(6)))) ) ) ) # ( \ALU~input_o\ & ( !\b2v_inst_alu_8b|Add0~29_sumout\ & ( (!\b2v_inst_ac_s|S\(0)) # (!\b2v_inst_alu_8b|Add1~29_sumout\) ) ) ) # ( !\ALU~input_o\ & ( !\b2v_inst_alu_8b|Add0~29_sumout\ & ( 
-- (\b2v_inst_ac_b|B\(6) & ((\b2v_inst_ac_s|S\(0)) # (\b2v_inst_ac_a|A\(6)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000011100000111111111111100110000000111000001110011001100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_a|ALT_INV_A\(6),
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_ac_b|ALT_INV_B\(6),
	datad => \b2v_inst_alu_8b|ALT_INV_Add1~29_sumout\,
	datae => \ALT_INV_ALU~input_o\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Add0~29_sumout\,
	combout => \b2v_inst_alu_8b|Mux2~0_combout\);

-- Location: MLABCELL_X78_Y5_N18
\b2v_inst_alu_8b|Mux2~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux2~1_combout\ = ( \b2v_inst_alu_8b|Mux2~0_combout\ & ( \b2v_inst_ac_a|A\(6) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & (!\b2v_inst_ac_b|B\(6) & ((\b2v_inst_alu_8b|Mux4~4_combout\)))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & 
-- ((!\b2v_inst_alu_8b|Mux4~4_combout\ & (!\b2v_inst_ac_b|B\(6))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & ((\b2v_inst_alu_8b|Add2~29_sumout\))))) ) ) ) # ( !\b2v_inst_alu_8b|Mux2~0_combout\ & ( \b2v_inst_ac_a|A\(6) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & 
-- ((!\b2v_inst_ac_b|B\(6)) # ((!\b2v_inst_alu_8b|Mux4~4_combout\)))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux4~4_combout\ & (!\b2v_inst_ac_b|B\(6))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & ((\b2v_inst_alu_8b|Add2~29_sumout\))))) ) ) ) # ( 
-- \b2v_inst_alu_8b|Mux2~0_combout\ & ( !\b2v_inst_ac_a|A\(6) & ( (\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux4~4_combout\ & (\b2v_inst_ac_b|B\(6))) # (\b2v_inst_alu_8b|Mux4~4_combout\ & ((\b2v_inst_alu_8b|Add2~29_sumout\))))) ) ) ) # ( 
-- !\b2v_inst_alu_8b|Mux2~0_combout\ & ( !\b2v_inst_ac_a|A\(6) & ( (!\b2v_inst_alu_8b|Mux4~3_combout\ & (((!\b2v_inst_alu_8b|Mux4~4_combout\)))) # (\b2v_inst_alu_8b|Mux4~3_combout\ & ((!\b2v_inst_alu_8b|Mux4~4_combout\ & (\b2v_inst_ac_b|B\(6))) # 
-- (\b2v_inst_alu_8b|Mux4~4_combout\ & ((\b2v_inst_alu_8b|Add2~29_sumout\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011101100000101000100010000010111101110100011010100010010001101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux4~3_combout\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(6),
	datac => \b2v_inst_alu_8b|ALT_INV_Add2~29_sumout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~4_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux2~0_combout\,
	dataf => \b2v_inst_ac_a|ALT_INV_A\(6),
	combout => \b2v_inst_alu_8b|Mux2~1_combout\);

-- Location: LABCELL_X79_Y7_N6
\b2v_inst_alu_8b|Mux2~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux2~2_combout\ = ( \b2v_inst_ac_b|B\(6) & ( \b2v_inst_ac_a|A\(6) & ( (\b2v_inst_ac_s|S\(2) & \b2v_inst_alu_8b|Mux2~1_combout\) ) ) ) # ( !\b2v_inst_ac_b|B\(6) & ( \b2v_inst_ac_a|A\(6) & ( (\b2v_inst_ac_s|S\(2) & 
-- \b2v_inst_alu_8b|Mux2~1_combout\) ) ) ) # ( \b2v_inst_ac_b|B\(6) & ( !\b2v_inst_ac_a|A\(6) & ( (!\b2v_inst_ac_s|S\(2) & (!\b2v_inst_ac_s|S\(0) & ((!\b2v_inst_ac_s|S\(1))))) # (\b2v_inst_ac_s|S\(2) & (((\b2v_inst_alu_8b|Mux2~1_combout\)))) ) ) ) # ( 
-- !\b2v_inst_ac_b|B\(6) & ( !\b2v_inst_ac_a|A\(6) & ( (!\b2v_inst_ac_s|S\(2) & ((!\b2v_inst_ac_s|S\(1)))) # (\b2v_inst_ac_s|S\(2) & (\b2v_inst_alu_8b|Mux2~1_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010111100000101100011010000010100000101000001010000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_s|ALT_INV_S\(2),
	datab => \b2v_inst_ac_s|ALT_INV_S\(0),
	datac => \b2v_inst_alu_8b|ALT_INV_Mux2~1_combout\,
	datad => \b2v_inst_ac_s|ALT_INV_S\(1),
	datae => \b2v_inst_ac_b|ALT_INV_B\(6),
	dataf => \b2v_inst_ac_a|ALT_INV_A\(6),
	combout => \b2v_inst_alu_8b|Mux2~2_combout\);

-- Location: LABCELL_X79_Y7_N30
\b2v_inst_alu_8b|Mux2~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux2~7_combout\ = ( !\b2v_inst_alu_8b|Mux4~7_combout\ & ( ((!\b2v_inst_alu_8b|Mux4~6_combout\ & ((!\b2v_inst_ac_b|B\(6)) # ((\b2v_inst_ac_a|A\(6))))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & (((\b2v_inst_alu_8b|Mux2~2_combout\))))) ) ) # ( 
-- \b2v_inst_alu_8b|Mux4~7_combout\ & ( ((!\b2v_inst_alu_8b|Mux4~6_combout\ & (((\b2v_inst_alu_8b|Mux2~3_combout\)))) # (\b2v_inst_alu_8b|Mux4~6_combout\ & (\b2v_inst_alu_8b|Mux2~5_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1100111100000000000011110101010111001111111111110000111101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux2~5_combout\,
	datab => \b2v_inst_ac_b|ALT_INV_B\(6),
	datac => \b2v_inst_alu_8b|ALT_INV_Mux2~3_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~6_combout\,
	datae => \b2v_inst_alu_8b|ALT_INV_Mux4~7_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux2~2_combout\,
	datag => \b2v_inst_ac_a|ALT_INV_A\(6),
	combout => \b2v_inst_alu_8b|Mux2~7_combout\);

-- Location: LABCELL_X85_Y6_N12
\b2v_inst_alu_8b|Mux2~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_alu_8b|Mux2~6_combout\ = ( \b2v_inst_ac_a|A\(6) & ( \b2v_inst_alu_8b|Mux2~7_combout\ & ( ((!\b2v_inst_alu_8b|Mux4~0_combout\) # (\b2v_inst_alu_8b|Mux4~1_combout\)) # (\b2v_inst_alu_8b|Mux4~2_combout\) ) ) ) # ( !\b2v_inst_ac_a|A\(6) & ( 
-- \b2v_inst_alu_8b|Mux2~7_combout\ & ( (!\b2v_inst_alu_8b|Mux4~0_combout\ & (((!\b2v_inst_alu_8b|Mux4~2_combout\)))) # (\b2v_inst_alu_8b|Mux4~0_combout\ & ((!\b2v_inst_alu_8b|Mux4~1_combout\ & (\b2v_inst_ac_b|B\(6))) # (\b2v_inst_alu_8b|Mux4~1_combout\ & 
-- ((!\b2v_inst_alu_8b|Mux4~2_combout\))))) ) ) ) # ( \b2v_inst_ac_a|A\(6) & ( !\b2v_inst_alu_8b|Mux2~7_combout\ & ( \b2v_inst_alu_8b|Mux4~2_combout\ ) ) ) # ( !\b2v_inst_ac_a|A\(6) & ( !\b2v_inst_alu_8b|Mux2~7_combout\ & ( (\b2v_inst_ac_b|B\(6) & 
-- (\b2v_inst_alu_8b|Mux4~0_combout\ & !\b2v_inst_alu_8b|Mux4~1_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000000001100110011001111000101110011001111001111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_ac_b|ALT_INV_B\(6),
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~2_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~0_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~1_combout\,
	datae => \b2v_inst_ac_a|ALT_INV_A\(6),
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux2~7_combout\,
	combout => \b2v_inst_alu_8b|Mux2~6_combout\);

-- Location: LABCELL_X85_Y6_N54
\b2v_inst_seg7|Mux13~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux13~0_combout\ = ( \b2v_inst_alu_8b|Mux2~6_combout\ & ( ((!\b2v_inst_alu_8b|Mux1~6_combout\ & (\b2v_inst_alu_8b|Mux3~5_combout\ & \b2v_inst_alu_8b|Mux4~13_combout\)) # (\b2v_inst_alu_8b|Mux1~6_combout\ & (!\b2v_inst_alu_8b|Mux3~5_combout\ 
-- & !\b2v_inst_alu_8b|Mux4~13_combout\))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_alu_8b|Mux2~6_combout\ & ( ((!\b2v_inst_alu_8b|Mux1~6_combout\ & !\b2v_inst_alu_8b|Mux3~5_combout\)) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000111110001111100011111000111101001111001011110100111100101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux1~6_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux3~5_combout\,
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~13_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux2~6_combout\,
	combout => \b2v_inst_seg7|Mux13~0_combout\);

-- Location: LABCELL_X85_Y6_N48
\b2v_inst_seg7|Mux12~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux12~0_combout\ = ( \b2v_inst_alu_8b|Mux2~6_combout\ & ( ((\b2v_inst_alu_8b|Mux4~13_combout\ & (!\b2v_inst_alu_8b|Mux1~6_combout\ $ (!\b2v_inst_alu_8b|Mux3~5_combout\)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_alu_8b|Mux2~6_combout\ & ( 
-- ((!\b2v_inst_alu_8b|Mux1~6_combout\ & ((\b2v_inst_alu_8b|Mux4~13_combout\) # (\b2v_inst_alu_8b|Mux3~5_combout\)))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010111110101111001011111010111100001111011011110000111101101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux1~6_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux3~5_combout\,
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~13_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux2~6_combout\,
	combout => \b2v_inst_seg7|Mux12~0_combout\);

-- Location: LABCELL_X85_Y6_N45
\b2v_inst_seg7|Mux11~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux11~0_combout\ = ( \SEG~input_o\ ) # ( !\SEG~input_o\ & ( (!\b2v_inst_alu_8b|Mux3~5_combout\ & ((!\b2v_inst_alu_8b|Mux2~6_combout\ & ((\b2v_inst_alu_8b|Mux4~13_combout\))) # (\b2v_inst_alu_8b|Mux2~6_combout\ & 
-- (!\b2v_inst_alu_8b|Mux1~6_combout\)))) # (\b2v_inst_alu_8b|Mux3~5_combout\ & (!\b2v_inst_alu_8b|Mux1~6_combout\ & ((\b2v_inst_alu_8b|Mux4~13_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010111000001010001011100000101011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux1~6_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux2~6_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux4~13_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux3~5_combout\,
	dataf => \ALT_INV_SEG~input_o\,
	combout => \b2v_inst_seg7|Mux11~0_combout\);

-- Location: LABCELL_X85_Y6_N42
\b2v_inst_seg7|Mux10~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux10~0_combout\ = ( \b2v_inst_alu_8b|Mux4~13_combout\ & ( ((!\b2v_inst_alu_8b|Mux2~6_combout\ & (!\b2v_inst_alu_8b|Mux1~6_combout\ & !\b2v_inst_alu_8b|Mux3~5_combout\)) # (\b2v_inst_alu_8b|Mux2~6_combout\ & 
-- ((\b2v_inst_alu_8b|Mux3~5_combout\)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_alu_8b|Mux4~13_combout\ & ( ((!\b2v_inst_alu_8b|Mux1~6_combout\ & (\b2v_inst_alu_8b|Mux2~6_combout\ & !\b2v_inst_alu_8b|Mux3~5_combout\)) # (\b2v_inst_alu_8b|Mux1~6_combout\ & 
-- (!\b2v_inst_alu_8b|Mux2~6_combout\ & \b2v_inst_alu_8b|Mux3~5_combout\))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010111101001111001011110100111110001111001111111000111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux1~6_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux2~6_combout\,
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux3~5_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux4~13_combout\,
	combout => \b2v_inst_seg7|Mux10~0_combout\);

-- Location: LABCELL_X85_Y6_N39
\b2v_inst_seg7|Mux9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux9~0_combout\ = ( \b2v_inst_alu_8b|Mux2~6_combout\ & ( ((\b2v_inst_alu_8b|Mux1~6_combout\ & ((!\b2v_inst_alu_8b|Mux4~13_combout\) # (\b2v_inst_alu_8b|Mux3~5_combout\)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_alu_8b|Mux2~6_combout\ & ( 
-- ((!\b2v_inst_alu_8b|Mux4~13_combout\ & (\b2v_inst_alu_8b|Mux3~5_combout\ & !\b2v_inst_alu_8b|Mux1~6_combout\))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101110101010101010111010101010101010101110111110101010111011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_SEG~input_o\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~13_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux3~5_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux1~6_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux2~6_combout\,
	combout => \b2v_inst_seg7|Mux9~0_combout\);

-- Location: LABCELL_X85_Y6_N0
\b2v_inst_seg7|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux8~0_combout\ = ( \b2v_inst_alu_8b|Mux2~6_combout\ & ( ((!\b2v_inst_alu_8b|Mux1~6_combout\ & (!\b2v_inst_alu_8b|Mux3~5_combout\ $ (!\b2v_inst_alu_8b|Mux4~13_combout\))) # (\b2v_inst_alu_8b|Mux1~6_combout\ & 
-- ((!\b2v_inst_alu_8b|Mux4~13_combout\) # (\b2v_inst_alu_8b|Mux3~5_combout\)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_alu_8b|Mux2~6_combout\ & ( ((\b2v_inst_alu_8b|Mux1~6_combout\ & (\b2v_inst_alu_8b|Mux3~5_combout\ & \b2v_inst_alu_8b|Mux4~13_combout\))) # 
-- (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100011111000011110001111101111111100111110111111110011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \b2v_inst_alu_8b|ALT_INV_Mux1~6_combout\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux3~5_combout\,
	datac => \ALT_INV_SEG~input_o\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux4~13_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux2~6_combout\,
	combout => \b2v_inst_seg7|Mux8~0_combout\);

-- Location: LABCELL_X85_Y6_N27
\b2v_inst_seg7|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \b2v_inst_seg7|Mux7~0_combout\ = ( \b2v_inst_alu_8b|Mux2~6_combout\ & ( ((!\b2v_inst_alu_8b|Mux3~5_combout\ & (!\b2v_inst_alu_8b|Mux4~13_combout\ $ (\b2v_inst_alu_8b|Mux1~6_combout\)))) # (\SEG~input_o\) ) ) # ( !\b2v_inst_alu_8b|Mux2~6_combout\ & ( 
-- ((\b2v_inst_alu_8b|Mux4~13_combout\ & (!\b2v_inst_alu_8b|Mux3~5_combout\ $ (\b2v_inst_alu_8b|Mux1~6_combout\)))) # (\SEG~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111010101010111011101010101011111010101011101011101010101110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_SEG~input_o\,
	datab => \b2v_inst_alu_8b|ALT_INV_Mux4~13_combout\,
	datac => \b2v_inst_alu_8b|ALT_INV_Mux3~5_combout\,
	datad => \b2v_inst_alu_8b|ALT_INV_Mux1~6_combout\,
	dataf => \b2v_inst_alu_8b|ALT_INV_Mux2~6_combout\,
	combout => \b2v_inst_seg7|Mux7~0_combout\);

-- Location: LABCELL_X22_Y16_N0
\~QUARTUS_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;
END structure;


