-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 20.1.1 Build 720 11/11/2020 SJ Lite Edition"

-- DATE "12/07/2025 01:24:41"

-- 
-- Device: Altera 5CSEMA5F31C6 Package FBGA896
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY ALTERA_LNSIM;
LIBRARY CYCLONEV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE ALTERA_LNSIM.ALTERA_LNSIM_COMPONENTS.ALL;
USE CYCLONEV.CYCLONEV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	ALU_RAM IS
    PORT (
	altera_reserved_tms : IN std_logic := '0';
	altera_reserved_tck : IN std_logic := '0';
	altera_reserved_tdi : IN std_logic := '0';
	altera_reserved_tdo : OUT std_logic;
	RQAddr1 : OUT std_logic_vector(6 DOWNTO 0);
	B_T_CN_M : IN std_logic;
	clkM : IN std_logic;
	clr : IN std_logic;
	LOAD_Addr_Data : IN std_logic;
	MDR_in : IN std_logic_vector(7 DOWNTO 0);
	RQAddr2 : OUT std_logic_vector(6 DOWNTO 0);
	RQALU1 : OUT std_logic_vector(6 DOWNTO 0);
	M_CN : IN std_logic;
	clk : IN std_logic;
	RQALU2 : OUT std_logic_vector(6 DOWNTO 0);
	RQData1 : OUT std_logic_vector(6 DOWNTO 0);
	RQData2 : OUT std_logic_vector(6 DOWNTO 0);
	SOUT : OUT std_logic_vector(3 DOWNTO 0)
	);
END ALU_RAM;

-- Design Ports Information
-- RQAddr1[6]	=>  Location: PIN_AA24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[5]	=>  Location: PIN_Y23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[4]	=>  Location: PIN_Y24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[3]	=>  Location: PIN_W22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[2]	=>  Location: PIN_W24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[1]	=>  Location: PIN_V23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[0]	=>  Location: PIN_W25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[6]	=>  Location: PIN_V25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[5]	=>  Location: PIN_AA28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[4]	=>  Location: PIN_Y27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[3]	=>  Location: PIN_AB27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[2]	=>  Location: PIN_AB26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[1]	=>  Location: PIN_AA26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[0]	=>  Location: PIN_AA25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[6]	=>  Location: PIN_AE26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[5]	=>  Location: PIN_AE27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[4]	=>  Location: PIN_AE28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[3]	=>  Location: PIN_AG27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[2]	=>  Location: PIN_AF28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[1]	=>  Location: PIN_AG28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[0]	=>  Location: PIN_AH28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[6]	=>  Location: PIN_AJ29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[5]	=>  Location: PIN_AH29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[4]	=>  Location: PIN_AH30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[3]	=>  Location: PIN_AG30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[2]	=>  Location: PIN_AF29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[1]	=>  Location: PIN_AF30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[0]	=>  Location: PIN_AD27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[6]	=>  Location: PIN_AB23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[5]	=>  Location: PIN_AE29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[4]	=>  Location: PIN_AD29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[3]	=>  Location: PIN_AC28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[2]	=>  Location: PIN_AD30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[1]	=>  Location: PIN_AC29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[0]	=>  Location: PIN_AC30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[6]	=>  Location: PIN_AD26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[5]	=>  Location: PIN_AC27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[4]	=>  Location: PIN_AD25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[3]	=>  Location: PIN_AC25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[2]	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[1]	=>  Location: PIN_AB25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[0]	=>  Location: PIN_AB22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SOUT[3]	=>  Location: PIN_V18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SOUT[2]	=>  Location: PIN_V17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SOUT[1]	=>  Location: PIN_W16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SOUT[0]	=>  Location: PIN_V16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- B_T_CN_M	=>  Location: PIN_AE12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M_CN	=>  Location: PIN_AD10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clkM	=>  Location: PIN_AA15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_AA14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- MDR_in[0]	=>  Location: PIN_AB12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LOAD_Addr_Data	=>  Location: PIN_W15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clr	=>  Location: PIN_Y16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- MDR_in[1]	=>  Location: PIN_AC12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- MDR_in[2]	=>  Location: PIN_AF9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- MDR_in[3]	=>  Location: PIN_AF10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- MDR_in[4]	=>  Location: PIN_AD11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- MDR_in[5]	=>  Location: PIN_AD12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- MDR_in[6]	=>  Location: PIN_AE11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- MDR_in[7]	=>  Location: PIN_AC9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- altera_reserved_tms	=>  Location: PIN_V9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- altera_reserved_tck	=>  Location: PIN_AC5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- altera_reserved_tdi	=>  Location: PIN_U8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- altera_reserved_tdo	=>  Location: PIN_AB9,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF ALU_RAM IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_altera_reserved_tms : std_logic;
SIGNAL ww_altera_reserved_tck : std_logic;
SIGNAL ww_altera_reserved_tdi : std_logic;
SIGNAL ww_altera_reserved_tdo : std_logic;
SIGNAL ww_RQAddr1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_B_T_CN_M : std_logic;
SIGNAL ww_clkM : std_logic;
SIGNAL ww_clr : std_logic;
SIGNAL ww_LOAD_Addr_Data : std_logic;
SIGNAL ww_MDR_in : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_RQAddr2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQALU1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_M_CN : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_RQALU2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQData1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQData2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_SOUT : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAIN_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAIN_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTAADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][6]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][7]~q\ : std_logic;
SIGNAL \auto_hub|~GND~combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~_wirecell_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[0]~_wirecell_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \B_T_CN_M~input_o\ : std_logic;
SIGNAL \clkM~input_o\ : std_logic;
SIGNAL \clkM~inputCLKENA0_outclk\ : std_logic;
SIGNAL \clr~input_o\ : std_logic;
SIGNAL \MDR_in[0]~input_o\ : std_logic;
SIGNAL \LOAD_Addr_Data~input_o\ : std_logic;
SIGNAL \MDR_in[1]~input_o\ : std_logic;
SIGNAL \MDR_in[2]~input_o\ : std_logic;
SIGNAL \MDR_in[3]~input_o\ : std_logic;
SIGNAL \MDR_in[4]~input_o\ : std_logic;
SIGNAL \MDR_in[5]~input_o\ : std_logic;
SIGNAL \MDR_in[6]~input_o\ : std_logic;
SIGNAL \MDR_in[7]~input_o\ : std_logic;
SIGNAL \inst5|Mux0~0_combout\ : std_logic;
SIGNAL \inst5|Mux1~0_combout\ : std_logic;
SIGNAL \inst5|Mux2~0_combout\ : std_logic;
SIGNAL \inst5|Mux3~0_combout\ : std_logic;
SIGNAL \inst5|Mux4~0_combout\ : std_logic;
SIGNAL \inst5|Mux5~0_combout\ : std_logic;
SIGNAL \inst5|Mux6~0_combout\ : std_logic;
SIGNAL \inst5|Mux7~0_combout\ : std_logic;
SIGNAL \inst5|Mux8~0_combout\ : std_logic;
SIGNAL \inst5|Mux9~0_combout\ : std_logic;
SIGNAL \inst5|Mux10~0_combout\ : std_logic;
SIGNAL \inst5|Mux11~0_combout\ : std_logic;
SIGNAL \inst5|Mux12~0_combout\ : std_logic;
SIGNAL \inst5|Mux13~0_combout\ : std_logic;
SIGNAL \altera_reserved_tms~input_o\ : std_logic;
SIGNAL \altera_reserved_tck~input_o\ : std_logic;
SIGNAL \altera_reserved_tdi~input_o\ : std_logic;
SIGNAL \altera_internal_jtag~TMSUTAP\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~9_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~12_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~13_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~10_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~11_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[6]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~7_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~8_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~3_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~1_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[0]~feeder_combout\ : std_logic;
SIGNAL \altera_internal_jtag~TDIUTAP\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[8]~feeder_combout\ : std_logic;
SIGNAL \~QIC_CREATED_GND~I_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~7_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[1]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal3~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~14_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[0]~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~8_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][3]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[7]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[6]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[2]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[0]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_dr_scan_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~2_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_incr_addr~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]~q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[0]~2_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[2]~1_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~2\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~5_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[1]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~6\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~9_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[2]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~10\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~13_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[3]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~14\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~17_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[4]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~18\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~21_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~22\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~25_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[6]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~26\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~29_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[4]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[5]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[6]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~12_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~11_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~10_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~9_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[2]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[1]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|clear_signal~combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[0]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[1]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Add0~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~9_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~10_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~7_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~8_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[1]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[1]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~2_combout\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputCLKENA0_outclk\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~sumout\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ : std_logic;
SIGNAL \M_CN~input_o\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[7]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[6]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[5]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[4]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[3]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[2]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~feeder_combout\ : std_logic;
SIGNAL \inst4|Add4~2\ : std_logic;
SIGNAL \inst4|Add4~6\ : std_logic;
SIGNAL \inst4|Add4~10\ : std_logic;
SIGNAL \inst4|Add4~14\ : std_logic;
SIGNAL \inst4|Add4~18\ : std_logic;
SIGNAL \inst4|Add4~22\ : std_logic;
SIGNAL \inst4|Add4~26\ : std_logic;
SIGNAL \inst4|Add4~29_sumout\ : std_logic;
SIGNAL \inst4|Add5~2\ : std_logic;
SIGNAL \inst4|Add5~6\ : std_logic;
SIGNAL \inst4|Add5~10\ : std_logic;
SIGNAL \inst4|Add5~14\ : std_logic;
SIGNAL \inst4|Add5~18\ : std_logic;
SIGNAL \inst4|Add5~22\ : std_logic;
SIGNAL \inst4|Add5~26\ : std_logic;
SIGNAL \inst4|Add5~29_sumout\ : std_logic;
SIGNAL \inst4|Mux1~13_combout\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~COUT\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~sumout\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ : std_logic;
SIGNAL \inst4|Mux7~5_combout\ : std_logic;
SIGNAL \inst4|Add3~2\ : std_logic;
SIGNAL \inst4|Add3~6\ : std_logic;
SIGNAL \inst4|Add3~10\ : std_logic;
SIGNAL \inst4|Add3~14\ : std_logic;
SIGNAL \inst4|Add3~18\ : std_logic;
SIGNAL \inst4|Add3~22\ : std_logic;
SIGNAL \inst4|Add3~26\ : std_logic;
SIGNAL \inst4|Add3~29_sumout\ : std_logic;
SIGNAL \inst4|F9~13_combout\ : std_logic;
SIGNAL \inst4|Mux1~6_combout\ : std_logic;
SIGNAL \inst4|Mux1~14_combout\ : std_logic;
SIGNAL \inst4|Add6~2\ : std_logic;
SIGNAL \inst4|Add6~6\ : std_logic;
SIGNAL \inst4|Add6~10\ : std_logic;
SIGNAL \inst4|Add6~14\ : std_logic;
SIGNAL \inst4|Add6~18\ : std_logic;
SIGNAL \inst4|Add6~22\ : std_logic;
SIGNAL \inst4|Add6~26\ : std_logic;
SIGNAL \inst4|Add6~29_sumout\ : std_logic;
SIGNAL \inst4|Add7~2\ : std_logic;
SIGNAL \inst4|Add7~6\ : std_logic;
SIGNAL \inst4|Add7~10\ : std_logic;
SIGNAL \inst4|Add7~14\ : std_logic;
SIGNAL \inst4|Add7~18\ : std_logic;
SIGNAL \inst4|Add7~22\ : std_logic;
SIGNAL \inst4|Add7~26\ : std_logic;
SIGNAL \inst4|Add7~29_sumout\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~COUT\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita2~sumout\ : std_logic;
SIGNAL \inst4|Mux1~5_combout\ : std_logic;
SIGNAL \inst4|Mux1~12_combout\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita2~COUT\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita3~sumout\ : std_logic;
SIGNAL \inst4|Mux1~7_combout\ : std_logic;
SIGNAL \inst4|Mux1~8_combout\ : std_logic;
SIGNAL \inst4|Mux1~4_combout\ : std_logic;
SIGNAL \inst4|Add0~2\ : std_logic;
SIGNAL \inst4|Add0~6\ : std_logic;
SIGNAL \inst4|Add0~10\ : std_logic;
SIGNAL \inst4|Add0~14\ : std_logic;
SIGNAL \inst4|Add0~18\ : std_logic;
SIGNAL \inst4|Add0~22\ : std_logic;
SIGNAL \inst4|Add0~26\ : std_logic;
SIGNAL \inst4|Add0~29_sumout\ : std_logic;
SIGNAL \inst4|Add1~2\ : std_logic;
SIGNAL \inst4|Add1~6\ : std_logic;
SIGNAL \inst4|Add1~10\ : std_logic;
SIGNAL \inst4|Add1~14\ : std_logic;
SIGNAL \inst4|Add1~18\ : std_logic;
SIGNAL \inst4|Add1~22\ : std_logic;
SIGNAL \inst4|Add1~26\ : std_logic;
SIGNAL \inst4|Add1~29_sumout\ : std_logic;
SIGNAL \inst4|Mux1~9_combout\ : std_logic;
SIGNAL \inst4|Mux1~3_combout\ : std_logic;
SIGNAL \inst4|Add2~2\ : std_logic;
SIGNAL \inst4|Add2~3\ : std_logic;
SIGNAL \inst4|Add2~6\ : std_logic;
SIGNAL \inst4|Add2~7\ : std_logic;
SIGNAL \inst4|Add2~10\ : std_logic;
SIGNAL \inst4|Add2~11\ : std_logic;
SIGNAL \inst4|Add2~14\ : std_logic;
SIGNAL \inst4|Add2~15\ : std_logic;
SIGNAL \inst4|Add2~18\ : std_logic;
SIGNAL \inst4|Add2~19\ : std_logic;
SIGNAL \inst4|Add2~22\ : std_logic;
SIGNAL \inst4|Add2~23\ : std_logic;
SIGNAL \inst4|Add2~26\ : std_logic;
SIGNAL \inst4|Add2~27\ : std_logic;
SIGNAL \inst4|Add2~29_sumout\ : std_logic;
SIGNAL \inst4|Mux1~10_combout\ : std_logic;
SIGNAL \inst4|Mux1~11_combout\ : std_logic;
SIGNAL \inst4|Mux1~16_combout\ : std_logic;
SIGNAL \inst4|Mux1~2_combout\ : std_logic;
SIGNAL \inst4|Mux1~0_combout\ : std_logic;
SIGNAL \inst4|Mux1~1_combout\ : std_logic;
SIGNAL \inst4|Mux1~15_combout\ : std_logic;
SIGNAL \inst4|Add7~25_sumout\ : std_logic;
SIGNAL \inst4|Add6~25_sumout\ : std_logic;
SIGNAL \inst4|Mux2~3_combout\ : std_logic;
SIGNAL \inst4|Add0~25_sumout\ : std_logic;
SIGNAL \inst4|Add1~25_sumout\ : std_logic;
SIGNAL \inst4|Mux2~0_combout\ : std_logic;
SIGNAL \inst4|Add2~25_sumout\ : std_logic;
SIGNAL \inst4|Mux2~1_combout\ : std_logic;
SIGNAL \inst4|Mux2~2_combout\ : std_logic;
SIGNAL \inst4|F9~12_combout\ : std_logic;
SIGNAL \inst4|Add3~25_sumout\ : std_logic;
SIGNAL \inst4|Add4~25_sumout\ : std_logic;
SIGNAL \inst4|Add5~25_sumout\ : std_logic;
SIGNAL \inst4|Mux2~4_combout\ : std_logic;
SIGNAL \inst4|Mux2~5_combout\ : std_logic;
SIGNAL \inst4|Mux2~7_combout\ : std_logic;
SIGNAL \inst4|Mux2~6_combout\ : std_logic;
SIGNAL \inst4|F9~11_combout\ : std_logic;
SIGNAL \inst4|Add4~21_sumout\ : std_logic;
SIGNAL \inst4|Add3~21_sumout\ : std_logic;
SIGNAL \inst4|Add5~21_sumout\ : std_logic;
SIGNAL \inst4|Mux3~4_combout\ : std_logic;
SIGNAL \inst4|Mux3~5_combout\ : std_logic;
SIGNAL \inst4|Add6~21_sumout\ : std_logic;
SIGNAL \inst4|Add7~21_sumout\ : std_logic;
SIGNAL \inst4|Mux3~3_combout\ : std_logic;
SIGNAL \inst4|Add1~21_sumout\ : std_logic;
SIGNAL \inst4|Add0~21_sumout\ : std_logic;
SIGNAL \inst4|Mux3~0_combout\ : std_logic;
SIGNAL \inst4|Add2~21_sumout\ : std_logic;
SIGNAL \inst4|Mux3~1_combout\ : std_logic;
SIGNAL \inst4|Mux3~2_combout\ : std_logic;
SIGNAL \inst4|Mux3~7_combout\ : std_logic;
SIGNAL \inst4|Mux3~6_combout\ : std_logic;
SIGNAL \inst4|Add1~17_sumout\ : std_logic;
SIGNAL \inst4|Add0~17_sumout\ : std_logic;
SIGNAL \inst4|Mux4~0_combout\ : std_logic;
SIGNAL \inst4|Add2~17_sumout\ : std_logic;
SIGNAL \inst4|Mux4~1_combout\ : std_logic;
SIGNAL \inst4|Mux4~2_combout\ : std_logic;
SIGNAL \inst4|Add6~17_sumout\ : std_logic;
SIGNAL \inst4|Add7~17_sumout\ : std_logic;
SIGNAL \inst4|Mux4~3_combout\ : std_logic;
SIGNAL \inst4|Add4~17_sumout\ : std_logic;
SIGNAL \inst4|F9~10_combout\ : std_logic;
SIGNAL \inst4|Add5~17_sumout\ : std_logic;
SIGNAL \inst4|Mux4~4_combout\ : std_logic;
SIGNAL \inst4|Add3~17_sumout\ : std_logic;
SIGNAL \inst4|Mux4~5_combout\ : std_logic;
SIGNAL \inst4|Mux4~7_combout\ : std_logic;
SIGNAL \inst4|Mux4~6_combout\ : std_logic;
SIGNAL \inst4|Add4~13_sumout\ : std_logic;
SIGNAL \inst4|F9~9_combout\ : std_logic;
SIGNAL \inst4|Add3~13_sumout\ : std_logic;
SIGNAL \inst4|Add5~13_sumout\ : std_logic;
SIGNAL \inst4|Mux5~4_combout\ : std_logic;
SIGNAL \inst4|Mux5~5_combout\ : std_logic;
SIGNAL \inst4|Add6~13_sumout\ : std_logic;
SIGNAL \inst4|Add7~13_sumout\ : std_logic;
SIGNAL \inst4|Mux5~3_combout\ : std_logic;
SIGNAL \inst4|Add0~13_sumout\ : std_logic;
SIGNAL \inst4|Add1~13_sumout\ : std_logic;
SIGNAL \inst4|Mux5~0_combout\ : std_logic;
SIGNAL \inst4|Add2~13_sumout\ : std_logic;
SIGNAL \inst4|Mux5~1_combout\ : std_logic;
SIGNAL \inst4|Mux5~2_combout\ : std_logic;
SIGNAL \inst4|Mux5~7_combout\ : std_logic;
SIGNAL \inst4|Mux5~6_combout\ : std_logic;
SIGNAL \inst4|Add5~9_sumout\ : std_logic;
SIGNAL \inst4|Mux6~4_combout\ : std_logic;
SIGNAL \inst4|F9~8_combout\ : std_logic;
SIGNAL \inst4|Add3~9_sumout\ : std_logic;
SIGNAL \inst4|Add4~9_sumout\ : std_logic;
SIGNAL \inst4|Mux6~5_combout\ : std_logic;
SIGNAL \inst4|Add6~9_sumout\ : std_logic;
SIGNAL \inst4|Add7~9_sumout\ : std_logic;
SIGNAL \inst4|Mux6~3_combout\ : std_logic;
SIGNAL \inst4|Add2~9_sumout\ : std_logic;
SIGNAL \inst4|Add0~9_sumout\ : std_logic;
SIGNAL \inst4|Add1~9_sumout\ : std_logic;
SIGNAL \inst4|Mux6~0_combout\ : std_logic;
SIGNAL \inst4|Mux6~1_combout\ : std_logic;
SIGNAL \inst4|Mux6~2_combout\ : std_logic;
SIGNAL \inst4|Mux6~7_combout\ : std_logic;
SIGNAL \inst4|Mux6~6_combout\ : std_logic;
SIGNAL \inst4|Add4~1_sumout\ : std_logic;
SIGNAL \inst4|Add2~1_sumout\ : std_logic;
SIGNAL \inst4|F9~2_combout\ : std_logic;
SIGNAL \inst4|F9~0_combout\ : std_logic;
SIGNAL \inst4|Add7~1_sumout\ : std_logic;
SIGNAL \inst4|F9~3_combout\ : std_logic;
SIGNAL \inst4|Add5~1_sumout\ : std_logic;
SIGNAL \inst4|F9~1_combout\ : std_logic;
SIGNAL \inst4|Mux8~0_combout\ : std_logic;
SIGNAL \inst4|Add6~1_sumout\ : std_logic;
SIGNAL \inst4|F9~6_combout\ : std_logic;
SIGNAL \inst4|Add1~1_sumout\ : std_logic;
SIGNAL \inst4|F9~5_combout\ : std_logic;
SIGNAL \inst4|F9~4_combout\ : std_logic;
SIGNAL \inst4|Mux8~3_combout\ : std_logic;
SIGNAL \inst4|Mux8~1_combout\ : std_logic;
SIGNAL \inst4|Add3~1_sumout\ : std_logic;
SIGNAL \inst4|Add0~1_sumout\ : std_logic;
SIGNAL \inst4|Mux8~7_combout\ : std_logic;
SIGNAL \inst4|Mux8~2_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|clear_signal~combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~5_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[4]~DUPLICATE_q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~3_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[2]~DUPLICATE_q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|Equal0~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~2_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~4_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~feeder_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~3_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~DUPLICATE_q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~5_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~7_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~8_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~6_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~4_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|adapted_tdo~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo~q\ : std_logic;
SIGNAL \altera_internal_jtag~TCKUTAP\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal1~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg~q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|enable_write~0_combout\ : std_logic;
SIGNAL \inst4|F9~7_combout\ : std_logic;
SIGNAL \inst4|Add5~5_sumout\ : std_logic;
SIGNAL \inst4|Mux7~4_combout\ : std_logic;
SIGNAL \inst4|Add4~5_sumout\ : std_logic;
SIGNAL \inst4|Add3~5_sumout\ : std_logic;
SIGNAL \inst4|Mux7~6_combout\ : std_logic;
SIGNAL \inst4|Add6~5_sumout\ : std_logic;
SIGNAL \inst4|Add7~5_sumout\ : std_logic;
SIGNAL \inst4|Mux7~3_combout\ : std_logic;
SIGNAL \inst4|Add0~5_sumout\ : std_logic;
SIGNAL \inst4|Add1~5_sumout\ : std_logic;
SIGNAL \inst4|Mux7~0_combout\ : std_logic;
SIGNAL \inst4|Add2~5_sumout\ : std_logic;
SIGNAL \inst4|Mux7~1_combout\ : std_logic;
SIGNAL \inst4|Mux7~2_combout\ : std_logic;
SIGNAL \inst4|Mux7~8_combout\ : std_logic;
SIGNAL \inst4|Mux7~7_combout\ : std_logic;
SIGNAL \inst6|Mux0~0_combout\ : std_logic;
SIGNAL \inst6|Mux1~0_combout\ : std_logic;
SIGNAL \inst6|Mux2~0_combout\ : std_logic;
SIGNAL \inst6|Mux3~0_combout\ : std_logic;
SIGNAL \inst6|Mux4~0_combout\ : std_logic;
SIGNAL \inst6|Mux5~0_combout\ : std_logic;
SIGNAL \inst6|Mux6~0_combout\ : std_logic;
SIGNAL \inst6|Mux7~0_combout\ : std_logic;
SIGNAL \inst6|Mux8~0_combout\ : std_logic;
SIGNAL \inst6|Mux9~0_combout\ : std_logic;
SIGNAL \inst6|Mux10~0_combout\ : std_logic;
SIGNAL \inst6|Mux11~0_combout\ : std_logic;
SIGNAL \inst6|Mux12~0_combout\ : std_logic;
SIGNAL \inst6|Mux13~0_combout\ : std_logic;
SIGNAL \inst7|Mux0~0_combout\ : std_logic;
SIGNAL \inst7|Mux1~0_combout\ : std_logic;
SIGNAL \inst7|Mux2~0_combout\ : std_logic;
SIGNAL \inst7|Mux3~0_combout\ : std_logic;
SIGNAL \inst7|Mux4~0_combout\ : std_logic;
SIGNAL \inst7|Mux5~0_combout\ : std_logic;
SIGNAL \inst7|Mux6~0_combout\ : std_logic;
SIGNAL \inst7|Mux7~0_combout\ : std_logic;
SIGNAL \inst7|Mux8~0_combout\ : std_logic;
SIGNAL \inst7|Mux9~0_combout\ : std_logic;
SIGNAL \inst7|Mux10~0_combout\ : std_logic;
SIGNAL \inst7|Mux11~0_combout\ : std_logic;
SIGNAL \inst7|Mux12~0_combout\ : std_logic;
SIGNAL \inst7|Mux13~0_combout\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[3]~DUPLICATE_q\ : std_logic;
SIGNAL \altera_internal_jtag~TDO\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst2|altsyncram_component|auto_generated|q_a\ : std_logic_vector(31 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|altsyncram1|q_b\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\ : std_logic_vector(6 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst|b2v_instlatch1|latches\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\ : std_logic_vector(8 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0\ : std_logic_vector(30 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\ : std_logic_vector(9 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[4]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[1]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[3]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[2]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[0]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[0]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg[8]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[1]~DUPLICATE_q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[4]~DUPLICATE_q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[2]~DUPLICATE_q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\ : std_logic;
SIGNAL \ALT_INV_clkM~inputCLKENA0_outclk\ : std_logic;
SIGNAL \ALT_INV_MDR_in[7]~input_o\ : std_logic;
SIGNAL \ALT_INV_MDR_in[6]~input_o\ : std_logic;
SIGNAL \ALT_INV_MDR_in[5]~input_o\ : std_logic;
SIGNAL \ALT_INV_MDR_in[4]~input_o\ : std_logic;
SIGNAL \ALT_INV_MDR_in[3]~input_o\ : std_logic;
SIGNAL \ALT_INV_MDR_in[2]~input_o\ : std_logic;
SIGNAL \ALT_INV_MDR_in[1]~input_o\ : std_logic;
SIGNAL \ALT_INV_clr~input_o\ : std_logic;
SIGNAL \ALT_INV_LOAD_Addr_Data~input_o\ : std_logic;
SIGNAL \ALT_INV_MDR_in[0]~input_o\ : std_logic;
SIGNAL \ALT_INV_M_CN~input_o\ : std_logic;
SIGNAL \ALT_INV_B_T_CN_M~input_o\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~9_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~7_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Add0~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal3~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state~14_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~7_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[2]~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[1]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\ : std_logic_vector(8 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal0~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\ : std_logic_vector(9 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_bypass_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_info_reg_ena~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][5]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][4]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\ : std_logic_vector(3 DOWNTO 3);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~6_combout\ : std_logic;
SIGNAL \ALT_INV_altera_internal_jtag~TDIUTAP\ : std_logic;
SIGNAL \ALT_INV_altera_internal_jtag~TCKUTAP\ : std_logic;
SIGNAL \ALT_INV_altera_internal_jtag~TMSUTAP\ : std_logic;
SIGNAL \inst|b2v_instlatch1|ALT_INV_latches\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~7_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~5_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter~4_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_clear_signal~combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_Equal0~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~3_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_incr_addr~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~3_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[0]~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_bypass_reg_out~q\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\ : std_logic_vector(6 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~q\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~15_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~14_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~13_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~13_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~12_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~11_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~10_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~9_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux2~6_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux2~5_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~12_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux2~4_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux2~3_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux2~2_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux2~1_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux2~0_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux3~6_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux3~5_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~11_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux3~4_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux3~3_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux3~2_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux3~1_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux3~0_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux4~6_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux4~5_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~10_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux4~4_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux4~3_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux4~2_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux4~1_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux4~0_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux5~6_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux5~5_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~9_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux5~4_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux5~3_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux5~2_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux5~1_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux5~0_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux6~6_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux6~5_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~8_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux6~4_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux6~3_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux6~2_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux6~1_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux7~7_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~8_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~7_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux7~6_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux7~5_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~6_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~7_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux7~4_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux7~3_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~5_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux7~2_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux7~1_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux7~0_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~4_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~3_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~2_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~1_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~0_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux8~2_combout\ : std_logic;
SIGNAL \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst4|ALT_INV_Mux8~1_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~6_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~5_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~4_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux8~0_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~3_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~2_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~1_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_F9~0_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux8~7_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux8~3_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux7~8_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux6~7_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux5~7_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux4~7_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux3~7_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux2~7_combout\ : std_logic;
SIGNAL \inst4|ALT_INV_Mux1~16_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_adapted_tdo~0_combout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg\ : std_logic_vector(0 DOWNTO 0);
SIGNAL \inst4|ALT_INV_Add4~29_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add3~29_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add5~29_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add6~29_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add7~29_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add2~29_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add1~29_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add4~25_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add3~25_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add5~25_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add6~25_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add7~25_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add2~25_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add1~25_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add4~21_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add3~21_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add5~21_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add6~21_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add7~21_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add2~21_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add1~21_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add4~17_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add3~17_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add5~17_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add6~17_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add7~17_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add2~17_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add1~17_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add4~13_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add3~13_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add5~13_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add6~13_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add7~13_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add2~13_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add1~13_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add4~9_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add3~9_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add5~9_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add6~9_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add7~9_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add2~9_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add1~9_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add4~5_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add3~5_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add5~5_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add6~5_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add7~5_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add2~5_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add1~5_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add6~1_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add1~1_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add7~1_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add4~1_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add2~1_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add5~1_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add3~1_sumout\ : std_logic;
SIGNAL \inst4|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\ : std_logic_vector(7 DOWNTO 0);

BEGIN

ww_altera_reserved_tms <= altera_reserved_tms;
ww_altera_reserved_tck <= altera_reserved_tck;
ww_altera_reserved_tdi <= altera_reserved_tdi;
altera_reserved_tdo <= ww_altera_reserved_tdo;
RQAddr1 <= ww_RQAddr1;
ww_B_T_CN_M <= B_T_CN_M;
ww_clkM <= clkM;
ww_clr <= clr;
ww_LOAD_Addr_Data <= LOAD_Addr_Data;
ww_MDR_in <= MDR_in;
RQAddr2 <= ww_RQAddr2;
RQALU1 <= ww_RQALU1;
ww_M_CN <= M_CN;
ww_clk <= clk;
RQALU2 <= ww_RQALU2;
RQData1 <= ww_RQData1;
RQData2 <= ww_RQData2;
SOUT <= ww_SOUT;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\inst2|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\ <= (\inst|b2v_instlatch1|latches\(7) & \inst|b2v_instlatch1|latches\(6) & \inst|b2v_instlatch1|latches\(5) & \inst|b2v_instlatch1|latches\(4) & 
\inst|b2v_instlatch1|latches\(3) & \inst|b2v_instlatch1|latches\(2) & \inst|b2v_instlatch1|latches\(1) & \inst|b2v_instlatch1|latches\(0));

\inst2|altsyncram_component|auto_generated|q_a\(0) <= \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(0);
\inst2|altsyncram_component|auto_generated|q_a\(1) <= \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(1);
\inst2|altsyncram_component|auto_generated|q_a\(2) <= \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(2);
\inst2|altsyncram_component|auto_generated|q_a\(3) <= \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(3);
\inst2|altsyncram_component|auto_generated|q_a\(4) <= \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(4);
\inst2|altsyncram_component|auto_generated|q_a\(5) <= \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(5);
\inst2|altsyncram_component|auto_generated|q_a\(6) <= \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(6);
\inst2|altsyncram_component|auto_generated|q_a\(7) <= \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(7);

\inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAIN_bus\ <= (gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & \inst4|Mux1~15_combout\ & \inst4|Mux2~6_combout\ & \inst4|Mux3~6_combout\ & 
\inst4|Mux4~6_combout\ & \inst4|Mux5~6_combout\ & \inst4|Mux6~6_combout\ & \inst4|Mux7~7_combout\ & \inst4|Mux8~2_combout\);

\inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAIN_bus\ <= (gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(7) & 
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(6) & \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(5) & \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(4) & 
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(3) & \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(2) & \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(1) & 
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(0));

\inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTAADDR_bus\ <= (\inst|b2v_instlatch1|latches\(7) & \inst|b2v_instlatch1|latches\(6) & \inst|b2v_instlatch1|latches\(5) & \inst|b2v_instlatch1|latches\(4) & 
\inst|b2v_instlatch1|latches\(3) & \inst|b2v_instlatch1|latches\(2) & \inst|b2v_instlatch1|latches\(1) & \inst|b2v_instlatch1|latches\(0));

\inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBADDR_bus\ <= (\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(7) & \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(6) & 
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(5) & \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(4) & \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(3) & 
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(2) & \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(1) & \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(0));

\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(0);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(1);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(2);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(3);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(4);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(5);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(6);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(7);

\inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(0) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(0);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(1) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(1);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(2) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(2);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(3) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(3);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(4) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(4);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(5) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(5);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(6) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(6);
\inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(7) <= \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(7);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[4]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]~DUPLICATE_q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[1]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]~DUPLICATE_q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[3]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]~DUPLICATE_q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[2]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~DUPLICATE_q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[0]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~DUPLICATE_q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[0]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[0]~DUPLICATE_q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg[8]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~DUPLICATE_q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[1]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[1]~DUPLICATE_q\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[4]~DUPLICATE_q\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[4]~DUPLICATE_q\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[2]~DUPLICATE_q\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[2]~DUPLICATE_q\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~DUPLICATE_q\;
\inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\ <= NOT \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\;
\inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\ <= NOT \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\;
\ALT_INV_clkM~inputCLKENA0_outclk\ <= NOT \clkM~inputCLKENA0_outclk\;
\ALT_INV_MDR_in[7]~input_o\ <= NOT \MDR_in[7]~input_o\;
\ALT_INV_MDR_in[6]~input_o\ <= NOT \MDR_in[6]~input_o\;
\ALT_INV_MDR_in[5]~input_o\ <= NOT \MDR_in[5]~input_o\;
\ALT_INV_MDR_in[4]~input_o\ <= NOT \MDR_in[4]~input_o\;
\ALT_INV_MDR_in[3]~input_o\ <= NOT \MDR_in[3]~input_o\;
\ALT_INV_MDR_in[2]~input_o\ <= NOT \MDR_in[2]~input_o\;
\ALT_INV_MDR_in[1]~input_o\ <= NOT \MDR_in[1]~input_o\;
\ALT_INV_clr~input_o\ <= NOT \clr~input_o\;
\ALT_INV_LOAD_Addr_Data~input_o\ <= NOT \LOAD_Addr_Data~input_o\;
\ALT_INV_MDR_in[0]~input_o\ <= NOT \MDR_in[0]~input_o\;
\ALT_INV_M_CN~input_o\ <= NOT \M_CN~input_o\;
\ALT_INV_B_T_CN_M~input_o\ <= NOT \B_T_CN_M~input_o\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~5_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~5_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~9_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~9_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~5_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~5_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~4_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~4_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~7_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~7_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~6_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~6_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~2_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~2_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~3_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~3_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(4) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(4);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~5_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~5_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~4_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~4_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Add0~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Add0~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal3~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal3~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state~14_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~14_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~7_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~7_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~6_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~6_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[2]~5_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~5_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[1]~1_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~1_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg_proc~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg_proc~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|clear_signal~combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~1_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~1_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(4);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_proc~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_proc~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg~4_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~4_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(7) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(7);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(6) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(6);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(5) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(5);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(4) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(4);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state~6_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~6_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal0~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(5) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(5);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(6) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(6);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(7) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(7);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(8) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(8);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(9) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(9);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(4) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(4);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~1_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~1_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_dr_scan_reg~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena_proc~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena_proc~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~4_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~4_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~3_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~3_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~2_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~2_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~1_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~1_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_bypass_reg~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_info_reg_ena~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][5]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][4]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][3]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(15) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(15);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(14) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(14);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(12) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(12);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(10) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(10);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(9) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(9);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(8);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(7);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(5);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~6_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~6_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(8);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(13) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(13);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(11) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(6) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(6);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(4);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(1);
\ALT_INV_altera_internal_jtag~TDIUTAP\ <= NOT \altera_internal_jtag~TDIUTAP\;
\ALT_INV_altera_internal_jtag~TCKUTAP\ <= NOT \altera_internal_jtag~TCKUTAP\;
\ALT_INV_altera_internal_jtag~TMSUTAP\ <= NOT \altera_internal_jtag~TMSUTAP\;
\inst|b2v_instlatch1|ALT_INV_latches\(7) <= NOT \inst|b2v_instlatch1|latches\(7);
\inst|b2v_instlatch1|ALT_INV_latches\(6) <= NOT \inst|b2v_instlatch1|latches\(6);
\inst|b2v_instlatch1|ALT_INV_latches\(5) <= NOT \inst|b2v_instlatch1|latches\(5);
\inst|b2v_instlatch1|ALT_INV_latches\(4) <= NOT \inst|b2v_instlatch1|latches\(4);
\inst|b2v_instlatch1|ALT_INV_latches\(3) <= NOT \inst|b2v_instlatch1|latches\(3);
\inst|b2v_instlatch1|ALT_INV_latches\(2) <= NOT \inst|b2v_instlatch1|latches\(2);
\inst|b2v_instlatch1|ALT_INV_latches\(1) <= NOT \inst|b2v_instlatch1|latches\(1);
\inst|b2v_instlatch1|ALT_INV_latches\(0) <= NOT \inst|b2v_instlatch1|latches\(0);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~7_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~7_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~5_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~5_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(3) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(3);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter~4_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~4_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_clear_signal~combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|clear_signal~combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_Equal0~0_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|Equal0~0_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(2) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(2);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~3_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~3_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_incr_addr~0_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_incr_addr~0_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~3_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[0]~0_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~0_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(0);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(2);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(1) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(1);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~0_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~0_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(4);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(3);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(2);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(1);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(0);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(1) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(1);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~0_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~0_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~0_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_bypass_reg_out~q\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~q\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(0) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(0);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(6) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(6);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(5) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(5);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(4) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(4);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(3) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(3);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(2) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(2);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(1) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(1);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(0) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(0);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~q\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~q\;
\inst4|ALT_INV_Mux1~15_combout\ <= NOT \inst4|Mux1~15_combout\;
\inst4|ALT_INV_Mux1~14_combout\ <= NOT \inst4|Mux1~14_combout\;
\inst4|ALT_INV_F9~13_combout\ <= NOT \inst4|F9~13_combout\;
\inst4|ALT_INV_Mux1~13_combout\ <= NOT \inst4|Mux1~13_combout\;
\inst4|ALT_INV_Mux1~12_combout\ <= NOT \inst4|Mux1~12_combout\;
\inst4|ALT_INV_Mux1~11_combout\ <= NOT \inst4|Mux1~11_combout\;
\inst4|ALT_INV_Mux1~10_combout\ <= NOT \inst4|Mux1~10_combout\;
\inst4|ALT_INV_Mux1~9_combout\ <= NOT \inst4|Mux1~9_combout\;
\inst4|ALT_INV_Mux2~6_combout\ <= NOT \inst4|Mux2~6_combout\;
\inst4|ALT_INV_Mux2~5_combout\ <= NOT \inst4|Mux2~5_combout\;
\inst4|ALT_INV_F9~12_combout\ <= NOT \inst4|F9~12_combout\;
\inst4|ALT_INV_Mux2~4_combout\ <= NOT \inst4|Mux2~4_combout\;
\inst4|ALT_INV_Mux2~3_combout\ <= NOT \inst4|Mux2~3_combout\;
\inst4|ALT_INV_Mux2~2_combout\ <= NOT \inst4|Mux2~2_combout\;
\inst4|ALT_INV_Mux2~1_combout\ <= NOT \inst4|Mux2~1_combout\;
\inst4|ALT_INV_Mux2~0_combout\ <= NOT \inst4|Mux2~0_combout\;
\inst4|ALT_INV_Mux3~6_combout\ <= NOT \inst4|Mux3~6_combout\;
\inst4|ALT_INV_Mux3~5_combout\ <= NOT \inst4|Mux3~5_combout\;
\inst4|ALT_INV_F9~11_combout\ <= NOT \inst4|F9~11_combout\;
\inst4|ALT_INV_Mux3~4_combout\ <= NOT \inst4|Mux3~4_combout\;
\inst4|ALT_INV_Mux3~3_combout\ <= NOT \inst4|Mux3~3_combout\;
\inst4|ALT_INV_Mux3~2_combout\ <= NOT \inst4|Mux3~2_combout\;
\inst4|ALT_INV_Mux3~1_combout\ <= NOT \inst4|Mux3~1_combout\;
\inst4|ALT_INV_Mux3~0_combout\ <= NOT \inst4|Mux3~0_combout\;
\inst4|ALT_INV_Mux4~6_combout\ <= NOT \inst4|Mux4~6_combout\;
\inst4|ALT_INV_Mux4~5_combout\ <= NOT \inst4|Mux4~5_combout\;
\inst4|ALT_INV_F9~10_combout\ <= NOT \inst4|F9~10_combout\;
\inst4|ALT_INV_Mux4~4_combout\ <= NOT \inst4|Mux4~4_combout\;
\inst4|ALT_INV_Mux4~3_combout\ <= NOT \inst4|Mux4~3_combout\;
\inst4|ALT_INV_Mux4~2_combout\ <= NOT \inst4|Mux4~2_combout\;
\inst4|ALT_INV_Mux4~1_combout\ <= NOT \inst4|Mux4~1_combout\;
\inst4|ALT_INV_Mux4~0_combout\ <= NOT \inst4|Mux4~0_combout\;
\inst4|ALT_INV_Mux5~6_combout\ <= NOT \inst4|Mux5~6_combout\;
\inst4|ALT_INV_Mux5~5_combout\ <= NOT \inst4|Mux5~5_combout\;
\inst4|ALT_INV_F9~9_combout\ <= NOT \inst4|F9~9_combout\;
\inst4|ALT_INV_Mux5~4_combout\ <= NOT \inst4|Mux5~4_combout\;
\inst4|ALT_INV_Mux5~3_combout\ <= NOT \inst4|Mux5~3_combout\;
\inst4|ALT_INV_Mux5~2_combout\ <= NOT \inst4|Mux5~2_combout\;
\inst4|ALT_INV_Mux5~1_combout\ <= NOT \inst4|Mux5~1_combout\;
\inst4|ALT_INV_Mux5~0_combout\ <= NOT \inst4|Mux5~0_combout\;
\inst4|ALT_INV_Mux6~6_combout\ <= NOT \inst4|Mux6~6_combout\;
\inst4|ALT_INV_Mux6~5_combout\ <= NOT \inst4|Mux6~5_combout\;
\inst4|ALT_INV_F9~8_combout\ <= NOT \inst4|F9~8_combout\;
\inst4|ALT_INV_Mux6~4_combout\ <= NOT \inst4|Mux6~4_combout\;
\inst4|ALT_INV_Mux6~3_combout\ <= NOT \inst4|Mux6~3_combout\;
\inst4|ALT_INV_Mux6~2_combout\ <= NOT \inst4|Mux6~2_combout\;
\inst4|ALT_INV_Mux6~1_combout\ <= NOT \inst4|Mux6~1_combout\;
\inst4|ALT_INV_Mux6~0_combout\ <= NOT \inst4|Mux6~0_combout\;
\inst4|ALT_INV_Mux7~7_combout\ <= NOT \inst4|Mux7~7_combout\;
\inst4|ALT_INV_Mux1~8_combout\ <= NOT \inst4|Mux1~8_combout\;
\inst4|ALT_INV_Mux1~7_combout\ <= NOT \inst4|Mux1~7_combout\;
\inst4|ALT_INV_Mux7~6_combout\ <= NOT \inst4|Mux7~6_combout\;
\inst4|ALT_INV_Mux7~5_combout\ <= NOT \inst4|Mux7~5_combout\;
\inst4|ALT_INV_Mux1~6_combout\ <= NOT \inst4|Mux1~6_combout\;
\inst4|ALT_INV_F9~7_combout\ <= NOT \inst4|F9~7_combout\;
\inst4|ALT_INV_Mux7~4_combout\ <= NOT \inst4|Mux7~4_combout\;
\inst4|ALT_INV_Mux7~3_combout\ <= NOT \inst4|Mux7~3_combout\;
\inst4|ALT_INV_Mux1~5_combout\ <= NOT \inst4|Mux1~5_combout\;
\inst4|ALT_INV_Mux7~2_combout\ <= NOT \inst4|Mux7~2_combout\;
\inst4|ALT_INV_Mux7~1_combout\ <= NOT \inst4|Mux7~1_combout\;
\inst4|ALT_INV_Mux7~0_combout\ <= NOT \inst4|Mux7~0_combout\;
\inst4|ALT_INV_Mux1~4_combout\ <= NOT \inst4|Mux1~4_combout\;
\inst4|ALT_INV_Mux1~3_combout\ <= NOT \inst4|Mux1~3_combout\;
\inst4|ALT_INV_Mux1~2_combout\ <= NOT \inst4|Mux1~2_combout\;
\inst4|ALT_INV_Mux1~1_combout\ <= NOT \inst4|Mux1~1_combout\;
\inst4|ALT_INV_Mux1~0_combout\ <= NOT \inst4|Mux1~0_combout\;
\inst4|ALT_INV_Mux8~2_combout\ <= NOT \inst4|Mux8~2_combout\;
\inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(0) <= NOT \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(0);
\inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(1) <= NOT \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1);
\inst4|ALT_INV_Mux8~1_combout\ <= NOT \inst4|Mux8~1_combout\;
\inst4|ALT_INV_F9~6_combout\ <= NOT \inst4|F9~6_combout\;
\inst4|ALT_INV_F9~5_combout\ <= NOT \inst4|F9~5_combout\;
\inst4|ALT_INV_F9~4_combout\ <= NOT \inst4|F9~4_combout\;
\inst4|ALT_INV_Mux8~0_combout\ <= NOT \inst4|Mux8~0_combout\;
\inst4|ALT_INV_F9~3_combout\ <= NOT \inst4|F9~3_combout\;
\inst4|ALT_INV_F9~2_combout\ <= NOT \inst4|F9~2_combout\;
\inst4|ALT_INV_F9~1_combout\ <= NOT \inst4|F9~1_combout\;
\inst4|ALT_INV_F9~0_combout\ <= NOT \inst4|F9~0_combout\;
\inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2) <= NOT \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2);
\inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3) <= NOT \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3);
\inst4|ALT_INV_Mux8~7_combout\ <= NOT \inst4|Mux8~7_combout\;
\inst4|ALT_INV_Mux8~3_combout\ <= NOT \inst4|Mux8~3_combout\;
\inst4|ALT_INV_Mux7~8_combout\ <= NOT \inst4|Mux7~8_combout\;
\inst4|ALT_INV_Mux6~7_combout\ <= NOT \inst4|Mux6~7_combout\;
\inst4|ALT_INV_Mux5~7_combout\ <= NOT \inst4|Mux5~7_combout\;
\inst4|ALT_INV_Mux4~7_combout\ <= NOT \inst4|Mux4~7_combout\;
\inst4|ALT_INV_Mux3~7_combout\ <= NOT \inst4|Mux3~7_combout\;
\inst4|ALT_INV_Mux2~7_combout\ <= NOT \inst4|Mux2~7_combout\;
\inst4|ALT_INV_Mux1~16_combout\ <= NOT \inst4|Mux1~16_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_adapted_tdo~0_combout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|adapted_tdo~0_combout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~29_sumout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~29_sumout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~25_sumout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~25_sumout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~21_sumout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~21_sumout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~17_sumout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~17_sumout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~13_sumout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~13_sumout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~9_sumout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~9_sumout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~5_sumout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~5_sumout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~1_sumout\ <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~1_sumout\;
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(7) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(7);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(6) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(6);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(5) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(5);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(4) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(4);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(3) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(3);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(2) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(2);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(1) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(1);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(0) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(0);
\inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg\(0) <= NOT \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(0);
\inst4|ALT_INV_Add4~29_sumout\ <= NOT \inst4|Add4~29_sumout\;
\inst4|ALT_INV_Add3~29_sumout\ <= NOT \inst4|Add3~29_sumout\;
\inst4|ALT_INV_Add5~29_sumout\ <= NOT \inst4|Add5~29_sumout\;
\inst4|ALT_INV_Add6~29_sumout\ <= NOT \inst4|Add6~29_sumout\;
\inst4|ALT_INV_Add7~29_sumout\ <= NOT \inst4|Add7~29_sumout\;
\inst4|ALT_INV_Add2~29_sumout\ <= NOT \inst4|Add2~29_sumout\;
\inst4|ALT_INV_Add0~29_sumout\ <= NOT \inst4|Add0~29_sumout\;
\inst4|ALT_INV_Add1~29_sumout\ <= NOT \inst4|Add1~29_sumout\;
\inst4|ALT_INV_Add4~25_sumout\ <= NOT \inst4|Add4~25_sumout\;
\inst4|ALT_INV_Add3~25_sumout\ <= NOT \inst4|Add3~25_sumout\;
\inst4|ALT_INV_Add5~25_sumout\ <= NOT \inst4|Add5~25_sumout\;
\inst4|ALT_INV_Add6~25_sumout\ <= NOT \inst4|Add6~25_sumout\;
\inst4|ALT_INV_Add7~25_sumout\ <= NOT \inst4|Add7~25_sumout\;
\inst4|ALT_INV_Add2~25_sumout\ <= NOT \inst4|Add2~25_sumout\;
\inst4|ALT_INV_Add0~25_sumout\ <= NOT \inst4|Add0~25_sumout\;
\inst4|ALT_INV_Add1~25_sumout\ <= NOT \inst4|Add1~25_sumout\;
\inst4|ALT_INV_Add4~21_sumout\ <= NOT \inst4|Add4~21_sumout\;
\inst4|ALT_INV_Add3~21_sumout\ <= NOT \inst4|Add3~21_sumout\;
\inst4|ALT_INV_Add5~21_sumout\ <= NOT \inst4|Add5~21_sumout\;
\inst4|ALT_INV_Add6~21_sumout\ <= NOT \inst4|Add6~21_sumout\;
\inst4|ALT_INV_Add7~21_sumout\ <= NOT \inst4|Add7~21_sumout\;
\inst4|ALT_INV_Add2~21_sumout\ <= NOT \inst4|Add2~21_sumout\;
\inst4|ALT_INV_Add0~21_sumout\ <= NOT \inst4|Add0~21_sumout\;
\inst4|ALT_INV_Add1~21_sumout\ <= NOT \inst4|Add1~21_sumout\;
\inst4|ALT_INV_Add4~17_sumout\ <= NOT \inst4|Add4~17_sumout\;
\inst4|ALT_INV_Add3~17_sumout\ <= NOT \inst4|Add3~17_sumout\;
\inst4|ALT_INV_Add5~17_sumout\ <= NOT \inst4|Add5~17_sumout\;
\inst4|ALT_INV_Add6~17_sumout\ <= NOT \inst4|Add6~17_sumout\;
\inst4|ALT_INV_Add7~17_sumout\ <= NOT \inst4|Add7~17_sumout\;
\inst4|ALT_INV_Add2~17_sumout\ <= NOT \inst4|Add2~17_sumout\;
\inst4|ALT_INV_Add0~17_sumout\ <= NOT \inst4|Add0~17_sumout\;
\inst4|ALT_INV_Add1~17_sumout\ <= NOT \inst4|Add1~17_sumout\;
\inst4|ALT_INV_Add4~13_sumout\ <= NOT \inst4|Add4~13_sumout\;
\inst4|ALT_INV_Add3~13_sumout\ <= NOT \inst4|Add3~13_sumout\;
\inst4|ALT_INV_Add5~13_sumout\ <= NOT \inst4|Add5~13_sumout\;
\inst4|ALT_INV_Add6~13_sumout\ <= NOT \inst4|Add6~13_sumout\;
\inst4|ALT_INV_Add7~13_sumout\ <= NOT \inst4|Add7~13_sumout\;
\inst4|ALT_INV_Add2~13_sumout\ <= NOT \inst4|Add2~13_sumout\;
\inst4|ALT_INV_Add0~13_sumout\ <= NOT \inst4|Add0~13_sumout\;
\inst4|ALT_INV_Add1~13_sumout\ <= NOT \inst4|Add1~13_sumout\;
\inst4|ALT_INV_Add4~9_sumout\ <= NOT \inst4|Add4~9_sumout\;
\inst4|ALT_INV_Add3~9_sumout\ <= NOT \inst4|Add3~9_sumout\;
\inst4|ALT_INV_Add5~9_sumout\ <= NOT \inst4|Add5~9_sumout\;
\inst4|ALT_INV_Add6~9_sumout\ <= NOT \inst4|Add6~9_sumout\;
\inst4|ALT_INV_Add7~9_sumout\ <= NOT \inst4|Add7~9_sumout\;
\inst4|ALT_INV_Add2~9_sumout\ <= NOT \inst4|Add2~9_sumout\;
\inst4|ALT_INV_Add0~9_sumout\ <= NOT \inst4|Add0~9_sumout\;
\inst4|ALT_INV_Add1~9_sumout\ <= NOT \inst4|Add1~9_sumout\;
\inst4|ALT_INV_Add4~5_sumout\ <= NOT \inst4|Add4~5_sumout\;
\inst4|ALT_INV_Add3~5_sumout\ <= NOT \inst4|Add3~5_sumout\;
\inst4|ALT_INV_Add5~5_sumout\ <= NOT \inst4|Add5~5_sumout\;
\inst4|ALT_INV_Add6~5_sumout\ <= NOT \inst4|Add6~5_sumout\;
\inst4|ALT_INV_Add7~5_sumout\ <= NOT \inst4|Add7~5_sumout\;
\inst4|ALT_INV_Add2~5_sumout\ <= NOT \inst4|Add2~5_sumout\;
\inst4|ALT_INV_Add0~5_sumout\ <= NOT \inst4|Add0~5_sumout\;
\inst4|ALT_INV_Add1~5_sumout\ <= NOT \inst4|Add1~5_sumout\;
\inst4|ALT_INV_Add6~1_sumout\ <= NOT \inst4|Add6~1_sumout\;
\inst4|ALT_INV_Add1~1_sumout\ <= NOT \inst4|Add1~1_sumout\;
\inst4|ALT_INV_Add7~1_sumout\ <= NOT \inst4|Add7~1_sumout\;
\inst4|ALT_INV_Add4~1_sumout\ <= NOT \inst4|Add4~1_sumout\;
\inst4|ALT_INV_Add2~1_sumout\ <= NOT \inst4|Add2~1_sumout\;
\inst4|ALT_INV_Add5~1_sumout\ <= NOT \inst4|Add5~1_sumout\;
\inst4|ALT_INV_Add3~1_sumout\ <= NOT \inst4|Add3~1_sumout\;
\inst4|ALT_INV_Add0~1_sumout\ <= NOT \inst4|Add0~1_sumout\;
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(1) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(1);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(2) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(2);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(3) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(3);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(4) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(4);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(5) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(5);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(6) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(6);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(7) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(7);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(0) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_b\(0);
\inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0) <= NOT \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0);
\inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1) <= NOT \inst2|altsyncram_component|auto_generated|q_a\(1);
\inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2) <= NOT \inst2|altsyncram_component|auto_generated|q_a\(2);
\inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3) <= NOT \inst2|altsyncram_component|auto_generated|q_a\(3);
\inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4) <= NOT \inst2|altsyncram_component|auto_generated|q_a\(4);
\inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5) <= NOT \inst2|altsyncram_component|auto_generated|q_a\(5);
\inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6) <= NOT \inst2|altsyncram_component|auto_generated|q_a\(6);
\inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7) <= NOT \inst2|altsyncram_component|auto_generated|q_a\(7);
\inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0) <= NOT \inst2|altsyncram_component|auto_generated|q_a\(0);

-- Location: IOOBUF_X89_Y11_N45
\RQAddr1[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(6));

-- Location: IOOBUF_X89_Y13_N5
\RQAddr1[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(5));

-- Location: IOOBUF_X89_Y13_N22
\RQAddr1[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(4));

-- Location: IOOBUF_X89_Y8_N22
\RQAddr1[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(3));

-- Location: IOOBUF_X89_Y15_N22
\RQAddr1[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(2));

-- Location: IOOBUF_X89_Y15_N5
\RQAddr1[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(1));

-- Location: IOOBUF_X89_Y20_N45
\RQAddr1[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(0));

-- Location: IOOBUF_X89_Y20_N62
\RQAddr2[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux7~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(6));

-- Location: IOOBUF_X89_Y21_N56
\RQAddr2[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux8~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(5));

-- Location: IOOBUF_X89_Y25_N22
\RQAddr2[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux9~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(4));

-- Location: IOOBUF_X89_Y23_N22
\RQAddr2[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux10~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(3));

-- Location: IOOBUF_X89_Y9_N56
\RQAddr2[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux11~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(2));

-- Location: IOOBUF_X89_Y23_N5
\RQAddr2[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux12~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(1));

-- Location: IOOBUF_X89_Y9_N39
\RQAddr2[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst5|Mux13~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(0));

-- Location: IOOBUF_X89_Y8_N39
\RQALU1[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(6));

-- Location: IOOBUF_X89_Y11_N79
\RQALU1[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(5));

-- Location: IOOBUF_X89_Y11_N96
\RQALU1[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(4));

-- Location: IOOBUF_X89_Y4_N79
\RQALU1[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(3));

-- Location: IOOBUF_X89_Y13_N56
\RQALU1[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(2));

-- Location: IOOBUF_X89_Y13_N39
\RQALU1[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(1));

-- Location: IOOBUF_X89_Y4_N96
\RQALU1[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(0));

-- Location: IOOBUF_X89_Y6_N39
\RQALU2[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux7~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(6));

-- Location: IOOBUF_X89_Y6_N56
\RQALU2[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux8~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(5));

-- Location: IOOBUF_X89_Y16_N39
\RQALU2[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux9~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(4));

-- Location: IOOBUF_X89_Y16_N56
\RQALU2[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux10~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(3));

-- Location: IOOBUF_X89_Y15_N39
\RQALU2[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux11~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(2));

-- Location: IOOBUF_X89_Y15_N56
\RQALU2[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux12~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(1));

-- Location: IOOBUF_X89_Y8_N56
\RQALU2[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst6|Mux13~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(0));

-- Location: IOOBUF_X89_Y9_N22
\RQData1[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(6));

-- Location: IOOBUF_X89_Y23_N39
\RQData1[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(5));

-- Location: IOOBUF_X89_Y23_N56
\RQData1[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(4));

-- Location: IOOBUF_X89_Y20_N79
\RQData1[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(3));

-- Location: IOOBUF_X89_Y25_N39
\RQData1[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(2));

-- Location: IOOBUF_X89_Y20_N96
\RQData1[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(1));

-- Location: IOOBUF_X89_Y25_N56
\RQData1[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(0));

-- Location: IOOBUF_X89_Y16_N5
\RQData2[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux7~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(6));

-- Location: IOOBUF_X89_Y16_N22
\RQData2[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux8~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(5));

-- Location: IOOBUF_X89_Y4_N45
\RQData2[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux9~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(4));

-- Location: IOOBUF_X89_Y4_N62
\RQData2[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux10~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(3));

-- Location: IOOBUF_X89_Y21_N39
\RQData2[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux11~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(2));

-- Location: IOOBUF_X89_Y11_N62
\RQData2[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux12~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(1));

-- Location: IOOBUF_X89_Y9_N5
\RQData2[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux13~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(0));

-- Location: IOOBUF_X80_Y0_N2
\SOUT[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[3]~DUPLICATE_q\,
	devoe => ww_devoe,
	o => ww_SOUT(3));

-- Location: IOOBUF_X60_Y0_N2
\SOUT[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2),
	devoe => ww_devoe,
	o => ww_SOUT(2));

-- Location: IOOBUF_X52_Y0_N19
\SOUT[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\,
	devoe => ww_devoe,
	o => ww_SOUT(1));

-- Location: IOOBUF_X52_Y0_N2
\SOUT[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\,
	devoe => ww_devoe,
	o => ww_SOUT(0));

-- Location: IOOBUF_X11_Y0_N2
\altera_reserved_tdo~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \altera_internal_jtag~TDO\,
	devoe => ww_devoe,
	o => ww_altera_reserved_tdo);

-- Location: IOIBUF_X2_Y0_N58
\B_T_CN_M~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_B_T_CN_M,
	o => \B_T_CN_M~input_o\);

-- Location: IOIBUF_X36_Y0_N18
\clkM~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clkM,
	o => \clkM~input_o\);

-- Location: CLKCTRL_G1
\clkM~inputCLKENA0\ : cyclonev_clkena
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	disable_mode => "low",
	ena_register_mode => "always enabled",
	ena_register_power_up => "high",
	test_syn => "high")
-- pragma translate_on
PORT MAP (
	inclk => \clkM~input_o\,
	outclk => \clkM~inputCLKENA0_outclk\);

-- Location: IOIBUF_X40_Y0_N18
\clr~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clr,
	o => \clr~input_o\);

-- Location: IOIBUF_X12_Y0_N18
\MDR_in[0]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_MDR_in(0),
	o => \MDR_in[0]~input_o\);

-- Location: IOIBUF_X40_Y0_N1
\LOAD_Addr_Data~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_LOAD_Addr_Data,
	o => \LOAD_Addr_Data~input_o\);

-- Location: LABCELL_X10_Y2_N39
\inst|b2v_instlatch1|latches[0]\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|b2v_instlatch1|latches\(0) = ( \LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(0) & ( (\clr~input_o\ & \MDR_in[0]~input_o\) ) ) ) # ( !\LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(0) & ( \clr~input_o\ ) ) ) # ( 
-- \LOAD_Addr_Data~input_o\ & ( !\inst|b2v_instlatch1|latches\(0) & ( (\clr~input_o\ & \MDR_in[0]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000101010101010101010101010000000001010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_clr~input_o\,
	datad => \ALT_INV_MDR_in[0]~input_o\,
	datae => \ALT_INV_LOAD_Addr_Data~input_o\,
	dataf => \inst|b2v_instlatch1|ALT_INV_latches\(0),
	combout => \inst|b2v_instlatch1|latches\(0));

-- Location: IOIBUF_X16_Y0_N1
\MDR_in[1]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_MDR_in(1),
	o => \MDR_in[1]~input_o\);

-- Location: LABCELL_X10_Y2_N18
\inst|b2v_instlatch1|latches[1]\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|b2v_instlatch1|latches\(1) = ( \MDR_in[1]~input_o\ & ( \inst|b2v_instlatch1|latches\(1) & ( \clr~input_o\ ) ) ) # ( !\MDR_in[1]~input_o\ & ( \inst|b2v_instlatch1|latches\(1) & ( (\clr~input_o\ & !\LOAD_Addr_Data~input_o\) ) ) ) # ( 
-- \MDR_in[1]~input_o\ & ( !\inst|b2v_instlatch1|latches\(1) & ( (\clr~input_o\ & \LOAD_Addr_Data~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000001010000010101010000010100000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_clr~input_o\,
	datac => \ALT_INV_LOAD_Addr_Data~input_o\,
	datae => \ALT_INV_MDR_in[1]~input_o\,
	dataf => \inst|b2v_instlatch1|ALT_INV_latches\(1),
	combout => \inst|b2v_instlatch1|latches\(1));

-- Location: IOIBUF_X8_Y0_N35
\MDR_in[2]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_MDR_in(2),
	o => \MDR_in[2]~input_o\);

-- Location: LABCELL_X10_Y2_N48
\inst|b2v_instlatch1|latches[2]\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|b2v_instlatch1|latches\(2) = ( \LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(2) & ( (\MDR_in[2]~input_o\ & \clr~input_o\) ) ) ) # ( !\LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(2) & ( \clr~input_o\ ) ) ) # ( 
-- \LOAD_Addr_Data~input_o\ & ( !\inst|b2v_instlatch1|latches\(2) & ( (\MDR_in[2]~input_o\ & \clr~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000110000001100001111000011110000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_MDR_in[2]~input_o\,
	datac => \ALT_INV_clr~input_o\,
	datae => \ALT_INV_LOAD_Addr_Data~input_o\,
	dataf => \inst|b2v_instlatch1|ALT_INV_latches\(2),
	combout => \inst|b2v_instlatch1|latches\(2));

-- Location: IOIBUF_X4_Y0_N52
\MDR_in[3]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_MDR_in(3),
	o => \MDR_in[3]~input_o\);

-- Location: LABCELL_X10_Y2_N57
\inst|b2v_instlatch1|latches[3]\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|b2v_instlatch1|latches\(3) = ( \LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(3) & ( (\clr~input_o\ & \MDR_in[3]~input_o\) ) ) ) # ( !\LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(3) & ( \clr~input_o\ ) ) ) # ( 
-- \LOAD_Addr_Data~input_o\ & ( !\inst|b2v_instlatch1|latches\(3) & ( (\clr~input_o\ & \MDR_in[3]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000101010101010101010101010000000001010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_clr~input_o\,
	datad => \ALT_INV_MDR_in[3]~input_o\,
	datae => \ALT_INV_LOAD_Addr_Data~input_o\,
	dataf => \inst|b2v_instlatch1|ALT_INV_latches\(3),
	combout => \inst|b2v_instlatch1|latches\(3));

-- Location: IOIBUF_X2_Y0_N41
\MDR_in[4]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_MDR_in(4),
	o => \MDR_in[4]~input_o\);

-- Location: LABCELL_X10_Y2_N12
\inst|b2v_instlatch1|latches[4]\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|b2v_instlatch1|latches\(4) = ( \LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(4) & ( (\MDR_in[4]~input_o\ & \clr~input_o\) ) ) ) # ( !\LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(4) & ( \clr~input_o\ ) ) ) # ( 
-- \LOAD_Addr_Data~input_o\ & ( !\inst|b2v_instlatch1|latches\(4) & ( (\MDR_in[4]~input_o\ & \clr~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000110000001100001111000011110000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_MDR_in[4]~input_o\,
	datac => \ALT_INV_clr~input_o\,
	datae => \ALT_INV_LOAD_Addr_Data~input_o\,
	dataf => \inst|b2v_instlatch1|ALT_INV_latches\(4),
	combout => \inst|b2v_instlatch1|latches\(4));

-- Location: IOIBUF_X16_Y0_N18
\MDR_in[5]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_MDR_in(5),
	o => \MDR_in[5]~input_o\);

-- Location: LABCELL_X10_Y2_N33
\inst|b2v_instlatch1|latches[5]\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|b2v_instlatch1|latches\(5) = ( \LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(5) & ( (\clr~input_o\ & \MDR_in[5]~input_o\) ) ) ) # ( !\LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(5) & ( \clr~input_o\ ) ) ) # ( 
-- \LOAD_Addr_Data~input_o\ & ( !\inst|b2v_instlatch1|latches\(5) & ( (\clr~input_o\ & \MDR_in[5]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000101010101010101010101010000000001010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_clr~input_o\,
	datad => \ALT_INV_MDR_in[5]~input_o\,
	datae => \ALT_INV_LOAD_Addr_Data~input_o\,
	dataf => \inst|b2v_instlatch1|ALT_INV_latches\(5),
	combout => \inst|b2v_instlatch1|latches\(5));

-- Location: IOIBUF_X4_Y0_N35
\MDR_in[6]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_MDR_in(6),
	o => \MDR_in[6]~input_o\);

-- Location: LABCELL_X10_Y2_N24
\inst|b2v_instlatch1|latches[6]\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|b2v_instlatch1|latches\(6) = ( \LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(6) & ( (\clr~input_o\ & \MDR_in[6]~input_o\) ) ) ) # ( !\LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(6) & ( \clr~input_o\ ) ) ) # ( 
-- \LOAD_Addr_Data~input_o\ & ( !\inst|b2v_instlatch1|latches\(6) & ( (\clr~input_o\ & \MDR_in[6]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000001010000010101010101010101010000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_clr~input_o\,
	datac => \ALT_INV_MDR_in[6]~input_o\,
	datae => \ALT_INV_LOAD_Addr_Data~input_o\,
	dataf => \inst|b2v_instlatch1|ALT_INV_latches\(6),
	combout => \inst|b2v_instlatch1|latches\(6));

-- Location: IOIBUF_X4_Y0_N1
\MDR_in[7]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_MDR_in(7),
	o => \MDR_in[7]~input_o\);

-- Location: LABCELL_X10_Y2_N9
\inst|b2v_instlatch1|latches[7]\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|b2v_instlatch1|latches\(7) = ( \LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(7) & ( (\clr~input_o\ & \MDR_in[7]~input_o\) ) ) ) # ( !\LOAD_Addr_Data~input_o\ & ( \inst|b2v_instlatch1|latches\(7) & ( \clr~input_o\ ) ) ) # ( 
-- \LOAD_Addr_Data~input_o\ & ( !\inst|b2v_instlatch1|latches\(7) & ( (\clr~input_o\ & \MDR_in[7]~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000001010000010101010101010101010000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_clr~input_o\,
	datac => \ALT_INV_MDR_in[7]~input_o\,
	datae => \ALT_INV_LOAD_Addr_Data~input_o\,
	dataf => \inst|b2v_instlatch1|ALT_INV_latches\(7),
	combout => \inst|b2v_instlatch1|latches\(7));

-- Location: M10K_X14_Y2_N0
\inst2|altsyncram_component|auto_generated|ram_block1a0\ : cyclonev_ram_block
-- pragma translate_off
GENERIC MAP (
	mem_init2 => "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init1 => "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init0 => "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800000000FB000FF0002000004000000002000017000C20000300000000C0000FF000080000100003000220000000000000180000400050000000000300022000000000000018000040005000000",
	data_interleave_offset_in_bits => 1,
	data_interleave_width_in_bits => 1,
	init_file => "ROM-RAM.mif",
	init_file_layout => "port_a",
	logical_ram_name => "ROM:inst2|altsyncram:altsyncram_component|altsyncram_bg14:auto_generated|ALTSYNCRAM",
	operation_mode => "rom",
	port_a_address_clear => "none",
	port_a_address_width => 8,
	port_a_byte_enable_clock => "none",
	port_a_data_out_clear => "none",
	port_a_data_out_clock => "clock0",
	port_a_data_width => 20,
	port_a_first_address => 0,
	port_a_first_bit_number => 0,
	port_a_last_address => 255,
	port_a_logical_ram_depth => 256,
	port_a_logical_ram_width => 32,
	port_a_read_during_write_mode => "new_data_no_nbe_read",
	port_a_write_enable_clock => "none",
	port_b_address_width => 8,
	port_b_data_width => 20,
	ram_block_type => "M20K")
-- pragma translate_on
PORT MAP (
	portare => VCC,
	clk0 => \clkM~inputCLKENA0_outclk\,
	portaaddr => \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	portadataout => \inst2|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\);

-- Location: LABCELL_X9_Y5_N12
\inst5|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux0~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((\inst2|altsyncram_component|auto_generated|q_a\(3) & (!\inst2|altsyncram_component|auto_generated|q_a\(2) & 
-- \inst2|altsyncram_component|auto_generated|q_a\(0)))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(3) & (!\inst2|altsyncram_component|auto_generated|q_a\(2) $ 
-- (!\inst2|altsyncram_component|auto_generated|q_a\(0)))) # (\inst2|altsyncram_component|auto_generated|q_a\(3) & (\inst2|altsyncram_component|auto_generated|q_a\(2) & \inst2|altsyncram_component|auto_generated|q_a\(0)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010111011101011101011101110101110101010101110101010101010111010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst5|Mux0~0_combout\);

-- Location: LABCELL_X9_Y5_N21
\inst5|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux1~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(0) & ((\inst2|altsyncram_component|auto_generated|q_a\(2)))) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(0) & (\inst2|altsyncram_component|auto_generated|q_a\(3)))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((\inst2|altsyncram_component|auto_generated|q_a\(2) & 
-- (!\inst2|altsyncram_component|auto_generated|q_a\(3) $ (!\inst2|altsyncram_component|auto_generated|q_a\(0))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101110101110101010111010111010101111101110111010111110111011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst5|Mux1~0_combout\);

-- Location: LABCELL_X9_Y5_N18
\inst5|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux2~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(3) & (!\inst2|altsyncram_component|auto_generated|q_a\(2) & 
-- !\inst2|altsyncram_component|auto_generated|q_a\(0))) # (\inst2|altsyncram_component|auto_generated|q_a\(3) & (\inst2|altsyncram_component|auto_generated|q_a\(2)))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # 
-- ((\inst2|altsyncram_component|auto_generated|q_a\(3) & (\inst2|altsyncram_component|auto_generated|q_a\(2) & !\inst2|altsyncram_component|auto_generated|q_a\(0)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101110101010101010111010101011101011101010111110101110101011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst5|Mux2~0_combout\);

-- Location: LABCELL_X10_Y4_N45
\inst5|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux3~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(0) & (\inst2|altsyncram_component|auto_generated|q_a\(3) & 
-- !\inst2|altsyncram_component|auto_generated|q_a\(2))) # (\inst2|altsyncram_component|auto_generated|q_a\(0) & ((\inst2|altsyncram_component|auto_generated|q_a\(2))))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # 
-- ((!\inst2|altsyncram_component|auto_generated|q_a\(3) & (!\inst2|altsyncram_component|auto_generated|q_a\(0) $ (!\inst2|altsyncram_component|auto_generated|q_a\(2))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101110011101100110111001110110011001110110111011100111011011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst5|Mux3~0_combout\);

-- Location: LABCELL_X10_Y4_N39
\inst5|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux4~0_combout\ = ( \B_T_CN_M~input_o\ & ( (!\inst2|altsyncram_component|auto_generated|q_a\(1) & ((!\inst2|altsyncram_component|auto_generated|q_a\(2) & ((\inst2|altsyncram_component|auto_generated|q_a\(0)))) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(2) & (!\inst2|altsyncram_component|auto_generated|q_a\(3))))) # (\inst2|altsyncram_component|auto_generated|q_a\(1) & (!\inst2|altsyncram_component|auto_generated|q_a\(3) & 
-- ((\inst2|altsyncram_component|auto_generated|q_a\(0))))) ) ) # ( !\B_T_CN_M~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100100000111010100010000011101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	dataf => \ALT_INV_B_T_CN_M~input_o\,
	combout => \inst5|Mux4~0_combout\);

-- Location: LABCELL_X9_Y5_N15
\inst5|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux5~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(3) & ((!\inst2|altsyncram_component|auto_generated|q_a\(2)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(0))))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((\inst2|altsyncram_component|auto_generated|q_a\(0) & (!\inst2|altsyncram_component|auto_generated|q_a\(3) $ 
-- (\inst2|altsyncram_component|auto_generated|q_a\(2))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101011101011101010101110101111101010111011101110101011101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst5|Mux5~0_combout\);

-- Location: LABCELL_X10_Y4_N42
\inst5|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux6~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((\inst2|altsyncram_component|auto_generated|q_a\(0) & (!\inst2|altsyncram_component|auto_generated|q_a\(3) & 
-- \inst2|altsyncram_component|auto_generated|q_a\(2)))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(3) & ((!\inst2|altsyncram_component|auto_generated|q_a\(2)))) 
-- # (\inst2|altsyncram_component|auto_generated|q_a\(3) & (!\inst2|altsyncram_component|auto_generated|q_a\(0) & \inst2|altsyncram_component|auto_generated|q_a\(2)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111110011001110111111001100111011001100110111001100110011011100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst5|Mux6~0_combout\);

-- Location: LABCELL_X10_Y5_N30
\inst5|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux7~0_combout\ = ( \B_T_CN_M~input_o\ & ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\inst2|altsyncram_component|auto_generated|q_a\(6) & (!\inst2|altsyncram_component|auto_generated|q_a\(5) $ 
-- (\inst2|altsyncram_component|auto_generated|q_a\(7)))) # (\inst2|altsyncram_component|auto_generated|q_a\(6) & (!\inst2|altsyncram_component|auto_generated|q_a\(5) & \inst2|altsyncram_component|auto_generated|q_a\(7))) ) ) ) # ( !\B_T_CN_M~input_o\ & ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(4) ) ) # ( \B_T_CN_M~input_o\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( (\inst2|altsyncram_component|auto_generated|q_a\(6) & (!\inst2|altsyncram_component|auto_generated|q_a\(5) & 
-- !\inst2|altsyncram_component|auto_generated|q_a\(7))) ) ) ) # ( !\B_T_CN_M~input_o\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(4) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111010000000100000011111111111111111000011010000110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datae => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	combout => \inst5|Mux7~0_combout\);

-- Location: LABCELL_X10_Y5_N3
\inst5|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux8~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(5) & (\inst2|altsyncram_component|auto_generated|q_a\(6) & 
-- !\inst2|altsyncram_component|auto_generated|q_a\(7))) # (\inst2|altsyncram_component|auto_generated|q_a\(5) & ((\inst2|altsyncram_component|auto_generated|q_a\(7))))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # 
-- ((\inst2|altsyncram_component|auto_generated|q_a\(6) & ((\inst2|altsyncram_component|auto_generated|q_a\(7)) # (\inst2|altsyncram_component|auto_generated|q_a\(5))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000111110101111100011111010111110100111100111111010011110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	combout => \inst5|Mux8~0_combout\);

-- Location: LABCELL_X10_Y5_N0
\inst5|Mux9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux9~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # ((\inst2|altsyncram_component|auto_generated|q_a\(6) & (\inst2|altsyncram_component|auto_generated|q_a\(5) & 
-- \inst2|altsyncram_component|auto_generated|q_a\(7)))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(6) & (\inst2|altsyncram_component|auto_generated|q_a\(5) & 
-- !\inst2|altsyncram_component|auto_generated|q_a\(7))) # (\inst2|altsyncram_component|auto_generated|q_a\(6) & ((\inst2|altsyncram_component|auto_generated|q_a\(7))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100100101111111110010010111111111000000011111111100000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	combout => \inst5|Mux9~0_combout\);

-- Location: LABCELL_X10_Y5_N9
\inst5|Mux10~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux10~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(6) & (!\inst2|altsyncram_component|auto_generated|q_a\(5) & 
-- !\inst2|altsyncram_component|auto_generated|q_a\(7))) # (\inst2|altsyncram_component|auto_generated|q_a\(6) & (\inst2|altsyncram_component|auto_generated|q_a\(5)))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # 
-- ((!\inst2|altsyncram_component|auto_generated|q_a\(6) & (\inst2|altsyncram_component|auto_generated|q_a\(5) & \inst2|altsyncram_component|auto_generated|q_a\(7))) # (\inst2|altsyncram_component|auto_generated|q_a\(6) & 
-- (!\inst2|altsyncram_component|auto_generated|q_a\(5) & !\inst2|altsyncram_component|auto_generated|q_a\(7)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111010011110010111101001111001011111001111100011111100111110001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	combout => \inst5|Mux10~0_combout\);

-- Location: LABCELL_X10_Y5_N6
\inst5|Mux11~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux11~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\inst2|altsyncram_component|auto_generated|q_a\(7)) # ((!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(6) & 
-- !\inst2|altsyncram_component|auto_generated|q_a\(5)))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # ((\inst2|altsyncram_component|auto_generated|q_a\(6) & (!\inst2|altsyncram_component|auto_generated|q_a\(5) & 
-- !\inst2|altsyncram_component|auto_generated|q_a\(7)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111101000000111111110100000011111111111110001111111111111000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	combout => \inst5|Mux11~0_combout\);

-- Location: LABCELL_X10_Y5_N27
\inst5|Mux12~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux12~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # (!\inst2|altsyncram_component|auto_generated|q_a\(7) $ (((\inst2|altsyncram_component|auto_generated|q_a\(6) & 
-- !\inst2|altsyncram_component|auto_generated|q_a\(5))))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(6) & (\inst2|altsyncram_component|auto_generated|q_a\(5) & 
-- !\inst2|altsyncram_component|auto_generated|q_a\(7)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001011110000111100101111000011111011111101001111101111110100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	combout => \inst5|Mux12~0_combout\);

-- Location: LABCELL_X10_Y5_N24
\inst5|Mux13~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux13~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(7) & (!\inst2|altsyncram_component|auto_generated|q_a\(6) $ 
-- (\inst2|altsyncram_component|auto_generated|q_a\(5))))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst2|altsyncram_component|auto_generated|q_a\(5) & (!\inst2|altsyncram_component|auto_generated|q_a\(6) $ 
-- (\inst2|altsyncram_component|auto_generated|q_a\(7))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111110000100111111111000010011111111100100001111111110010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	combout => \inst5|Mux13~0_combout\);

-- Location: IOIBUF_X11_Y0_N7
\altera_reserved_tms~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_altera_reserved_tms,
	o => \altera_reserved_tms~input_o\);

-- Location: IOIBUF_X13_Y0_N1
\altera_reserved_tck~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_altera_reserved_tck,
	o => \altera_reserved_tck~input_o\);

-- Location: IOIBUF_X13_Y0_N7
\altera_reserved_tdi~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_altera_reserved_tdi,
	o => \altera_reserved_tdi~input_o\);

-- Location: JTAG_X0_Y2_N3
altera_internal_jtag : cyclonev_jtag
PORT MAP (
	tms => \altera_reserved_tms~input_o\,
	tck => \altera_reserved_tck~input_o\,
	tdi => \altera_reserved_tdi~input_o\,
	tdouser => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo~q\,
	tdo => \altera_internal_jtag~TDO\,
	tmsutap => \altera_internal_jtag~TMSUTAP\,
	tckutap => \altera_internal_jtag~TCKUTAP\,
	tdiutap => \altera_internal_jtag~TDIUTAP\);

-- Location: LABCELL_X1_Y3_N51
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena_proc~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000001010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena_proc~0_combout\);

-- Location: FF_X1_Y3_N53
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(9));

-- Location: LABCELL_X1_Y3_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~9\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(9),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~9_combout\);

-- Location: FF_X1_Y3_N47
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(10));

-- Location: LABCELL_X1_Y3_N57
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~12\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(13),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(12),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~12_combout\);

-- Location: FF_X1_Y3_N56
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~12_combout\,
	sclr => \altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(13));

-- Location: LABCELL_X1_Y3_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~13\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000001010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(13),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~13_combout\);

-- Location: FF_X1_Y3_N20
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(14));

-- Location: LABCELL_X2_Y3_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~10\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101111101011111010111110101111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(11),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(14),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(10),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~10_combout\);

-- Location: FF_X1_Y3_N5
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~10_combout\,
	sclr => \altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11));

-- Location: LABCELL_X1_Y3_N21
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~11\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001010101000000000101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(10),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(11),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~11_combout\);

-- Location: FF_X1_Y3_N23
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~11_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(12));

-- Location: LABCELL_X1_Y3_N39
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(12),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(14),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0_combout\);

-- Location: FF_X1_Y3_N41
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(15));

-- Location: LABCELL_X1_Y1_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000001010000010100000101000001010000010100000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~1_combout\);

-- Location: FF_X1_Y1_N32
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~1_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(0));

-- Location: LABCELL_X1_Y1_N9
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010110101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~2_combout\);

-- Location: FF_X1_Y1_N29
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~2_combout\,
	sclr => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(1));

-- Location: LABCELL_X1_Y1_N27
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101101010100101010110101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~0_combout\);

-- Location: FF_X1_Y1_N26
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~0_combout\,
	sclr => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(2));

-- Location: LABCELL_X1_Y1_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100001100000000000000110000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(9),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(0),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(2),
	dataf => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~0_combout\);

-- Location: FF_X1_Y3_N11
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~0_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0));

-- Location: MLABCELL_X6_Y3_N39
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(6),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~6_combout\);

-- Location: LABCELL_X1_Y3_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[6]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state~6_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[6]~feeder_combout\);

-- Location: FF_X1_Y3_N8
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[6]~feeder_combout\,
	sclr => \altera_internal_jtag~TMSUTAP\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(6));

-- Location: LABCELL_X1_Y3_N27
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~7\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010100000101000001010000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(6),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~7_combout\);

-- Location: FF_X1_Y3_N29
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(7));

-- Location: MLABCELL_X6_Y3_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011111111111111111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~4_combout\);

-- Location: FF_X1_Y3_N2
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~4_combout\,
	sclr => \altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(4));

-- Location: LABCELL_X1_Y1_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000011100000111000001110000011100000111000001110000011100000111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~5_combout\);

-- Location: FF_X1_Y1_N44
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(5));

-- Location: LABCELL_X1_Y3_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~8\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111000000000000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~8_combout\);

-- Location: FF_X1_Y3_N32
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(8));

-- Location: LABCELL_X1_Y3_N9
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111101011111111111110101111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(15),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(0),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~1_combout\);

-- Location: FF_X1_Y3_N7
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~1_combout\,
	sclr => \altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(1));

-- Location: LABCELL_X1_Y3_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001010100010101000101010001010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(15),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~2_combout\);

-- Location: FF_X1_Y3_N38
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(2));

-- Location: LABCELL_X1_Y3_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~3_combout\);

-- Location: FF_X1_Y3_N44
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(3));

-- Location: LABCELL_X2_Y4_N0
\inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(0),
	cin => GND,
	sumout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~1_sumout\,
	cout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~2\);

-- Location: LABCELL_X2_Y4_N36
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[0]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~1_sumout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[0]~feeder_combout\);

-- Location: LABCELL_X2_Y3_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001100000011000000110000001111001111110011111100111111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datac => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~4_combout\);

-- Location: MLABCELL_X3_Y3_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[8]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg~4_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[8]~feeder_combout\);

-- Location: MLABCELL_X6_Y3_N30
\~QIC_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):
-- \~QIC_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	combout => \~QIC_CREATED_GND~I_combout\);

-- Location: FF_X3_Y3_N26
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[8]~feeder_combout\,
	asdata => \~QIC_CREATED_GND~I_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(3),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(8));

-- Location: LABCELL_X2_Y4_N42
\inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][4]~q\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~0_combout\);

-- Location: FF_X6_Y2_N52
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(2),
	clrn => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	sload => VCC,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(2));

-- Location: LABCELL_X1_Y4_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~7\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000010000000000000001011111000111110101111100011111010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~7_combout\);

-- Location: LABCELL_X1_Y5_N27
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(1),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[1]~feeder_combout\);

-- Location: FF_X1_Y5_N28
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[1]~feeder_combout\,
	clrn => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(1));

-- Location: LABCELL_X1_Y4_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001101100011011000110110001101100011011000110110001101100011011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~2_combout\);

-- Location: MLABCELL_X3_Y3_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000000010000000100000001010100010101000101010001000000010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(0),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\);

-- Location: FF_X1_Y4_N7
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~2_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(2));

-- Location: MLABCELL_X3_Y3_N39
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal3~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000001111000000000000111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal3~0_combout\);

-- Location: MLABCELL_X3_Y3_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~14\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000100010001000100010001000100010001000100010001000100010001000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~14_combout\);

-- Location: MLABCELL_X3_Y3_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[0]~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010011000001010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(0),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal3~0_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datad => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state~14_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[0]~3_combout\);

-- Location: FF_X3_Y2_N41
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[0]~3_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(0));

-- Location: MLABCELL_X3_Y3_N57
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000001000000000000000100000000000010110000000000001011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(0),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~5_combout\);

-- Location: MLABCELL_X3_Y3_N54
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000000010000000100000001000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(0),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~6_combout\);

-- Location: MLABCELL_X3_Y3_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~8\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011011100110111001101110011011111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~7_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[2]~5_combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~6_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~8_combout\);

-- Location: FF_X3_Y3_N37
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~8_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(3));

-- Location: MLABCELL_X3_Y3_N9
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000001110000000000000111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7),
	datac => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\);

-- Location: FF_X1_Y4_N50
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(3),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][3]~q\);

-- Location: FF_X2_Y3_N20
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \altera_internal_jtag~TDIUTAP\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(9));

-- Location: LABCELL_X2_Y3_N21
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(9),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~feeder_combout\);

-- Location: FF_X2_Y3_N22
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~DUPLICATE_q\);

-- Location: LABCELL_X2_Y3_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[7]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg[8]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[7]~feeder_combout\);

-- Location: FF_X2_Y3_N50
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[7]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(7));

-- Location: LABCELL_X2_Y3_N51
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[6]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(7),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[6]~feeder_combout\);

-- Location: FF_X2_Y3_N52
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[6]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(6));

-- Location: FF_X2_Y3_N56
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(6),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(5));

-- Location: FF_X2_Y3_N58
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(5),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(4));

-- Location: FF_X2_Y3_N37
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(4),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(3));

-- Location: LABCELL_X2_Y3_N27
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[2]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101010101010101010101010101010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[2]~0_combout\);

-- Location: FF_X2_Y3_N29
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[2]~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(2));

-- Location: FF_X2_Y3_N40
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(2),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(1));

-- Location: LABCELL_X2_Y3_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[0]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110011001100110011001100110011001100110011001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[0]~1_combout\);

-- Location: FF_X2_Y3_N25
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[0]~1_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(0));

-- Location: FF_X2_Y3_N23
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(8));

-- Location: LABCELL_X2_Y3_N54
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000010000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(5),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(9),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(6),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(7),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~0_combout\);

-- Location: LABCELL_X2_Y3_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000010000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(0),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal0~0_combout\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~1_combout\);

-- Location: FF_X2_Y3_N2
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_dr_scan_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~1_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_dr_scan_reg~q\);

-- Location: LABCELL_X2_Y3_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001110000000000000111000010001111111110001000111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(15),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~0_combout\);

-- Location: LABCELL_X2_Y3_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000100000001000000010000000111101111111011111110111111101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datac => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~1_combout\);

-- Location: LABCELL_X2_Y3_N9
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000000111010001100000011101000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(1),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~1_combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena_proc~0_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~2_combout\);

-- Location: FF_X3_Y2_N29
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~2_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0\(3));

-- Location: LABCELL_X2_Y4_N45
\inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000101000000000000010100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\);

-- Location: FF_X6_Y2_N58
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(0),
	clrn => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	sload => VCC,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(0));

-- Location: LABCELL_X1_Y4_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001000100010001000110111011101110111011101110111011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(0),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~3_combout\);

-- Location: FF_X1_Y4_N4
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~3_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(1));

-- Location: LABCELL_X1_Y3_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg_proc~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000010001000000000001000100010001000100010001000100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg_proc~0_combout\);

-- Location: MLABCELL_X3_Y3_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100101111000001110000010100000111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg_proc~0_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~0_combout\);

-- Location: FF_X3_Y2_N32
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(1));

-- Location: FF_X1_Y3_N34
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg~q\);

-- Location: MLABCELL_X3_Y3_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000001010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~1_combout\);

-- Location: MLABCELL_X3_Y3_N12
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011110000000000101111001000000000111100000000000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(1),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(2),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[1]~1_combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~2_combout\);

-- Location: FF_X2_Y2_N31
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~2_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(2));

-- Location: LABCELL_X1_Y4_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg_proc~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111000000000000111100000000000011110000000000001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg_proc~0_combout\);

-- Location: FF_X1_Y4_N44
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~q\);

-- Location: FF_X1_Y4_N53
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(0),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~q\);

-- Location: LABCELL_X2_Y4_N24
\inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000010000000100000001000000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\);

-- Location: LABCELL_X1_Y4_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~feeder_combout\);

-- Location: FF_X1_Y4_N32
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~q\);

-- Location: LABCELL_X1_Y4_N15
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_incr_addr~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000011000000000000001100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_incr_addr~0_combout\);

-- Location: LABCELL_X1_Y4_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]~feeder_combout\);

-- Location: FF_X1_Y4_N35
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]~q\);

-- Location: LABCELL_X4_Y2_N48
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000010000000000000001000000010000000100000001000000010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~0_combout\);

-- Location: LABCELL_X4_Y2_N9
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[0]~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101101001011010010110100101101001011010010100000101101001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[0]~0_combout\,
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	datad => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(1),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[0]~2_combout\);

-- Location: FF_X4_Y2_N14
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[0]~2_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(0));

-- Location: LABCELL_X4_Y2_N33
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010001010100010101000101010001011010010110100101101001011010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(1),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[0]~0_combout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~0_combout\);

-- Location: FF_X4_Y2_N23
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(1));

-- Location: LABCELL_X4_Y2_N6
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[2]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110100001101000011010000110100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[0]~0_combout\,
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(1),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[2]~1_combout\);

-- Location: FF_X4_Y2_N17
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[2]~1_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(2));

-- Location: LABCELL_X4_Y2_N12
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010111010111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_incr_addr~0_combout\,
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\,
	datae => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~3_combout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0_combout\);

-- Location: FF_X2_Y4_N37
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[0]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(1),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(0));

-- Location: LABCELL_X2_Y4_N3
\inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(1),
	cin => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~2\,
	sumout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~5_sumout\,
	cout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~6\);

-- Location: LABCELL_X2_Y4_N57
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~5_sumout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[1]~feeder_combout\);

-- Location: FF_X2_Y4_N58
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[1]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(2),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(1));

-- Location: LABCELL_X2_Y4_N6
\inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~9\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(2),
	cin => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~6\,
	sumout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~9_sumout\,
	cout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~10\);

-- Location: LABCELL_X2_Y4_N54
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~9_sumout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[2]~feeder_combout\);

-- Location: FF_X2_Y4_N55
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[2]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(3),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(2));

-- Location: LABCELL_X2_Y4_N9
\inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~13\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(3),
	cin => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~10\,
	sumout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~13_sumout\,
	cout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~14\);

-- Location: LABCELL_X2_Y4_N48
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[3]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~13_sumout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[3]~feeder_combout\);

-- Location: LABCELL_X2_Y4_N12
\inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~17\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(4),
	cin => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~14\,
	sumout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~17_sumout\,
	cout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~18\);

-- Location: LABCELL_X2_Y4_N39
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[4]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~17_sumout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[4]~feeder_combout\);

-- Location: LABCELL_X2_Y4_N15
\inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~21\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(5),
	cin => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~18\,
	sumout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~21_sumout\,
	cout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~22\);

-- Location: LABCELL_X2_Y4_N33
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~21_sumout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~feeder_combout\);

-- Location: LABCELL_X2_Y4_N18
\inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~25\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(6),
	cin => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~22\,
	sumout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~25_sumout\,
	cout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~26\);

-- Location: LABCELL_X2_Y4_N30
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[6]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~25_sumout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[6]~feeder_combout\);

-- Location: LABCELL_X2_Y4_N21
\inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~29\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(7),
	cin => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~26\,
	sumout => \inst3|altsyncram_component|auto_generated|mgl_prim2|Add0~29_sumout\);

-- Location: LABCELL_X2_Y4_N51
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~29_sumout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~feeder_combout\);

-- Location: FF_X2_Y4_N53
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~feeder_combout\,
	asdata => \altera_internal_jtag~TDIUTAP\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(7));

-- Location: FF_X2_Y4_N31
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[6]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(7),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(6));

-- Location: FF_X2_Y4_N34
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(6),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(5));

-- Location: FF_X2_Y4_N40
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[4]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(5),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(4));

-- Location: FF_X2_Y4_N49
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[3]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(4),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(3));

-- Location: FF_X1_Y5_N31
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(3),
	clrn => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	sload => VCC,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(3));

-- Location: LABCELL_X1_Y5_N39
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[4]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(4),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[4]~feeder_combout\);

-- Location: FF_X1_Y5_N40
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[4]~feeder_combout\,
	clrn => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(4));

-- Location: LABCELL_X1_Y5_N6
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[5]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(5),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[5]~feeder_combout\);

-- Location: FF_X1_Y5_N7
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[5]~feeder_combout\,
	clrn => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(5));

-- Location: LABCELL_X1_Y5_N12
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[6]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(6),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[6]~feeder_combout\);

-- Location: FF_X1_Y5_N13
\inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[6]~feeder_combout\,
	clrn => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(6));

-- Location: LABCELL_X1_Y4_N21
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~12\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010011100100111001001110010011100100111001001110010011100100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(6),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~12_combout\);

-- Location: FF_X1_Y4_N22
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~12_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(7));

-- Location: LABCELL_X1_Y4_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~11\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010110101111101011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(5),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(7),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~11_combout\);

-- Location: FF_X1_Y4_N19
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~11_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(6));

-- Location: LABCELL_X1_Y4_N39
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~10\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111101010101000011110101010100001111010101010000111101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(4),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(6),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~10_combout\);

-- Location: FF_X1_Y4_N40
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~10_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(5));

-- Location: LABCELL_X1_Y4_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~9\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100110011000011110011001100001111001100110000111100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(5),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~9_combout\);

-- Location: FF_X1_Y4_N37
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~9_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(4));

-- Location: LABCELL_X1_Y4_N27
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~feeder_combout\);

-- Location: FF_X1_Y4_N29
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~q\);

-- Location: LABCELL_X1_Y4_N12
\inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001010000010100000101011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][4]~q\,
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~0_combout\);

-- Location: MLABCELL_X3_Y4_N3
\inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~0_combout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~feeder_combout\);

-- Location: FF_X3_Y4_N5
\inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~q\);

-- Location: LABCELL_X1_Y4_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010110101111101011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~0_combout\);

-- Location: FF_X1_Y4_N1
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(0));

-- Location: LABCELL_X2_Y2_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000001000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\);

-- Location: FF_X2_Y2_N47
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \altera_internal_jtag~TDIUTAP\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(3));

-- Location: LABCELL_X2_Y2_N12
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[2]~feeder_combout\);

-- Location: FF_X2_Y2_N13
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[2]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(2));

-- Location: LABCELL_X2_Y2_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[1]~feeder_combout\);

-- Location: FF_X2_Y2_N16
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[1]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(1));

-- Location: FF_X2_Y2_N26
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(1),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(0));

-- Location: MLABCELL_X3_Y2_N9
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~feeder_combout\);

-- Location: MLABCELL_X3_Y3_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000100000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[1]~1_combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\);

-- Location: FF_X3_Y2_N10
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(0));

-- Location: LABCELL_X2_Y2_N27
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|clear_signal\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111000000000000111100000000000011110000000000001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|clear_signal~combout\);

-- Location: MLABCELL_X3_Y2_N21
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[0]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~4_combout\);

-- Location: LABCELL_X2_Y2_N9
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001010101000000000101010100001111010111110000111101011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\);

-- Location: FF_X2_Y2_N19
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[0]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~4_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[0]~DUPLICATE_q\);

-- Location: MLABCELL_X6_Y2_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100001111000011110000111100001111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[1]~DUPLICATE_q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[0]~DUPLICATE_q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~0_combout\);

-- Location: FF_X2_Y2_N4
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[1]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~0_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[1]~DUPLICATE_q\);

-- Location: MLABCELL_X3_Y2_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Add0~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[0]~DUPLICATE_q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[1]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Add0~0_combout\);

-- Location: MLABCELL_X3_Y2_N51
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101111110101111010111111010111101011111101011110101111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Add0~0_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~5_combout\);

-- Location: FF_X2_Y2_N40
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~5_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(2));

-- Location: MLABCELL_X3_Y2_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110111100111111011011110011111101101111001111110110111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Add0~0_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~2_combout\);

-- Location: FF_X2_Y2_N2
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~2_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(3));

-- Location: MLABCELL_X3_Y2_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111001110111111011100111011111100110011111111110011001111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Add0~0_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~3_combout\);

-- Location: FF_X2_Y2_N58
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~3_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(4));

-- Location: MLABCELL_X3_Y2_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000010000000000000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[0]~DUPLICATE_q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[1]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~0_combout\);

-- Location: MLABCELL_X3_Y2_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_proc~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111000000000000111100000000000011110000000000001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_proc~0_combout\);

-- Location: FF_X2_Y2_N5
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~0_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(1));

-- Location: FF_X2_Y2_N20
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~4_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(0));

-- Location: LABCELL_X2_Y2_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010100010100000001010001010000011000110100010001100011010001000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~1_combout\);

-- Location: FF_X3_Y2_N13
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(3),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(3));

-- Location: LABCELL_X2_Y2_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~9\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011100010111000000001010000010100001000000010000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~9_combout\);

-- Location: LABCELL_X1_Y2_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~10\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100000000001100110101010100110011111111110011001101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(3),
	datab => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_proc~0_combout\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~0_combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~9_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~10_combout\);

-- Location: MLABCELL_X6_Y2_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~3_combout\);

-- Location: FF_X1_Y2_N16
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~10_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(3));

-- Location: MLABCELL_X3_Y2_N57
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001000000010000000000000000000001000000010000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[0]~DUPLICATE_q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[1]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~6_combout\);

-- Location: FF_X3_Y2_N56
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(2),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(2));

-- Location: MLABCELL_X3_Y2_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~7\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011011000000000001101100000000001001001000000000100100100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[0]~DUPLICATE_q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[1]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~7_combout\);

-- Location: MLABCELL_X3_Y2_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~8\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010100110011010101011111111101010101000011110101010100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~6_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_proc~0_combout\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~7_combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~0_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~8_combout\);

-- Location: FF_X1_Y2_N19
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~8_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(2));

-- Location: MLABCELL_X3_Y2_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[1]~feeder_combout\);

-- Location: FF_X3_Y2_N7
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[1]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(1));

-- Location: MLABCELL_X3_Y2_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011101001111111100000000010000000111010011111111000000000100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[1]~DUPLICATE_q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[0]~DUPLICATE_q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~4_combout\);

-- Location: MLABCELL_X3_Y2_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000001100000111010001110100101110001011100011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~0_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_proc~0_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(2),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~4_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~5_combout\);

-- Location: LABCELL_X1_Y2_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~5_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[1]~feeder_combout\);

-- Location: FF_X1_Y2_N46
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[1]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(1));

-- Location: LABCELL_X1_Y2_N21
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000101000000001111010111111111000001011111111111110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_proc~0_combout\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~1_combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~2_combout\);

-- Location: FF_X1_Y2_N23
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~2_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(0));

-- Location: LABCELL_X1_Y2_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001000100110001000100010001000100010001000100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(0),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~2_combout\);

-- Location: IOIBUF_X36_Y0_N1
\clk~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G6
\clk~inputCLKENA0\ : cyclonev_clkena
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	disable_mode => "low",
	ena_register_mode => "always enabled",
	ena_register_power_up => "high",
	test_syn => "high")
-- pragma translate_on
PORT MAP (
	inclk => \clk~input_o\,
	outclk => \clk~inputCLKENA0_outclk\);

-- Location: FF_X7_Y2_N32
\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(0));

-- Location: LABCELL_X7_Y2_N30
\inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~sumout\ = SUM(( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(0) ) + ( VCC ) + ( !VCC ))
-- \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~COUT\ = CARRY(( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(0),
	cin => GND,
	sumout => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~sumout\,
	cout => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~COUT\);

-- Location: FF_X7_Y2_N31
\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\);

-- Location: IOIBUF_X4_Y0_N18
\M_CN~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M_CN,
	o => \M_CN~input_o\);

-- Location: M10K_X5_Y2_N0
\inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0\ : cyclonev_ram_block
-- pragma translate_off
GENERIC MAP (
	data_interleave_offset_in_bits => 1,
	data_interleave_width_in_bits => 1,
	logical_ram_name => "RAM:inst3|altsyncram:altsyncram_component|altsyncram_5c14:auto_generated|altsyncram_mqu2:altsyncram1|ALTSYNCRAM",
	mixed_port_feed_through_mode => "dont_care",
	operation_mode => "bidir_dual_port",
	port_a_address_clear => "none",
	port_a_address_width => 8,
	port_a_byte_enable_clock => "none",
	port_a_data_out_clear => "none",
	port_a_data_out_clock => "clock0",
	port_a_data_width => 20,
	port_a_first_address => 0,
	port_a_first_bit_number => 0,
	port_a_last_address => 255,
	port_a_logical_ram_depth => 256,
	port_a_logical_ram_width => 8,
	port_a_read_during_write_mode => "new_data_no_nbe_read",
	port_b_address_clear => "none",
	port_b_address_clock => "clock1",
	port_b_address_width => 8,
	port_b_data_in_clock => "clock1",
	port_b_data_out_clear => "none",
	port_b_data_out_clock => "none",
	port_b_data_width => 20,
	port_b_first_address => 0,
	port_b_first_bit_number => 0,
	port_b_last_address => 255,
	port_b_logical_ram_depth => 256,
	port_b_logical_ram_width => 8,
	port_b_read_during_write_mode => "new_data_no_nbe_read",
	port_b_read_enable_clock => "clock1",
	port_b_write_enable_clock => "clock1",
	ram_block_type => "M20K")
-- pragma translate_on
PORT MAP (
	portawe => \B_T_CN_M~input_o\,
	portare => VCC,
	portbwe => \inst3|altsyncram_component|auto_generated|mgl_prim2|enable_write~0_combout\,
	portbre => VCC,
	clk0 => \ALT_INV_clkM~inputCLKENA0_outclk\,
	clk1 => \altera_internal_jtag~TCKUTAP\,
	portadatain => \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAIN_bus\,
	portbdatain => \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAIN_bus\,
	portaaddr => \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTAADDR_bus\,
	portbaddr => \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBADDR_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	portadataout => \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\,
	portbdataout => \inst3|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\);

-- Location: LABCELL_X4_Y2_N45
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[7]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(7),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[7]~feeder_combout\);

-- Location: LABCELL_X4_Y2_N30
\inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111000001111000011100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(1),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\,
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\);

-- Location: LABCELL_X4_Y2_N18
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111111111111000011111111111100001111111111110001111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(1),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[0]~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\,
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1_combout\);

-- Location: FF_X4_Y2_N47
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[7]~feeder_combout\,
	asdata => \altera_internal_jtag~TDIUTAP\,
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(7));

-- Location: LABCELL_X4_Y2_N42
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[6]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(6),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[6]~feeder_combout\);

-- Location: FF_X4_Y2_N44
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[6]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(7),
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(6));

-- Location: LABCELL_X4_Y2_N39
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[5]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(5),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[5]~feeder_combout\);

-- Location: FF_X4_Y2_N41
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[5]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(6),
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(5));

-- Location: LABCELL_X4_Y2_N36
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[4]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(4),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[4]~feeder_combout\);

-- Location: FF_X4_Y2_N37
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[4]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(5),
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(4));

-- Location: LABCELL_X4_Y2_N57
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[3]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(3),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[3]~feeder_combout\);

-- Location: FF_X4_Y2_N58
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[3]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(4),
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(3));

-- Location: LABCELL_X4_Y2_N54
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(2),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[2]~feeder_combout\);

-- Location: FF_X4_Y2_N55
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[2]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(3),
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(2));

-- Location: LABCELL_X4_Y2_N3
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(1),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~feeder_combout\);

-- Location: FF_X4_Y2_N4
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(2),
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(1));

-- Location: LABCELL_X9_Y4_N30
\inst4|Add4~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add4~1_sumout\ = SUM(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(0) ) + ( !VCC ))
-- \inst4|Add4~2\ = CARRY(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	cin => GND,
	sumout => \inst4|Add4~1_sumout\,
	cout => \inst4|Add4~2\);

-- Location: LABCELL_X9_Y4_N33
\inst4|Add4~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add4~5_sumout\ = SUM(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(1) ) + ( \inst4|Add4~2\ ))
-- \inst4|Add4~6\ = CARRY(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(1) ) + ( \inst4|Add4~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	cin => \inst4|Add4~2\,
	sumout => \inst4|Add4~5_sumout\,
	cout => \inst4|Add4~6\);

-- Location: LABCELL_X9_Y4_N36
\inst4|Add4~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add4~9_sumout\ = SUM(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(2) ) + ( \inst4|Add4~6\ ))
-- \inst4|Add4~10\ = CARRY(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(2) ) + ( \inst4|Add4~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111110000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	cin => \inst4|Add4~6\,
	sumout => \inst4|Add4~9_sumout\,
	cout => \inst4|Add4~10\);

-- Location: LABCELL_X9_Y4_N39
\inst4|Add4~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add4~13_sumout\ = SUM(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(3) ) + ( \inst4|Add4~10\ ))
-- \inst4|Add4~14\ = CARRY(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(3) ) + ( \inst4|Add4~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	cin => \inst4|Add4~10\,
	sumout => \inst4|Add4~13_sumout\,
	cout => \inst4|Add4~14\);

-- Location: LABCELL_X9_Y4_N42
\inst4|Add4~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add4~17_sumout\ = SUM(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(4) ) + ( \inst4|Add4~14\ ))
-- \inst4|Add4~18\ = CARRY(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(4) ) + ( \inst4|Add4~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	cin => \inst4|Add4~14\,
	sumout => \inst4|Add4~17_sumout\,
	cout => \inst4|Add4~18\);

-- Location: LABCELL_X9_Y4_N45
\inst4|Add4~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add4~21_sumout\ = SUM(( \inst2|altsyncram_component|auto_generated|q_a\(5) ) + ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) ) + ( \inst4|Add4~18\ ))
-- \inst4|Add4~22\ = CARRY(( \inst2|altsyncram_component|auto_generated|q_a\(5) ) + ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) ) + ( \inst4|Add4~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	cin => \inst4|Add4~18\,
	sumout => \inst4|Add4~21_sumout\,
	cout => \inst4|Add4~22\);

-- Location: LABCELL_X9_Y4_N48
\inst4|Add4~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add4~25_sumout\ = SUM(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(6) ) + ( \inst4|Add4~22\ ))
-- \inst4|Add4~26\ = CARRY(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(6) ) + ( \inst4|Add4~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111110000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	cin => \inst4|Add4~22\,
	sumout => \inst4|Add4~25_sumout\,
	cout => \inst4|Add4~26\);

-- Location: LABCELL_X9_Y4_N51
\inst4|Add4~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add4~29_sumout\ = SUM(( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(7) ) + ( \inst4|Add4~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	cin => \inst4|Add4~26\,
	sumout => \inst4|Add4~29_sumout\);

-- Location: LABCELL_X10_Y4_N0
\inst4|Add5~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add5~1_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & \inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( !VCC ))
-- \inst4|Add5~2\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & \inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	cin => GND,
	sumout => \inst4|Add5~1_sumout\,
	cout => \inst4|Add5~2\);

-- Location: LABCELL_X10_Y4_N3
\inst4|Add5~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add5~5_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & \inst2|altsyncram_component|auto_generated|q_a\(1)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(1)) ) + ( \inst4|Add5~2\ ))
-- \inst4|Add5~6\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & \inst2|altsyncram_component|auto_generated|q_a\(1)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(1)) ) + ( \inst4|Add5~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100000011000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	cin => \inst4|Add5~2\,
	sumout => \inst4|Add5~5_sumout\,
	cout => \inst4|Add5~6\);

-- Location: LABCELL_X10_Y4_N6
\inst4|Add5~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add5~9_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(2) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst4|Add5~6\ ))
-- \inst4|Add5~10\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(2) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst4|Add5~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	cin => \inst4|Add5~6\,
	sumout => \inst4|Add5~9_sumout\,
	cout => \inst4|Add5~10\);

-- Location: LABCELL_X10_Y4_N9
\inst4|Add5~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add5~13_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst4|Add5~10\ ))
-- \inst4|Add5~14\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst4|Add5~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	cin => \inst4|Add5~10\,
	sumout => \inst4|Add5~13_sumout\,
	cout => \inst4|Add5~14\);

-- Location: LABCELL_X10_Y4_N12
\inst4|Add5~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add5~17_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(4) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst4|Add5~14\ ))
-- \inst4|Add5~18\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(4) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst4|Add5~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	cin => \inst4|Add5~14\,
	sumout => \inst4|Add5~17_sumout\,
	cout => \inst4|Add5~18\);

-- Location: LABCELL_X10_Y4_N15
\inst4|Add5~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add5~21_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(5) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst4|Add5~18\ ))
-- \inst4|Add5~22\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(5) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst4|Add5~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	cin => \inst4|Add5~18\,
	sumout => \inst4|Add5~21_sumout\,
	cout => \inst4|Add5~22\);

-- Location: LABCELL_X10_Y4_N18
\inst4|Add5~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add5~25_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & \inst2|altsyncram_component|auto_generated|q_a\(6)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(6)) ) + ( \inst4|Add5~22\ ))
-- \inst4|Add5~26\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & \inst2|altsyncram_component|auto_generated|q_a\(6)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(6)) ) + ( \inst4|Add5~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100000011000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	cin => \inst4|Add5~22\,
	sumout => \inst4|Add5~25_sumout\,
	cout => \inst4|Add5~26\);

-- Location: LABCELL_X10_Y4_N21
\inst4|Add5~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add5~29_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(7) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(7)) ) + ( \inst4|Add5~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	cin => \inst4|Add5~26\,
	sumout => \inst4|Add5~29_sumout\);

-- Location: LABCELL_X10_Y4_N54
\inst4|Mux1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~13_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(7) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7))) # 
-- (\M_CN~input_o\ & ((\inst4|Add5~29_sumout\))))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7))))) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(7) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7))) # (\M_CN~input_o\ & 
-- ((\inst4|Add5~29_sumout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000101010000010000010101000001101001011110000110100101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \ALT_INV_M_CN~input_o\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datad => \inst4|ALT_INV_Add5~29_sumout\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	combout => \inst4|Mux1~13_combout\);

-- Location: FF_X7_Y2_N35
\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1));

-- Location: LABCELL_X7_Y2_N33
\inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~sumout\ = SUM(( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) ) + ( GND ) + ( \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~COUT\ ))
-- \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~COUT\ = CARRY(( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) ) + ( GND ) + ( \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~COUT\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(1),
	cin => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita0~COUT\,
	sumout => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~sumout\,
	cout => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~COUT\);

-- Location: FF_X7_Y2_N34
\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\);

-- Location: MLABCELL_X8_Y3_N36
\inst4|Mux7~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux7~5_combout\ = ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	combout => \inst4|Mux7~5_combout\);

-- Location: LABCELL_X7_Y4_N30
\inst4|Add3~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add3~1_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & \inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(0) ) + ( !VCC ))
-- \inst4|Add3~2\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & \inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	cin => GND,
	sumout => \inst4|Add3~1_sumout\,
	cout => \inst4|Add3~2\);

-- Location: LABCELL_X7_Y4_N33
\inst4|Add3~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add3~5_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(1) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(1) ) + ( \inst4|Add3~2\ ))
-- \inst4|Add3~6\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(1) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(1) ) + ( \inst4|Add3~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000000000001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst4|Add3~2\,
	sumout => \inst4|Add3~5_sumout\,
	cout => \inst4|Add3~6\);

-- Location: LABCELL_X7_Y4_N36
\inst4|Add3~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add3~9_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & \inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(2) ) + ( \inst4|Add3~6\ ))
-- \inst4|Add3~10\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & \inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(2) ) + ( \inst4|Add3~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	cin => \inst4|Add3~6\,
	sumout => \inst4|Add3~9_sumout\,
	cout => \inst4|Add3~10\);

-- Location: LABCELL_X7_Y4_N39
\inst4|Add3~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add3~13_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(3) ) + ( \inst4|Add3~10\ ))
-- \inst4|Add3~14\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(3) ) + ( \inst4|Add3~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	cin => \inst4|Add3~10\,
	sumout => \inst4|Add3~13_sumout\,
	cout => \inst4|Add3~14\);

-- Location: LABCELL_X7_Y4_N42
\inst4|Add3~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add3~17_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(4) ) + ( \inst4|Add3~14\ ))
-- \inst4|Add3~18\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(4) ) + ( \inst4|Add3~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	cin => \inst4|Add3~14\,
	sumout => \inst4|Add3~17_sumout\,
	cout => \inst4|Add3~18\);

-- Location: LABCELL_X7_Y4_N45
\inst4|Add3~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add3~21_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & \inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(5) ) + ( \inst4|Add3~18\ ))
-- \inst4|Add3~22\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & \inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(5) ) + ( \inst4|Add3~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	cin => \inst4|Add3~18\,
	sumout => \inst4|Add3~21_sumout\,
	cout => \inst4|Add3~22\);

-- Location: LABCELL_X7_Y4_N48
\inst4|Add3~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add3~25_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(6) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(6) ) + ( \inst4|Add3~22\ ))
-- \inst4|Add3~26\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(6) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(6) ) + ( \inst4|Add3~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000000000001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	cin => \inst4|Add3~22\,
	sumout => \inst4|Add3~25_sumout\,
	cout => \inst4|Add3~26\);

-- Location: LABCELL_X7_Y4_N51
\inst4|Add3~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add3~29_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(7) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(7) ) + ( \inst4|Add3~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000000000001010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	cin => \inst4|Add3~26\,
	sumout => \inst4|Add3~29_sumout\);

-- Location: LABCELL_X9_Y4_N21
\inst4|F9~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~13_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( !\inst2|altsyncram_component|auto_generated|q_a\(7) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(7) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001111001100110011001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	combout => \inst4|F9~13_combout\);

-- Location: LABCELL_X12_Y4_N45
\inst4|Mux1~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~6_combout\ = ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (\M_CN~input_o\ & !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\) ) ) # ( 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100000000111111110000000000001111000000000000111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_M_CN~input_o\,
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	combout => \inst4|Mux1~6_combout\);

-- Location: LABCELL_X9_Y4_N57
\inst4|Mux1~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~14_combout\ = ( \inst4|F9~13_combout\ & ( \inst4|Mux1~6_combout\ & ( (!\inst4|Mux7~5_combout\ & ((\inst4|Add3~29_sumout\))) # (\inst4|Mux7~5_combout\ & (\inst4|Add4~29_sumout\)) ) ) ) # ( !\inst4|F9~13_combout\ & ( \inst4|Mux1~6_combout\ & ( 
-- (!\inst4|Mux7~5_combout\ & ((\inst4|Add3~29_sumout\))) # (\inst4|Mux7~5_combout\ & (\inst4|Add4~29_sumout\)) ) ) ) # ( \inst4|F9~13_combout\ & ( !\inst4|Mux1~6_combout\ & ( (\inst4|Mux1~13_combout\ & !\inst4|Mux7~5_combout\) ) ) ) # ( 
-- !\inst4|F9~13_combout\ & ( !\inst4|Mux1~6_combout\ & ( (\inst4|Mux7~5_combout\) # (\inst4|Mux1~13_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011111100111111001100000011000000000101111101010000010111110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Add4~29_sumout\,
	datab => \inst4|ALT_INV_Mux1~13_combout\,
	datac => \inst4|ALT_INV_Mux7~5_combout\,
	datad => \inst4|ALT_INV_Add3~29_sumout\,
	datae => \inst4|ALT_INV_F9~13_combout\,
	dataf => \inst4|ALT_INV_Mux1~6_combout\,
	combout => \inst4|Mux1~14_combout\);

-- Location: LABCELL_X9_Y3_N30
\inst4|Add6~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add6~1_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(0)) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(0) ) + ( !VCC ))
-- \inst4|Add6~2\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(0)) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	cin => GND,
	sumout => \inst4|Add6~1_sumout\,
	cout => \inst4|Add6~2\);

-- Location: LABCELL_X9_Y3_N33
\inst4|Add6~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add6~5_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst2|altsyncram_component|auto_generated|q_a\(1)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(1) ) + ( \inst4|Add6~2\ ))
-- \inst4|Add6~6\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst2|altsyncram_component|auto_generated|q_a\(1)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(1) ) + ( \inst4|Add6~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000101111101011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst4|Add6~2\,
	sumout => \inst4|Add6~5_sumout\,
	cout => \inst4|Add6~6\);

-- Location: LABCELL_X9_Y3_N36
\inst4|Add6~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add6~9_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(2)) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(2) ) + ( \inst4|Add6~6\ ))
-- \inst4|Add6~10\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(2)) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(2) ) + ( \inst4|Add6~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	cin => \inst4|Add6~6\,
	sumout => \inst4|Add6~9_sumout\,
	cout => \inst4|Add6~10\);

-- Location: LABCELL_X9_Y3_N39
\inst4|Add6~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add6~13_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (\inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(3) ) + ( \inst4|Add6~10\ ))
-- \inst4|Add6~14\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (\inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(3) ) + ( \inst4|Add6~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000101111101011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	cin => \inst4|Add6~10\,
	sumout => \inst4|Add6~13_sumout\,
	cout => \inst4|Add6~14\);

-- Location: LABCELL_X9_Y3_N42
\inst4|Add6~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add6~17_sumout\ = SUM(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(4) ) + ( \inst4|Add6~14\ ))
-- \inst4|Add6~18\ = CARRY(( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(4) ) + ( \inst4|Add6~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000000011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	cin => \inst4|Add6~14\,
	sumout => \inst4|Add6~17_sumout\,
	cout => \inst4|Add6~18\);

-- Location: LABCELL_X9_Y3_N45
\inst4|Add6~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add6~21_sumout\ = SUM(( \inst2|altsyncram_component|auto_generated|q_a\(5) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst4|Add6~18\ ))
-- \inst4|Add6~22\ = CARRY(( \inst2|altsyncram_component|auto_generated|q_a\(5) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst4|Add6~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010100000000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	cin => \inst4|Add6~18\,
	sumout => \inst4|Add6~21_sumout\,
	cout => \inst4|Add6~22\);

-- Location: LABCELL_X9_Y3_N48
\inst4|Add6~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add6~25_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(6)) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(6) ) + ( \inst4|Add6~22\ ))
-- \inst4|Add6~26\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(6)) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(6) ) + ( \inst4|Add6~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000101111101011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	cin => \inst4|Add6~22\,
	sumout => \inst4|Add6~25_sumout\,
	cout => \inst4|Add6~26\);

-- Location: LABCELL_X9_Y3_N51
\inst4|Add6~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add6~29_sumout\ = SUM(( \inst2|altsyncram_component|auto_generated|q_a\(7) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) # (\inst2|altsyncram_component|auto_generated|q_a\(7)) ) + ( \inst4|Add6~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	cin => \inst4|Add6~26\,
	sumout => \inst4|Add6~29_sumout\);

-- Location: LABCELL_X9_Y3_N0
\inst4|Add7~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add7~1_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # (\inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(0) ) + ( !VCC ))
-- \inst4|Add7~2\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # (\inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000001100111111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	cin => GND,
	sumout => \inst4|Add7~1_sumout\,
	cout => \inst4|Add7~2\);

-- Location: LABCELL_X9_Y3_N3
\inst4|Add7~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add7~5_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst2|altsyncram_component|auto_generated|q_a\(1)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(1) ) + ( \inst4|Add7~2\ ))
-- \inst4|Add7~6\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst2|altsyncram_component|auto_generated|q_a\(1)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(1) ) + ( \inst4|Add7~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000001111010111110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst4|Add7~2\,
	sumout => \inst4|Add7~5_sumout\,
	cout => \inst4|Add7~6\);

-- Location: LABCELL_X9_Y3_N6
\inst4|Add7~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add7~9_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # (\inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(2) ) + ( \inst4|Add7~6\ ))
-- \inst4|Add7~10\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # (\inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(2) ) + ( \inst4|Add7~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000001100111111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	cin => \inst4|Add7~6\,
	sumout => \inst4|Add7~9_sumout\,
	cout => \inst4|Add7~10\);

-- Location: LABCELL_X9_Y3_N9
\inst4|Add7~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add7~13_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (\inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(3) ) + ( \inst4|Add7~10\ ))
-- \inst4|Add7~14\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (\inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(3) ) + ( \inst4|Add7~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000001111010111110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	cin => \inst4|Add7~10\,
	sumout => \inst4|Add7~13_sumout\,
	cout => \inst4|Add7~14\);

-- Location: LABCELL_X9_Y3_N12
\inst4|Add7~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add7~17_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(4) ) + ( \inst4|Add7~14\ ))
-- \inst4|Add7~18\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(4) ) + ( \inst4|Add7~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000001111001111110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	cin => \inst4|Add7~14\,
	sumout => \inst4|Add7~17_sumout\,
	cout => \inst4|Add7~18\);

-- Location: LABCELL_X9_Y3_N15
\inst4|Add7~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add7~21_sumout\ = SUM(( \inst2|altsyncram_component|auto_generated|q_a\(5) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst4|Add7~18\ ))
-- \inst4|Add7~22\ = CARRY(( \inst2|altsyncram_component|auto_generated|q_a\(5) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst4|Add7~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000001010101000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	cin => \inst4|Add7~18\,
	sumout => \inst4|Add7~21_sumout\,
	cout => \inst4|Add7~22\);

-- Location: LABCELL_X9_Y3_N18
\inst4|Add7~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add7~25_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # (\inst2|altsyncram_component|auto_generated|q_a\(6)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(6) ) + ( \inst4|Add7~22\ ))
-- \inst4|Add7~26\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # (\inst2|altsyncram_component|auto_generated|q_a\(6)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(6) ) + ( \inst4|Add7~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000001010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	cin => \inst4|Add7~22\,
	sumout => \inst4|Add7~25_sumout\,
	cout => \inst4|Add7~26\);

-- Location: LABCELL_X9_Y3_N21
\inst4|Add7~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add7~29_sumout\ = SUM(( \inst2|altsyncram_component|auto_generated|q_a\(7) ) + ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) # (\inst2|altsyncram_component|auto_generated|q_a\(7)) ) + ( \inst4|Add7~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000001111000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	cin => \inst4|Add7~26\,
	sumout => \inst4|Add7~29_sumout\);

-- Location: LABCELL_X7_Y2_N36
\inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita2~sumout\ = SUM(( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) ) + ( GND ) + ( \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~COUT\ ))
-- \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita2~COUT\ = CARRY(( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) ) + ( GND ) + ( \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~COUT\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	cin => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita1~COUT\,
	sumout => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita2~sumout\,
	cout => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita2~COUT\);

-- Location: FF_X7_Y2_N37
\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita2~sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2));

-- Location: MLABCELL_X8_Y3_N6
\inst4|Mux1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~5_combout\ = ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ ) ) # ( 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ( (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & !\M_CN~input_o\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000000110000111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datac => \ALT_INV_M_CN~input_o\,
	datae => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	combout => \inst4|Mux1~5_combout\);

-- Location: MLABCELL_X8_Y3_N54
\inst4|Mux1~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~12_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(6) & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ( (\inst4|Add7~29_sumout\ & !\inst4|Mux1~5_combout\) ) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(6) & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ( (\inst4|Add7~29_sumout\ & !\inst4|Mux1~5_combout\) ) ) ) # ( \inst2|altsyncram_component|auto_generated|q_a\(6) & ( 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((!\inst4|Mux1~5_combout\)))) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\inst4|Add7~29_sumout\ & !\inst4|Mux1~5_combout\)) # (\inst4|Add6~29_sumout\))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(6) & ( 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ( (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\inst4|Add7~29_sumout\ & !\inst4|Mux1~5_combout\)) # (\inst4|Add6~29_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001001100010001110111110001000100001111000000000000111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Add6~29_sumout\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datac => \inst4|ALT_INV_Add7~29_sumout\,
	datad => \inst4|ALT_INV_Mux1~5_combout\,
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	combout => \inst4|Mux1~12_combout\);

-- Location: LABCELL_X7_Y2_N39
\inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita3~sumout\ = SUM(( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) ) + ( GND ) + ( \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita2~COUT\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3),
	cin => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita2~COUT\,
	sumout => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita3~sumout\);

-- Location: FF_X7_Y2_N41
\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita3~sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3));

-- Location: LABCELL_X7_Y2_N18
\inst4|Mux1~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~7_combout\ = ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) ) ) # ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1)) # ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(0) & ((\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)))) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(0) & ((!\M_CN~input_o\) # (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001111111110111100111111111011111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_M_CN~input_o\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(0),
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(1),
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3),
	combout => \inst4|Mux1~7_combout\);

-- Location: LABCELL_X7_Y2_N21
\inst4|Mux1~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~8_combout\ = ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) ) ) # ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & ( 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(0)) # (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2))) # (\M_CN~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001101000011110000110100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_M_CN~input_o\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(0),
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3),
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(1),
	combout => \inst4|Mux1~8_combout\);

-- Location: LABCELL_X7_Y3_N0
\inst4|Mux1~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~4_combout\ = ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ ) ) # ( 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & \M_CN~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datac => \ALT_INV_M_CN~input_o\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	combout => \inst4|Mux1~4_combout\);

-- Location: LABCELL_X7_Y4_N0
\inst4|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add0~1_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & \inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(0) ) + ( !VCC ))
-- \inst4|Add0~2\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & \inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	cin => GND,
	sumout => \inst4|Add0~1_sumout\,
	cout => \inst4|Add0~2\);

-- Location: LABCELL_X7_Y4_N3
\inst4|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add0~5_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(1) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(1) ) + ( \inst4|Add0~2\ ))
-- \inst4|Add0~6\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(1) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(1) ) + ( \inst4|Add0~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst4|Add0~2\,
	sumout => \inst4|Add0~5_sumout\,
	cout => \inst4|Add0~6\);

-- Location: LABCELL_X7_Y4_N6
\inst4|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add0~9_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & \inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(2) ) + ( \inst4|Add0~6\ ))
-- \inst4|Add0~10\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & \inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(2) ) + ( \inst4|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	cin => \inst4|Add0~6\,
	sumout => \inst4|Add0~9_sumout\,
	cout => \inst4|Add0~10\);

-- Location: LABCELL_X7_Y4_N9
\inst4|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add0~13_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(3) ) + ( \inst4|Add0~10\ ))
-- \inst4|Add0~14\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(3) ) + ( \inst4|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	cin => \inst4|Add0~10\,
	sumout => \inst4|Add0~13_sumout\,
	cout => \inst4|Add0~14\);

-- Location: LABCELL_X7_Y4_N12
\inst4|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add0~17_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(4) ) + ( \inst4|Add0~14\ ))
-- \inst4|Add0~18\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(4) ) + ( \inst4|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	cin => \inst4|Add0~14\,
	sumout => \inst4|Add0~17_sumout\,
	cout => \inst4|Add0~18\);

-- Location: LABCELL_X7_Y4_N15
\inst4|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add0~21_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & \inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(5) ) + ( \inst4|Add0~18\ ))
-- \inst4|Add0~22\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & \inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(5) ) + ( \inst4|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	cin => \inst4|Add0~18\,
	sumout => \inst4|Add0~21_sumout\,
	cout => \inst4|Add0~22\);

-- Location: LABCELL_X7_Y4_N18
\inst4|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add0~25_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(6) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(6) ) + ( \inst4|Add0~22\ ))
-- \inst4|Add0~26\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(6) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(6) ) + ( \inst4|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	cin => \inst4|Add0~22\,
	sumout => \inst4|Add0~25_sumout\,
	cout => \inst4|Add0~26\);

-- Location: LABCELL_X7_Y4_N21
\inst4|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add0~29_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(7) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) ) + ( \inst2|altsyncram_component|auto_generated|q_a\(7) ) + ( \inst4|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000101010100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	cin => \inst4|Add0~26\,
	sumout => \inst4|Add0~29_sumout\);

-- Location: MLABCELL_X8_Y4_N30
\inst4|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add1~1_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(0) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( !VCC ))
-- \inst4|Add1~2\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(0) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(0)) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	cin => GND,
	sumout => \inst4|Add1~1_sumout\,
	cout => \inst4|Add1~2\);

-- Location: MLABCELL_X8_Y4_N33
\inst4|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add1~5_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(1) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(1)) ) + ( \inst4|Add1~2\ ))
-- \inst4|Add1~6\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(1) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(1)) ) + ( \inst4|Add1~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst4|Add1~2\,
	sumout => \inst4|Add1~5_sumout\,
	cout => \inst4|Add1~6\);

-- Location: MLABCELL_X8_Y4_N36
\inst4|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add1~9_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(2) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst4|Add1~6\ ))
-- \inst4|Add1~10\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(2) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst4|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	cin => \inst4|Add1~6\,
	sumout => \inst4|Add1~9_sumout\,
	cout => \inst4|Add1~10\);

-- Location: MLABCELL_X8_Y4_N39
\inst4|Add1~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add1~13_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( (\inst2|altsyncram_component|auto_generated|q_a\(3)) # 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( \inst4|Add1~10\ ))
-- \inst4|Add1~14\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst2|altsyncram_component|auto_generated|q_a\(3)) ) + ( (\inst2|altsyncram_component|auto_generated|q_a\(3)) # 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( \inst4|Add1~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	cin => \inst4|Add1~10\,
	sumout => \inst4|Add1~13_sumout\,
	cout => \inst4|Add1~14\);

-- Location: MLABCELL_X8_Y4_N42
\inst4|Add1~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add1~17_sumout\ = SUM(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( (\inst2|altsyncram_component|auto_generated|q_a\(4)) # 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) ) + ( \inst4|Add1~14\ ))
-- \inst4|Add1~18\ = CARRY(( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( (\inst2|altsyncram_component|auto_generated|q_a\(4)) # 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) ) + ( \inst4|Add1~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	cin => \inst4|Add1~14\,
	sumout => \inst4|Add1~17_sumout\,
	cout => \inst4|Add1~18\);

-- Location: MLABCELL_X8_Y4_N45
\inst4|Add1~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add1~21_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(5) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst4|Add1~18\ ))
-- \inst4|Add1~22\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(5) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst4|Add1~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	cin => \inst4|Add1~18\,
	sumout => \inst4|Add1~21_sumout\,
	cout => \inst4|Add1~22\);

-- Location: MLABCELL_X8_Y4_N48
\inst4|Add1~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add1~25_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(6) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(6)) ) + ( \inst4|Add1~22\ ))
-- \inst4|Add1~26\ = CARRY(( (\inst2|altsyncram_component|auto_generated|q_a\(6) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(6)) ) + ( \inst4|Add1~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	cin => \inst4|Add1~22\,
	sumout => \inst4|Add1~25_sumout\,
	cout => \inst4|Add1~26\);

-- Location: MLABCELL_X8_Y4_N51
\inst4|Add1~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add1~29_sumout\ = SUM(( (\inst2|altsyncram_component|auto_generated|q_a\(7) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) ) + ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(7)) ) + ( \inst4|Add1~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	cin => \inst4|Add1~26\,
	sumout => \inst4|Add1~29_sumout\);

-- Location: MLABCELL_X8_Y4_N18
\inst4|Mux1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~9_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( \inst4|Add1~29_sumout\ & ( (!\M_CN~input_o\ & (((\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\)) # 
-- (\inst2|altsyncram_component|auto_generated|q_a\(7)))) # (\M_CN~input_o\ & (((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & !\inst4|Add0~29_sumout\)))) ) ) ) # ( 
-- !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( \inst4|Add1~29_sumout\ & ( (\M_CN~input_o\ & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & !\inst4|Add0~29_sumout\)) ) ) ) # ( 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( !\inst4|Add1~29_sumout\ & ( ((!\M_CN~input_o\ & (\inst2|altsyncram_component|auto_generated|q_a\(7))) # (\M_CN~input_o\ & ((!\inst4|Add0~29_sumout\)))) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) ) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( !\inst4|Add1~29_sumout\ & ( (\M_CN~input_o\ & ((!\inst4|Add0~29_sumout\) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100000011011111110100111100110000000000000111110001001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datab => \ALT_INV_M_CN~input_o\,
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datad => \inst4|ALT_INV_Add0~29_sumout\,
	datae => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	dataf => \inst4|ALT_INV_Add1~29_sumout\,
	combout => \inst4|Mux1~9_combout\);

-- Location: MLABCELL_X8_Y3_N3
\inst4|Mux1~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~3_combout\ = ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	combout => \inst4|Mux1~3_combout\);

-- Location: LABCELL_X9_Y5_N30
\inst4|Add2~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add2~1_sumout\ = SUM(( !\inst2|altsyncram_component|auto_generated|q_a\(0) $ (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) ) + ( !VCC ) + ( !VCC ))
-- \inst4|Add2~2\ = CARRY(( !\inst2|altsyncram_component|auto_generated|q_a\(0) $ (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) ) + ( !VCC ) + ( !VCC ))
-- \inst4|Add2~3\ = SHARE((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # (\inst2|altsyncram_component|auto_generated|q_a\(0)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111110000111100000000000000000000111111110000",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	cin => GND,
	sharein => GND,
	sumout => \inst4|Add2~1_sumout\,
	cout => \inst4|Add2~2\,
	shareout => \inst4|Add2~3\);

-- Location: LABCELL_X9_Y5_N33
\inst4|Add2~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add2~5_sumout\ = SUM(( !\inst2|altsyncram_component|auto_generated|q_a\(1) $ (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( \inst4|Add2~3\ ) + ( \inst4|Add2~2\ ))
-- \inst4|Add2~6\ = CARRY(( !\inst2|altsyncram_component|auto_generated|q_a\(1) $ (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( \inst4|Add2~3\ ) + ( \inst4|Add2~2\ ))
-- \inst4|Add2~7\ = SHARE((\inst2|altsyncram_component|auto_generated|q_a\(1) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000001010010110100101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst4|Add2~2\,
	sharein => \inst4|Add2~3\,
	sumout => \inst4|Add2~5_sumout\,
	cout => \inst4|Add2~6\,
	shareout => \inst4|Add2~7\);

-- Location: LABCELL_X9_Y5_N36
\inst4|Add2~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add2~9_sumout\ = SUM(( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) $ (\inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst4|Add2~7\ ) + ( \inst4|Add2~6\ ))
-- \inst4|Add2~10\ = CARRY(( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) $ (\inst2|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst4|Add2~7\ ) + ( \inst4|Add2~6\ ))
-- \inst4|Add2~11\ = SHARE((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & \inst2|altsyncram_component|auto_generated|q_a\(2)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000001100001111000011",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	cin => \inst4|Add2~6\,
	sharein => \inst4|Add2~7\,
	sumout => \inst4|Add2~9_sumout\,
	cout => \inst4|Add2~10\,
	shareout => \inst4|Add2~11\);

-- Location: LABCELL_X9_Y5_N39
\inst4|Add2~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add2~13_sumout\ = SUM(( !\inst2|altsyncram_component|auto_generated|q_a\(3) $ (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( \inst4|Add2~11\ ) + ( \inst4|Add2~10\ ))
-- \inst4|Add2~14\ = CARRY(( !\inst2|altsyncram_component|auto_generated|q_a\(3) $ (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( \inst4|Add2~11\ ) + ( \inst4|Add2~10\ ))
-- \inst4|Add2~15\ = SHARE((\inst2|altsyncram_component|auto_generated|q_a\(3) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000001010010110100101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	cin => \inst4|Add2~10\,
	sharein => \inst4|Add2~11\,
	sumout => \inst4|Add2~13_sumout\,
	cout => \inst4|Add2~14\,
	shareout => \inst4|Add2~15\);

-- Location: LABCELL_X9_Y5_N42
\inst4|Add2~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add2~17_sumout\ = SUM(( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) $ (\inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst4|Add2~15\ ) + ( \inst4|Add2~14\ ))
-- \inst4|Add2~18\ = CARRY(( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) $ (\inst2|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst4|Add2~15\ ) + ( \inst4|Add2~14\ ))
-- \inst4|Add2~19\ = SHARE((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst2|altsyncram_component|auto_generated|q_a\(4)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000001010010110100101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	cin => \inst4|Add2~14\,
	sharein => \inst4|Add2~15\,
	sumout => \inst4|Add2~17_sumout\,
	cout => \inst4|Add2~18\,
	shareout => \inst4|Add2~19\);

-- Location: LABCELL_X9_Y5_N45
\inst4|Add2~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add2~21_sumout\ = SUM(( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) $ (\inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst4|Add2~19\ ) + ( \inst4|Add2~18\ ))
-- \inst4|Add2~22\ = CARRY(( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) $ (\inst2|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst4|Add2~19\ ) + ( \inst4|Add2~18\ ))
-- \inst4|Add2~23\ = SHARE((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & \inst2|altsyncram_component|auto_generated|q_a\(5)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000001100001111000011",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	cin => \inst4|Add2~18\,
	sharein => \inst4|Add2~19\,
	sumout => \inst4|Add2~21_sumout\,
	cout => \inst4|Add2~22\,
	shareout => \inst4|Add2~23\);

-- Location: LABCELL_X9_Y5_N48
\inst4|Add2~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add2~25_sumout\ = SUM(( !\inst2|altsyncram_component|auto_generated|q_a\(6) $ (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst4|Add2~23\ ) + ( \inst4|Add2~22\ ))
-- \inst4|Add2~26\ = CARRY(( !\inst2|altsyncram_component|auto_generated|q_a\(6) $ (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst4|Add2~23\ ) + ( \inst4|Add2~22\ ))
-- \inst4|Add2~27\ = SHARE((\inst2|altsyncram_component|auto_generated|q_a\(6) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100000011000000000000000000001100001111000011",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	cin => \inst4|Add2~22\,
	sharein => \inst4|Add2~23\,
	sumout => \inst4|Add2~25_sumout\,
	cout => \inst4|Add2~26\,
	shareout => \inst4|Add2~27\);

-- Location: LABCELL_X9_Y5_N51
\inst4|Add2~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Add2~29_sumout\ = SUM(( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) $ (\inst2|altsyncram_component|auto_generated|q_a\(7)) ) + ( \inst4|Add2~27\ ) + ( \inst4|Add2~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000001010101001010101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	cin => \inst4|Add2~26\,
	sharein => \inst4|Add2~27\,
	sumout => \inst4|Add2~29_sumout\);

-- Location: LABCELL_X9_Y5_N54
\inst4|Mux1~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~10_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(7) & ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\inst4|Mux1~4_combout\ & (!\inst4|Mux1~9_combout\ & (!\inst4|Mux1~3_combout\))) # 
-- (\inst4|Mux1~4_combout\ & (((\inst4|Mux1~3_combout\ & \inst4|Add2~29_sumout\)))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(7) & ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\inst4|Mux1~4_combout\ & 
-- ((!\inst4|Mux1~9_combout\) # ((\inst4|Mux1~3_combout\)))) # (\inst4|Mux1~4_combout\ & (((\inst4|Mux1~3_combout\ & \inst4|Add2~29_sumout\)))) ) ) ) # ( \inst2|altsyncram_component|auto_generated|q_a\(7) & ( 
-- !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\inst4|Mux1~4_combout\ & ((!\inst4|Mux1~9_combout\) # ((\inst4|Mux1~3_combout\)))) # (\inst4|Mux1~4_combout\ & (((!\inst4|Mux1~3_combout\) # (\inst4|Add2~29_sumout\)))) ) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(7) & ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\inst4|Mux1~4_combout\ & (!\inst4|Mux1~9_combout\ & (!\inst4|Mux1~3_combout\))) # (\inst4|Mux1~4_combout\ & 
-- (((\inst4|Mux1~3_combout\ & \inst4|Add2~29_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000010000101110110101101111110001010100011111000000010000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~4_combout\,
	datab => \inst4|ALT_INV_Mux1~9_combout\,
	datac => \inst4|ALT_INV_Mux1~3_combout\,
	datad => \inst4|ALT_INV_Add2~29_sumout\,
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	combout => \inst4|Mux1~10_combout\);

-- Location: MLABCELL_X8_Y3_N24
\inst4|Mux1~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~11_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(7) & ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (\inst4|Mux1~10_combout\ & \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)) ) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(7) & ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & 
-- (((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & 
-- (\inst4|Mux1~10_combout\)) ) ) ) # ( \inst2|altsyncram_component|auto_generated|q_a\(7) & ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (\inst4|Mux1~10_combout\ & \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)) ) ) 
-- ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(7) & ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & 
-- ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & (\inst4|Mux1~10_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000001010101000000000101010111000000010101010000000001010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~10_combout\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	combout => \inst4|Mux1~11_combout\);

-- Location: MLABCELL_X8_Y3_N12
\inst4|Mux1~16\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~16_combout\ = ( !\inst4|Mux1~8_combout\ & ( ((!\inst4|Mux1~7_combout\ & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) # ((\inst2|altsyncram_component|auto_generated|q_a\(7))))) # (\inst4|Mux1~7_combout\ & 
-- (((\inst4|Mux1~11_combout\))))) ) ) # ( \inst4|Mux1~8_combout\ & ( ((!\inst4|Mux1~7_combout\ & (((\inst4|Mux1~12_combout\)))) # (\inst4|Mux1~7_combout\ & (\inst4|Mux1~14_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1010111100000000000011110011001110101111111111110000111100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datab => \inst4|ALT_INV_Mux1~14_combout\,
	datac => \inst4|ALT_INV_Mux1~12_combout\,
	datad => \inst4|ALT_INV_Mux1~7_combout\,
	datae => \inst4|ALT_INV_Mux1~8_combout\,
	dataf => \inst4|ALT_INV_Mux1~11_combout\,
	datag => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	combout => \inst4|Mux1~16_combout\);

-- Location: LABCELL_X7_Y2_N27
\inst4|Mux1~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~2_combout\ = ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & \M_CN~input_o\))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)))) ) ) # ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & \M_CN~input_o\))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & !\M_CN~input_o\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000110000000000000011000000000000001100000010000000110000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(1),
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3),
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datad => \ALT_INV_M_CN~input_o\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	combout => \inst4|Mux1~2_combout\);

-- Location: LABCELL_X7_Y2_N3
\inst4|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~0_combout\ = ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & ( (!\M_CN~input_o\ & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(0) & 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & ((\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)))))) ) ) # ( 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ((!\M_CN~input_o\ & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(0) & 
-- \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3))) # (\M_CN~input_o\ & (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(0) & !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001100000000000000110000000000010000000000010101000000000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_M_CN~input_o\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(0),
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3),
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(1),
	combout => \inst4|Mux1~0_combout\);

-- Location: LABCELL_X7_Y2_N24
\inst4|Mux1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~1_combout\ = ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & 
-- \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2))) ) ) # ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (\M_CN~input_o\ & !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000000000010000000000000000000000100010000000000010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(1),
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3),
	datac => \ALT_INV_M_CN~input_o\,
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	combout => \inst4|Mux1~1_combout\);

-- Location: MLABCELL_X6_Y2_N48
\inst4|Mux1~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux1~15_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(7) & ( \inst4|Mux1~1_combout\ & ( (\inst4|Mux1~2_combout\) # (\inst4|Mux1~16_combout\) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(7) & ( \inst4|Mux1~1_combout\ & ( 
-- (\inst4|Mux1~16_combout\ & !\inst4|Mux1~2_combout\) ) ) ) # ( \inst2|altsyncram_component|auto_generated|q_a\(7) & ( !\inst4|Mux1~1_combout\ & ( ((\inst4|Mux1~16_combout\ & !\inst4|Mux1~0_combout\)) # (\inst4|Mux1~2_combout\) ) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(7) & ( !\inst4|Mux1~1_combout\ & ( (!\inst4|Mux1~0_combout\ & (\inst4|Mux1~16_combout\ & (!\inst4|Mux1~2_combout\))) # (\inst4|Mux1~0_combout\ & 
-- (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000001001111011100110111001101000100010001000111011101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~16_combout\,
	datab => \inst4|ALT_INV_Mux1~2_combout\,
	datac => \inst4|ALT_INV_Mux1~0_combout\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst4|ALT_INV_Mux1~1_combout\,
	combout => \inst4|Mux1~15_combout\);

-- Location: LABCELL_X10_Y3_N54
\inst4|Mux2~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux2~3_combout\ = ( \inst4|Add6~25_sumout\ & ( \inst2|altsyncram_component|auto_generated|q_a\(5) & ( (!\inst4|Mux1~5_combout\ & (((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)) # (\inst4|Add7~25_sumout\))) # 
-- (\inst4|Mux1~5_combout\ & (((\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)))) ) ) ) # ( !\inst4|Add6~25_sumout\ & ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(5) & ( (!\inst4|Mux1~5_combout\ & (((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)) # 
-- (\inst4|Add7~25_sumout\))) ) ) ) # ( \inst4|Add6~25_sumout\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(5) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & 
-- (((\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & (!\inst4|Mux1~5_combout\ & (\inst4|Add7~25_sumout\))) ) ) ) # ( !\inst4|Add6~25_sumout\ & ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(5) & ( (!\inst4|Mux1~5_combout\ & (\inst4|Add7~25_sumout\ & ((\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000100010000011110010001010100010001000101010111100100010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~5_combout\,
	datab => \inst4|ALT_INV_Add7~25_sumout\,
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datae => \inst4|ALT_INV_Add6~25_sumout\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	combout => \inst4|Mux2~3_combout\);

-- Location: MLABCELL_X8_Y4_N0
\inst4|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux2~0_combout\ = ( \M_CN~input_o\ & ( \inst4|Add1~25_sumout\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & !\inst4|Add0~25_sumout\) ) ) ) # ( !\M_CN~input_o\ & ( \inst4|Add1~25_sumout\ & ( 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ((\inst2|altsyncram_component|auto_generated|q_a\(6)) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\))) ) ) ) # ( \M_CN~input_o\ & ( !\inst4|Add1~25_sumout\ 
-- & ( (!\inst4|Add0~25_sumout\) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) ) ) ) # ( !\M_CN~input_o\ & ( !\inst4|Add1~25_sumout\ & ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & 
-- ((\inst2|altsyncram_component|auto_generated|q_a\(6)) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000011100000111111111110101010100000111000001111010101000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datad => \inst4|ALT_INV_Add0~25_sumout\,
	datae => \ALT_INV_M_CN~input_o\,
	dataf => \inst4|ALT_INV_Add1~25_sumout\,
	combout => \inst4|Mux2~0_combout\);

-- Location: LABCELL_X9_Y4_N24
\inst4|Mux2~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux2~1_combout\ = ( \inst4|Mux1~3_combout\ & ( \inst2|altsyncram_component|auto_generated|q_a\(6) & ( (!\inst4|Mux1~4_combout\ & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6))) # (\inst4|Mux1~4_combout\ & 
-- ((\inst4|Add2~25_sumout\))) ) ) ) # ( !\inst4|Mux1~3_combout\ & ( \inst2|altsyncram_component|auto_generated|q_a\(6) & ( (!\inst4|Mux1~4_combout\ & ((!\inst4|Mux2~0_combout\))) # (\inst4|Mux1~4_combout\ & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6))) ) ) ) # ( \inst4|Mux1~3_combout\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(6) & ( (!\inst4|Mux1~4_combout\ & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6))) # 
-- (\inst4|Mux1~4_combout\ & ((\inst4|Add2~25_sumout\))) ) ) ) # ( !\inst4|Mux1~3_combout\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(6) & ( (!\inst4|Mux2~0_combout\ & !\inst4|Mux1~4_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100000011000000010100000101111111001010110010101010000010101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datab => \inst4|ALT_INV_Mux2~0_combout\,
	datac => \inst4|ALT_INV_Mux1~4_combout\,
	datad => \inst4|ALT_INV_Add2~25_sumout\,
	datae => \inst4|ALT_INV_Mux1~3_combout\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	combout => \inst4|Mux2~1_combout\);

-- Location: LABCELL_X10_Y3_N12
\inst4|Mux2~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux2~2_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(6) & ( \inst4|Mux2~1_combout\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(6) & ( 
-- \inst4|Mux2~1_combout\ & ( ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(6) & ( !\inst4|Mux2~1_combout\ & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000100010000000000000000000000011011101110101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	dataf => \inst4|ALT_INV_Mux2~1_combout\,
	combout => \inst4|Mux2~2_combout\);

-- Location: LABCELL_X9_Y4_N18
\inst4|F9~12\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~12_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(6) & ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(6) & ( 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	combout => \inst4|F9~12_combout\);

-- Location: LABCELL_X10_Y4_N30
\inst4|Mux2~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux2~4_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(6) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)))) # 
-- (\M_CN~input_o\ & (\inst4|Add5~25_sumout\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6))))) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(6) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)))) # (\M_CN~input_o\ & 
-- (\inst4|Add5~25_sumout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001010001010000000101000101000000010110111110000001011011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \ALT_INV_M_CN~input_o\,
	datac => \inst4|ALT_INV_Add5~25_sumout\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	combout => \inst4|Mux2~4_combout\);

-- Location: LABCELL_X9_Y4_N0
\inst4|Mux2~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux2~5_combout\ = ( \inst4|Mux2~4_combout\ & ( \inst4|Mux1~6_combout\ & ( (!\inst4|Mux7~5_combout\ & (\inst4|Add3~25_sumout\)) # (\inst4|Mux7~5_combout\ & ((\inst4|Add4~25_sumout\))) ) ) ) # ( !\inst4|Mux2~4_combout\ & ( \inst4|Mux1~6_combout\ & ( 
-- (!\inst4|Mux7~5_combout\ & (\inst4|Add3~25_sumout\)) # (\inst4|Mux7~5_combout\ & ((\inst4|Add4~25_sumout\))) ) ) ) # ( \inst4|Mux2~4_combout\ & ( !\inst4|Mux1~6_combout\ & ( (!\inst4|F9~12_combout\) # (!\inst4|Mux7~5_combout\) ) ) ) # ( 
-- !\inst4|Mux2~4_combout\ & ( !\inst4|Mux1~6_combout\ & ( (!\inst4|F9~12_combout\ & \inst4|Mux7~5_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010101010111111111010101000110011000011110011001100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_F9~12_combout\,
	datab => \inst4|ALT_INV_Add3~25_sumout\,
	datac => \inst4|ALT_INV_Add4~25_sumout\,
	datad => \inst4|ALT_INV_Mux7~5_combout\,
	datae => \inst4|ALT_INV_Mux2~4_combout\,
	dataf => \inst4|ALT_INV_Mux1~6_combout\,
	combout => \inst4|Mux2~5_combout\);

-- Location: LABCELL_X10_Y3_N24
\inst4|Mux2~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux2~7_combout\ = ( !\inst4|Mux1~8_combout\ & ( (!\inst4|Mux1~7_combout\ & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # ((\inst2|altsyncram_component|auto_generated|q_a\(6))))) # (\inst4|Mux1~7_combout\ & 
-- ((((\inst4|Mux2~2_combout\))))) ) ) # ( \inst4|Mux1~8_combout\ & ( ((!\inst4|Mux1~7_combout\ & (\inst4|Mux2~3_combout\)) # (\inst4|Mux1~7_combout\ & (((\inst4|Mux2~5_combout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1000110010111111000011000000110010001100101111110011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datab => \inst4|ALT_INV_Mux1~7_combout\,
	datac => \inst4|ALT_INV_Mux2~3_combout\,
	datad => \inst4|ALT_INV_Mux2~2_combout\,
	datae => \inst4|ALT_INV_Mux1~8_combout\,
	dataf => \inst4|ALT_INV_Mux2~5_combout\,
	datag => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	combout => \inst4|Mux2~7_combout\);

-- Location: MLABCELL_X6_Y2_N42
\inst4|Mux2~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux2~6_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(6) & ( \inst4|Mux2~7_combout\ & ( ((!\inst4|Mux1~0_combout\) # (\inst4|Mux1~1_combout\)) # (\inst4|Mux1~2_combout\) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(6) & 
-- ( \inst4|Mux2~7_combout\ & ( (!\inst4|Mux1~0_combout\ & (((!\inst4|Mux1~2_combout\)))) # (\inst4|Mux1~0_combout\ & ((!\inst4|Mux1~1_combout\ & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6))) # (\inst4|Mux1~1_combout\ & 
-- ((!\inst4|Mux1~2_combout\))))) ) ) ) # ( \inst2|altsyncram_component|auto_generated|q_a\(6) & ( !\inst4|Mux2~7_combout\ & ( \inst4|Mux1~2_combout\ ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(6) & ( !\inst4|Mux2~7_combout\ & ( 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & (\inst4|Mux1~0_combout\ & !\inst4|Mux1~1_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000000001100110011001111000101110011001111001111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datab => \inst4|ALT_INV_Mux1~2_combout\,
	datac => \inst4|ALT_INV_Mux1~0_combout\,
	datad => \inst4|ALT_INV_Mux1~1_combout\,
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	dataf => \inst4|ALT_INV_Mux2~7_combout\,
	combout => \inst4|Mux2~6_combout\);

-- Location: MLABCELL_X8_Y3_N30
\inst4|F9~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~11_combout\ = ( !\inst2|altsyncram_component|auto_generated|q_a\(5) & ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) ) ) # ( \inst2|altsyncram_component|auto_generated|q_a\(5) & ( 
-- !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111111111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	combout => \inst4|F9~11_combout\);

-- Location: LABCELL_X10_Y4_N24
\inst4|Mux3~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux3~4_combout\ = ( \M_CN~input_o\ & ( \inst4|Add5~21_sumout\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # ((\inst2|altsyncram_component|auto_generated|q_a\(5) & 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))) ) ) ) # ( !\M_CN~input_o\ & ( \inst4|Add5~21_sumout\ & ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & 
-- ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # (\inst2|altsyncram_component|auto_generated|q_a\(5)))) ) ) ) # ( \M_CN~input_o\ & ( !\inst4|Add5~21_sumout\ & ( (\inst2|altsyncram_component|auto_generated|q_a\(5) & 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\)) ) ) ) # ( !\M_CN~input_o\ & ( !\inst4|Add5~21_sumout\ & ( 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # (\inst2|altsyncram_component|auto_generated|q_a\(5)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000100110001000000010000000100110001001100011111000111110001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datae => \ALT_INV_M_CN~input_o\,
	dataf => \inst4|ALT_INV_Add5~21_sumout\,
	combout => \inst4|Mux3~4_combout\);

-- Location: LABCELL_X7_Y3_N57
\inst4|Mux3~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux3~5_combout\ = ( \inst4|Mux1~6_combout\ & ( \inst4|Mux3~4_combout\ & ( (!\inst4|Mux7~5_combout\ & ((\inst4|Add3~21_sumout\))) # (\inst4|Mux7~5_combout\ & (\inst4|Add4~21_sumout\)) ) ) ) # ( !\inst4|Mux1~6_combout\ & ( \inst4|Mux3~4_combout\ & ( 
-- (!\inst4|F9~11_combout\) # (!\inst4|Mux7~5_combout\) ) ) ) # ( \inst4|Mux1~6_combout\ & ( !\inst4|Mux3~4_combout\ & ( (!\inst4|Mux7~5_combout\ & ((\inst4|Add3~21_sumout\))) # (\inst4|Mux7~5_combout\ & (\inst4|Add4~21_sumout\)) ) ) ) # ( 
-- !\inst4|Mux1~6_combout\ & ( !\inst4|Mux3~4_combout\ & ( (!\inst4|F9~11_combout\ & \inst4|Mux7~5_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001010000000111111001111111010111110100000001111110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_F9~11_combout\,
	datab => \inst4|ALT_INV_Add4~21_sumout\,
	datac => \inst4|ALT_INV_Mux7~5_combout\,
	datad => \inst4|ALT_INV_Add3~21_sumout\,
	datae => \inst4|ALT_INV_Mux1~6_combout\,
	dataf => \inst4|ALT_INV_Mux3~4_combout\,
	combout => \inst4|Mux3~5_combout\);

-- Location: LABCELL_X9_Y3_N54
\inst4|Mux3~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux3~3_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( \inst4|Add7~21_sumout\ & ( (!\inst4|Mux1~5_combout\) # ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & (\inst4|Add6~21_sumout\ & 
-- \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( \inst4|Add7~21_sumout\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\inst4|Mux1~5_combout\) # (\inst4|Add6~21_sumout\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & (((!\inst4|Mux1~5_combout\)))) ) ) ) # 
-- ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( !\inst4|Add7~21_sumout\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & 
-- ((!\inst4|Mux1~5_combout\))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (\inst4|Add6~21_sumout\)))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( !\inst4|Add7~21_sumout\ & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & (\inst4|Add6~21_sumout\ & \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000100010101000000010001001010000111100101111000011110010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datab => \inst4|ALT_INV_Add6~21_sumout\,
	datac => \inst4|ALT_INV_Mux1~5_combout\,
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	dataf => \inst4|ALT_INV_Add7~21_sumout\,
	combout => \inst4|Mux3~3_combout\);

-- Location: MLABCELL_X8_Y4_N6
\inst4|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux3~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(5) & ( \inst4|Add0~21_sumout\ & ( (!\M_CN~input_o\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) # (\M_CN~input_o\ & 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (!\inst4|Add1~21_sumout\))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(5) & ( \inst4|Add0~21_sumout\ & ( 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) # (\M_CN~input_o\ & (!\inst4|Add1~21_sumout\)))) ) ) ) # ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(5) & ( !\inst4|Add0~21_sumout\ & ( (!\M_CN~input_o\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) # (\M_CN~input_o\ & 
-- ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # ((!\inst4|Add1~21_sumout\)))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(5) & ( !\inst4|Add0~21_sumout\ & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\M_CN~input_o\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & 
-- ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) # (\M_CN~input_o\ & (!\inst4|Add1~21_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010111101110000011111110111000000101010001000000111101000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \inst4|ALT_INV_Add1~21_sumout\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \ALT_INV_M_CN~input_o\,
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	dataf => \inst4|ALT_INV_Add0~21_sumout\,
	combout => \inst4|Mux3~0_combout\);

-- Location: MLABCELL_X8_Y3_N42
\inst4|Mux3~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux3~1_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(5) & ( \inst4|Add2~21_sumout\ & ( (!\inst4|Mux1~3_combout\ & ((!\inst4|Mux1~4_combout\ & ((!\inst4|Mux3~0_combout\))) # (\inst4|Mux1~4_combout\ & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) # (\inst4|Mux1~3_combout\ & (((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))) # (\inst4|Mux1~4_combout\))) ) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(5) & ( \inst4|Add2~21_sumout\ & ( (!\inst4|Mux1~3_combout\ & (!\inst4|Mux1~4_combout\ & ((!\inst4|Mux3~0_combout\)))) # (\inst4|Mux1~3_combout\ & 
-- (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))) # (\inst4|Mux1~4_combout\))) ) ) ) # ( \inst2|altsyncram_component|auto_generated|q_a\(5) & ( !\inst4|Add2~21_sumout\ & ( (!\inst4|Mux1~3_combout\ & ((!\inst4|Mux1~4_combout\ & 
-- ((!\inst4|Mux3~0_combout\))) # (\inst4|Mux1~4_combout\ & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) # (\inst4|Mux1~3_combout\ & (!\inst4|Mux1~4_combout\ & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) ) ) ) 
-- # ( !\inst2|altsyncram_component|auto_generated|q_a\(5) & ( !\inst4|Add2~21_sumout\ & ( (!\inst4|Mux1~4_combout\ & ((!\inst4|Mux1~3_combout\ & ((!\inst4|Mux3~0_combout\))) # (\inst4|Mux1~3_combout\ & 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000110000000100111010000110000010011101000101011111100101110001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~3_combout\,
	datab => \inst4|ALT_INV_Mux1~4_combout\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \inst4|ALT_INV_Mux3~0_combout\,
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	dataf => \inst4|ALT_INV_Add2~21_sumout\,
	combout => \inst4|Mux3~1_combout\);

-- Location: MLABCELL_X8_Y3_N48
\inst4|Mux3~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux3~2_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(5) & ( \inst4|Mux3~1_combout\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(5) & ( 
-- \inst4|Mux3~1_combout\ & ( ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(5) & ( !\inst4|Mux3~1_combout\ & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010100000000000000000000000000010101000111111110000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	dataf => \inst4|ALT_INV_Mux3~1_combout\,
	combout => \inst4|Mux3~2_combout\);

-- Location: MLABCELL_X8_Y3_N18
\inst4|Mux3~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux3~7_combout\ = ( !\inst4|Mux1~8_combout\ & ( ((!\inst4|Mux1~7_combout\ & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # ((\inst2|altsyncram_component|auto_generated|q_a\(5))))) # (\inst4|Mux1~7_combout\ & 
-- (((\inst4|Mux3~2_combout\))))) ) ) # ( \inst4|Mux1~8_combout\ & ( ((!\inst4|Mux1~7_combout\ & (((\inst4|Mux3~3_combout\)))) # (\inst4|Mux1~7_combout\ & (\inst4|Mux3~5_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1010111100000000000011110011001110101111111111110000111100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datab => \inst4|ALT_INV_Mux3~5_combout\,
	datac => \inst4|ALT_INV_Mux3~3_combout\,
	datad => \inst4|ALT_INV_Mux1~7_combout\,
	datae => \inst4|ALT_INV_Mux1~8_combout\,
	dataf => \inst4|ALT_INV_Mux3~2_combout\,
	datag => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	combout => \inst4|Mux3~7_combout\);

-- Location: MLABCELL_X6_Y2_N12
\inst4|Mux3~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux3~6_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ( \inst4|Mux1~0_combout\ & ( (!\inst4|Mux1~2_combout\ & ((!\inst4|Mux1~1_combout\ & ((!\inst2|altsyncram_component|auto_generated|q_a\(5)))) # 
-- (\inst4|Mux1~1_combout\ & (\inst4|Mux3~7_combout\)))) # (\inst4|Mux1~2_combout\ & (((!\inst4|Mux1~1_combout\) # (\inst2|altsyncram_component|auto_generated|q_a\(5))))) ) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ( 
-- \inst4|Mux1~0_combout\ & ( (!\inst4|Mux1~2_combout\ & (\inst4|Mux3~7_combout\ & ((\inst4|Mux1~1_combout\)))) # (\inst4|Mux1~2_combout\ & (((\inst2|altsyncram_component|auto_generated|q_a\(5))))) ) ) ) # ( 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ( !\inst4|Mux1~0_combout\ & ( (!\inst4|Mux1~2_combout\ & (\inst4|Mux3~7_combout\)) # (\inst4|Mux1~2_combout\ & ((\inst2|altsyncram_component|auto_generated|q_a\(5)))) ) ) ) # ( 
-- !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ( !\inst4|Mux1~0_combout\ & ( (!\inst4|Mux1~2_combout\ & (\inst4|Mux3~7_combout\)) # (\inst4|Mux1~2_combout\ & ((\inst2|altsyncram_component|auto_generated|q_a\(5)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100011101000111010001110100011100000011010001111111001101000111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux3~7_combout\,
	datab => \inst4|ALT_INV_Mux1~2_combout\,
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datad => \inst4|ALT_INV_Mux1~1_combout\,
	datae => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst4|ALT_INV_Mux1~0_combout\,
	combout => \inst4|Mux3~6_combout\);

-- Location: MLABCELL_X8_Y2_N12
\inst4|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux4~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( \inst4|Add0~17_sumout\ & ( (!\M_CN~input_o\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))) # (\M_CN~input_o\ & 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (!\inst4|Add1~17_sumout\))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( \inst4|Add0~17_sumout\ & ( 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)))) # (\M_CN~input_o\ & (!\inst4|Add1~17_sumout\)))) ) ) ) # ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(4) & ( !\inst4|Add0~17_sumout\ & ( (!\M_CN~input_o\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))) # (\M_CN~input_o\ & 
-- ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # ((!\inst4|Add1~17_sumout\)))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( !\inst4|Add0~17_sumout\ & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\M_CN~input_o\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & 
-- ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)))) # (\M_CN~input_o\ & (!\inst4|Add1~17_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111001011110000011101111111000000100010101000000010011110100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \inst4|ALT_INV_Add1~17_sumout\,
	datac => \ALT_INV_M_CN~input_o\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	dataf => \inst4|ALT_INV_Add0~17_sumout\,
	combout => \inst4|Mux4~0_combout\);

-- Location: MLABCELL_X8_Y2_N42
\inst4|Mux4~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux4~1_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( \inst4|Add2~17_sumout\ & ( (!\inst4|Mux1~3_combout\ & ((!\inst4|Mux1~4_combout\ & (!\inst4|Mux4~0_combout\)) # (\inst4|Mux1~4_combout\ & 
-- ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)))))) # (\inst4|Mux1~3_combout\ & (((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst4|Mux1~4_combout\)))) ) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( \inst4|Add2~17_sumout\ & ( (!\inst4|Mux1~3_combout\ & (!\inst4|Mux4~0_combout\ & (!\inst4|Mux1~4_combout\))) # (\inst4|Mux1~3_combout\ & 
-- (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst4|Mux1~4_combout\)))) ) ) ) # ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( !\inst4|Add2~17_sumout\ & ( (!\inst4|Mux1~3_combout\ & ((!\inst4|Mux1~4_combout\ & 
-- (!\inst4|Mux4~0_combout\)) # (\inst4|Mux1~4_combout\ & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)))))) # (\inst4|Mux1~3_combout\ & (((!\inst4|Mux1~4_combout\ & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))) ) ) 
-- ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( !\inst4|Add2~17_sumout\ & ( (!\inst4|Mux1~4_combout\ & ((!\inst4|Mux1~3_combout\ & (!\inst4|Mux4~0_combout\)) # (\inst4|Mux1~3_combout\ & 
-- ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000011010000110110101000000010000101110101011101111110000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~3_combout\,
	datab => \inst4|ALT_INV_Mux4~0_combout\,
	datac => \inst4|ALT_INV_Mux1~4_combout\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	dataf => \inst4|ALT_INV_Add2~17_sumout\,
	combout => \inst4|Mux4~1_combout\);

-- Location: MLABCELL_X8_Y2_N36
\inst4|Mux4~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux4~2_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( \inst4|Mux4~1_combout\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( 
-- \inst4|Mux4~1_combout\ & ( ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( !\inst4|Mux4~1_combout\ & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100000010000000000000000000000011001111100011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	dataf => \inst4|ALT_INV_Mux4~1_combout\,
	combout => \inst4|Mux4~2_combout\);

-- Location: LABCELL_X10_Y3_N42
\inst4|Mux4~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux4~3_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(3) & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst4|Mux1~5_combout\ & (((\inst4|Add6~17_sumout\ & 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)) # (\inst4|Add7~17_sumout\))) # (\inst4|Mux1~5_combout\ & (\inst4|Add6~17_sumout\ & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)))) ) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(3) & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst4|Mux1~5_combout\ & (((\inst4|Add6~17_sumout\ & 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)) # (\inst4|Add7~17_sumout\))) # (\inst4|Mux1~5_combout\ & (\inst4|Add6~17_sumout\ & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)))) ) ) ) # ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(3) & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst4|Mux1~5_combout\ & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\) # 
-- (\inst4|Add7~17_sumout\))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(3) & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst4|Mux1~5_combout\ & (\inst4|Add7~17_sumout\ & 
-- \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001010101010100000101000111011000010100011101100001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~5_combout\,
	datab => \inst4|ALT_INV_Add6~17_sumout\,
	datac => \inst4|ALT_INV_Add7~17_sumout\,
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	combout => \inst4|Mux4~3_combout\);

-- Location: MLABCELL_X8_Y2_N30
\inst4|F9~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~10_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ( !\inst2|altsyncram_component|auto_generated|q_a\(4) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(4) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	combout => \inst4|F9~10_combout\);

-- Location: LABCELL_X10_Y4_N48
\inst4|Mux4~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux4~4_combout\ = ( \inst4|Add5~17_sumout\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4))) # (\M_CN~input_o\))) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst2|altsyncram_component|auto_generated|q_a\(4))))) ) ) # ( !\inst4|Add5~17_sumout\ & ( 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (!\M_CN~input_o\)) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & 
-- ((\inst2|altsyncram_component|auto_generated|q_a\(4)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000001101000010000000110100101010001011110010101000101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \ALT_INV_M_CN~input_o\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	dataf => \inst4|ALT_INV_Add5~17_sumout\,
	combout => \inst4|Mux4~4_combout\);

-- Location: MLABCELL_X8_Y2_N18
\inst4|Mux4~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux4~5_combout\ = ( \inst4|Mux1~6_combout\ & ( \inst4|Add3~17_sumout\ & ( (!\inst4|Mux7~5_combout\) # (\inst4|Add4~17_sumout\) ) ) ) # ( !\inst4|Mux1~6_combout\ & ( \inst4|Add3~17_sumout\ & ( (!\inst4|Mux7~5_combout\ & ((\inst4|Mux4~4_combout\))) # 
-- (\inst4|Mux7~5_combout\ & (!\inst4|F9~10_combout\)) ) ) ) # ( \inst4|Mux1~6_combout\ & ( !\inst4|Add3~17_sumout\ & ( (\inst4|Add4~17_sumout\ & \inst4|Mux7~5_combout\) ) ) ) # ( !\inst4|Mux1~6_combout\ & ( !\inst4|Add3~17_sumout\ & ( 
-- (!\inst4|Mux7~5_combout\ & ((\inst4|Mux4~4_combout\))) # (\inst4|Mux7~5_combout\ & (!\inst4|F9~10_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110011111100000001010000010100001100111111001111010111110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Add4~17_sumout\,
	datab => \inst4|ALT_INV_F9~10_combout\,
	datac => \inst4|ALT_INV_Mux7~5_combout\,
	datad => \inst4|ALT_INV_Mux4~4_combout\,
	datae => \inst4|ALT_INV_Mux1~6_combout\,
	dataf => \inst4|ALT_INV_Add3~17_sumout\,
	combout => \inst4|Mux4~5_combout\);

-- Location: MLABCELL_X8_Y2_N24
\inst4|Mux4~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux4~7_combout\ = ( !\inst4|Mux1~8_combout\ & ( (!\inst4|Mux1~7_combout\ & ((((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4))) # (\inst2|altsyncram_component|auto_generated|q_a\(4))))) # (\inst4|Mux1~7_combout\ & 
-- (\inst4|Mux4~2_combout\)) ) ) # ( \inst4|Mux1~8_combout\ & ( ((!\inst4|Mux1~7_combout\ & (\inst4|Mux4~3_combout\)) # (\inst4|Mux1~7_combout\ & (((\inst4|Mux4~5_combout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1101110100011101000011000000110011011101000111010011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux4~2_combout\,
	datab => \inst4|ALT_INV_Mux1~7_combout\,
	datac => \inst4|ALT_INV_Mux4~3_combout\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datae => \inst4|ALT_INV_Mux1~8_combout\,
	dataf => \inst4|ALT_INV_Mux4~5_combout\,
	datag => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	combout => \inst4|Mux4~7_combout\);

-- Location: MLABCELL_X6_Y2_N54
\inst4|Mux4~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux4~6_combout\ = ( \inst4|Mux1~0_combout\ & ( \inst2|altsyncram_component|auto_generated|q_a\(4) & ( ((\inst4|Mux1~1_combout\ & \inst4|Mux4~7_combout\)) # (\inst4|Mux1~2_combout\) ) ) ) # ( !\inst4|Mux1~0_combout\ & ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(4) & ( (\inst4|Mux1~2_combout\) # (\inst4|Mux4~7_combout\) ) ) ) # ( \inst4|Mux1~0_combout\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( (!\inst4|Mux1~1_combout\ & 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4))) # (\inst4|Mux1~1_combout\ & (((\inst4|Mux4~7_combout\ & !\inst4|Mux1~2_combout\)))) ) ) ) # ( !\inst4|Mux1~0_combout\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(4) & ( 
-- (\inst4|Mux4~7_combout\ & !\inst4|Mux1~2_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100000000010001110100010000001111111111110000001111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datab => \inst4|ALT_INV_Mux1~1_combout\,
	datac => \inst4|ALT_INV_Mux4~7_combout\,
	datad => \inst4|ALT_INV_Mux1~2_combout\,
	datae => \inst4|ALT_INV_Mux1~0_combout\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	combout => \inst4|Mux4~6_combout\);

-- Location: LABCELL_X9_Y5_N3
\inst4|F9~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~9_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( !\inst2|altsyncram_component|auto_generated|q_a\(3) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(3) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	combout => \inst4|F9~9_combout\);

-- Location: LABCELL_X10_Y4_N33
\inst4|Mux5~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux5~4_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(3) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)))) # 
-- (\M_CN~input_o\ & (\inst4|Add5~13_sumout\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3))))) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(3) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)))) # (\M_CN~input_o\ & 
-- (\inst4|Add5~13_sumout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001010001010000000101000101000000010110111110000001011011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \ALT_INV_M_CN~input_o\,
	datac => \inst4|ALT_INV_Add5~13_sumout\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	combout => \inst4|Mux5~4_combout\);

-- Location: LABCELL_X9_Y4_N6
\inst4|Mux5~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux5~5_combout\ = ( \inst4|Add3~13_sumout\ & ( \inst4|Mux5~4_combout\ & ( (!\inst4|Mux7~5_combout\) # ((!\inst4|Mux1~6_combout\ & ((!\inst4|F9~9_combout\))) # (\inst4|Mux1~6_combout\ & (\inst4|Add4~13_sumout\))) ) ) ) # ( !\inst4|Add3~13_sumout\ & 
-- ( \inst4|Mux5~4_combout\ & ( (!\inst4|Mux1~6_combout\ & (((!\inst4|F9~9_combout\) # (!\inst4|Mux7~5_combout\)))) # (\inst4|Mux1~6_combout\ & (\inst4|Add4~13_sumout\ & ((\inst4|Mux7~5_combout\)))) ) ) ) # ( \inst4|Add3~13_sumout\ & ( 
-- !\inst4|Mux5~4_combout\ & ( (!\inst4|Mux1~6_combout\ & (((!\inst4|F9~9_combout\ & \inst4|Mux7~5_combout\)))) # (\inst4|Mux1~6_combout\ & (((!\inst4|Mux7~5_combout\)) # (\inst4|Add4~13_sumout\))) ) ) ) # ( !\inst4|Add3~13_sumout\ & ( 
-- !\inst4|Mux5~4_combout\ & ( (\inst4|Mux7~5_combout\ & ((!\inst4|Mux1~6_combout\ & ((!\inst4|F9~9_combout\))) # (\inst4|Mux1~6_combout\ & (\inst4|Add4~13_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010110001010101011011000110101010101100011111111110110001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~6_combout\,
	datab => \inst4|ALT_INV_Add4~13_sumout\,
	datac => \inst4|ALT_INV_F9~9_combout\,
	datad => \inst4|ALT_INV_Mux7~5_combout\,
	datae => \inst4|ALT_INV_Add3~13_sumout\,
	dataf => \inst4|ALT_INV_Mux5~4_combout\,
	combout => \inst4|Mux5~5_combout\);

-- Location: LABCELL_X10_Y3_N48
\inst4|Mux5~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux5~3_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(2) & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst4|Mux1~5_combout\ & 
-- (((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & \inst4|Add6~13_sumout\)) # (\inst4|Add7~13_sumout\))) # (\inst4|Mux1~5_combout\ & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & 
-- (\inst4|Add6~13_sumout\))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(2) & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst4|Mux1~5_combout\ & 
-- (((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & \inst4|Add6~13_sumout\)) # (\inst4|Add7~13_sumout\))) # (\inst4|Mux1~5_combout\ & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & 
-- (\inst4|Add6~13_sumout\))) ) ) ) # ( \inst2|altsyncram_component|auto_generated|q_a\(2) & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst4|Mux1~5_combout\ & 
-- ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\) # (\inst4|Add7~13_sumout\))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(2) & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( 
-- (!\inst4|Mux1~5_combout\ & (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & \inst4|Add7~13_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000100010100010001010101000001100101011100000110010101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~5_combout\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datac => \inst4|ALT_INV_Add6~13_sumout\,
	datad => \inst4|ALT_INV_Add7~13_sumout\,
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	combout => \inst4|Mux5~3_combout\);

-- Location: MLABCELL_X8_Y4_N24
\inst4|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux5~0_combout\ = ( \M_CN~input_o\ & ( \inst2|altsyncram_component|auto_generated|q_a\(3) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (!\inst4|Add0~13_sumout\)) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\inst4|Add1~13_sumout\))) ) ) ) # ( !\M_CN~input_o\ & ( \inst2|altsyncram_component|auto_generated|q_a\(3) & ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) 
-- ) ) ) # ( \M_CN~input_o\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(3) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (!\inst4|Add0~13_sumout\)) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\inst4|Add1~13_sumout\))) ) ) ) # ( !\M_CN~input_o\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(3) & ( 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101110111011000100000001111000011111101110110001000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \inst4|ALT_INV_Add0~13_sumout\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datad => \inst4|ALT_INV_Add1~13_sumout\,
	datae => \ALT_INV_M_CN~input_o\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	combout => \inst4|Mux5~0_combout\);

-- Location: LABCELL_X9_Y5_N6
\inst4|Mux5~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux5~1_combout\ = ( \inst4|Mux1~4_combout\ & ( \inst4|Add2~13_sumout\ & ( ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst2|altsyncram_component|auto_generated|q_a\(3))) # (\inst4|Mux1~3_combout\) ) ) ) # ( 
-- !\inst4|Mux1~4_combout\ & ( \inst4|Add2~13_sumout\ & ( (!\inst4|Mux1~3_combout\ & (!\inst4|Mux5~0_combout\)) # (\inst4|Mux1~3_combout\ & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) $ 
-- (!\inst2|altsyncram_component|auto_generated|q_a\(3))))) ) ) ) # ( \inst4|Mux1~4_combout\ & ( !\inst4|Add2~13_sumout\ & ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (!\inst4|Mux1~3_combout\ & 
-- \inst2|altsyncram_component|auto_generated|q_a\(3))) ) ) ) # ( !\inst4|Mux1~4_combout\ & ( !\inst4|Add2~13_sumout\ & ( (!\inst4|Mux1~3_combout\ & (!\inst4|Mux5~0_combout\)) # (\inst4|Mux1~3_combout\ & 
-- ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) $ (!\inst2|altsyncram_component|auto_generated|q_a\(3))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010001110101100000000001100000010100011101011000000111111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux5~0_combout\,
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst4|ALT_INV_Mux1~3_combout\,
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datae => \inst4|ALT_INV_Mux1~4_combout\,
	dataf => \inst4|ALT_INV_Add2~13_sumout\,
	combout => \inst4|Mux5~1_combout\);

-- Location: LABCELL_X10_Y3_N6
\inst4|Mux5~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux5~2_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(3) & ( \inst4|Mux5~1_combout\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(3) & ( 
-- \inst4|Mux5~1_combout\ & ( ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3))))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(3) & ( !\inst4|Mux5~1_combout\ & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100000010000000000000000000000011001111100011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	dataf => \inst4|ALT_INV_Mux5~1_combout\,
	combout => \inst4|Mux5~2_combout\);

-- Location: LABCELL_X10_Y3_N18
\inst4|Mux5~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux5~7_combout\ = ( !\inst4|Mux1~8_combout\ & ( (!\inst4|Mux1~7_combout\ & ((((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3))) # (\inst2|altsyncram_component|auto_generated|q_a\(3))))) # (\inst4|Mux1~7_combout\ & 
-- ((((\inst4|Mux5~2_combout\))))) ) ) # ( \inst4|Mux1~8_combout\ & ( (!\inst4|Mux1~7_combout\ & (((\inst4|Mux5~3_combout\)))) # (\inst4|Mux1~7_combout\ & (\inst4|Mux5~5_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1010101000001010000110110001101111111111010111110001101100011011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~7_combout\,
	datab => \inst4|ALT_INV_Mux5~5_combout\,
	datac => \inst4|ALT_INV_Mux5~3_combout\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datae => \inst4|ALT_INV_Mux1~8_combout\,
	dataf => \inst4|ALT_INV_Mux5~2_combout\,
	datag => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	combout => \inst4|Mux5~7_combout\);

-- Location: MLABCELL_X6_Y2_N24
\inst4|Mux5~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux5~6_combout\ = ( \inst4|Mux5~7_combout\ & ( \inst4|Mux1~2_combout\ & ( ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (!\inst4|Mux1~1_combout\ & \inst4|Mux1~0_combout\))) # (\inst2|altsyncram_component|auto_generated|q_a\(3)) 
-- ) ) ) # ( !\inst4|Mux5~7_combout\ & ( \inst4|Mux1~2_combout\ & ( ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (!\inst4|Mux1~1_combout\ & \inst4|Mux1~0_combout\))) # (\inst2|altsyncram_component|auto_generated|q_a\(3)) ) ) ) # ( 
-- \inst4|Mux5~7_combout\ & ( !\inst4|Mux1~2_combout\ & ( ((!\inst4|Mux1~0_combout\) # ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & !\inst2|altsyncram_component|auto_generated|q_a\(3)))) # (\inst4|Mux1~1_combout\) ) ) ) # ( 
-- !\inst4|Mux5~7_combout\ & ( !\inst4|Mux1~2_combout\ & ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (!\inst4|Mux1~1_combout\ & (!\inst2|altsyncram_component|auto_generated|q_a\(3) & \inst4|Mux1~0_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001000000111111110111001100001111010011110000111101001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datab => \inst4|ALT_INV_Mux1~1_combout\,
	datac => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datad => \inst4|ALT_INV_Mux1~0_combout\,
	datae => \inst4|ALT_INV_Mux5~7_combout\,
	dataf => \inst4|ALT_INV_Mux1~2_combout\,
	combout => \inst4|Mux5~6_combout\);

-- Location: LABCELL_X10_Y4_N57
\inst4|Mux6~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux6~4_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(2) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)))) # 
-- (\M_CN~input_o\ & (\inst4|Add5~9_sumout\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))))) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(2) 
-- & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)))) # (\M_CN~input_o\ & (\inst4|Add5~9_sumout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001010001010000000101000101000000010110111110000001011011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \ALT_INV_M_CN~input_o\,
	datac => \inst4|ALT_INV_Add5~9_sumout\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	combout => \inst4|Mux6~4_combout\);

-- Location: LABCELL_X10_Y4_N36
\inst4|F9~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~8_combout\ = !\inst2|altsyncram_component|auto_generated|q_a\(2) $ (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011110000111100001111000011110000111100001111000011110000111100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	combout => \inst4|F9~8_combout\);

-- Location: LABCELL_X9_Y4_N12
\inst4|Mux6~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux6~5_combout\ = ( \inst4|Add4~9_sumout\ & ( \inst4|Mux1~6_combout\ & ( (\inst4|Mux7~5_combout\) # (\inst4|Add3~9_sumout\) ) ) ) # ( !\inst4|Add4~9_sumout\ & ( \inst4|Mux1~6_combout\ & ( (\inst4|Add3~9_sumout\ & !\inst4|Mux7~5_combout\) ) ) ) # ( 
-- \inst4|Add4~9_sumout\ & ( !\inst4|Mux1~6_combout\ & ( (!\inst4|Mux7~5_combout\ & (\inst4|Mux6~4_combout\)) # (\inst4|Mux7~5_combout\ & ((!\inst4|F9~8_combout\))) ) ) ) # ( !\inst4|Add4~9_sumout\ & ( !\inst4|Mux1~6_combout\ & ( (!\inst4|Mux7~5_combout\ & 
-- (\inst4|Mux6~4_combout\)) # (\inst4|Mux7~5_combout\ & ((!\inst4|F9~8_combout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010111001100010101011100110000001111000000000000111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux6~4_combout\,
	datab => \inst4|ALT_INV_F9~8_combout\,
	datac => \inst4|ALT_INV_Add3~9_sumout\,
	datad => \inst4|ALT_INV_Mux7~5_combout\,
	datae => \inst4|ALT_INV_Add4~9_sumout\,
	dataf => \inst4|ALT_INV_Mux1~6_combout\,
	combout => \inst4|Mux6~5_combout\);

-- Location: LABCELL_X10_Y3_N36
\inst4|Mux6~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux6~3_combout\ = ( \inst4|Add7~9_sumout\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst4|Mux1~5_combout\) # ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & 
-- \inst4|Add6~9_sumout\)) ) ) ) # ( !\inst4|Add7~9_sumout\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & \inst4|Add6~9_sumout\) ) ) ) # ( 
-- \inst4|Add7~9_sumout\ & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst4|Mux1~5_combout\ & ((\inst2|altsyncram_component|auto_generated|q_a\(1)) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\))) ) ) ) # ( !\inst4|Add7~9_sumout\ & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst4|Mux1~5_combout\ & 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & \inst2|altsyncram_component|auto_generated|q_a\(1))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010001000001000101010101000001100000011001010111010101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~5_combout\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datac => \inst4|ALT_INV_Add6~9_sumout\,
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datae => \inst4|ALT_INV_Add7~9_sumout\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	combout => \inst4|Mux6~3_combout\);

-- Location: MLABCELL_X8_Y4_N54
\inst4|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux6~0_combout\ = ( \inst4|Add1~9_sumout\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & !\M_CN~input_o\) ) ) ) # ( !\inst4|Add1~9_sumout\ & ( 
-- \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (\M_CN~input_o\) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) ) ) # ( \inst4|Add1~9_sumout\ & ( 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\M_CN~input_o\ & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & (\inst2|altsyncram_component|auto_generated|q_a\(2)))) # (\M_CN~input_o\ & 
-- (((!\inst4|Add0~9_sumout\)))) ) ) ) # ( !\inst4|Add1~9_sumout\ & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\M_CN~input_o\ & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & 
-- (\inst2|altsyncram_component|auto_generated|q_a\(2)))) # (\M_CN~input_o\ & (((!\inst4|Add0~9_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000111110000000100011111000001010101111111110101010100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datab => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datac => \inst4|ALT_INV_Add0~9_sumout\,
	datad => \ALT_INV_M_CN~input_o\,
	datae => \inst4|ALT_INV_Add1~9_sumout\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	combout => \inst4|Mux6~0_combout\);

-- Location: LABCELL_X9_Y5_N24
\inst4|Mux6~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux6~1_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(2) & ( \inst4|Mux6~0_combout\ & ( (!\inst4|Mux1~3_combout\ & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & (\inst4|Mux1~4_combout\))) # (\inst4|Mux1~3_combout\ 
-- & ((!\inst4|Mux1~4_combout\ & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))) # (\inst4|Mux1~4_combout\ & ((\inst4|Add2~9_sumout\))))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(2) & ( \inst4|Mux6~0_combout\ & ( 
-- (\inst4|Mux1~3_combout\ & ((!\inst4|Mux1~4_combout\ & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))) # (\inst4|Mux1~4_combout\ & ((\inst4|Add2~9_sumout\))))) ) ) ) # ( \inst2|altsyncram_component|auto_generated|q_a\(2) & ( 
-- !\inst4|Mux6~0_combout\ & ( (!\inst4|Mux1~3_combout\ & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # ((!\inst4|Mux1~4_combout\)))) # (\inst4|Mux1~3_combout\ & ((!\inst4|Mux1~4_combout\ & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))) # (\inst4|Mux1~4_combout\ & ((\inst4|Add2~9_sumout\))))) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(2) & ( !\inst4|Mux6~0_combout\ & ( (!\inst4|Mux1~3_combout\ & 
-- (((!\inst4|Mux1~4_combout\)))) # (\inst4|Mux1~3_combout\ & ((!\inst4|Mux1~4_combout\ & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))) # (\inst4|Mux1~4_combout\ & ((\inst4|Add2~9_sumout\))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011000010110101111010001110110100010000000101010100100001001101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~3_combout\,
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \inst4|ALT_INV_Mux1~4_combout\,
	datad => \inst4|ALT_INV_Add2~9_sumout\,
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	dataf => \inst4|ALT_INV_Mux6~0_combout\,
	combout => \inst4|Mux6~1_combout\);

-- Location: LABCELL_X10_Y3_N30
\inst4|Mux6~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux6~2_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(2) & ( \inst4|Mux6~1_combout\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(2) & ( 
-- \inst4|Mux6~1_combout\ & ( ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)) ) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(2) & ( !\inst4|Mux6~1_combout\ & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100000010000000000000000000000011001111100011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	dataf => \inst4|ALT_INV_Mux6~1_combout\,
	combout => \inst4|Mux6~2_combout\);

-- Location: LABCELL_X10_Y3_N0
\inst4|Mux6~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux6~7_combout\ = ( !\inst4|Mux1~8_combout\ & ( ((!\inst4|Mux1~7_combout\ & (((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))) # (\inst2|altsyncram_component|auto_generated|q_a\(2)))) # (\inst4|Mux1~7_combout\ & 
-- (((\inst4|Mux6~2_combout\))))) ) ) # ( \inst4|Mux1~8_combout\ & ( (!\inst4|Mux1~7_combout\ & (((\inst4|Mux6~3_combout\)))) # (\inst4|Mux1~7_combout\ & (\inst4|Mux6~5_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1100110000001100000111010001110111111111001111110001110100011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux6~5_combout\,
	datab => \inst4|ALT_INV_Mux1~7_combout\,
	datac => \inst4|ALT_INV_Mux6~3_combout\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datae => \inst4|ALT_INV_Mux1~8_combout\,
	dataf => \inst4|ALT_INV_Mux6~2_combout\,
	datag => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	combout => \inst4|Mux6~7_combout\);

-- Location: MLABCELL_X6_Y2_N6
\inst4|Mux6~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux6~6_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( \inst2|altsyncram_component|auto_generated|q_a\(2) & ( ((\inst4|Mux6~7_combout\ & ((!\inst4|Mux1~0_combout\) # (\inst4|Mux1~1_combout\)))) # 
-- (\inst4|Mux1~2_combout\) ) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( \inst2|altsyncram_component|auto_generated|q_a\(2) & ( ((\inst4|Mux6~7_combout\ & ((!\inst4|Mux1~0_combout\) # (\inst4|Mux1~1_combout\)))) # 
-- (\inst4|Mux1~2_combout\) ) ) ) # ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( !\inst2|altsyncram_component|auto_generated|q_a\(2) & ( (!\inst4|Mux6~7_combout\ & (((\inst4|Mux1~0_combout\ & !\inst4|Mux1~1_combout\)))) # 
-- (\inst4|Mux6~7_combout\ & ((!\inst4|Mux1~2_combout\) # ((\inst4|Mux1~0_combout\ & !\inst4|Mux1~1_combout\)))) ) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( !\inst2|altsyncram_component|auto_generated|q_a\(2) & ( 
-- (\inst4|Mux6~7_combout\ & (!\inst4|Mux1~2_combout\ & ((!\inst4|Mux1~0_combout\) # (\inst4|Mux1~1_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000001000100010011110100010001110011011101110111001101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux6~7_combout\,
	datab => \inst4|ALT_INV_Mux1~2_combout\,
	datac => \inst4|ALT_INV_Mux1~0_combout\,
	datad => \inst4|ALT_INV_Mux1~1_combout\,
	datae => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	combout => \inst4|Mux6~6_combout\);

-- Location: LABCELL_X7_Y2_N0
\inst4|F9~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~2_combout\ = (!\M_CN~input_o\ & (\inst4|Add4~1_sumout\)) # (\M_CN~input_o\ & ((\inst4|Add2~1_sumout\)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101001011111000010100101111100001010010111110000101001011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_M_CN~input_o\,
	datac => \inst4|ALT_INV_Add4~1_sumout\,
	datad => \inst4|ALT_INV_Add2~1_sumout\,
	combout => \inst4|F9~2_combout\);

-- Location: MLABCELL_X8_Y2_N9
\inst4|F9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~0_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(0) & ( \M_CN~input_o\ ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(0) & ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) $ (!\M_CN~input_o\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010110101010010101011010101000000000111111110000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datad => \ALT_INV_M_CN~input_o\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	combout => \inst4|F9~0_combout\);

-- Location: MLABCELL_X8_Y2_N54
\inst4|F9~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~3_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(0) & ( (\M_CN~input_o\ & !\inst4|Add7~1_sumout\) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(0) & ( (!\M_CN~input_o\ & 
-- ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)))) # (\M_CN~input_o\ & (!\inst4|Add7~1_sumout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1110010011100100111001001110010001000100010001000100010001000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_M_CN~input_o\,
	datab => \inst4|ALT_INV_Add7~1_sumout\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	combout => \inst4|F9~3_combout\);

-- Location: MLABCELL_X8_Y2_N51
\inst4|F9~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~1_combout\ = ( \inst4|Add5~1_sumout\ & ( \M_CN~input_o\ ) ) # ( \inst4|Add5~1_sumout\ & ( !\M_CN~input_o\ & ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) ) ) ) # ( !\inst4|Add5~1_sumout\ & ( !\M_CN~input_o\ & ( 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010100000000000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datae => \inst4|ALT_INV_Add5~1_sumout\,
	dataf => \ALT_INV_M_CN~input_o\,
	combout => \inst4|F9~1_combout\);

-- Location: LABCELL_X7_Y2_N42
\inst4|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux8~0_combout\ = ( \inst4|F9~3_combout\ & ( \inst4|F9~1_combout\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ((\inst4|F9~0_combout\))) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & (\inst4|F9~2_combout\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2))))) ) ) ) # ( 
-- !\inst4|F9~3_combout\ & ( \inst4|F9~1_combout\ & ( ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ((\inst4|F9~0_combout\))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & (\inst4|F9~2_combout\))) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3)) ) ) ) # ( \inst4|F9~3_combout\ & ( !\inst4|F9~1_combout\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & 
-- ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ((\inst4|F9~0_combout\))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & (\inst4|F9~2_combout\)))) ) ) ) # ( !\inst4|F9~3_combout\ & ( !\inst4|F9~1_combout\ & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ((\inst4|F9~0_combout\))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & 
-- (\inst4|F9~2_combout\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (((\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110001110111000011000100010000111111011101110011111101000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_F9~2_combout\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3),
	datac => \inst4|ALT_INV_F9~0_combout\,
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datae => \inst4|ALT_INV_F9~3_combout\,
	dataf => \inst4|ALT_INV_F9~1_combout\,
	combout => \inst4|Mux8~0_combout\);

-- Location: MLABCELL_X8_Y2_N33
\inst4|F9~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~6_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(0) & ( (!\M_CN~input_o\) # (\inst4|Add6~1_sumout\) ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(0) & ( (!\M_CN~input_o\ & 
-- ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)))) # (\M_CN~input_o\ & (\inst4|Add6~1_sumout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010111100000101101011110000010110101111101011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_M_CN~input_o\,
	datac => \inst4|ALT_INV_Add6~1_sumout\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	combout => \inst4|F9~6_combout\);

-- Location: MLABCELL_X8_Y2_N0
\inst4|F9~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~5_combout\ = ( \M_CN~input_o\ & ( \inst4|Add1~1_sumout\ ) ) # ( !\M_CN~input_o\ & ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000000110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst4|ALT_INV_Add1~1_sumout\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	dataf => \ALT_INV_M_CN~input_o\,
	combout => \inst4|F9~5_combout\);

-- Location: LABCELL_X7_Y2_N12
\inst4|F9~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~4_combout\ = !\M_CN~input_o\ $ (((!\inst2|altsyncram_component|auto_generated|q_a\(0) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110110001101100011011000110110001101100011011000110110001101100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datab => \ALT_INV_M_CN~input_o\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	combout => \inst4|F9~4_combout\);

-- Location: LABCELL_X7_Y2_N48
\inst4|Mux8~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux8~3_combout\ = ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ( ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (((!\inst4|F9~4_combout\)))) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (!\M_CN~input_o\ $ (((\inst4|Add4~1_sumout\)))))) ) ) # ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (((\inst4|F9~5_combout\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (\inst4|F9~6_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1111110000110000000111010001110111001111000000110001110100011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_F9~6_combout\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3),
	datac => \inst4|ALT_INV_F9~5_combout\,
	datad => \inst4|ALT_INV_F9~4_combout\,
	datae => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	dataf => \inst4|ALT_INV_Add4~1_sumout\,
	datag => \ALT_INV_M_CN~input_o\,
	combout => \inst4|Mux8~3_combout\);

-- Location: LABCELL_X7_Y2_N15
\inst4|Mux8~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux8~1_combout\ = ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & ( (\inst2|altsyncram_component|auto_generated|q_a\(0) & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)))) ) ) # ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & ( (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & 
-- ((!\inst2|altsyncram_component|auto_generated|q_a\(0) & (\M_CN~input_o\ & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0))) # (\inst2|altsyncram_component|auto_generated|q_a\(0) & 
-- ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # (\M_CN~input_o\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000011100000001000001110000000100000101010101010000010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datab => \ALT_INV_M_CN~input_o\,
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3),
	combout => \inst4|Mux8~1_combout\);

-- Location: LABCELL_X7_Y2_N54
\inst4|Mux8~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux8~7_combout\ = ( !\M_CN~input_o\ & ( (!\inst2|altsyncram_component|auto_generated|q_a\(0) & (((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3)) # ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)))))) # (\inst2|altsyncram_component|auto_generated|q_a\(0) & (((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3)))))) ) ) # ( \M_CN~input_o\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & 
-- (((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & (\inst2|altsyncram_component|auto_generated|q_a\(0))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3) & ((\inst4|Add3~1_sumout\)))))) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & ((((\inst4|Add0~1_sumout\ & !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(3)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1010101011111010010101010000111100001010000000000011001100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datab => \inst4|ALT_INV_Add3~1_sumout\,
	datac => \inst4|ALT_INV_Add0~1_sumout\,
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datae => \ALT_INV_M_CN~input_o\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(3),
	datag => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	combout => \inst4|Mux8~7_combout\);

-- Location: LABCELL_X7_Y2_N6
\inst4|Mux8~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux8~2_combout\ = ( \inst4|Mux8~7_combout\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (\inst4|Mux8~0_combout\)) # 
-- (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((\inst4|Mux8~1_combout\))) ) ) ) # ( !\inst4|Mux8~7_combout\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & ( 
-- (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (\inst4|Mux8~0_combout\)) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((\inst4|Mux8~1_combout\))) ) ) ) # ( \inst4|Mux8~7_combout\ & ( 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\) # (\inst4|Mux8~3_combout\) ) ) ) # ( !\inst4|Mux8~7_combout\ & ( 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(1) & ( (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & \inst4|Mux8~3_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101101011111010111100100010011101110010001001110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \inst4|ALT_INV_Mux8~0_combout\,
	datac => \inst4|ALT_INV_Mux8~3_combout\,
	datad => \inst4|ALT_INV_Mux8~1_combout\,
	datae => \inst4|ALT_INV_Mux8~7_combout\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(1),
	combout => \inst4|Mux8~2_combout\);

-- Location: LABCELL_X4_Y2_N0
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(0),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~feeder_combout\);

-- Location: FF_X4_Y2_N1
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~feeder_combout\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(1),
	sload => \inst3|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(0));

-- Location: LABCELL_X4_Y2_N51
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000100000000000000010000000001111001011110000111100101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1_combout\);

-- Location: FF_X4_Y3_N35
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~3_combout\,
	sload => VCC,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(2));

-- Location: LABCELL_X4_Y2_N24
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|clear_signal\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|clear_signal~combout\);

-- Location: LABCELL_X4_Y3_N39
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110011000000110011001100000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_Equal0~0_combout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~0_combout\);

-- Location: FF_X4_Y3_N41
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~0_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(0));

-- Location: LABCELL_X4_Y3_N51
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000000110000001000000011000000110000001100000011000001100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[4]~DUPLICATE_q\,
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_clear_signal~combout\,
	datad => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datae => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~5_combout\);

-- Location: FF_X4_Y3_N49
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[4]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~5_combout\,
	sload => VCC,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[4]~DUPLICATE_q\);

-- Location: LABCELL_X4_Y3_N30
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100010001000100010001000000010001000100010001001000100010001000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_clear_signal~combout\,
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datad => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[4]~DUPLICATE_q\,
	datae => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~3_combout\);

-- Location: FF_X4_Y3_N34
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[2]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~3_combout\,
	sload => VCC,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[2]~DUPLICATE_q\);

-- Location: FF_X4_Y3_N50
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~5_combout\,
	sload => VCC,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(4));

-- Location: LABCELL_X4_Y3_N57
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|Equal0~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000001000000000000000100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[2]~DUPLICATE_q\,
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	datad => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|Equal0~0_combout\);

-- Location: LABCELL_X4_Y3_N15
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000001000000011000000100011000000100000001100000010000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_Equal0~0_combout\,
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~2_combout\);

-- Location: FF_X6_Y2_N10
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~2_combout\,
	sload => VCC,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(1));

-- Location: LABCELL_X4_Y3_N45
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000001010000010100000101000001010000011000000101000001100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_clear_signal~combout\,
	datad => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[2]~DUPLICATE_q\,
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~4_combout\);

-- Location: MLABCELL_X6_Y2_N18
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter~4_combout\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~feeder_combout\);

-- Location: FF_X6_Y2_N19
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~feeder_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(3));

-- Location: LABCELL_X4_Y3_N54
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000001000100000000000100010000000000010001000000000001000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[2]~DUPLICATE_q\,
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4),
	datad => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~3_combout\);

-- Location: FF_X4_Y3_N40
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~0_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~DUPLICATE_q\);

-- Location: MLABCELL_X6_Y3_N15
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000010010000100000000000000000000000100000001000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[4]~DUPLICATE_q\,
	datae => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[2]~DUPLICATE_q\,
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~5_combout\);

-- Location: LABCELL_X4_Y3_N36
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~7\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010000000000000001000000000000000000100000001000000010000000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datad => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[4]~DUPLICATE_q\,
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~7_combout\);

-- Location: LABCELL_X4_Y3_N24
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~8\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100000011000001010101010101010101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~7_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~8_combout\);

-- Location: LABCELL_X4_Y2_N27
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100011101000100010001110100011101000111010001110100011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\);

-- Location: FF_X4_Y3_N25
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~8_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(3));

-- Location: LABCELL_X4_Y3_N3
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111000000000000011100000000000001110111011100000111011101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~5_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(3),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~6_combout\);

-- Location: FF_X4_Y3_N4
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~6_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(2));

-- Location: LABCELL_X4_Y3_N18
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010100110011010100000011000000000000001100110000000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~3_combout\,
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~4_combout\);

-- Location: FF_X4_Y3_N19
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~4_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(1));

-- Location: LABCELL_X4_Y3_N42
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000110000000000000011000010000010000110101000001000011010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datad => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[2]~DUPLICATE_q\,
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~0_combout\);

-- Location: LABCELL_X4_Y3_N0
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011101110000000001110111000001110000011100000111000001110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(1),
	datad => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~0_combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~1_combout\);

-- Location: FF_X4_Y3_N1
\inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~1_combout\,
	ena => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(0));

-- Location: LABCELL_X1_Y4_N54
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(5),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~feeder_combout\);

-- Location: FF_X1_Y4_N55
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~q\);

-- Location: LABCELL_X4_Y3_N12
\inst3|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100000000000011110000000000001111111111110000111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_bypass_reg_out~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	dataf => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~0_combout\);

-- Location: FF_X1_Y3_N14
\inst3|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst3|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst3|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~q\);

-- Location: LABCELL_X1_Y3_N12
\inst3|altsyncram_component|auto_generated|mgl_prim2|adapted_tdo~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0001001100010011000011110000111110110011000100110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\,
	datab => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg\(0),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(0),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][5]~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	dataf => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_bypass_reg_out~q\,
	datag => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|adapted_tdo~0_combout\);

-- Location: MLABCELL_X3_Y2_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000000000001010000000000110111001100110011011100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\);

-- Location: FF_X1_Y2_N28
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~2_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(2));

-- Location: LABCELL_X2_Y2_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000000110000001100000011000011000000110000001100000011000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[1]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~4_combout\);

-- Location: LABCELL_X1_Y2_N51
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~4_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]~feeder_combout\);

-- Location: FF_X1_Y2_N52
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]~DUPLICATE_q\);

-- Location: LABCELL_X1_Y1_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100000000001100110000000000111100000000000011110000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[1]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~2_combout\);

-- Location: FF_X1_Y2_N29
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~2_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~DUPLICATE_q\);

-- Location: FF_X1_Y2_N59
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(0));

-- Location: FF_X1_Y2_N53
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(1));

-- Location: FF_X1_Y2_N8
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(3));

-- Location: LABCELL_X1_Y2_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100000000001100110000000000110110000000000011011000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[2]~DUPLICATE_q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~3_combout\);

-- Location: LABCELL_X1_Y2_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~3_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]~feeder_combout\);

-- Location: FF_X1_Y2_N7
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]~DUPLICATE_q\);

-- Location: FF_X1_Y2_N10
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]~DUPLICATE_q\);

-- Location: LABCELL_X2_Y2_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000010000000001111111000000001111111000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[1]~DUPLICATE_q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[3]~DUPLICATE_q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[4]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~5_combout\);

-- Location: LABCELL_X1_Y2_N9
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~5_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]~feeder_combout\);

-- Location: FF_X1_Y2_N11
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(4));

-- Location: LABCELL_X1_Y2_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110001001100000000000000000011001100110011000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[2]~DUPLICATE_q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(4),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~0_combout\);

-- Location: LABCELL_X1_Y2_N57
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~0_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~feeder_combout\);

-- Location: FF_X1_Y2_N58
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~DUPLICATE_q\);

-- Location: LABCELL_X2_Y2_N21
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000000000000000000000000011110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[1]~DUPLICATE_q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[4]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~2_combout\);

-- Location: LABCELL_X1_Y2_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100000000001100110000000000000000001100110000000000110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[2]~DUPLICATE_q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~5_combout\);

-- Location: LABCELL_X1_Y1_N54
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000010001111000000000000111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~5_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datad => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[4]~DUPLICATE_q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~6_combout\);

-- Location: LABCELL_X1_Y1_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111000000000000111101110111011111110111011101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\);

-- Location: FF_X1_Y1_N55
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~6_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(3));

-- Location: LABCELL_X1_Y1_N12
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000001001100010000000100110001000000010011000100000001001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~2_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~4_combout\);

-- Location: FF_X1_Y1_N13
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~4_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(2));

-- Location: LABCELL_X1_Y1_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100010000000000010001000000000001000100110011000100010011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~2_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~3_combout\);

-- Location: FF_X1_Y1_N17
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~3_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(1));

-- Location: LABCELL_X1_Y1_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000010000000011110001111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[3]~DUPLICATE_q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(2),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~0_combout\);

-- Location: FF_X1_Y1_N19
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~0_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(0));

-- Location: LABCELL_X2_Y2_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0000100000000000000011110000000000000000000000000000111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	datac => \inst3|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_adapted_tdo~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datag => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~6_combout\);

-- Location: MLABCELL_X3_Y3_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_bypass_reg~q\,
	datac => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~0_combout\);

-- Location: FF_X1_Y3_N50
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~0_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~q\);

-- Location: LABCELL_X1_Y3_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110000001100110011000000110011001100110011001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_bypass_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~4_combout\);

-- Location: LABCELL_X2_Y2_N54
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111111111111111100001111000011111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\);

-- Location: LABCELL_X2_Y2_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010101000101010000000000000000010101010101010100000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~3_combout\);

-- Location: LABCELL_X1_Y1_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011001100110011001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	dataf => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~3_combout\);

-- Location: FF_X1_Y1_N37
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~3_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(3));

-- Location: LABCELL_X1_Y1_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~2_combout\);

-- Location: FF_X1_Y1_N4
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~2_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(2));

-- Location: LABCELL_X1_Y1_N51
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100010001000100010001000100010001000100010001000100010001000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~1_combout\);

-- Location: FF_X1_Y1_N52
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~1_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(1));

-- Location: LABCELL_X1_Y1_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011111100111111001111110011111100111111001111110011111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~0_combout\);

-- Location: FF_X1_Y1_N49
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~0_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(0));

-- Location: LABCELL_X2_Y3_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~0_combout\);

-- Location: LABCELL_X1_Y3_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000100000000000001010000000011110001111100001111010111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(0),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_bypass_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~1_combout\);

-- Location: LABCELL_X1_Y2_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110111111100001111011111110000111101111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~2_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~6_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~4_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_info_reg_ena~0_combout\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~3_combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~1_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~5_combout\);

-- Location: FF_X1_Y2_N32
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo~q\);

-- Location: LABCELL_X2_Y3_N12
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal1~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(0),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal0~0_combout\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal1~0_combout\);

-- Location: FF_X2_Y3_N14
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal1~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg~q\);

-- Location: LABCELL_X2_Y4_N27
\inst3|altsyncram_component|auto_generated|mgl_prim2|enable_write~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000010000000100000001000000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\,
	combout => \inst3|altsyncram_component|auto_generated|mgl_prim2|enable_write~0_combout\);

-- Location: LABCELL_X12_Y4_N51
\inst4|F9~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|F9~7_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( !\inst2|altsyncram_component|auto_generated|q_a\(1) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(1) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111000000001111111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	combout => \inst4|F9~7_combout\);

-- Location: LABCELL_X10_Y4_N51
\inst4|Mux7~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux7~4_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1))) # 
-- (\M_CN~input_o\ & ((\inst4|Add5~5_sumout\))))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1))))) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\M_CN~input_o\ & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1))) # (\M_CN~input_o\ & 
-- ((\inst4|Add5~5_sumout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000101010000010000010101000001101001011110000110100101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datab => \ALT_INV_M_CN~input_o\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datad => \inst4|ALT_INV_Add5~5_sumout\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst4|Mux7~4_combout\);

-- Location: LABCELL_X12_Y4_N24
\inst4|Mux7~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux7~6_combout\ = ( \inst4|Add4~5_sumout\ & ( \inst4|Add3~5_sumout\ & ( ((!\inst4|Mux7~5_combout\ & ((\inst4|Mux7~4_combout\))) # (\inst4|Mux7~5_combout\ & (!\inst4|F9~7_combout\))) # (\inst4|Mux1~6_combout\) ) ) ) # ( !\inst4|Add4~5_sumout\ & ( 
-- \inst4|Add3~5_sumout\ & ( (!\inst4|Mux1~6_combout\ & ((!\inst4|Mux7~5_combout\ & ((\inst4|Mux7~4_combout\))) # (\inst4|Mux7~5_combout\ & (!\inst4|F9~7_combout\)))) # (\inst4|Mux1~6_combout\ & (((!\inst4|Mux7~5_combout\)))) ) ) ) # ( \inst4|Add4~5_sumout\ 
-- & ( !\inst4|Add3~5_sumout\ & ( (!\inst4|Mux1~6_combout\ & ((!\inst4|Mux7~5_combout\ & ((\inst4|Mux7~4_combout\))) # (\inst4|Mux7~5_combout\ & (!\inst4|F9~7_combout\)))) # (\inst4|Mux1~6_combout\ & (((\inst4|Mux7~5_combout\)))) ) ) ) # ( 
-- !\inst4|Add4~5_sumout\ & ( !\inst4|Add3~5_sumout\ & ( (!\inst4|Mux1~6_combout\ & ((!\inst4|Mux7~5_combout\ & ((\inst4|Mux7~4_combout\))) # (\inst4|Mux7~5_combout\ & (!\inst4|F9~7_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110010001000000011001011101100111111100010000011111110111011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_F9~7_combout\,
	datab => \inst4|ALT_INV_Mux1~6_combout\,
	datac => \inst4|ALT_INV_Mux7~4_combout\,
	datad => \inst4|ALT_INV_Mux7~5_combout\,
	datae => \inst4|ALT_INV_Add4~5_sumout\,
	dataf => \inst4|ALT_INV_Add3~5_sumout\,
	combout => \inst4|Mux7~6_combout\);

-- Location: LABCELL_X9_Y3_N24
\inst4|Mux7~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux7~3_combout\ = ( \inst4|Add7~5_sumout\ & ( \inst2|altsyncram_component|auto_generated|q_a\(0) & ( (!\inst4|Mux1~5_combout\) # ((\inst4|Add6~5_sumout\ & (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\))) ) ) ) # ( !\inst4|Add7~5_sumout\ & ( \inst2|altsyncram_component|auto_generated|q_a\(0) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & 
-- ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\inst4|Mux1~5_combout\))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & (\inst4|Add6~5_sumout\)))) ) ) ) # ( \inst4|Add7~5_sumout\ & ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(0) & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ((!\inst4|Mux1~5_combout\) # 
-- (\inst4|Add6~5_sumout\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\ & (((!\inst4|Mux1~5_combout\)))) ) ) ) # ( !\inst4|Add7~5_sumout\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(0) & ( (\inst4|Add6~5_sumout\ 
-- & (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100000000001100011111000011010001000000001111000111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Add6~5_sumout\,
	datab => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	datac => \inst4|ALT_INV_Mux1~5_combout\,
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datae => \inst4|ALT_INV_Add7~5_sumout\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	combout => \inst4|Mux7~3_combout\);

-- Location: MLABCELL_X8_Y4_N12
\inst4|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux7~0_combout\ = ( \M_CN~input_o\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( !\inst4|Add1~5_sumout\ ) ) ) # ( !\M_CN~input_o\ & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ 
-- & ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) ) ) ) # ( \M_CN~input_o\ & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( !\inst4|Add0~5_sumout\ ) ) ) # ( !\M_CN~input_o\ & ( 
-- !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (\inst2|altsyncram_component|auto_generated|q_a\(1) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001010101110011001100110000000000111111111111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datab => \inst4|ALT_INV_Add0~5_sumout\,
	datac => \inst4|ALT_INV_Add1~5_sumout\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datae => \ALT_INV_M_CN~input_o\,
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	combout => \inst4|Mux7~0_combout\);

-- Location: LABCELL_X7_Y4_N24
\inst4|Mux7~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux7~1_combout\ = ( \inst4|Add2~5_sumout\ & ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst4|Mux1~3_combout\ & ((!\inst4|Mux1~4_combout\ & (!\inst4|Mux7~0_combout\)) # (\inst4|Mux1~4_combout\ & 
-- ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)))))) # (\inst4|Mux1~3_combout\ & (((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst4|Mux1~4_combout\)))) ) ) ) # ( !\inst4|Add2~5_sumout\ & ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst4|Mux1~3_combout\ & ((!\inst4|Mux1~4_combout\ & (!\inst4|Mux7~0_combout\)) # (\inst4|Mux1~4_combout\ & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)))))) # 
-- (\inst4|Mux1~3_combout\ & (((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & !\inst4|Mux1~4_combout\)))) ) ) ) # ( \inst4|Add2~5_sumout\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst4|Mux1~3_combout\ & 
-- (!\inst4|Mux7~0_combout\ & ((!\inst4|Mux1~4_combout\)))) # (\inst4|Mux1~3_combout\ & (((\inst4|Mux1~4_combout\) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1))))) ) ) ) # ( !\inst4|Add2~5_sumout\ & ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst4|Mux1~4_combout\ & ((!\inst4|Mux1~3_combout\ & (!\inst4|Mux7~0_combout\)) # (\inst4|Mux1~3_combout\ & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000110100000000100011010101010111011000101000001101100011110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~3_combout\,
	datab => \inst4|ALT_INV_Mux7~0_combout\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datad => \inst4|ALT_INV_Mux1~4_combout\,
	datae => \inst4|ALT_INV_Add2~5_sumout\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst4|Mux7~1_combout\);

-- Location: LABCELL_X12_Y4_N6
\inst4|Mux7~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux7~2_combout\ = ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (\inst4|Mux7~1_combout\ & \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)) ) 
-- ) ) # ( !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\)))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & (((\inst4|Mux7~1_combout\)))) ) ) ) 
-- # ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (\inst4|Mux7~1_combout\ & \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2)) ) ) ) # ( 
-- !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( !\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[0]~DUPLICATE_q\ & ( (!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & 
-- ((!\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[1]~DUPLICATE_q\))) # (\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit\(2) & (\inst4|Mux7~1_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000000110011000000000011001110100000001100110000000000110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datab => \inst4|ALT_INV_Mux7~1_combout\,
	datac => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[1]~DUPLICATE_q\,
	datad => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit\(2),
	datae => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	dataf => \inst1|LPM_COUNTER_component|auto_generated|ALT_INV_counter_reg_bit[0]~DUPLICATE_q\,
	combout => \inst4|Mux7~2_combout\);

-- Location: LABCELL_X12_Y4_N36
\inst4|Mux7~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux7~8_combout\ = ( !\inst4|Mux1~8_combout\ & ( ((!\inst4|Mux1~7_combout\ & (((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1))) # (\inst2|altsyncram_component|auto_generated|q_a\(1)))) # (\inst4|Mux1~7_combout\ & 
-- (((\inst4|Mux7~2_combout\))))) ) ) # ( \inst4|Mux1~8_combout\ & ( (!\inst4|Mux1~7_combout\ & (((\inst4|Mux7~3_combout\)))) # (\inst4|Mux1~7_combout\ & (\inst4|Mux7~6_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1100110011111111000111010001110100001100001111110001110100011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux7~6_combout\,
	datab => \inst4|ALT_INV_Mux1~7_combout\,
	datac => \inst4|ALT_INV_Mux7~3_combout\,
	datad => \inst4|ALT_INV_Mux7~2_combout\,
	datae => \inst4|ALT_INV_Mux1~8_combout\,
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datag => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst4|Mux7~8_combout\);

-- Location: MLABCELL_X6_Y2_N36
\inst4|Mux7~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst4|Mux7~7_combout\ = ( \inst4|Mux1~0_combout\ & ( \inst2|altsyncram_component|auto_generated|q_a\(1) & ( ((\inst4|Mux7~8_combout\ & \inst4|Mux1~1_combout\)) # (\inst4|Mux1~2_combout\) ) ) ) # ( !\inst4|Mux1~0_combout\ & ( 
-- \inst2|altsyncram_component|auto_generated|q_a\(1) & ( (\inst4|Mux1~2_combout\) # (\inst4|Mux7~8_combout\) ) ) ) # ( \inst4|Mux1~0_combout\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst4|Mux1~1_combout\ & 
-- (((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1))))) # (\inst4|Mux1~1_combout\ & (\inst4|Mux7~8_combout\ & ((!\inst4|Mux1~2_combout\)))) ) ) ) # ( !\inst4|Mux1~0_combout\ & ( !\inst2|altsyncram_component|auto_generated|q_a\(1) & ( 
-- (\inst4|Mux7~8_combout\ & !\inst4|Mux1~2_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010100000000000111010000110001010101111111110001000111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux7~8_combout\,
	datab => \inst4|ALT_INV_Mux1~1_combout\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datad => \inst4|ALT_INV_Mux1~2_combout\,
	datae => \inst4|ALT_INV_Mux1~0_combout\,
	dataf => \inst2|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst4|Mux7~7_combout\);

-- Location: LABCELL_X12_Y4_N42
\inst6|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux0~0_combout\ = ( \B_T_CN_M~input_o\ & ( (!\inst4|Mux5~6_combout\ & (!\inst4|Mux7~7_combout\ & (!\inst4|Mux8~2_combout\ $ (!\inst4|Mux6~6_combout\)))) # (\inst4|Mux5~6_combout\ & (\inst4|Mux8~2_combout\ & (!\inst4|Mux7~7_combout\ $ 
-- (!\inst4|Mux6~6_combout\)))) ) ) # ( !\B_T_CN_M~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100001001100000100000100110000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux7~7_combout\,
	datab => \inst4|ALT_INV_Mux5~6_combout\,
	datac => \inst4|ALT_INV_Mux8~2_combout\,
	datad => \inst4|ALT_INV_Mux6~6_combout\,
	dataf => \ALT_INV_B_T_CN_M~input_o\,
	combout => \inst6|Mux0~0_combout\);

-- Location: LABCELL_X12_Y4_N21
\inst6|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux1~0_combout\ = ( \inst4|Mux7~7_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux8~2_combout\ & ((\inst4|Mux6~6_combout\))) # (\inst4|Mux8~2_combout\ & (\inst4|Mux5~6_combout\))) ) ) # ( !\inst4|Mux7~7_combout\ & ( (!\B_T_CN_M~input_o\) # 
-- ((\inst4|Mux6~6_combout\ & (!\inst4|Mux8~2_combout\ $ (!\inst4|Mux5~6_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110011011110110011001101111011001101111011111100110111101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux8~2_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst4|ALT_INV_Mux5~6_combout\,
	datad => \inst4|ALT_INV_Mux6~6_combout\,
	dataf => \inst4|ALT_INV_Mux7~7_combout\,
	combout => \inst6|Mux1~0_combout\);

-- Location: LABCELL_X12_Y4_N18
\inst6|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux2~0_combout\ = ( \inst4|Mux7~7_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux6~6_combout\ & (!\inst4|Mux8~2_combout\ & !\inst4|Mux5~6_combout\)) # (\inst4|Mux6~6_combout\ & ((\inst4|Mux5~6_combout\)))) ) ) # ( !\inst4|Mux7~7_combout\ & ( 
-- (!\B_T_CN_M~input_o\) # ((!\inst4|Mux8~2_combout\ & (\inst4|Mux6~6_combout\ & \inst4|Mux5~6_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110011001110110011001100111011101100110011111110110011001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux8~2_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst4|ALT_INV_Mux6~6_combout\,
	datad => \inst4|ALT_INV_Mux5~6_combout\,
	dataf => \inst4|ALT_INV_Mux7~7_combout\,
	combout => \inst6|Mux2~0_combout\);

-- Location: LABCELL_X12_Y4_N0
\inst6|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux3~0_combout\ = ( \inst4|Mux7~7_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux8~2_combout\ & (!\inst4|Mux6~6_combout\ & \inst4|Mux5~6_combout\)) # (\inst4|Mux8~2_combout\ & (\inst4|Mux6~6_combout\))) ) ) # ( !\inst4|Mux7~7_combout\ & ( 
-- (!\B_T_CN_M~input_o\) # ((!\inst4|Mux5~6_combout\ & (!\inst4|Mux8~2_combout\ $ (!\inst4|Mux6~6_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101111011001100110111101100110011001101111011011100110111101101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux8~2_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst4|ALT_INV_Mux6~6_combout\,
	datad => \inst4|ALT_INV_Mux5~6_combout\,
	dataf => \inst4|ALT_INV_Mux7~7_combout\,
	combout => \inst6|Mux3~0_combout\);

-- Location: LABCELL_X12_Y4_N3
\inst6|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux4~0_combout\ = ( \inst4|Mux7~7_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst4|Mux8~2_combout\ & !\inst4|Mux5~6_combout\)) ) ) # ( !\inst4|Mux7~7_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux6~6_combout\ & (\inst4|Mux8~2_combout\)) # 
-- (\inst4|Mux6~6_combout\ & ((!\inst4|Mux5~6_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101110111111100110111011111110011011100110111001101110011011100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux8~2_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst4|ALT_INV_Mux5~6_combout\,
	datad => \inst4|ALT_INV_Mux6~6_combout\,
	dataf => \inst4|ALT_INV_Mux7~7_combout\,
	combout => \inst6|Mux4~0_combout\);

-- Location: LABCELL_X4_Y3_N9
\inst6|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux5~0_combout\ = ( \inst4|Mux8~2_combout\ & ( (!\B_T_CN_M~input_o\) # (!\inst4|Mux5~6_combout\ $ (((!\inst4|Mux7~7_combout\ & \inst4|Mux6~6_combout\)))) ) ) # ( !\inst4|Mux8~2_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst4|Mux7~7_combout\ & 
-- (!\inst4|Mux5~6_combout\ & !\inst4|Mux6~6_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011101010101010101110101010101011111010101111101111101010111110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst4|ALT_INV_Mux7~7_combout\,
	datac => \inst4|ALT_INV_Mux5~6_combout\,
	datad => \inst4|ALT_INV_Mux6~6_combout\,
	dataf => \inst4|ALT_INV_Mux8~2_combout\,
	combout => \inst6|Mux5~0_combout\);

-- Location: LABCELL_X4_Y3_N6
\inst6|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux6~0_combout\ = ( \inst4|Mux5~6_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux7~7_combout\ & (\inst4|Mux6~6_combout\ & !\inst4|Mux8~2_combout\))) ) ) # ( !\inst4|Mux5~6_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux7~7_combout\ & 
-- (!\inst4|Mux6~6_combout\)) # (\inst4|Mux7~7_combout\ & (\inst4|Mux6~6_combout\ & \inst4|Mux8~2_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1110101011101011111010101110101110101110101010101010111010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst4|ALT_INV_Mux7~7_combout\,
	datac => \inst4|ALT_INV_Mux6~6_combout\,
	datad => \inst4|ALT_INV_Mux8~2_combout\,
	dataf => \inst4|ALT_INV_Mux5~6_combout\,
	combout => \inst6|Mux6~0_combout\);

-- Location: LABCELL_X12_Y4_N48
\inst6|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux7~0_combout\ = ( \B_T_CN_M~input_o\ & ( (!\inst4|Mux2~6_combout\ & (\inst4|Mux4~6_combout\ & (!\inst4|Mux3~6_combout\ $ (\inst4|Mux1~15_combout\)))) # (\inst4|Mux2~6_combout\ & (!\inst4|Mux3~6_combout\ & (!\inst4|Mux1~15_combout\ $ 
-- (\inst4|Mux4~6_combout\)))) ) ) # ( !\B_T_CN_M~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111101000000100001100100000010000110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux2~6_combout\,
	datab => \inst4|ALT_INV_Mux3~6_combout\,
	datac => \inst4|ALT_INV_Mux1~15_combout\,
	datad => \inst4|ALT_INV_Mux4~6_combout\,
	dataf => \ALT_INV_B_T_CN_M~input_o\,
	combout => \inst6|Mux7~0_combout\);

-- Location: LABCELL_X12_Y4_N57
\inst6|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux8~0_combout\ = ( \inst4|Mux2~6_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux1~15_combout\ & (!\inst4|Mux3~6_combout\ $ (!\inst4|Mux4~6_combout\))) # (\inst4|Mux1~15_combout\ & ((!\inst4|Mux4~6_combout\) # (\inst4|Mux3~6_combout\)))) ) ) # ( 
-- !\inst4|Mux2~6_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst4|Mux1~15_combout\ & (\inst4|Mux3~6_combout\ & \inst4|Mux4~6_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110001111100001111000111110111111110011111011111111001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~15_combout\,
	datab => \inst4|ALT_INV_Mux3~6_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst4|ALT_INV_Mux4~6_combout\,
	dataf => \inst4|ALT_INV_Mux2~6_combout\,
	combout => \inst6|Mux8~0_combout\);

-- Location: LABCELL_X12_Y4_N54
\inst6|Mux9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux9~0_combout\ = ( \B_T_CN_M~input_o\ & ( (!\inst4|Mux1~15_combout\ & (\inst4|Mux3~6_combout\ & (!\inst4|Mux2~6_combout\ & !\inst4|Mux4~6_combout\))) # (\inst4|Mux1~15_combout\ & (\inst4|Mux2~6_combout\ & ((!\inst4|Mux4~6_combout\) # 
-- (\inst4|Mux3~6_combout\)))) ) ) # ( !\B_T_CN_M~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100100101000000010010010100000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux1~15_combout\,
	datab => \inst4|ALT_INV_Mux3~6_combout\,
	datac => \inst4|ALT_INV_Mux2~6_combout\,
	datad => \inst4|ALT_INV_Mux4~6_combout\,
	dataf => \ALT_INV_B_T_CN_M~input_o\,
	combout => \inst6|Mux9~0_combout\);

-- Location: LABCELL_X12_Y4_N15
\inst6|Mux10~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux10~0_combout\ = ( \inst4|Mux1~15_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst4|Mux3~6_combout\ & (!\inst4|Mux2~6_combout\ $ (\inst4|Mux4~6_combout\)))) ) ) # ( !\inst4|Mux1~15_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux2~6_combout\ & 
-- (!\inst4|Mux3~6_combout\ & \inst4|Mux4~6_combout\)) # (\inst4|Mux2~6_combout\ & (!\inst4|Mux3~6_combout\ $ (\inst4|Mux4~6_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101110011101101110111001110110111001110110011011100111011001101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux2~6_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst4|ALT_INV_Mux3~6_combout\,
	datad => \inst4|ALT_INV_Mux4~6_combout\,
	dataf => \inst4|ALT_INV_Mux1~15_combout\,
	combout => \inst6|Mux10~0_combout\);

-- Location: LABCELL_X12_Y4_N12
\inst6|Mux11~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux11~0_combout\ = ( \inst4|Mux3~6_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux1~15_combout\ & \inst4|Mux4~6_combout\)) ) ) # ( !\inst4|Mux3~6_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux2~6_combout\ & ((\inst4|Mux4~6_combout\))) # 
-- (\inst4|Mux2~6_combout\ & (!\inst4|Mux1~15_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101110011111110110111001111111011001100111111001100110011111100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux2~6_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst4|ALT_INV_Mux1~15_combout\,
	datad => \inst4|ALT_INV_Mux4~6_combout\,
	dataf => \inst4|ALT_INV_Mux3~6_combout\,
	combout => \inst6|Mux11~0_combout\);

-- Location: LABCELL_X12_Y4_N33
\inst6|Mux12~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux12~0_combout\ = ( \inst4|Mux1~15_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst4|Mux2~6_combout\ & (!\inst4|Mux3~6_combout\ & \inst4|Mux4~6_combout\))) ) ) # ( !\inst4|Mux1~15_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux2~6_combout\ & 
-- ((\inst4|Mux4~6_combout\) # (\inst4|Mux3~6_combout\))) # (\inst4|Mux2~6_combout\ & (\inst4|Mux3~6_combout\ & \inst4|Mux4~6_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100111011101111110011101110111111001100110111001100110011011100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux2~6_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst4|ALT_INV_Mux3~6_combout\,
	datad => \inst4|ALT_INV_Mux4~6_combout\,
	dataf => \inst4|ALT_INV_Mux1~15_combout\,
	combout => \inst6|Mux12~0_combout\);

-- Location: LABCELL_X12_Y4_N30
\inst6|Mux13~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst6|Mux13~0_combout\ = ( \inst4|Mux3~6_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst4|Mux2~6_combout\ & (!\inst4|Mux1~15_combout\ & \inst4|Mux4~6_combout\))) ) ) # ( !\inst4|Mux3~6_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst4|Mux2~6_combout\ & 
-- (!\inst4|Mux1~15_combout\)) # (\inst4|Mux2~6_combout\ & (\inst4|Mux1~15_combout\ & !\inst4|Mux4~6_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1110110111101100111011011110110011001100110111001100110011011100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|ALT_INV_Mux2~6_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst4|ALT_INV_Mux1~15_combout\,
	datad => \inst4|ALT_INV_Mux4~6_combout\,
	dataf => \inst4|ALT_INV_Mux3~6_combout\,
	combout => \inst6|Mux13~0_combout\);

-- Location: LABCELL_X10_Y5_N54
\inst7|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux0~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0))) ) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # 
-- ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0))) ) ) ) # ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( 
-- !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( !\B_T_CN_M~input_o\ ) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) 
-- # (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) $ (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101111011011110110011001100110011001101110011011100111011001110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datae => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	combout => \inst7|Mux0~0_combout\);

-- Location: LABCELL_X10_Y5_N15
\inst7|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux1~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))) # 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1))))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # 
-- ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) $ (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000111110010111100011111001011110010111101111111001011110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	combout => \inst7|Mux1~0_combout\);

-- Location: LABCELL_X10_Y5_N12
\inst7|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux2~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1))))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100001000111111110000100011111111001000111111111100100011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	combout => \inst7|Mux2~0_combout\);

-- Location: LABCELL_X10_Y5_N21
\inst7|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux3~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) $ 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0))))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) $ (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)))) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100111011101101110011101110110111011100110011011101110011001101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	combout => \inst7|Mux3~0_combout\);

-- Location: LABCELL_X10_Y5_N18
\inst7|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux4~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # (((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100111011111111110011101111111111001100111011001100110011101100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	combout => \inst7|Mux4~0_combout\);

-- Location: LABCELL_X10_Y5_N51
\inst7|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux5~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0))) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & 
-- ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111010011111101111101001111110111110000111100101111000011110010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	combout => \inst7|Mux5~0_combout\);

-- Location: LABCELL_X10_Y5_N48
\inst7|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux6~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & 
-- !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2))) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(0)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111110001001111111111000100111111111001000001111111100100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	combout => \inst7|Mux6~0_combout\);

-- Location: LABCELL_X10_Y5_N42
\inst7|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux7~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\B_T_CN_M~input_o\) # ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) $ 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) $ (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111101100000111111110110000011111111000101001111111100010100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	combout => \inst7|Mux7~0_combout\);

-- Location: LABCELL_X10_Y5_N39
\inst7|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux8~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6))) # 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\B_T_CN_M~input_o\) # 
-- ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) $ (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000111110010111100011111001011110010111101111111001011110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	combout => \inst7|Mux8~0_combout\);

-- Location: LABCELL_X7_Y4_N54
\inst7|Mux9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux9~0_combout\ = ( \B_T_CN_M~input_o\ & ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & 
-- !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)))) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & 
-- ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) ) # ( !\B_T_CN_M~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100001000010001010000100001000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	dataf => \ALT_INV_B_T_CN_M~input_o\,
	combout => \inst7|Mux9~0_combout\);

-- Location: LABCELL_X7_Y4_N57
\inst7|Mux10~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux10~0_combout\ = ( \B_T_CN_M~input_o\ & ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) $ 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6))))) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6))) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)))))) ) ) # ( !\B_T_CN_M~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100100100100000110010010010000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	dataf => \ALT_INV_B_T_CN_M~input_o\,
	combout => \inst7|Mux10~0_combout\);

-- Location: LABCELL_X9_Y5_N0
\inst7|Mux11~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux11~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ( (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) # ((!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & 
-- !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ( (!\B_T_CN_M~input_o\) # ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111010011110000111101001111000011111110111111001111111011111100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	combout => \inst7|Mux11~0_combout\);

-- Location: LABCELL_X10_Y5_N45
\inst7|Mux12~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux12~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\B_T_CN_M~input_o\) # ((\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & 
-- !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- (!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111010011111101111101001111110111110001111100001111000111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	combout => \inst7|Mux12~0_combout\);

-- Location: LABCELL_X10_Y5_N36
\inst7|Mux13~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux13~0_combout\ = ( \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & 
-- !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) ) ) # ( !\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( (!\B_T_CN_M~input_o\) # ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & 
-- ((!\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) # (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & (\inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- \inst3|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111000001111111111100000111111111001000001111111100100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datab => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datac => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst3|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	combout => \inst7|Mux13~0_combout\);

-- Location: FF_X7_Y2_N40
\inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[3]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst1|LPM_COUNTER_component|auto_generated|counter_comb_bita3~sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst1|LPM_COUNTER_component|auto_generated|counter_reg_bit[3]~DUPLICATE_q\);

-- Location: FF_X1_Y4_N26
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(6),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][6]~q\);

-- Location: FF_X1_Y4_N59
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(7),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][7]~q\);

-- Location: LABCELL_X57_Y2_N3
\auto_hub|~GND\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;

-- Location: LABCELL_X1_Y4_N9
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~_wirecell\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~_wirecell_combout\);

-- Location: LABCELL_X1_Y3_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[0]~_wirecell\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[0]~_wirecell_combout\);

-- Location: LABCELL_X53_Y33_N0
\~QUARTUS_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;
END structure;


