LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;

ENTITY decoder IS
    PORT (
        OP       : IN  STD_LOGIC_VECTOR(3 DOWNTO 0);
        S        : OUT STD_LOGIC_VECTOR(3 DOWNTO 0);
        CN       : OUT STD_LOGIC;
        M        : OUT STD_LOGIC;
        PC_INCR  : OUT STD_LOGIC;
        PC_WR    : OUT STD_LOGIC;
        RAM_LOAD : OUT STD_LOGIC;
        RAM_STR  : OUT STD_LOGIC;
        AC_LOAD  : OUT STD_LOGIC;
        Mux_Sel  : OUT STD_LOGIC;
        S_LOAD   : OUT STD_LOGIC
    );
END decoder;

ARCHITECTURE behav OF decoder IS
    SIGNAL OP_sig : STD_LOGIC_VECTOR(3 DOWNTO 0);
BEGIN
    OP_sig <= OP(3) & OP(2) & OP(1) & OP(0);

    PROCESS(OP_sig)
    BEGIN
        CASE OP_sig IS
            WHEN "0000" => 
                S <= (others => 'Z'); CN <= 'Z'; S_LOAD <= '0'; M <= 'Z';
                PC_INCR <= '1'; PC_WR <= '0'; RAM_LOAD <= '0'; RAM_STR <= '0'; AC_LOAD <= '0'; Mux_Sel <= 'Z';

            WHEN "0001" => 
                S <= (others => 'Z'); CN <= 'Z'; S_LOAD <= '0'; M <= 'Z';
                PC_INCR <= '0'; PC_WR <= '1'; RAM_LOAD <= '1'; RAM_STR <= '0'; AC_LOAD <= '0'; Mux_Sel <= 'Z';

            WHEN "0010" => 
                S <= "0110"; CN <= '0'; S_LOAD <= '1'; M <= '0';
                PC_INCR <= '1'; PC_WR <= '0'; RAM_LOAD <= '1'; RAM_STR <= '0'; AC_LOAD <= '1'; Mux_Sel <= '1';

            WHEN "0011" => 
                S <= (others => 'Z'); CN <= 'Z'; S_LOAD <= '0'; M <= 'Z';
                PC_INCR <= '1'; PC_WR <= '0'; RAM_LOAD <= '1'; RAM_STR <= '0'; AC_LOAD <= '0'; Mux_Sel <= '0';

            WHEN "0100" => 
                S <= "1011"; CN <= '0'; S_LOAD <= '1'; M <= '1';
                PC_INCR <= '1'; PC_WR <= '0'; RAM_LOAD <= '1'; RAM_STR <= '0'; AC_LOAD <= '1'; Mux_Sel <= '1';

            WHEN "0101" => 
                S <= "0001"; CN <= '0'; S_LOAD <= '1'; M <= '1';
                PC_INCR <= '1'; PC_WR <= '0'; RAM_LOAD <= '1'; RAM_STR <= '0'; AC_LOAD <= '1'; Mux_Sel <= '1';

            WHEN "0110" => 
                S <= "1001"; CN <= '0'; S_LOAD <= '1'; M <= '0';
                PC_INCR <= '1'; PC_WR <= '0'; RAM_LOAD <= '1'; RAM_STR <= '0'; AC_LOAD <= '1'; Mux_Sel <= '1';

            WHEN "0111" => 
                S <= (others => 'Z'); CN <= 'Z'; S_LOAD <= '0'; M <= 'Z';
                PC_INCR <= '1'; PC_WR <= '0'; RAM_LOAD <= '0'; RAM_STR <= '1'; AC_LOAD <= '0'; Mux_Sel <= 'Z';

            WHEN OTHERS => 
                S <= (others => 'Z'); CN <= 'Z'; S_LOAD <= '0'; M <= 'Z';
                PC_INCR <= '1'; PC_WR <= '0'; RAM_LOAD <= '0'; RAM_STR <= '0'; AC_LOAD <= '0'; Mux_Sel <= 'Z';
        END CASE;
    END PROCESS;
END behav;