transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {E:/quartus/shiyan4/PC.vhd}
vcom -93 -work work {E:/quartus/shiyan4/ALU_8b.vhd}
vcom -93 -work work {E:/quartus/shiyan4/AC_A.vhd}
vcom -93 -work work {E:/quartus/shiyan4/AC_S.vhd}
vcom -93 -work work {E:/quartus/shiyan4/seg7_16b.vhd}
vcom -93 -work work {E:/quartus/shiyan4/RAM.vhd}
vcom -93 -work work {E:/quartus/shiyan4/ROM.vhd}
vcom -93 -work work {E:/quartus/shiyan4/MUX_0.vhd}
vcom -93 -work work {E:/quartus/shiyan4/decoder.vhd}

