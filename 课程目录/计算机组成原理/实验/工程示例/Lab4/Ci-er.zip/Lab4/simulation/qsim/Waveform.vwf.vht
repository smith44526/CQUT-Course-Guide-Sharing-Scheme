-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "12/14/2025 14:40:36"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          controller
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY controller_vhd_vec_tst IS
END controller_vhd_vec_tst;
ARCHITECTURE controller_arch OF controller_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL B_T_CN_M : STD_LOGIC;
SIGNAL clk : STD_LOGIC;
SIGNAL M_CN : STD_LOGIC;
SIGNAL RQAddr1 : STD_LOGIC_VECTOR(6 DOWNTO 0);
SIGNAL RQAddr2 : STD_LOGIC_VECTOR(6 DOWNTO 0);
SIGNAL RQALU1 : STD_LOGIC_VECTOR(6 DOWNTO 0);
SIGNAL RQALU2 : STD_LOGIC_VECTOR(6 DOWNTO 0);
SIGNAL RQData1 : STD_LOGIC_VECTOR(6 DOWNTO 0);
SIGNAL RQData2 : STD_LOGIC_VECTOR(6 DOWNTO 0);
SIGNAL SOUT : STD_LOGIC_VECTOR(3 DOWNTO 0);
COMPONENT controller
	PORT (
	B_T_CN_M : IN STD_LOGIC;
	clk : IN STD_LOGIC;
	M_CN : IN STD_LOGIC;
	RQAddr1 : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
	RQAddr2 : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
	RQALU1 : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
	RQALU2 : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
	RQData1 : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
	RQData2 : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
	SOUT : OUT STD_LOGIC_VECTOR(3 DOWNTO 0)
	);
END COMPONENT;
BEGIN
	i1 : controller
	PORT MAP (
-- list connections between master ports and signals
	B_T_CN_M => B_T_CN_M,
	clk => clk,
	M_CN => M_CN,
	RQAddr1 => RQAddr1,
	RQAddr2 => RQAddr2,
	RQALU1 => RQALU1,
	RQALU2 => RQALU2,
	RQData1 => RQData1,
	RQData2 => RQData2,
	SOUT => SOUT
	);

-- B_T_CN_M
t_prcs_B_T_CN_M: PROCESS
BEGIN
LOOP
	B_T_CN_M <= '0';
	WAIT FOR 10000 ps;
	B_T_CN_M <= '1';
	WAIT FOR 10000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_B_T_CN_M;

-- clk
t_prcs_clk: PROCESS
BEGIN
LOOP
	clk <= '0';
	WAIT FOR 10000 ps;
	clk <= '1';
	WAIT FOR 10000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_clk;

-- M_CN
t_prcs_M_CN: PROCESS
BEGIN
	M_CN <= '0';
WAIT;
END PROCESS t_prcs_M_CN;
END controller_arch;
