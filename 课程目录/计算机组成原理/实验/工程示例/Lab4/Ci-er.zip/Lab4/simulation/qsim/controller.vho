-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 20.1.1 Build 720 11/11/2020 SJ Lite Edition"

-- DATE "12/14/2025 15:03:31"

-- 
-- Device: Altera 5CSEMA5F31C6 Package FBGA896
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY ALTERA_LNSIM;
LIBRARY CYCLONEV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE ALTERA_LNSIM.ALTERA_LNSIM_COMPONENTS.ALL;
USE CYCLONEV.CYCLONEV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	controller IS
    PORT (
	altera_reserved_tms : IN std_logic := '0';
	altera_reserved_tck : IN std_logic := '0';
	altera_reserved_tdi : IN std_logic := '0';
	altera_reserved_tdo : OUT std_logic;
	RQAddr1 : OUT std_logic_vector(6 DOWNTO 0);
	B_T_CN_M : IN std_logic;
	clk : IN std_logic;
	M_CN : IN std_logic;
	RQAddr2 : OUT std_logic_vector(6 DOWNTO 0);
	RQALU1 : OUT std_logic_vector(6 DOWNTO 0);
	RQALU2 : OUT std_logic_vector(6 DOWNTO 0);
	RQData1 : OUT std_logic_vector(6 DOWNTO 0);
	RQData2 : OUT std_logic_vector(6 DOWNTO 0);
	SOUT : OUT std_logic_vector(3 DOWNTO 0)
	);
END controller;

-- Design Ports Information
-- RQAddr1[6]	=>  Location: PIN_AB23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[5]	=>  Location: PIN_AE29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[4]	=>  Location: PIN_AD29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[3]	=>  Location: PIN_AC28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[2]	=>  Location: PIN_AD30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[1]	=>  Location: PIN_AC29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr1[0]	=>  Location: PIN_AC30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[6]	=>  Location: PIN_AD26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[5]	=>  Location: PIN_AC27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[4]	=>  Location: PIN_AD25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[3]	=>  Location: PIN_AC25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[2]	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[1]	=>  Location: PIN_AB25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQAddr2[0]	=>  Location: PIN_AB22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[6]	=>  Location: PIN_AE26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[5]	=>  Location: PIN_AE27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[4]	=>  Location: PIN_AE28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[3]	=>  Location: PIN_AG27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[2]	=>  Location: PIN_AF28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[1]	=>  Location: PIN_AG28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU1[0]	=>  Location: PIN_AH28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[6]	=>  Location: PIN_AJ29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[5]	=>  Location: PIN_AH29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[4]	=>  Location: PIN_AH30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[3]	=>  Location: PIN_AG30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[2]	=>  Location: PIN_AF29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[1]	=>  Location: PIN_AF30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQALU2[0]	=>  Location: PIN_AD27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[6]	=>  Location: PIN_AA24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[5]	=>  Location: PIN_Y23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[4]	=>  Location: PIN_Y24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[3]	=>  Location: PIN_W22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[2]	=>  Location: PIN_W24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[1]	=>  Location: PIN_V23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData1[0]	=>  Location: PIN_W25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[6]	=>  Location: PIN_V25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[5]	=>  Location: PIN_AA28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[4]	=>  Location: PIN_Y27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[3]	=>  Location: PIN_AB27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[2]	=>  Location: PIN_AB26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[1]	=>  Location: PIN_AA26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RQData2[0]	=>  Location: PIN_AA25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SOUT[3]	=>  Location: PIN_V18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SOUT[2]	=>  Location: PIN_V17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SOUT[1]	=>  Location: PIN_W16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SOUT[0]	=>  Location: PIN_V16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- B_T_CN_M	=>  Location: PIN_AE12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_AA14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- M_CN	=>  Location: PIN_AD10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- altera_reserved_tms	=>  Location: PIN_V9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- altera_reserved_tck	=>  Location: PIN_AC5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- altera_reserved_tdi	=>  Location: PIN_U8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- altera_reserved_tdo	=>  Location: PIN_AB9,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF controller IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_altera_reserved_tms : std_logic;
SIGNAL ww_altera_reserved_tck : std_logic;
SIGNAL ww_altera_reserved_tdi : std_logic;
SIGNAL ww_altera_reserved_tdo : std_logic;
SIGNAL ww_RQAddr1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_B_T_CN_M : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_M_CN : std_logic;
SIGNAL ww_RQAddr2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQALU1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQALU2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQData1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_RQData2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_SOUT : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAIN_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAIN_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTAADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][6]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][7]~q\ : std_logic;
SIGNAL \auto_hub|~GND~combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~_wirecell_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[0]~_wirecell_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputCLKENA0_outclk\ : std_logic;
SIGNAL \inst16|Add0~1_sumout\ : std_logic;
SIGNAL \inst16|Add0~2\ : std_logic;
SIGNAL \inst16|Add0~5_sumout\ : std_logic;
SIGNAL \inst16|Add0~6\ : std_logic;
SIGNAL \inst16|Add0~9_sumout\ : std_logic;
SIGNAL \inst16|Add0~10\ : std_logic;
SIGNAL \inst16|Add0~13_sumout\ : std_logic;
SIGNAL \inst16|Add0~14\ : std_logic;
SIGNAL \inst16|Add0~17_sumout\ : std_logic;
SIGNAL \inst16|Add0~18\ : std_logic;
SIGNAL \inst16|Add0~21_sumout\ : std_logic;
SIGNAL \inst16|Add0~22\ : std_logic;
SIGNAL \inst16|Add0~25_sumout\ : std_logic;
SIGNAL \inst16|Add0~26\ : std_logic;
SIGNAL \inst16|Add0~29_sumout\ : std_logic;
SIGNAL \M_CN~input_o\ : std_logic;
SIGNAL \inst18|Mux2~0_combout\ : std_logic;
SIGNAL \inst16|PC_out[7]~reg0_q\ : std_logic;
SIGNAL \inst16|PC_out[6]~reg0_q\ : std_logic;
SIGNAL \inst16|PC_out[5]~reg0_q\ : std_logic;
SIGNAL \inst16|PC_out[4]~reg0_q\ : std_logic;
SIGNAL \inst16|PC_out[3]~reg0_q\ : std_logic;
SIGNAL \inst16|PC_out[2]~reg0_q\ : std_logic;
SIGNAL \inst16|PC_out[1]~reg0_q\ : std_logic;
SIGNAL \inst16|PC_out[0]~reg0_q\ : std_logic;
SIGNAL \inst18|Mux4~0_combout\ : std_logic;
SIGNAL \inst18|Mux3~0_combout\ : std_logic;
SIGNAL \altera_reserved_tms~input_o\ : std_logic;
SIGNAL \altera_reserved_tck~input_o\ : std_logic;
SIGNAL \altera_reserved_tdi~input_o\ : std_logic;
SIGNAL \altera_internal_jtag~TMSUTAP\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~8_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~9_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~12_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~13_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~10_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~11_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~7_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~1_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[0]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~0_combout\ : std_logic;
SIGNAL \altera_internal_jtag~TDIUTAP\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[7]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[6]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[4]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[3]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[2]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[1]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[0]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_dr_scan_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal1~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[8]~feeder_combout\ : std_logic;
SIGNAL \~QIC_CREATED_GND~I_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0[3]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~7_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~14_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[0]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal3~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[0]~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~5_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[2]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~8_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][3]~q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_incr_addr~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]~q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~DUPLICATE_q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[0]~2_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[2]~1_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~2\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~5_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[1]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~6\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~9_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[2]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~10\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~13_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[3]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~14\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~17_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[4]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~18\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~21_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~22\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~25_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[6]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~26\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~29_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[5]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~12_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~11_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~10_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~9_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|clear_signal~combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[4]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[3]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[1]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[1]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[2]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~7_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~9_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[3]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~10_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~8_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~2_combout\ : std_logic;
SIGNAL \inst18|Mux12~0_combout\ : std_logic;
SIGNAL \inst18|Mux13~0_combout\ : std_logic;
SIGNAL \inst|S[3]~DUPLICATE_q\ : std_logic;
SIGNAL \inst18|Mux10~0_combout\ : std_logic;
SIGNAL \inst2|Mux5~1_combout\ : std_logic;
SIGNAL \inst2|Mux5~0_combout\ : std_logic;
SIGNAL \inst2|Mux5~2_combout\ : std_logic;
SIGNAL \inst2|Add7~2\ : std_logic;
SIGNAL \inst2|Add7~6\ : std_logic;
SIGNAL \inst2|Add7~10\ : std_logic;
SIGNAL \inst2|Add7~13_sumout\ : std_logic;
SIGNAL \inst2|Add6~30_cout\ : std_logic;
SIGNAL \inst2|Add6~2\ : std_logic;
SIGNAL \inst2|Add6~6\ : std_logic;
SIGNAL \inst2|Add6~9_sumout\ : std_logic;
SIGNAL \inst2|Mux5~7_combout\ : std_logic;
SIGNAL \inst2|Mux5~3_combout\ : std_logic;
SIGNAL \inst2|F9~2_combout\ : std_logic;
SIGNAL \inst2|Add5~30_cout\ : std_logic;
SIGNAL \inst2|Add5~2\ : std_logic;
SIGNAL \inst2|Add5~6\ : std_logic;
SIGNAL \inst2|Add5~9_sumout\ : std_logic;
SIGNAL \inst2|Mux5~5_combout\ : std_logic;
SIGNAL \inst2|Add3~30_cout\ : std_logic;
SIGNAL \inst2|Add3~2\ : std_logic;
SIGNAL \inst2|Add3~6\ : std_logic;
SIGNAL \inst2|Add3~9_sumout\ : std_logic;
SIGNAL \inst2|Add4~2\ : std_logic;
SIGNAL \inst2|Add4~6\ : std_logic;
SIGNAL \inst2|Add4~10\ : std_logic;
SIGNAL \inst2|Add4~13_sumout\ : std_logic;
SIGNAL \inst2|Mux5~4_combout\ : std_logic;
SIGNAL \inst2|Mux5~6_combout\ : std_logic;
SIGNAL \inst2|Add2~2\ : std_logic;
SIGNAL \inst2|Add2~3\ : std_logic;
SIGNAL \inst2|Add2~6\ : std_logic;
SIGNAL \inst2|Add2~7\ : std_logic;
SIGNAL \inst2|Add2~10\ : std_logic;
SIGNAL \inst2|Add2~11\ : std_logic;
SIGNAL \inst2|Add2~13_sumout\ : std_logic;
SIGNAL \inst2|Mux5~15_combout\ : std_logic;
SIGNAL \inst2|Add0~2\ : std_logic;
SIGNAL \inst2|Add0~6\ : std_logic;
SIGNAL \inst2|Add0~10\ : std_logic;
SIGNAL \inst2|Add0~13_sumout\ : std_logic;
SIGNAL \inst2|Add1~14_cout\ : std_logic;
SIGNAL \inst2|Add1~2\ : std_logic;
SIGNAL \inst2|Add1~6\ : std_logic;
SIGNAL \inst2|Add1~9_sumout\ : std_logic;
SIGNAL \inst2|Mux5~11_combout\ : std_logic;
SIGNAL \inst2|Mux5~8_combout\ : std_logic;
SIGNAL \inst2|Mux5~9_combout\ : std_logic;
SIGNAL \inst2|Mux5~10_combout\ : std_logic;
SIGNAL \inst18|Mux5~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[7]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[6]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[5]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[4]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[3]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[2]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~feeder_combout\ : std_logic;
SIGNAL \inst2|Add6~10\ : std_logic;
SIGNAL \inst2|Add6~14\ : std_logic;
SIGNAL \inst2|Add6~18\ : std_logic;
SIGNAL \inst2|Add6~22\ : std_logic;
SIGNAL \inst2|Add6~25_sumout\ : std_logic;
SIGNAL \inst2|Add7~14\ : std_logic;
SIGNAL \inst2|Add7~18\ : std_logic;
SIGNAL \inst2|Add7~22\ : std_logic;
SIGNAL \inst2|Add7~26\ : std_logic;
SIGNAL \inst2|Add7~29_sumout\ : std_logic;
SIGNAL \inst2|Mux1~2_combout\ : std_logic;
SIGNAL \inst2|Add3~10\ : std_logic;
SIGNAL \inst2|Add3~14\ : std_logic;
SIGNAL \inst2|Add3~18\ : std_logic;
SIGNAL \inst2|Add3~22\ : std_logic;
SIGNAL \inst2|Add3~25_sumout\ : std_logic;
SIGNAL \inst2|F9~6_combout\ : std_logic;
SIGNAL \inst2|Add5~10\ : std_logic;
SIGNAL \inst2|Add5~14\ : std_logic;
SIGNAL \inst2|Add5~18\ : std_logic;
SIGNAL \inst2|Add5~22\ : std_logic;
SIGNAL \inst2|Add5~25_sumout\ : std_logic;
SIGNAL \inst2|Mux1~0_combout\ : std_logic;
SIGNAL \inst2|Add4~14\ : std_logic;
SIGNAL \inst2|Add4~18\ : std_logic;
SIGNAL \inst2|Add4~22\ : std_logic;
SIGNAL \inst2|Add4~26\ : std_logic;
SIGNAL \inst2|Add4~29_sumout\ : std_logic;
SIGNAL \inst2|Mux1~1_combout\ : std_logic;
SIGNAL \inst2|Add2~14\ : std_logic;
SIGNAL \inst2|Add2~15\ : std_logic;
SIGNAL \inst2|Add2~18\ : std_logic;
SIGNAL \inst2|Add2~19\ : std_logic;
SIGNAL \inst2|Add2~22\ : std_logic;
SIGNAL \inst2|Add2~23\ : std_logic;
SIGNAL \inst2|Add2~26\ : std_logic;
SIGNAL \inst2|Add2~27\ : std_logic;
SIGNAL \inst2|Add2~29_sumout\ : std_logic;
SIGNAL \inst2|Add0~14\ : std_logic;
SIGNAL \inst2|Add0~18\ : std_logic;
SIGNAL \inst2|Add0~22\ : std_logic;
SIGNAL \inst2|Add0~26\ : std_logic;
SIGNAL \inst2|Add0~29_sumout\ : std_logic;
SIGNAL \inst2|Mux1~5_combout\ : std_logic;
SIGNAL \inst2|Mux1~3_combout\ : std_logic;
SIGNAL \inst2|Mux1~4_combout\ : std_logic;
SIGNAL \inst2|Add2~25_sumout\ : std_logic;
SIGNAL \inst2|Add0~25_sumout\ : std_logic;
SIGNAL \inst2|Mux2~5_combout\ : std_logic;
SIGNAL \inst2|Add6~21_sumout\ : std_logic;
SIGNAL \inst2|Add7~25_sumout\ : std_logic;
SIGNAL \inst2|Mux2~2_combout\ : std_logic;
SIGNAL \inst2|Add5~21_sumout\ : std_logic;
SIGNAL \inst2|Mux2~0_combout\ : std_logic;
SIGNAL \inst2|Add4~25_sumout\ : std_logic;
SIGNAL \inst2|Add3~21_sumout\ : std_logic;
SIGNAL \inst2|F9~5_combout\ : std_logic;
SIGNAL \inst2|Mux2~1_combout\ : std_logic;
SIGNAL \inst2|Mux2~3_combout\ : std_logic;
SIGNAL \inst2|Mux2~4_combout\ : std_logic;
SIGNAL \inst2|Add5~17_sumout\ : std_logic;
SIGNAL \inst2|Mux3~0_combout\ : std_logic;
SIGNAL \inst2|Add3~17_sumout\ : std_logic;
SIGNAL \inst2|F9~4_combout\ : std_logic;
SIGNAL \inst2|Add4~21_sumout\ : std_logic;
SIGNAL \inst2|Mux3~1_combout\ : std_logic;
SIGNAL \inst2|Add2~21_sumout\ : std_logic;
SIGNAL \inst2|Add0~21_sumout\ : std_logic;
SIGNAL \inst2|Mux3~5_combout\ : std_logic;
SIGNAL \inst2|Add7~21_sumout\ : std_logic;
SIGNAL \inst2|Add6~17_sumout\ : std_logic;
SIGNAL \inst2|Mux3~2_combout\ : std_logic;
SIGNAL \inst2|Mux3~3_combout\ : std_logic;
SIGNAL \inst2|Mux3~4_combout\ : std_logic;
SIGNAL \inst10|A[5]~feeder_combout\ : std_logic;
SIGNAL \inst10|A[5]~DUPLICATE_q\ : std_logic;
SIGNAL \inst2|Add6~13_sumout\ : std_logic;
SIGNAL \inst2|Add7~17_sumout\ : std_logic;
SIGNAL \inst2|Mux4~2_combout\ : std_logic;
SIGNAL \inst2|Add5~13_sumout\ : std_logic;
SIGNAL \inst2|Mux4~0_combout\ : std_logic;
SIGNAL \inst2|Add3~13_sumout\ : std_logic;
SIGNAL \inst2|Add4~17_sumout\ : std_logic;
SIGNAL \inst2|F9~3_combout\ : std_logic;
SIGNAL \inst2|Mux4~1_combout\ : std_logic;
SIGNAL \inst2|Add2~17_sumout\ : std_logic;
SIGNAL \inst2|Add0~17_sumout\ : std_logic;
SIGNAL \inst2|Mux4~5_combout\ : std_logic;
SIGNAL \inst2|Mux4~3_combout\ : std_logic;
SIGNAL \inst2|Mux4~4_combout\ : std_logic;
SIGNAL \inst10|A[4]~feeder_combout\ : std_logic;
SIGNAL \inst2|Add3~5_sumout\ : std_logic;
SIGNAL \inst2|Add5~5_sumout\ : std_logic;
SIGNAL \inst2|Mux6~0_combout\ : std_logic;
SIGNAL \inst2|Add4~9_sumout\ : std_logic;
SIGNAL \inst2|F9~1_combout\ : std_logic;
SIGNAL \inst2|Mux6~1_combout\ : std_logic;
SIGNAL \inst2|Add0~9_sumout\ : std_logic;
SIGNAL \inst2|Add2~9_sumout\ : std_logic;
SIGNAL \inst2|Mux6~10_combout\ : std_logic;
SIGNAL \inst2|Add1~5_sumout\ : std_logic;
SIGNAL \inst2|Mux6~6_combout\ : std_logic;
SIGNAL \inst2|Mux6~3_combout\ : std_logic;
SIGNAL \inst2|Add6~5_sumout\ : std_logic;
SIGNAL \inst2|Add7~9_sumout\ : std_logic;
SIGNAL \inst2|Mux6~2_combout\ : std_logic;
SIGNAL \inst2|Mux6~4_combout\ : std_logic;
SIGNAL \inst2|Mux6~5_combout\ : std_logic;
SIGNAL \inst2|Mux7~10_combout\ : std_logic;
SIGNAL \inst2|Add2~5_sumout\ : std_logic;
SIGNAL \inst2|Add0~5_sumout\ : std_logic;
SIGNAL \inst2|Add1~1_sumout\ : std_logic;
SIGNAL \inst2|Mux7~6_combout\ : std_logic;
SIGNAL \inst2|Mux7~3_combout\ : std_logic;
SIGNAL \inst2|Add7~5_sumout\ : std_logic;
SIGNAL \inst2|Add6~1_sumout\ : std_logic;
SIGNAL \inst2|Mux7~2_combout\ : std_logic;
SIGNAL \inst2|F9~0_combout\ : std_logic;
SIGNAL \inst2|Add4~5_sumout\ : std_logic;
SIGNAL \inst2|Add5~1_sumout\ : std_logic;
SIGNAL \inst2|Mux7~0_combout\ : std_logic;
SIGNAL \inst2|Add3~1_sumout\ : std_logic;
SIGNAL \inst2|Mux7~1_combout\ : std_logic;
SIGNAL \inst2|Mux7~4_combout\ : std_logic;
SIGNAL \inst2|Mux7~5_combout\ : std_logic;
SIGNAL \inst10|A[1]~feeder_combout\ : std_logic;
SIGNAL \inst2|Add4~1_sumout\ : std_logic;
SIGNAL \inst2|Mux8~1_combout\ : std_logic;
SIGNAL \inst2|Add7~1_sumout\ : std_logic;
SIGNAL \inst2|Mux8~0_combout\ : std_logic;
SIGNAL \inst2|Add2~1_sumout\ : std_logic;
SIGNAL \inst2|Add0~1_sumout\ : std_logic;
SIGNAL \inst2|Mux8~3_combout\ : std_logic;
SIGNAL \inst2|Mux8~2_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~feeder_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|clear_signal~combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~1_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~2_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~5_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~3_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|Equal0~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~DUPLICATE_q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~4_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~3_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~5_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~7_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~8_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~6_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~4_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|adapted_tdo~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo~q\ : std_logic;
SIGNAL \altera_internal_jtag~TCKUTAP\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~feeder_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|enable_write~0_combout\ : std_logic;
SIGNAL \B_T_CN_M~input_o\ : std_logic;
SIGNAL \inst7|Mux0~0_combout\ : std_logic;
SIGNAL \inst7|Mux1~0_combout\ : std_logic;
SIGNAL \inst7|Mux2~0_combout\ : std_logic;
SIGNAL \inst7|Mux3~0_combout\ : std_logic;
SIGNAL \inst7|Mux4~0_combout\ : std_logic;
SIGNAL \inst7|Mux5~0_combout\ : std_logic;
SIGNAL \inst7|Mux6~0_combout\ : std_logic;
SIGNAL \inst7|Mux7~0_combout\ : std_logic;
SIGNAL \inst7|Mux8~0_combout\ : std_logic;
SIGNAL \inst7|Mux9~0_combout\ : std_logic;
SIGNAL \inst7|Mux10~0_combout\ : std_logic;
SIGNAL \inst7|Mux11~0_combout\ : std_logic;
SIGNAL \inst7|Mux12~0_combout\ : std_logic;
SIGNAL \inst7|Mux13~0_combout\ : std_logic;
SIGNAL \inst8|Mux0~0_combout\ : std_logic;
SIGNAL \inst8|Mux1~0_combout\ : std_logic;
SIGNAL \inst8|Mux2~0_combout\ : std_logic;
SIGNAL \inst8|Mux3~0_combout\ : std_logic;
SIGNAL \inst8|Mux4~0_combout\ : std_logic;
SIGNAL \inst8|Mux5~0_combout\ : std_logic;
SIGNAL \inst8|Mux6~0_combout\ : std_logic;
SIGNAL \inst8|Mux7~0_combout\ : std_logic;
SIGNAL \inst8|Mux8~0_combout\ : std_logic;
SIGNAL \inst8|Mux9~0_combout\ : std_logic;
SIGNAL \inst8|Mux10~0_combout\ : std_logic;
SIGNAL \inst8|Mux11~0_combout\ : std_logic;
SIGNAL \inst8|Mux12~0_combout\ : std_logic;
SIGNAL \inst8|Mux13~0_combout\ : std_logic;
SIGNAL \inst9|Mux0~0_combout\ : std_logic;
SIGNAL \inst9|Mux1~0_combout\ : std_logic;
SIGNAL \inst9|Mux2~0_combout\ : std_logic;
SIGNAL \inst9|Mux3~0_combout\ : std_logic;
SIGNAL \inst9|Mux4~0_combout\ : std_logic;
SIGNAL \inst9|Mux5~0_combout\ : std_logic;
SIGNAL \inst9|Mux6~0_combout\ : std_logic;
SIGNAL \inst9|Mux7~0_combout\ : std_logic;
SIGNAL \inst9|Mux8~0_combout\ : std_logic;
SIGNAL \inst9|Mux9~0_combout\ : std_logic;
SIGNAL \inst9|Mux10~0_combout\ : std_logic;
SIGNAL \inst9|Mux11~0_combout\ : std_logic;
SIGNAL \inst9|Mux12~0_combout\ : std_logic;
SIGNAL \inst9|Mux13~0_combout\ : std_logic;
SIGNAL \altera_internal_jtag~TDO\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|altsyncram1|q_b\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst10|A\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \inst|S\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst6|altsyncram_component|auto_generated|q_a\ : std_logic_vector(31 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\ : std_logic_vector(6 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\ : std_logic_vector(8 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0\ : std_logic_vector(30 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\ : std_logic_vector(9 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst2|ALT_INV_Add6~1_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add7~5_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add4~5_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add3~1_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add5~1_sumout\ : std_logic;
SIGNAL \inst10|ALT_INV_A\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst2|ALT_INV_Add7~1_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add4~1_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add2~1_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\ : std_logic_vector(31 DOWNTO 28);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg\ : std_logic_vector(0 DOWNTO 0);
SIGNAL \inst2|ALT_INV_Add2~29_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add6~25_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add7~29_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add4~29_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add3~25_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add5~25_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add2~25_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add6~21_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add7~25_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add4~25_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add3~21_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add5~21_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add2~21_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add6~17_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add7~21_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add4~21_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add3~17_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add5~17_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add2~17_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add6~13_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add7~17_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add4~17_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add3~13_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add5~13_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add2~13_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add1~9_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add6~9_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add7~13_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add4~13_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add3~9_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add5~9_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add2~9_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add1~5_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add6~5_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add7~9_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add4~9_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add3~5_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add5~5_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add2~5_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_Add1~1_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_F9~6_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux1~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux2~4_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux2~3_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux2~2_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux2~1_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_F9~5_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux2~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux3~4_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux3~3_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux3~2_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux3~1_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_F9~4_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux3~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux4~4_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux4~3_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux4~2_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux4~1_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_F9~3_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux4~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~10_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~9_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~8_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~7_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~6_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_F9~2_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~5_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux6~5_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux6~4_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux6~3_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux6~2_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux6~1_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_F9~1_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux7~5_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux7~4_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux7~3_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux7~2_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux7~1_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~4_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~3_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_F9~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux7~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~2_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~1_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux8~2_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux8~1_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux8~0_combout\ : std_logic;
SIGNAL \inst|ALT_INV_S\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst2|ALT_INV_Mux8~3_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux7~6_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux6~6_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~11_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux4~5_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux3~5_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux2~5_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux1~5_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_adapted_tdo~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \inst16|ALT_INV_PC_out[7]~reg0_q\ : std_logic;
SIGNAL \inst16|ALT_INV_PC_out[6]~reg0_q\ : std_logic;
SIGNAL \inst16|ALT_INV_PC_out[5]~reg0_q\ : std_logic;
SIGNAL \inst16|ALT_INV_PC_out[4]~reg0_q\ : std_logic;
SIGNAL \inst16|ALT_INV_PC_out[3]~reg0_q\ : std_logic;
SIGNAL \inst16|ALT_INV_PC_out[2]~reg0_q\ : std_logic;
SIGNAL \inst16|ALT_INV_PC_out[1]~reg0_q\ : std_logic;
SIGNAL \inst16|ALT_INV_PC_out[0]~reg0_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\ : std_logic_vector(8 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \ALT_INV_altera_internal_jtag~TDIUTAP\ : std_logic;
SIGNAL \ALT_INV_altera_internal_jtag~TCKUTAP\ : std_logic;
SIGNAL \ALT_INV_altera_internal_jtag~TMSUTAP\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux7~10_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux6~10_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux5~15_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~7_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~5_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_clear_signal~combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_Equal0~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~3_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_incr_addr~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~3_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[1]~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_bypass_reg_out~q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\ : std_logic_vector(6 DOWNTO 0);
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~q\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux1~4_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux1~3_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux1~2_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_Mux1~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[2]~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[1]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal0~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\ : std_logic_vector(9 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena_proc~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~4_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~3_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~1_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_bypass_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_info_reg_ena~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][5]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][4]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\ : std_logic_vector(3 DOWNTO 3);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[2]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[4]~DUPLICATE_q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg[1]~DUPLICATE_q\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg[3]~DUPLICATE_q\ : std_logic;
SIGNAL \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\ : std_logic;
SIGNAL \inst|ALT_INV_S[3]~DUPLICATE_q\ : std_logic;
SIGNAL \inst10|ALT_INV_A[5]~DUPLICATE_q\ : std_logic;
SIGNAL \ALT_INV_clk~inputCLKENA0_outclk\ : std_logic;
SIGNAL \ALT_INV_B_T_CN_M~input_o\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~9_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~7_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~2_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~5_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal3~0_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state~14_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~7_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~6_combout\ : std_logic;
SIGNAL \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[2]~5_combout\ : std_logic;

BEGIN

ww_altera_reserved_tms <= altera_reserved_tms;
ww_altera_reserved_tck <= altera_reserved_tck;
ww_altera_reserved_tdi <= altera_reserved_tdi;
altera_reserved_tdo <= ww_altera_reserved_tdo;
RQAddr1 <= ww_RQAddr1;
ww_B_T_CN_M <= B_T_CN_M;
ww_clk <= clk;
ww_M_CN <= M_CN;
RQAddr2 <= ww_RQAddr2;
RQALU1 <= ww_RQALU1;
RQALU2 <= ww_RQALU2;
RQData1 <= ww_RQData1;
RQData2 <= ww_RQData2;
SOUT <= ww_SOUT;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAIN_bus\ <= (gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & \inst10|A\(7) & \inst10|A\(6) & \inst10|A[5]~DUPLICATE_q\ & \inst10|A\(4) & 
\inst10|A\(3) & \inst10|A\(2) & \inst10|A\(1) & \inst10|A\(0));

\inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAIN_bus\ <= (gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(7) & 
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(6) & \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(5) & \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(4) & 
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(3) & \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(2) & \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(1) & 
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(0));

\inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTAADDR_bus\ <= (\inst6|altsyncram_component|auto_generated|q_a\(7) & \inst6|altsyncram_component|auto_generated|q_a\(6) & \inst6|altsyncram_component|auto_generated|q_a\(5) & 
\inst6|altsyncram_component|auto_generated|q_a\(4) & \inst6|altsyncram_component|auto_generated|q_a\(3) & \inst6|altsyncram_component|auto_generated|q_a\(2) & \inst6|altsyncram_component|auto_generated|q_a\(1) & 
\inst6|altsyncram_component|auto_generated|q_a\(0));

\inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBADDR_bus\ <= (\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(7) & \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(6) & 
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(5) & \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(4) & \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(3) & 
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(2) & \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(1) & \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(0));

\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(0);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(1);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(2);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(3);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(4);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(5);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(6);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\(7);

\inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(0) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(0);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(1) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(1);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(2) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(2);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(3) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(3);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(4) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(4);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(5) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(5);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(6) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(6);
\inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(7) <= \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\(7);

\inst6|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\ <= (\inst16|PC_out[7]~reg0_q\ & \inst16|PC_out[6]~reg0_q\ & \inst16|PC_out[5]~reg0_q\ & \inst16|PC_out[4]~reg0_q\ & \inst16|PC_out[3]~reg0_q\ & \inst16|PC_out[2]~reg0_q\ & 
\inst16|PC_out[1]~reg0_q\ & \inst16|PC_out[0]~reg0_q\);

\inst6|altsyncram_component|auto_generated|q_a\(0) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(0);
\inst6|altsyncram_component|auto_generated|q_a\(1) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(1);
\inst6|altsyncram_component|auto_generated|q_a\(2) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(2);
\inst6|altsyncram_component|auto_generated|q_a\(3) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(3);
\inst6|altsyncram_component|auto_generated|q_a\(4) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(4);
\inst6|altsyncram_component|auto_generated|q_a\(5) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(5);
\inst6|altsyncram_component|auto_generated|q_a\(6) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(6);
\inst6|altsyncram_component|auto_generated|q_a\(7) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(7);
\inst6|altsyncram_component|auto_generated|q_a\(28) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(8);
\inst6|altsyncram_component|auto_generated|q_a\(29) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(9);
\inst6|altsyncram_component|auto_generated|q_a\(30) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(10);
\inst6|altsyncram_component|auto_generated|q_a\(31) <= \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(11);
\inst2|ALT_INV_Add6~1_sumout\ <= NOT \inst2|Add6~1_sumout\;
\inst2|ALT_INV_Add7~5_sumout\ <= NOT \inst2|Add7~5_sumout\;
\inst2|ALT_INV_Add4~5_sumout\ <= NOT \inst2|Add4~5_sumout\;
\inst2|ALT_INV_Add3~1_sumout\ <= NOT \inst2|Add3~1_sumout\;
\inst2|ALT_INV_Add5~1_sumout\ <= NOT \inst2|Add5~1_sumout\;
\inst10|ALT_INV_A\(1) <= NOT \inst10|A\(1);
\inst2|ALT_INV_Add7~1_sumout\ <= NOT \inst2|Add7~1_sumout\;
\inst2|ALT_INV_Add4~1_sumout\ <= NOT \inst2|Add4~1_sumout\;
\inst10|ALT_INV_A\(0) <= NOT \inst10|A\(0);
\inst2|ALT_INV_Add2~1_sumout\ <= NOT \inst2|Add2~1_sumout\;
\inst2|ALT_INV_Add0~1_sumout\ <= NOT \inst2|Add0~1_sumout\;
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(1) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(1);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(2) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(2);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(3) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(3);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(4) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(4);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(5) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(5);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(6) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(6);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(7) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(7);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(0) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_b\(0);
\inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0) <= NOT \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(7) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(7);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(6) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(6);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(5) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(5);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(4) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(4);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(3) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(3);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(2) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(2);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(1) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(1);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(0) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(0);
\inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(28) <= NOT \inst6|altsyncram_component|auto_generated|q_a\(28);
\inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29) <= NOT \inst6|altsyncram_component|auto_generated|q_a\(29);
\inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(30) <= NOT \inst6|altsyncram_component|auto_generated|q_a\(30);
\inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(31) <= NOT \inst6|altsyncram_component|auto_generated|q_a\(31);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg\(0) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(0);
\inst2|ALT_INV_Add2~29_sumout\ <= NOT \inst2|Add2~29_sumout\;
\inst2|ALT_INV_Add0~29_sumout\ <= NOT \inst2|Add0~29_sumout\;
\inst2|ALT_INV_Add6~25_sumout\ <= NOT \inst2|Add6~25_sumout\;
\inst2|ALT_INV_Add7~29_sumout\ <= NOT \inst2|Add7~29_sumout\;
\inst2|ALT_INV_Add4~29_sumout\ <= NOT \inst2|Add4~29_sumout\;
\inst2|ALT_INV_Add3~25_sumout\ <= NOT \inst2|Add3~25_sumout\;
\inst2|ALT_INV_Add5~25_sumout\ <= NOT \inst2|Add5~25_sumout\;
\inst10|ALT_INV_A\(7) <= NOT \inst10|A\(7);
\inst2|ALT_INV_Add2~25_sumout\ <= NOT \inst2|Add2~25_sumout\;
\inst2|ALT_INV_Add0~25_sumout\ <= NOT \inst2|Add0~25_sumout\;
\inst2|ALT_INV_Add6~21_sumout\ <= NOT \inst2|Add6~21_sumout\;
\inst2|ALT_INV_Add7~25_sumout\ <= NOT \inst2|Add7~25_sumout\;
\inst2|ALT_INV_Add4~25_sumout\ <= NOT \inst2|Add4~25_sumout\;
\inst2|ALT_INV_Add3~21_sumout\ <= NOT \inst2|Add3~21_sumout\;
\inst2|ALT_INV_Add5~21_sumout\ <= NOT \inst2|Add5~21_sumout\;
\inst10|ALT_INV_A\(6) <= NOT \inst10|A\(6);
\inst2|ALT_INV_Add2~21_sumout\ <= NOT \inst2|Add2~21_sumout\;
\inst2|ALT_INV_Add0~21_sumout\ <= NOT \inst2|Add0~21_sumout\;
\inst2|ALT_INV_Add6~17_sumout\ <= NOT \inst2|Add6~17_sumout\;
\inst2|ALT_INV_Add7~21_sumout\ <= NOT \inst2|Add7~21_sumout\;
\inst2|ALT_INV_Add4~21_sumout\ <= NOT \inst2|Add4~21_sumout\;
\inst2|ALT_INV_Add3~17_sumout\ <= NOT \inst2|Add3~17_sumout\;
\inst2|ALT_INV_Add5~17_sumout\ <= NOT \inst2|Add5~17_sumout\;
\inst10|ALT_INV_A\(5) <= NOT \inst10|A\(5);
\inst2|ALT_INV_Add2~17_sumout\ <= NOT \inst2|Add2~17_sumout\;
\inst2|ALT_INV_Add0~17_sumout\ <= NOT \inst2|Add0~17_sumout\;
\inst2|ALT_INV_Add6~13_sumout\ <= NOT \inst2|Add6~13_sumout\;
\inst2|ALT_INV_Add7~17_sumout\ <= NOT \inst2|Add7~17_sumout\;
\inst2|ALT_INV_Add4~17_sumout\ <= NOT \inst2|Add4~17_sumout\;
\inst2|ALT_INV_Add3~13_sumout\ <= NOT \inst2|Add3~13_sumout\;
\inst2|ALT_INV_Add5~13_sumout\ <= NOT \inst2|Add5~13_sumout\;
\inst10|ALT_INV_A\(4) <= NOT \inst10|A\(4);
\inst2|ALT_INV_Add2~13_sumout\ <= NOT \inst2|Add2~13_sumout\;
\inst2|ALT_INV_Add0~13_sumout\ <= NOT \inst2|Add0~13_sumout\;
\inst2|ALT_INV_Add1~9_sumout\ <= NOT \inst2|Add1~9_sumout\;
\inst2|ALT_INV_Add6~9_sumout\ <= NOT \inst2|Add6~9_sumout\;
\inst2|ALT_INV_Add7~13_sumout\ <= NOT \inst2|Add7~13_sumout\;
\inst2|ALT_INV_Add4~13_sumout\ <= NOT \inst2|Add4~13_sumout\;
\inst2|ALT_INV_Add3~9_sumout\ <= NOT \inst2|Add3~9_sumout\;
\inst2|ALT_INV_Add5~9_sumout\ <= NOT \inst2|Add5~9_sumout\;
\inst10|ALT_INV_A\(3) <= NOT \inst10|A\(3);
\inst2|ALT_INV_Add2~9_sumout\ <= NOT \inst2|Add2~9_sumout\;
\inst2|ALT_INV_Add0~9_sumout\ <= NOT \inst2|Add0~9_sumout\;
\inst2|ALT_INV_Add1~5_sumout\ <= NOT \inst2|Add1~5_sumout\;
\inst2|ALT_INV_Add6~5_sumout\ <= NOT \inst2|Add6~5_sumout\;
\inst2|ALT_INV_Add7~9_sumout\ <= NOT \inst2|Add7~9_sumout\;
\inst2|ALT_INV_Add4~9_sumout\ <= NOT \inst2|Add4~9_sumout\;
\inst2|ALT_INV_Add3~5_sumout\ <= NOT \inst2|Add3~5_sumout\;
\inst2|ALT_INV_Add5~5_sumout\ <= NOT \inst2|Add5~5_sumout\;
\inst10|ALT_INV_A\(2) <= NOT \inst10|A\(2);
\inst2|ALT_INV_Add2~5_sumout\ <= NOT \inst2|Add2~5_sumout\;
\inst2|ALT_INV_Add0~5_sumout\ <= NOT \inst2|Add0~5_sumout\;
\inst2|ALT_INV_Add1~1_sumout\ <= NOT \inst2|Add1~1_sumout\;
\inst2|ALT_INV_F9~6_combout\ <= NOT \inst2|F9~6_combout\;
\inst2|ALT_INV_Mux1~0_combout\ <= NOT \inst2|Mux1~0_combout\;
\inst2|ALT_INV_Mux2~4_combout\ <= NOT \inst2|Mux2~4_combout\;
\inst2|ALT_INV_Mux2~3_combout\ <= NOT \inst2|Mux2~3_combout\;
\inst2|ALT_INV_Mux2~2_combout\ <= NOT \inst2|Mux2~2_combout\;
\inst2|ALT_INV_Mux2~1_combout\ <= NOT \inst2|Mux2~1_combout\;
\inst2|ALT_INV_F9~5_combout\ <= NOT \inst2|F9~5_combout\;
\inst2|ALT_INV_Mux2~0_combout\ <= NOT \inst2|Mux2~0_combout\;
\inst2|ALT_INV_Mux3~4_combout\ <= NOT \inst2|Mux3~4_combout\;
\inst2|ALT_INV_Mux3~3_combout\ <= NOT \inst2|Mux3~3_combout\;
\inst2|ALT_INV_Mux3~2_combout\ <= NOT \inst2|Mux3~2_combout\;
\inst2|ALT_INV_Mux3~1_combout\ <= NOT \inst2|Mux3~1_combout\;
\inst2|ALT_INV_F9~4_combout\ <= NOT \inst2|F9~4_combout\;
\inst2|ALT_INV_Mux3~0_combout\ <= NOT \inst2|Mux3~0_combout\;
\inst2|ALT_INV_Mux4~4_combout\ <= NOT \inst2|Mux4~4_combout\;
\inst2|ALT_INV_Mux4~3_combout\ <= NOT \inst2|Mux4~3_combout\;
\inst2|ALT_INV_Mux4~2_combout\ <= NOT \inst2|Mux4~2_combout\;
\inst2|ALT_INV_Mux4~1_combout\ <= NOT \inst2|Mux4~1_combout\;
\inst2|ALT_INV_F9~3_combout\ <= NOT \inst2|F9~3_combout\;
\inst2|ALT_INV_Mux4~0_combout\ <= NOT \inst2|Mux4~0_combout\;
\inst2|ALT_INV_Mux5~10_combout\ <= NOT \inst2|Mux5~10_combout\;
\inst2|ALT_INV_Mux5~9_combout\ <= NOT \inst2|Mux5~9_combout\;
\inst2|ALT_INV_Mux5~8_combout\ <= NOT \inst2|Mux5~8_combout\;
\inst2|ALT_INV_Mux5~7_combout\ <= NOT \inst2|Mux5~7_combout\;
\inst2|ALT_INV_Mux5~6_combout\ <= NOT \inst2|Mux5~6_combout\;
\inst2|ALT_INV_F9~2_combout\ <= NOT \inst2|F9~2_combout\;
\inst2|ALT_INV_Mux5~5_combout\ <= NOT \inst2|Mux5~5_combout\;
\inst2|ALT_INV_Mux6~5_combout\ <= NOT \inst2|Mux6~5_combout\;
\inst2|ALT_INV_Mux6~4_combout\ <= NOT \inst2|Mux6~4_combout\;
\inst2|ALT_INV_Mux6~3_combout\ <= NOT \inst2|Mux6~3_combout\;
\inst2|ALT_INV_Mux6~2_combout\ <= NOT \inst2|Mux6~2_combout\;
\inst2|ALT_INV_Mux6~1_combout\ <= NOT \inst2|Mux6~1_combout\;
\inst2|ALT_INV_F9~1_combout\ <= NOT \inst2|F9~1_combout\;
\inst2|ALT_INV_Mux6~0_combout\ <= NOT \inst2|Mux6~0_combout\;
\inst2|ALT_INV_Mux7~5_combout\ <= NOT \inst2|Mux7~5_combout\;
\inst2|ALT_INV_Mux7~4_combout\ <= NOT \inst2|Mux7~4_combout\;
\inst2|ALT_INV_Mux7~3_combout\ <= NOT \inst2|Mux7~3_combout\;
\inst2|ALT_INV_Mux7~2_combout\ <= NOT \inst2|Mux7~2_combout\;
\inst2|ALT_INV_Mux7~1_combout\ <= NOT \inst2|Mux7~1_combout\;
\inst2|ALT_INV_Mux5~4_combout\ <= NOT \inst2|Mux5~4_combout\;
\inst2|ALT_INV_Mux5~3_combout\ <= NOT \inst2|Mux5~3_combout\;
\inst2|ALT_INV_F9~0_combout\ <= NOT \inst2|F9~0_combout\;
\inst2|ALT_INV_Mux7~0_combout\ <= NOT \inst2|Mux7~0_combout\;
\inst2|ALT_INV_Mux5~2_combout\ <= NOT \inst2|Mux5~2_combout\;
\inst2|ALT_INV_Mux5~1_combout\ <= NOT \inst2|Mux5~1_combout\;
\inst2|ALT_INV_Mux5~0_combout\ <= NOT \inst2|Mux5~0_combout\;
\inst2|ALT_INV_Mux8~2_combout\ <= NOT \inst2|Mux8~2_combout\;
\inst2|ALT_INV_Mux8~1_combout\ <= NOT \inst2|Mux8~1_combout\;
\inst2|ALT_INV_Mux8~0_combout\ <= NOT \inst2|Mux8~0_combout\;
\inst|ALT_INV_S\(1) <= NOT \inst|S\(1);
\inst|ALT_INV_S\(3) <= NOT \inst|S\(3);
\inst|ALT_INV_S\(0) <= NOT \inst|S\(0);
\inst2|ALT_INV_Mux8~3_combout\ <= NOT \inst2|Mux8~3_combout\;
\inst2|ALT_INV_Mux7~6_combout\ <= NOT \inst2|Mux7~6_combout\;
\inst2|ALT_INV_Mux6~6_combout\ <= NOT \inst2|Mux6~6_combout\;
\inst2|ALT_INV_Mux5~11_combout\ <= NOT \inst2|Mux5~11_combout\;
\inst2|ALT_INV_Mux4~5_combout\ <= NOT \inst2|Mux4~5_combout\;
\inst2|ALT_INV_Mux3~5_combout\ <= NOT \inst2|Mux3~5_combout\;
\inst2|ALT_INV_Mux2~5_combout\ <= NOT \inst2|Mux2~5_combout\;
\inst2|ALT_INV_Mux1~5_combout\ <= NOT \inst2|Mux1~5_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_adapted_tdo~0_combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|adapted_tdo~0_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~29_sumout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~29_sumout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~25_sumout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~25_sumout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~21_sumout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~21_sumout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~17_sumout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~17_sumout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~13_sumout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~13_sumout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~9_sumout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~9_sumout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~5_sumout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~5_sumout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~1_sumout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~1_sumout\;
\inst16|ALT_INV_PC_out[7]~reg0_q\ <= NOT \inst16|PC_out[7]~reg0_q\;
\inst16|ALT_INV_PC_out[6]~reg0_q\ <= NOT \inst16|PC_out[6]~reg0_q\;
\inst16|ALT_INV_PC_out[5]~reg0_q\ <= NOT \inst16|PC_out[5]~reg0_q\;
\inst16|ALT_INV_PC_out[4]~reg0_q\ <= NOT \inst16|PC_out[4]~reg0_q\;
\inst16|ALT_INV_PC_out[3]~reg0_q\ <= NOT \inst16|PC_out[3]~reg0_q\;
\inst16|ALT_INV_PC_out[2]~reg0_q\ <= NOT \inst16|PC_out[2]~reg0_q\;
\inst16|ALT_INV_PC_out[1]~reg0_q\ <= NOT \inst16|PC_out[1]~reg0_q\;
\inst16|ALT_INV_PC_out[0]~reg0_q\ <= NOT \inst16|PC_out[0]~reg0_q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(8);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(13) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(13);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(11) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(6) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(6);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(4);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(1);
\ALT_INV_altera_internal_jtag~TDIUTAP\ <= NOT \altera_internal_jtag~TDIUTAP\;
\ALT_INV_altera_internal_jtag~TCKUTAP\ <= NOT \altera_internal_jtag~TCKUTAP\;
\ALT_INV_altera_internal_jtag~TMSUTAP\ <= NOT \altera_internal_jtag~TMSUTAP\;
\inst2|ALT_INV_Mux7~10_combout\ <= NOT \inst2|Mux7~10_combout\;
\inst2|ALT_INV_Mux6~10_combout\ <= NOT \inst2|Mux6~10_combout\;
\inst2|ALT_INV_Mux5~15_combout\ <= NOT \inst2|Mux5~15_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~7_combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~7_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~5_combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~5_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(3) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(3);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_clear_signal~combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|clear_signal~combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_Equal0~0_combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|Equal0~0_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(2) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(2);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~3_combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~3_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_incr_addr~0_combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_incr_addr~0_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~3_combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[1]~0_combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~0_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(0);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(2);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(1) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(1);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~0_combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~0_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(4);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(3);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(2);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(1);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(0);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(1) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(1);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~0_combout\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_bypass_reg_out~q\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~q\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(0) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(0);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(6) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(6);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(5) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(5);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(4) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(4);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(3) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(3);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(2) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(2);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(1) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(1);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(0) <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(0);
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~q\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~q\;
\inst2|ALT_INV_Mux1~4_combout\ <= NOT \inst2|Mux1~4_combout\;
\inst2|ALT_INV_Mux1~3_combout\ <= NOT \inst2|Mux1~3_combout\;
\inst2|ALT_INV_Mux1~2_combout\ <= NOT \inst2|Mux1~2_combout\;
\inst2|ALT_INV_Mux1~1_combout\ <= NOT \inst2|Mux1~1_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[2]~2_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~2_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[1]~1_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~1_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg_proc~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg_proc~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|clear_signal~combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~2_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~2_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~1_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~1_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(4);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg~4_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~4_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(7) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(7);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(6) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(6);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(5) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(5);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(4) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(4);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal0~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(5) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(5);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(6) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(6);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(7) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(7);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(8) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(8);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(9) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(9);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(4) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(4);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~2_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~2_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~1_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~1_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_dr_scan_reg~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena_proc~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena_proc~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~4_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~4_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~3_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~3_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~2_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~2_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~1_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~1_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_bypass_reg~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_info_reg_ena~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][5]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][4]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][3]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(15) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(15);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(14) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(14);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(12) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(12);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(10) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(10);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(9) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(9);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(8);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(7);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(5);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg~q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~6_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~6_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[2]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~DUPLICATE_q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[4]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[4]~DUPLICATE_q\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg[1]~DUPLICATE_q\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~DUPLICATE_q\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg[3]~DUPLICATE_q\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[3]~DUPLICATE_q\;
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\ <= NOT \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~DUPLICATE_q\;
\inst|ALT_INV_S[3]~DUPLICATE_q\ <= NOT \inst|S[3]~DUPLICATE_q\;
\inst10|ALT_INV_A[5]~DUPLICATE_q\ <= NOT \inst10|A[5]~DUPLICATE_q\;
\ALT_INV_clk~inputCLKENA0_outclk\ <= NOT \clk~inputCLKENA0_outclk\;
\ALT_INV_B_T_CN_M~input_o\ <= NOT \B_T_CN_M~input_o\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~5_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~5_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~9_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~9_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~7_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~7_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(3) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(3);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~2_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~2_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~2_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~2_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(4) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(4);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(0) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(0);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(1) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(1);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~5_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~5_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(2) <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(2);
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal3~0_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal3~0_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state~14_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~14_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~7_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~7_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~6_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~6_combout\;
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[2]~5_combout\ <= NOT \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~5_combout\;

-- Location: IOOBUF_X89_Y9_N22
\RQAddr1[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(6));

-- Location: IOOBUF_X89_Y23_N39
\RQAddr1[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(5));

-- Location: IOOBUF_X89_Y23_N56
\RQAddr1[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(4));

-- Location: IOOBUF_X89_Y20_N79
\RQAddr1[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(3));

-- Location: IOOBUF_X89_Y25_N39
\RQAddr1[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(2));

-- Location: IOOBUF_X89_Y20_N96
\RQAddr1[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(1));

-- Location: IOOBUF_X89_Y25_N56
\RQAddr1[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr1(0));

-- Location: IOOBUF_X89_Y16_N5
\RQAddr2[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux7~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(6));

-- Location: IOOBUF_X89_Y16_N22
\RQAddr2[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux8~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(5));

-- Location: IOOBUF_X89_Y4_N45
\RQAddr2[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux9~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(4));

-- Location: IOOBUF_X89_Y4_N62
\RQAddr2[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux10~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(3));

-- Location: IOOBUF_X89_Y21_N39
\RQAddr2[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux11~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(2));

-- Location: IOOBUF_X89_Y11_N62
\RQAddr2[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux12~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(1));

-- Location: IOOBUF_X89_Y9_N5
\RQAddr2[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst7|Mux13~0_combout\,
	devoe => ww_devoe,
	o => ww_RQAddr2(0));

-- Location: IOOBUF_X89_Y8_N39
\RQALU1[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(6));

-- Location: IOOBUF_X89_Y11_N79
\RQALU1[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(5));

-- Location: IOOBUF_X89_Y11_N96
\RQALU1[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(4));

-- Location: IOOBUF_X89_Y4_N79
\RQALU1[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(3));

-- Location: IOOBUF_X89_Y13_N56
\RQALU1[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(2));

-- Location: IOOBUF_X89_Y13_N39
\RQALU1[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(1));

-- Location: IOOBUF_X89_Y4_N96
\RQALU1[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU1(0));

-- Location: IOOBUF_X89_Y6_N39
\RQALU2[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux7~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(6));

-- Location: IOOBUF_X89_Y6_N56
\RQALU2[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux8~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(5));

-- Location: IOOBUF_X89_Y16_N39
\RQALU2[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux9~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(4));

-- Location: IOOBUF_X89_Y16_N56
\RQALU2[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux10~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(3));

-- Location: IOOBUF_X89_Y15_N39
\RQALU2[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux11~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(2));

-- Location: IOOBUF_X89_Y15_N56
\RQALU2[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux12~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(1));

-- Location: IOOBUF_X89_Y8_N56
\RQALU2[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux13~0_combout\,
	devoe => ww_devoe,
	o => ww_RQALU2(0));

-- Location: IOOBUF_X89_Y11_N45
\RQData1[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(6));

-- Location: IOOBUF_X89_Y13_N5
\RQData1[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(5));

-- Location: IOOBUF_X89_Y13_N22
\RQData1[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(4));

-- Location: IOOBUF_X89_Y8_N22
\RQData1[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(3));

-- Location: IOOBUF_X89_Y15_N22
\RQData1[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(2));

-- Location: IOOBUF_X89_Y15_N5
\RQData1[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(1));

-- Location: IOOBUF_X89_Y20_N45
\RQData1[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData1(0));

-- Location: IOOBUF_X89_Y20_N62
\RQData2[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux7~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(6));

-- Location: IOOBUF_X89_Y21_N56
\RQData2[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux8~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(5));

-- Location: IOOBUF_X89_Y25_N22
\RQData2[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux9~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(4));

-- Location: IOOBUF_X89_Y23_N22
\RQData2[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux10~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(3));

-- Location: IOOBUF_X89_Y9_N56
\RQData2[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux11~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(2));

-- Location: IOOBUF_X89_Y23_N5
\RQData2[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux12~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(1));

-- Location: IOOBUF_X89_Y9_N39
\RQData2[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux13~0_combout\,
	devoe => ww_devoe,
	o => ww_RQData2(0));

-- Location: IOOBUF_X80_Y0_N2
\SOUT[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|S[3]~DUPLICATE_q\,
	devoe => ww_devoe,
	o => ww_SOUT(3));

-- Location: IOOBUF_X60_Y0_N2
\SOUT[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|ALT_INV_S\(0),
	devoe => ww_devoe,
	o => ww_SOUT(2));

-- Location: IOOBUF_X52_Y0_N19
\SOUT[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|S\(1),
	devoe => ww_devoe,
	o => ww_SOUT(1));

-- Location: IOOBUF_X52_Y0_N2
\SOUT[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|S\(0),
	devoe => ww_devoe,
	o => ww_SOUT(0));

-- Location: IOOBUF_X11_Y0_N2
\altera_reserved_tdo~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \altera_internal_jtag~TDO\,
	devoe => ww_devoe,
	o => ww_altera_reserved_tdo);

-- Location: IOIBUF_X36_Y0_N1
\clk~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G10
\clk~inputCLKENA0\ : cyclonev_clkena
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	disable_mode => "low",
	ena_register_mode => "always enabled",
	ena_register_power_up => "high",
	test_syn => "high")
-- pragma translate_on
PORT MAP (
	inclk => \clk~input_o\,
	outclk => \clk~inputCLKENA0_outclk\);

-- Location: LABCELL_X4_Y6_N0
\inst16|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst16|Add0~1_sumout\ = SUM(( \inst16|PC_out[0]~reg0_q\ ) + ( VCC ) + ( !VCC ))
-- \inst16|Add0~2\ = CARRY(( \inst16|PC_out[0]~reg0_q\ ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst16|ALT_INV_PC_out[0]~reg0_q\,
	cin => GND,
	sumout => \inst16|Add0~1_sumout\,
	cout => \inst16|Add0~2\);

-- Location: LABCELL_X4_Y6_N3
\inst16|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst16|Add0~5_sumout\ = SUM(( \inst16|PC_out[1]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~2\ ))
-- \inst16|Add0~6\ = CARRY(( \inst16|PC_out[1]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst16|ALT_INV_PC_out[1]~reg0_q\,
	cin => \inst16|Add0~2\,
	sumout => \inst16|Add0~5_sumout\,
	cout => \inst16|Add0~6\);

-- Location: LABCELL_X4_Y6_N6
\inst16|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst16|Add0~9_sumout\ = SUM(( \inst16|PC_out[2]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~6\ ))
-- \inst16|Add0~10\ = CARRY(( \inst16|PC_out[2]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst16|ALT_INV_PC_out[2]~reg0_q\,
	cin => \inst16|Add0~6\,
	sumout => \inst16|Add0~9_sumout\,
	cout => \inst16|Add0~10\);

-- Location: LABCELL_X4_Y6_N9
\inst16|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst16|Add0~13_sumout\ = SUM(( \inst16|PC_out[3]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~10\ ))
-- \inst16|Add0~14\ = CARRY(( \inst16|PC_out[3]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst16|ALT_INV_PC_out[3]~reg0_q\,
	cin => \inst16|Add0~10\,
	sumout => \inst16|Add0~13_sumout\,
	cout => \inst16|Add0~14\);

-- Location: LABCELL_X4_Y6_N12
\inst16|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst16|Add0~17_sumout\ = SUM(( \inst16|PC_out[4]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~14\ ))
-- \inst16|Add0~18\ = CARRY(( \inst16|PC_out[4]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst16|ALT_INV_PC_out[4]~reg0_q\,
	cin => \inst16|Add0~14\,
	sumout => \inst16|Add0~17_sumout\,
	cout => \inst16|Add0~18\);

-- Location: LABCELL_X4_Y6_N15
\inst16|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst16|Add0~21_sumout\ = SUM(( \inst16|PC_out[5]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~18\ ))
-- \inst16|Add0~22\ = CARRY(( \inst16|PC_out[5]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst16|ALT_INV_PC_out[5]~reg0_q\,
	cin => \inst16|Add0~18\,
	sumout => \inst16|Add0~21_sumout\,
	cout => \inst16|Add0~22\);

-- Location: LABCELL_X4_Y6_N18
\inst16|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst16|Add0~25_sumout\ = SUM(( \inst16|PC_out[6]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~22\ ))
-- \inst16|Add0~26\ = CARRY(( \inst16|PC_out[6]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst16|ALT_INV_PC_out[6]~reg0_q\,
	cin => \inst16|Add0~22\,
	sumout => \inst16|Add0~25_sumout\,
	cout => \inst16|Add0~26\);

-- Location: LABCELL_X4_Y6_N21
\inst16|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst16|Add0~29_sumout\ = SUM(( \inst16|PC_out[7]~reg0_q\ ) + ( GND ) + ( \inst16|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst16|ALT_INV_PC_out[7]~reg0_q\,
	cin => \inst16|Add0~26\,
	sumout => \inst16|Add0~29_sumout\);

-- Location: M10K_X5_Y6_N0
\inst6|altsyncram_component|auto_generated|ram_block1a0\ : cyclonev_ram_block
-- pragma translate_off
GENERIC MAP (
	mem_init2 => "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init1 => "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init0 => "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000010000000000000010400709002070060400503004020030100000",
	data_interleave_offset_in_bits => 1,
	data_interleave_width_in_bits => 1,
	init_file => "ROM-RAM.mif",
	init_file_layout => "port_a",
	logical_ram_name => "ROM:inst6|altsyncram:altsyncram_component|altsyncram_bg14:auto_generated|ALTSYNCRAM",
	operation_mode => "rom",
	port_a_address_clear => "none",
	port_a_address_width => 8,
	port_a_byte_enable_clock => "none",
	port_a_data_out_clear => "none",
	port_a_data_out_clock => "clock0",
	port_a_data_width => 20,
	port_a_first_address => 0,
	port_a_first_bit_number => 0,
	port_a_last_address => 255,
	port_a_logical_ram_depth => 256,
	port_a_logical_ram_width => 32,
	port_a_read_during_write_mode => "new_data_no_nbe_read",
	port_a_write_enable_clock => "none",
	port_b_address_width => 8,
	port_b_data_width => 20,
	ram_block_type => "M20K")
-- pragma translate_on
PORT MAP (
	portare => VCC,
	clk0 => \ALT_INV_clk~inputCLKENA0_outclk\,
	portaaddr => \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	portadataout => \inst6|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\);

-- Location: IOIBUF_X4_Y0_N18
\M_CN~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_M_CN,
	o => \M_CN~input_o\);

-- Location: MLABCELL_X6_Y6_N48
\inst18|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst18|Mux2~0_combout\ = ( !\inst6|altsyncram_component|auto_generated|q_a\(29) & ( \inst6|altsyncram_component|auto_generated|q_a\(28) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(30) & !\inst6|altsyncram_component|auto_generated|q_a\(31)) ) ) 
-- )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011000000110000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(30),
	datac => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(31),
	datae => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	dataf => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(28),
	combout => \inst18|Mux2~0_combout\);

-- Location: FF_X4_Y6_N22
\inst16|PC_out[7]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst16|Add0~29_sumout\,
	asdata => \inst6|altsyncram_component|auto_generated|q_a\(7),
	clrn => \M_CN~input_o\,
	sload => \inst18|Mux2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst16|PC_out[7]~reg0_q\);

-- Location: FF_X4_Y6_N19
\inst16|PC_out[6]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst16|Add0~25_sumout\,
	asdata => \inst6|altsyncram_component|auto_generated|q_a\(6),
	clrn => \M_CN~input_o\,
	sload => \inst18|Mux2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst16|PC_out[6]~reg0_q\);

-- Location: FF_X4_Y6_N16
\inst16|PC_out[5]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst16|Add0~21_sumout\,
	asdata => \inst6|altsyncram_component|auto_generated|q_a\(5),
	clrn => \M_CN~input_o\,
	sload => \inst18|Mux2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst16|PC_out[5]~reg0_q\);

-- Location: FF_X4_Y6_N13
\inst16|PC_out[4]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst16|Add0~17_sumout\,
	asdata => \inst6|altsyncram_component|auto_generated|q_a\(4),
	clrn => \M_CN~input_o\,
	sload => \inst18|Mux2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst16|PC_out[4]~reg0_q\);

-- Location: FF_X4_Y6_N10
\inst16|PC_out[3]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst16|Add0~13_sumout\,
	asdata => \inst6|altsyncram_component|auto_generated|q_a\(3),
	clrn => \M_CN~input_o\,
	sload => \inst18|Mux2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst16|PC_out[3]~reg0_q\);

-- Location: FF_X4_Y6_N7
\inst16|PC_out[2]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst16|Add0~9_sumout\,
	asdata => \inst6|altsyncram_component|auto_generated|q_a\(2),
	clrn => \M_CN~input_o\,
	sload => \inst18|Mux2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst16|PC_out[2]~reg0_q\);

-- Location: FF_X4_Y6_N4
\inst16|PC_out[1]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst16|Add0~5_sumout\,
	asdata => \inst6|altsyncram_component|auto_generated|q_a\(1),
	clrn => \M_CN~input_o\,
	sload => \inst18|Mux2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst16|PC_out[1]~reg0_q\);

-- Location: FF_X4_Y6_N1
\inst16|PC_out[0]~reg0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputCLKENA0_outclk\,
	d => \inst16|Add0~1_sumout\,
	asdata => \inst6|altsyncram_component|auto_generated|q_a\(0),
	clrn => \M_CN~input_o\,
	sload => \inst18|Mux2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst16|PC_out[0]~reg0_q\);

-- Location: MLABCELL_X6_Y6_N3
\inst18|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst18|Mux4~0_combout\ = ( !\inst6|altsyncram_component|auto_generated|q_a\(31) & ( (\inst6|altsyncram_component|auto_generated|q_a\(29) & (\inst6|altsyncram_component|auto_generated|q_a\(28) & \inst6|altsyncram_component|auto_generated|q_a\(30))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000101000000000000010100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datac => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(28),
	datad => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(30),
	dataf => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(31),
	combout => \inst18|Mux4~0_combout\);

-- Location: MLABCELL_X6_Y6_N24
\inst18|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst18|Mux3~0_combout\ = ( !\inst6|altsyncram_component|auto_generated|q_a\(31) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(28) & ((\inst6|altsyncram_component|auto_generated|q_a\(30)) # (\inst6|altsyncram_component|auto_generated|q_a\(29)))) # 
-- (\inst6|altsyncram_component|auto_generated|q_a\(28) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29)) # (!\inst6|altsyncram_component|auto_generated|q_a\(30)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011111111111100001111111111110000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(28),
	datac => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datad => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(30),
	dataf => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(31),
	combout => \inst18|Mux3~0_combout\);

-- Location: IOIBUF_X11_Y0_N7
\altera_reserved_tms~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_altera_reserved_tms,
	o => \altera_reserved_tms~input_o\);

-- Location: IOIBUF_X13_Y0_N1
\altera_reserved_tck~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_altera_reserved_tck,
	o => \altera_reserved_tck~input_o\);

-- Location: IOIBUF_X13_Y0_N7
\altera_reserved_tdi~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_altera_reserved_tdi,
	o => \altera_reserved_tdi~input_o\);

-- Location: JTAG_X0_Y2_N3
altera_internal_jtag : cyclonev_jtag
PORT MAP (
	tms => \altera_reserved_tms~input_o\,
	tck => \altera_reserved_tck~input_o\,
	tdi => \altera_reserved_tdi~input_o\,
	tdouser => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo~q\,
	tdo => \altera_internal_jtag~TDO\,
	tmsutap => \altera_internal_jtag~TMSUTAP\,
	tckutap => \altera_internal_jtag~TCKUTAP\,
	tdiutap => \altera_internal_jtag~TDIUTAP\);

-- Location: LABCELL_X1_Y2_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena_proc~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena_proc~0_combout\);

-- Location: FF_X1_Y2_N26
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(9));

-- Location: LABCELL_X1_Y2_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000001100000011000000110000001100000011000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(0),
	datac => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~1_combout\);

-- Location: FF_X1_Y2_N47
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~1_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(0));

-- Location: LABCELL_X1_Y2_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111100001111000000001111000011111111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(1),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~2_combout\);

-- Location: FF_X1_Y2_N59
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~2_combout\,
	sclr => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(1));

-- Location: LABCELL_X1_Y2_N57
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111000000000000111111111111111100001111111111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(0),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~0_combout\);

-- Location: FF_X1_Y2_N8
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt~0_combout\,
	sclr => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|tms_cnt\(2));

-- Location: LABCELL_X1_Y2_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110011001100110011001100110011111100111111001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(9),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_tms_cnt\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~0_combout\);

-- Location: FF_X1_Y2_N44
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~0_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0));

-- Location: LABCELL_X1_Y2_N51
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~8\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001100000011000000110000001100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7),
	datac => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~8_combout\);

-- Location: FF_X1_Y2_N53
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(8));

-- Location: LABCELL_X1_Y2_N54
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~9\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000001100000011000000110000001100000011000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(9),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~9_combout\);

-- Location: FF_X1_Y2_N56
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(10));

-- Location: MLABCELL_X3_Y2_N9
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~12\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111111111111111100001111000011111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(13),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(12),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~12_combout\);

-- Location: FF_X3_Y2_N14
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~12_combout\,
	sclr => \altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(13));

-- Location: MLABCELL_X3_Y2_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~13\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(13),
	dataf => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~13_combout\);

-- Location: FF_X1_Y2_N50
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~13_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(14));

-- Location: LABCELL_X4_Y2_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~10\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111111111111111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(10),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(14),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(11),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~10_combout\);

-- Location: FF_X3_Y2_N56
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~10_combout\,
	sclr => \altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11));

-- Location: LABCELL_X1_Y2_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~11\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001111000000000000111100000000111111110000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(11),
	datad => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(10),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~11_combout\);

-- Location: FF_X1_Y2_N20
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~11_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(12));

-- Location: MLABCELL_X3_Y2_N51
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000001110111011101110111011101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(12),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(14),
	dataf => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0_combout\);

-- Location: FF_X1_Y2_N11
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(15));

-- Location: MLABCELL_X3_Y2_N39
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011101110111011111111111111111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(0),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(15),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~1_combout\);

-- Location: FF_X3_Y2_N26
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~1_combout\,
	sclr => \altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(1));

-- Location: LABCELL_X1_Y2_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001001100010011000100110001001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(1),
	datab => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(15),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~2_combout\);

-- Location: FF_X1_Y2_N17
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(2));

-- Location: LABCELL_X2_Y2_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~3_combout\);

-- Location: FF_X2_Y2_N26
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(3));

-- Location: MLABCELL_X3_Y2_N12
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001000100010001000101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~5_combout\);

-- Location: FF_X1_Y2_N23
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~5_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(5));

-- Location: MLABCELL_X3_Y2_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(6),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~6_combout\);

-- Location: FF_X3_Y2_N37
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~6_combout\,
	sclr => \altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(6));

-- Location: MLABCELL_X3_Y2_N57
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~7\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010100000101000001010000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(6),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~7_combout\);

-- Location: FF_X1_Y2_N14
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~7_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(7));

-- Location: LABCELL_X4_Y3_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111111111111111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~4_combout\);

-- Location: FF_X3_Y2_N8
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~4_combout\,
	sclr => \altera_internal_jtag~TMSUTAP\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(4));

-- Location: LABCELL_X2_Y3_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111111111111111100001111000011111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\);

-- Location: LABCELL_X1_Y6_N30
\inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(0),
	cin => GND,
	sumout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~1_sumout\,
	cout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~2\);

-- Location: LABCELL_X1_Y6_N24
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[0]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~1_sumout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[0]~feeder_combout\);

-- Location: LABCELL_X1_Y6_N54
\inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111111111111111100001111000011111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][4]~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~0_combout\);

-- Location: FF_X4_Y2_N38
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \altera_internal_jtag~TDIUTAP\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(9));

-- Location: LABCELL_X4_Y2_N39
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(9),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~feeder_combout\);

-- Location: FF_X4_Y2_N40
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[8]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(8));

-- Location: LABCELL_X4_Y2_N54
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[7]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[7]~feeder_combout\);

-- Location: FF_X4_Y2_N56
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[7]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(7));

-- Location: LABCELL_X4_Y2_N57
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[6]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(7),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[6]~feeder_combout\);

-- Location: FF_X4_Y2_N58
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[6]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(6));

-- Location: FF_X4_Y2_N26
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(6),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(5));

-- Location: LABCELL_X4_Y2_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[4]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(5),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[4]~feeder_combout\);

-- Location: FF_X4_Y2_N34
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[4]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(4));

-- Location: FF_X4_Y2_N2
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[3]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(4),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[3]~DUPLICATE_q\);

-- Location: FF_X4_Y2_N1
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(4),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(3));

-- Location: LABCELL_X4_Y2_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[2]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[2]~0_combout\);

-- Location: FF_X4_Y2_N4
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[2]~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(2));

-- Location: LABCELL_X4_Y2_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000000000000000000000000010000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(5),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(7),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(9),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(6),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~0_combout\);

-- Location: LABCELL_X4_Y2_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[1]~feeder_combout\);

-- Location: FF_X4_Y2_N17
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[1]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(1));

-- Location: LABCELL_X4_Y2_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[0]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111000000000000000011111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[0]~1_combout\);

-- Location: FF_X4_Y2_N43
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg[0]~1_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(11),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|jtag_ir_reg\(0));

-- Location: MLABCELL_X3_Y2_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000100000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg[3]~DUPLICATE_q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal0~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(0),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~1_combout\);

-- Location: FF_X3_Y2_N44
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_dr_scan_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal0~1_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_dr_scan_reg~q\);

-- Location: MLABCELL_X3_Y2_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal1~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg[3]~DUPLICATE_q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal0~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(0),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_jtag_ir_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal1~0_combout\);

-- Location: FF_X3_Y2_N20
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal1~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(0),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_dr_scan_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg~q\);

-- Location: MLABCELL_X3_Y2_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001110000000000000111000010001111111110001000111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(15),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~0_combout\);

-- Location: MLABCELL_X3_Y2_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111000000001111111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~4_combout\);

-- Location: MLABCELL_X3_Y4_N12
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[8]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg~4_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[8]~feeder_combout\);

-- Location: MLABCELL_X3_Y4_N54
\~QIC_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):
-- \~QIC_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	combout => \~QIC_CREATED_GND~I_combout\);

-- Location: FF_X3_Y4_N14
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[8]~feeder_combout\,
	asdata => \~QIC_CREATED_GND~I_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state\(3),
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(8));

-- Location: LABCELL_X2_Y2_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010001010100010101110101011101010100010101000101011101010111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datab => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datae => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~1_combout\);

-- Location: LABCELL_X2_Y2_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000001000000010000000100000001001100010000000100110001000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena_proc~0_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~1_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|node_ena~2_combout\);

-- Location: MLABCELL_X3_Y3_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0[3]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_node_ena~2_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0[3]~feeder_combout\);

-- Location: FF_X3_Y3_N2
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0[3]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|splitter_nodes_receive_0\(3));

-- Location: MLABCELL_X3_Y4_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~7\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101000100000011000100010000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(4),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~7_combout\);

-- Location: LABCELL_X1_Y4_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~14\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state~14_combout\);

-- Location: MLABCELL_X6_Y2_N21
\inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[0]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(0),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[0]~feeder_combout\);

-- Location: FF_X6_Y2_N22
\inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[0]~feeder_combout\,
	clrn => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(0));

-- Location: LABCELL_X2_Y4_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010110101111101011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(0),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~3_combout\);

-- Location: MLABCELL_X3_Y4_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000001000000001111000100000000000011010000000011111101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\);

-- Location: FF_X2_Y4_N4
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~3_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(1));

-- Location: LABCELL_X1_Y4_N57
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal3~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000001010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|Equal3~0_combout\);

-- Location: MLABCELL_X3_Y4_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[0]~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100100011001000110111001100100011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state~14_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_Equal3~0_combout\,
	dataf => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[0]~3_combout\);

-- Location: FF_X3_Y4_N41
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[0]~3_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(0));

-- Location: MLABCELL_X3_Y4_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000000010000000100000001000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(0),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~6_combout\);

-- Location: MLABCELL_X3_Y4_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000001000000010000000000000000000001010100010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~5_combout\);

-- Location: MLABCELL_X6_Y2_N48
\inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(2),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[2]~feeder_combout\);

-- Location: FF_X6_Y2_N49
\inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[2]~feeder_combout\,
	clrn => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(2));

-- Location: MLABCELL_X3_Y4_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~8\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111011101111111011101110111111101110111011111110111011101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~7_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[3]~6_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg[2]~5_combout\,
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~8_combout\);

-- Location: FF_X3_Y4_N31
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[3]~8_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(3));

-- Location: MLABCELL_X3_Y4_N51
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000001000100010000000100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datab => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\);

-- Location: FF_X2_Y4_N59
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(3),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][3]~q\);

-- Location: LABCELL_X1_Y4_N42
\inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000101000000000000010100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\);

-- Location: FF_X6_Y2_N4
\inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(1),
	clrn => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	sload => VCC,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(1));

-- Location: LABCELL_X2_Y4_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001110100011101000111010001110100011101000111010001110100011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(1),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~2_combout\);

-- Location: FF_X2_Y4_N43
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~2_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(2));

-- Location: MLABCELL_X3_Y4_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg_proc~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000100000001000000010000000100010001000100010001000100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datab => \ALT_INV_altera_internal_jtag~TMSUTAP\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(7),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg_proc~0_combout\);

-- Location: MLABCELL_X3_Y4_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001000111010001100000011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg_proc~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~0_combout\);

-- Location: FF_X3_Y4_N11
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(1));

-- Location: MLABCELL_X3_Y4_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[1]~1_combout\);

-- Location: FF_X3_Y4_N49
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|reset_ena_reg~q\);

-- Location: MLABCELL_X3_Y4_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101000000000000110001010101010101010000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[1]~1_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_reset_ena_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~2_combout\);

-- Location: LABCELL_X4_Y3_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[2]~2_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~feeder_combout\);

-- Location: FF_X4_Y3_N1
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg[2]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|virtual_ir_scan_reg~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_mode_reg\(2));

-- Location: LABCELL_X1_Y2_N27
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg_proc~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010100000101000001010000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg_proc~0_combout\);

-- Location: FF_X1_Y2_N29
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg_proc~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~q\);

-- Location: FF_X2_Y4_N50
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(0),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~q\);

-- Location: LABCELL_X4_Y4_N42
\inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000011000000110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\);

-- Location: LABCELL_X1_Y4_N21
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_incr_addr~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000011000000000000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_incr_addr~0_combout\);

-- Location: FF_X2_Y4_N8
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(1),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][1]~q\);

-- Location: LABCELL_X1_Y4_N18
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000100000000000000010000000000000011000000000000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~0_combout\);

-- Location: LABCELL_X1_Y4_N39
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111000001110000011100000111000111100001111000011110000111100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg[1]~DUPLICATE_q\,
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[1]~0_combout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~0_combout\);

-- Location: FF_X1_Y4_N28
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~DUPLICATE_q\);

-- Location: LABCELL_X1_Y4_N15
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[0]~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001000110010001100100011001011001100110011001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg[1]~DUPLICATE_q\,
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[1]~0_combout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[0]~2_combout\);

-- Location: FF_X1_Y4_N32
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[0]~2_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(0));

-- Location: LABCELL_X1_Y4_N12
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[2]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101000110010001100100011001000110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[1]~0_combout\,
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg[1]~DUPLICATE_q\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[2]~1_combout\);

-- Location: FF_X1_Y4_N35
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[2]~1_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(2));

-- Location: LABCELL_X1_Y4_N30
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101110101010111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_incr_addr~0_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\,
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg[1]~DUPLICATE_q\,
	datae => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~3_combout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0_combout\);

-- Location: FF_X1_Y6_N25
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[0]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(1),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(0));

-- Location: LABCELL_X1_Y6_N33
\inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(1),
	cin => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~2\,
	sumout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~5_sumout\,
	cout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~6\);

-- Location: LABCELL_X1_Y6_N27
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~5_sumout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[1]~feeder_combout\);

-- Location: FF_X1_Y6_N28
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[1]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(2),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(1));

-- Location: LABCELL_X1_Y6_N36
\inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~9\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(2),
	cin => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~6\,
	sumout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~9_sumout\,
	cout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~10\);

-- Location: LABCELL_X1_Y6_N6
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~9_sumout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[2]~feeder_combout\);

-- Location: FF_X1_Y6_N7
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[2]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(3),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(2));

-- Location: LABCELL_X1_Y6_N39
\inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~13\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(3),
	cin => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~10\,
	sumout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~13_sumout\,
	cout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~14\);

-- Location: LABCELL_X1_Y6_N12
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[3]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~13_sumout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[3]~feeder_combout\);

-- Location: LABCELL_X1_Y6_N42
\inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~17\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(4),
	cin => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~14\,
	sumout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~17_sumout\,
	cout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~18\);

-- Location: LABCELL_X1_Y6_N15
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[4]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~17_sumout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[4]~feeder_combout\);

-- Location: LABCELL_X1_Y6_N45
\inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~21\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(5),
	cin => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~18\,
	sumout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~21_sumout\,
	cout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~22\);

-- Location: LABCELL_X1_Y6_N21
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~21_sumout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~feeder_combout\);

-- Location: LABCELL_X1_Y6_N48
\inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~25\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(6),
	cin => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~22\,
	sumout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~25_sumout\,
	cout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~26\);

-- Location: LABCELL_X1_Y6_N18
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[6]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~25_sumout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[6]~feeder_combout\);

-- Location: LABCELL_X1_Y6_N51
\inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~29\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(7),
	cin => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~26\,
	sumout => \inst5|altsyncram_component|auto_generated|mgl_prim2|Add0~29_sumout\);

-- Location: LABCELL_X1_Y6_N9
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_Add0~29_sumout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~feeder_combout\);

-- Location: FF_X1_Y6_N11
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~feeder_combout\,
	asdata => \altera_internal_jtag~TDIUTAP\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(7));

-- Location: FF_X1_Y6_N19
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[6]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(7),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(6));

-- Location: FF_X1_Y6_N22
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[5]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(6),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(5));

-- Location: FF_X1_Y6_N17
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[4]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(5),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(4));

-- Location: FF_X1_Y6_N13
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[3]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(4),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~3_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(3));

-- Location: FF_X6_Y2_N52
\inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(3),
	clrn => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	sload => VCC,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(3));

-- Location: FF_X6_Y2_N55
\inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(4),
	clrn => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	sload => VCC,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(4));

-- Location: MLABCELL_X6_Y2_N57
\inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[5]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_addr_reg\(5),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[5]~feeder_combout\);

-- Location: FF_X6_Y2_N58
\inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[5]~feeder_combout\,
	clrn => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(5));

-- Location: FF_X6_Y2_N37
\inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_addr_reg\(6),
	clrn => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_process_0~0_combout\,
	sload => VCC,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ir_loaded_address_reg\(6));

-- Location: LABCELL_X2_Y4_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~12\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010011100100111001001110010011100100111001001110010011100100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(6),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~12_combout\);

-- Location: FF_X2_Y4_N37
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~12_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(7));

-- Location: LABCELL_X2_Y4_N21
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~11\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010110101111101011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(5),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(7),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~11_combout\);

-- Location: FF_X2_Y4_N22
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~11_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(6));

-- Location: LABCELL_X2_Y4_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~10\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010110101111101011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(6),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~10_combout\);

-- Location: FF_X2_Y4_N19
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~10_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(5));

-- Location: LABCELL_X2_Y4_N39
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~9\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010110101111101011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ir_loaded_address_reg\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(5),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~9_combout\);

-- Location: FF_X2_Y4_N40
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~9_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(4));

-- Location: LABCELL_X2_Y4_N27
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~feeder_combout\);

-- Location: FF_X2_Y4_N29
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][4]~q\);

-- Location: LABCELL_X1_Y6_N3
\inst5|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111101011111010111100001111000011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][4]~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	datae => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~q\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~0_combout\);

-- Location: FF_X2_Y3_N41
\inst5|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|is_in_use_reg~q\);

-- Location: LABCELL_X2_Y4_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010110101111101011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_is_in_use_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~0_combout\);

-- Location: FF_X2_Y4_N1
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(0));

-- Location: MLABCELL_X3_Y2_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_bypass_reg~q\,
	datac => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~0_combout\);

-- Location: FF_X2_Y2_N23
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~0_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_bypass_reg~q\);

-- Location: LABCELL_X1_Y3_N12
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~0_combout\);

-- Location: LABCELL_X1_Y2_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001010000010100000101000001010000010100000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~3_combout\);

-- Location: FF_X1_Y2_N37
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~3_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(3));

-- Location: LABCELL_X1_Y2_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~2_combout\);

-- Location: FF_X1_Y2_N1
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~2_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(2));

-- Location: LABCELL_X1_Y2_N39
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001010000010100000101000001010000010100000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~1_combout\);

-- Location: FF_X1_Y2_N40
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~1_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(1));

-- Location: MLABCELL_X3_Y3_N21
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111011101110111011101110111011101110111011101110111011101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(1),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~0_combout\);

-- Location: FF_X3_Y3_N22
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg~0_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg_ena~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_minor_ver_reg\(0));

-- Location: LABCELL_X2_Y3_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100000000000011110000000000001111010001000000111111001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_bypass_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~0_combout\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_minor_ver_reg\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~1_combout\);

-- Location: LABCELL_X1_Y1_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|clear_signal\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001100000011000000110000001100000011000000110000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|clear_signal~combout\);

-- Location: LABCELL_X2_Y3_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110011001100110011001100110011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~3_combout\);

-- Location: MLABCELL_X3_Y2_N27
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001011111111100000101000001010000010111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\);

-- Location: FF_X1_Y3_N14
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~3_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(0));

-- Location: LABCELL_X2_Y3_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000000011110000111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~4_combout\);

-- Location: FF_X1_Y3_N59
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~4_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(1));

-- Location: LABCELL_X1_Y3_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100001100001111110000110000111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~2_combout\);

-- Location: FF_X1_Y3_N56
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~2_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(2));

-- Location: LABCELL_X1_Y3_N21
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000001111111100000000111111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~5_combout\);

-- Location: FF_X1_Y3_N38
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~5_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(3));

-- Location: FF_X1_Y3_N5
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~0_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal\(4));

-- Location: LABCELL_X1_Y3_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000000000011111111111111111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~0_combout\);

-- Location: FF_X1_Y3_N4
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[4]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal~0_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[2]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|mixer_addr_reg_internal[4]~DUPLICATE_q\);

-- Location: LABCELL_X1_Y3_N36
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001111001100111100111100110000110000000000110011000000000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~2_combout\);

-- Location: LABCELL_X1_Y3_N57
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000010000000000000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[4]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~1_combout\);

-- Location: LABCELL_X4_Y2_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[3]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[3]~feeder_combout\);

-- Location: LABCELL_X2_Y3_N54
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000010000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\);

-- Location: FF_X4_Y2_N8
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[3]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(3));

-- Location: FF_X4_Y2_N52
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(3),
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(2));

-- Location: LABCELL_X2_Y3_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[1]~feeder_combout\);

-- Location: FF_X2_Y3_N25
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[1]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(1));

-- Location: LABCELL_X2_Y3_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~feeder_combout\);

-- Location: FF_X2_Y3_N16
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|identity_contrib_shift_reg\(0));

-- Location: LABCELL_X1_Y3_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~feeder_combout\);

-- Location: LABCELL_X2_Y3_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000100000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_mode_reg[1]~1_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\);

-- Location: FF_X1_Y3_N49
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(0));

-- Location: LABCELL_X2_Y3_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010101010101010100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~0_combout\);

-- Location: LABCELL_X1_Y3_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[1]~feeder_combout\);

-- Location: FF_X1_Y3_N7
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[1]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(1));

-- Location: LABCELL_X1_Y3_N51
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[2]~feeder_combout\);

-- Location: FF_X1_Y3_N52
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[2]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(2));

-- Location: LABCELL_X1_Y3_N39
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~7\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001010111001001000101011100100110000000000000001000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[4]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~7_combout\);

-- Location: LABCELL_X1_Y3_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~9\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110010101110100011001010111010000000010000000000000001000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[4]~DUPLICATE_q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~9_combout\);

-- Location: LABCELL_X1_Y3_N9
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[3]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_identity_contrib_shift_reg\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[3]~feeder_combout\);

-- Location: FF_X1_Y3_N10
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[3]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric_ident_writedata\(3));

-- Location: LABCELL_X1_Y3_N33
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~10\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000010011000000100001001111001110110111111100111011011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~1_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~0_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~9_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(3),
	dataf => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~10_combout\);

-- Location: LABCELL_X4_Y3_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100110011001100000000000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~4_combout\);

-- Location: FF_X1_Y3_N34
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~10_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(3));

-- Location: LABCELL_X1_Y3_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~8\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100110101001101010011010100110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(2),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~7_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~1_combout\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~0_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~8_combout\);

-- Location: FF_X1_Y3_N25
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~8_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(2));

-- Location: LABCELL_X1_Y3_N54
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100101010100000010010101010000010000000101100001000000010110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(3),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(4),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~5_combout\);

-- Location: LABCELL_X1_Y3_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000111001101000000011100110100100011111011110010001111101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~1_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~0_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(2),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~5_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~6_combout\);

-- Location: FF_X1_Y3_N31
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~6_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(1));

-- Location: LABCELL_X1_Y3_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111110001000100011111000100010001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_mixer_addr_reg_internal[4]~DUPLICATE_q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~2_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg[2]~1_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_sldfabric_ident_writedata\(0),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg~0_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~3_combout\);

-- Location: FF_X1_Y3_N43
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg~3_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg[2]~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|design_hash_reg\(0));

-- Location: LABCELL_X2_Y2_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000100000000000000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_design_hash_reg\(0),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~2_combout\);

-- Location: MLABCELL_X6_Y6_N39
\inst18|Mux12~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst18|Mux12~0_combout\ = ( \inst6|altsyncram_component|auto_generated|q_a\(30) & ( !\inst6|altsyncram_component|auto_generated|q_a\(28) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(30),
	dataf => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(28),
	combout => \inst18|Mux12~0_combout\);

-- Location: MLABCELL_X6_Y6_N27
\inst18|Mux13~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst18|Mux13~0_combout\ = ( !\inst6|altsyncram_component|auto_generated|q_a\(31) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & ((\inst6|altsyncram_component|auto_generated|q_a\(30)))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & 
-- (!\inst6|altsyncram_component|auto_generated|q_a\(28))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000011111010010100001111101000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datac => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(28),
	datad => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(30),
	dataf => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(31),
	combout => \inst18|Mux13~0_combout\);

-- Location: FF_X6_Y6_N40
\inst|S[3]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst18|Mux12~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|S[3]~DUPLICATE_q\);

-- Location: FF_X6_Y6_N46
\inst|S[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	asdata => \inst6|altsyncram_component|auto_generated|q_a\(30),
	sload => VCC,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|S\(0));

-- Location: MLABCELL_X6_Y6_N30
\inst18|Mux10~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst18|Mux10~0_combout\ = ( \inst6|altsyncram_component|auto_generated|q_a\(29) & ( !\inst6|altsyncram_component|auto_generated|q_a\(28) & ( !\inst6|altsyncram_component|auto_generated|q_a\(30) ) ) ) # ( 
-- !\inst6|altsyncram_component|auto_generated|q_a\(29) & ( !\inst6|altsyncram_component|auto_generated|q_a\(28) & ( \inst6|altsyncram_component|auto_generated|q_a\(30) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011110011001100110000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(30),
	datae => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	dataf => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(28),
	combout => \inst18|Mux10~0_combout\);

-- Location: FF_X6_Y6_N31
\inst|S[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst18|Mux10~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|S\(1));

-- Location: MLABCELL_X6_Y2_N42
\inst2|Mux5~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~1_combout\ = (!\inst|S[3]~DUPLICATE_q\ & (\inst|S\(0) & (\inst6|altsyncram_component|auto_generated|q_a\(29) & !\inst|S\(1)))) # (\inst|S[3]~DUPLICATE_q\ & (((!\inst6|altsyncram_component|auto_generated|q_a\(29) & \inst|S\(1)))))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001001010000000000100101000000000010010100000000001001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	datab => \inst|ALT_INV_S\(0),
	datac => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datad => \inst|ALT_INV_S\(1),
	combout => \inst2|Mux5~1_combout\);

-- Location: FF_X6_Y6_N41
\inst|S[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst18|Mux12~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|S\(3));

-- Location: MLABCELL_X6_Y6_N0
\inst2|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~0_combout\ = ( \inst|S\(3) & ( (\inst|S\(0) & \inst|S\(1)) ) ) # ( !\inst|S\(3) & ( (\inst6|altsyncram_component|auto_generated|q_a\(29) & (!\inst|S\(0) & !\inst|S\(1))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100010000000000010001000000000000000000001100110000000000110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datad => \inst|ALT_INV_S\(1),
	dataf => \inst|ALT_INV_S\(3),
	combout => \inst2|Mux5~0_combout\);

-- Location: LABCELL_X11_Y6_N12
\inst2|Mux5~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~2_combout\ = !\inst|S\(0) $ (!\inst|S[3]~DUPLICATE_q\)

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110011001100110011001100110011001100110011001100110011001100110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(0),
	datab => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	combout => \inst2|Mux5~2_combout\);

-- Location: MLABCELL_X8_Y2_N30
\inst2|Add7~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add7~1_sumout\ = SUM(( \inst10|A\(0) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # (\inst10|A\(0)) ) + ( !VCC ))
-- \inst2|Add7~2\ = CARRY(( \inst10|A\(0) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # (\inst10|A\(0)) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(0),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	cin => GND,
	sumout => \inst2|Add7~1_sumout\,
	cout => \inst2|Add7~2\);

-- Location: MLABCELL_X8_Y2_N33
\inst2|Add7~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add7~5_sumout\ = SUM(( \inst10|A\(1) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst10|A\(1)) ) + ( \inst2|Add7~2\ ))
-- \inst2|Add7~6\ = CARRY(( \inst10|A\(1) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst10|A\(1)) ) + ( \inst2|Add7~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst2|Add7~2\,
	sumout => \inst2|Add7~5_sumout\,
	cout => \inst2|Add7~6\);

-- Location: MLABCELL_X8_Y2_N36
\inst2|Add7~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add7~9_sumout\ = SUM(( \inst10|A\(2) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # (\inst10|A\(2)) ) + ( \inst2|Add7~6\ ))
-- \inst2|Add7~10\ = CARRY(( \inst10|A\(2) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # (\inst10|A\(2)) ) + ( \inst2|Add7~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \inst10|ALT_INV_A\(2),
	cin => \inst2|Add7~6\,
	sumout => \inst2|Add7~9_sumout\,
	cout => \inst2|Add7~10\);

-- Location: MLABCELL_X8_Y2_N39
\inst2|Add7~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add7~13_sumout\ = SUM(( \inst10|A\(3) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (\inst10|A\(3)) ) + ( \inst2|Add7~10\ ))
-- \inst2|Add7~14\ = CARRY(( \inst10|A\(3) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (\inst10|A\(3)) ) + ( \inst2|Add7~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100000011000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst10|ALT_INV_A\(3),
	cin => \inst2|Add7~10\,
	sumout => \inst2|Add7~13_sumout\,
	cout => \inst2|Add7~14\);

-- Location: MLABCELL_X8_Y2_N0
\inst2|Add6~30\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add6~30_cout\ = CARRY(( \inst10|A\(0) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # (\inst10|A\(0)) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(0),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	cin => GND,
	cout => \inst2|Add6~30_cout\);

-- Location: MLABCELL_X8_Y2_N3
\inst2|Add6~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add6~1_sumout\ = SUM(( \inst10|A\(1) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst10|A\(1)) ) + ( \inst2|Add6~30_cout\ ))
-- \inst2|Add6~2\ = CARRY(( \inst10|A\(1) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst10|A\(1)) ) + ( \inst2|Add6~30_cout\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst2|Add6~30_cout\,
	sumout => \inst2|Add6~1_sumout\,
	cout => \inst2|Add6~2\);

-- Location: MLABCELL_X8_Y2_N6
\inst2|Add6~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add6~5_sumout\ = SUM(( \inst10|A\(2) ) + ( (\inst10|A\(2)) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( \inst2|Add6~2\ ))
-- \inst2|Add6~6\ = CARRY(( \inst10|A\(2) ) + ( (\inst10|A\(2)) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( \inst2|Add6~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datac => \inst10|ALT_INV_A\(2),
	cin => \inst2|Add6~2\,
	sumout => \inst2|Add6~5_sumout\,
	cout => \inst2|Add6~6\);

-- Location: MLABCELL_X8_Y2_N9
\inst2|Add6~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add6~9_sumout\ = SUM(( \inst10|A\(3) ) + ( (\inst10|A\(3)) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( \inst2|Add6~6\ ))
-- \inst2|Add6~10\ = CARRY(( \inst10|A\(3) ) + ( (\inst10|A\(3)) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( \inst2|Add6~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst10|ALT_INV_A\(3),
	cin => \inst2|Add6~6\,
	sumout => \inst2|Add6~9_sumout\,
	cout => \inst2|Add6~10\);

-- Location: LABCELL_X4_Y3_N18
\inst2|Mux5~7\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~7_combout\ = ( \inst|S\(1) & ( \inst|S\(0) & ( \inst2|Add7~13_sumout\ ) ) ) # ( !\inst|S\(1) & ( \inst|S\(0) & ( \inst2|Add6~9_sumout\ ) ) ) # ( \inst|S\(1) & ( !\inst|S\(0) & ( \inst2|Add7~13_sumout\ ) ) ) # ( !\inst|S\(1) & ( !\inst|S\(0) & 
-- ( (\inst6|altsyncram_component|auto_generated|q_a\(29) & \inst10|A\(2)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101001100110011001100000000111111110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst2|ALT_INV_Add7~13_sumout\,
	datac => \inst10|ALT_INV_A\(2),
	datad => \inst2|ALT_INV_Add6~9_sumout\,
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst|ALT_INV_S\(0),
	combout => \inst2|Mux5~7_combout\);

-- Location: LABCELL_X4_Y3_N36
\inst2|Mux5~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~3_combout\ = ( !\inst|S\(1) & ( \inst|S\(0) & ( \inst6|altsyncram_component|auto_generated|q_a\(29) ) ) ) # ( !\inst|S\(1) & ( !\inst|S\(0) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111000000000000000000001111000011110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst|ALT_INV_S\(0),
	combout => \inst2|Mux5~3_combout\);

-- Location: LABCELL_X7_Y2_N42
\inst2|F9~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|F9~2_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( !\inst10|A\(3) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( \inst10|A\(3) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst10|ALT_INV_A\(3),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	combout => \inst2|F9~2_combout\);

-- Location: LABCELL_X7_Y2_N0
\inst2|Add5~30\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add5~30_cout\ = CARRY(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & \inst10|A\(0)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # (\inst10|A\(0)) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100000011000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst10|ALT_INV_A\(0),
	cin => GND,
	cout => \inst2|Add5~30_cout\);

-- Location: LABCELL_X7_Y2_N3
\inst2|Add5~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add5~1_sumout\ = SUM(( (\inst10|A\(1) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst10|A\(1)) ) + ( \inst2|Add5~30_cout\ ))
-- \inst2|Add5~2\ = CARRY(( (\inst10|A\(1) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # (\inst10|A\(1)) ) + ( \inst2|Add5~30_cout\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst2|Add5~30_cout\,
	sumout => \inst2|Add5~1_sumout\,
	cout => \inst2|Add5~2\);

-- Location: LABCELL_X7_Y2_N6
\inst2|Add5~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add5~5_sumout\ = SUM(( (\inst10|A\(2) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # (\inst10|A\(2)) ) + ( \inst2|Add5~2\ ))
-- \inst2|Add5~6\ = CARRY(( (\inst10|A\(2) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # (\inst10|A\(2)) ) + ( \inst2|Add5~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(2),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	cin => \inst2|Add5~2\,
	sumout => \inst2|Add5~5_sumout\,
	cout => \inst2|Add5~6\);

-- Location: LABCELL_X7_Y2_N9
\inst2|Add5~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add5~9_sumout\ = SUM(( (\inst10|A\(3) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (\inst10|A\(3)) ) + ( \inst2|Add5~6\ ))
-- \inst2|Add5~10\ = CARRY(( (\inst10|A\(3) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (\inst10|A\(3)) ) + ( \inst2|Add5~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(3),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	cin => \inst2|Add5~6\,
	sumout => \inst2|Add5~9_sumout\,
	cout => \inst2|Add5~10\);

-- Location: LABCELL_X7_Y2_N27
\inst2|Mux5~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~5_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (!\inst|S\(0) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29)) # ((\inst2|Add5~9_sumout\)))) # (\inst|S\(0) & (((\inst10|A\(3))))) ) ) # ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ( (\inst6|altsyncram_component|auto_generated|q_a\(29) & (!\inst|S\(0) & \inst2|Add5~9_sumout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001000100000000000100010010001011110011111000101111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst10|ALT_INV_A\(3),
	datad => \inst2|ALT_INV_Add5~9_sumout\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	combout => \inst2|Mux5~5_combout\);

-- Location: LABCELL_X9_Y2_N30
\inst2|Add3~30\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add3~30_cout\ = CARRY(( (\inst10|A\(0) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) ) + ( \inst10|A\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000000000001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst10|ALT_INV_A\(0),
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	cin => GND,
	cout => \inst2|Add3~30_cout\);

-- Location: LABCELL_X9_Y2_N33
\inst2|Add3~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add3~1_sumout\ = SUM(( (\inst10|A\(1) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( \inst10|A\(1) ) + ( \inst2|Add3~30_cout\ ))
-- \inst2|Add3~2\ = CARRY(( (\inst10|A\(1) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( \inst10|A\(1) ) + ( \inst2|Add3~30_cout\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst2|Add3~30_cout\,
	sumout => \inst2|Add3~1_sumout\,
	cout => \inst2|Add3~2\);

-- Location: LABCELL_X9_Y2_N36
\inst2|Add3~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add3~5_sumout\ = SUM(( \inst10|A\(2) ) + ( (\inst10|A\(2) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( \inst2|Add3~2\ ))
-- \inst2|Add3~6\ = CARRY(( \inst10|A\(2) ) + ( (\inst10|A\(2) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( \inst2|Add3~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111100110000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(2),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	cin => \inst2|Add3~2\,
	sumout => \inst2|Add3~5_sumout\,
	cout => \inst2|Add3~6\);

-- Location: LABCELL_X9_Y2_N39
\inst2|Add3~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add3~9_sumout\ = SUM(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst10|A\(3)) ) + ( \inst10|A\(3) ) + ( \inst2|Add3~6\ ))
-- \inst2|Add3~10\ = CARRY(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst10|A\(3)) ) + ( \inst10|A\(3) ) + ( \inst2|Add3~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst10|ALT_INV_A\(3),
	cin => \inst2|Add3~6\,
	sumout => \inst2|Add3~9_sumout\,
	cout => \inst2|Add3~10\);

-- Location: LABCELL_X9_Y2_N0
\inst2|Add4~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add4~1_sumout\ = SUM(( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) ) + ( \inst10|A\(0) ) + ( !VCC ))
-- \inst2|Add4~2\ = CARRY(( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) ) + ( \inst10|A\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst10|ALT_INV_A\(0),
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	cin => GND,
	sumout => \inst2|Add4~1_sumout\,
	cout => \inst2|Add4~2\);

-- Location: LABCELL_X9_Y2_N3
\inst2|Add4~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add4~5_sumout\ = SUM(( \inst10|A\(1) ) + ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) ) + ( \inst2|Add4~2\ ))
-- \inst2|Add4~6\ = CARRY(( \inst10|A\(1) ) + ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) ) + ( \inst2|Add4~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	cin => \inst2|Add4~2\,
	sumout => \inst2|Add4~5_sumout\,
	cout => \inst2|Add4~6\);

-- Location: LABCELL_X9_Y2_N6
\inst2|Add4~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add4~9_sumout\ = SUM(( \inst10|A\(2) ) + ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) ) + ( \inst2|Add4~6\ ))
-- \inst2|Add4~10\ = CARRY(( \inst10|A\(2) ) + ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) ) + ( \inst2|Add4~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datad => \inst10|ALT_INV_A\(2),
	cin => \inst2|Add4~6\,
	sumout => \inst2|Add4~9_sumout\,
	cout => \inst2|Add4~10\);

-- Location: LABCELL_X9_Y2_N9
\inst2|Add4~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add4~13_sumout\ = SUM(( \inst10|A\(3) ) + ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) ) + ( \inst2|Add4~10\ ))
-- \inst2|Add4~14\ = CARRY(( \inst10|A\(3) ) + ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) ) + ( \inst2|Add4~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst10|ALT_INV_A\(3),
	cin => \inst2|Add4~10\,
	sumout => \inst2|Add4~13_sumout\,
	cout => \inst2|Add4~14\);

-- Location: LABCELL_X10_Y2_N39
\inst2|Mux5~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~4_combout\ = ( \inst|S\(0) & ( !\inst|S\(1) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000010101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(1),
	dataf => \inst|ALT_INV_S\(0),
	combout => \inst2|Mux5~4_combout\);

-- Location: LABCELL_X7_Y2_N48
\inst2|Mux5~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~6_combout\ = ( \inst2|Add4~13_sumout\ & ( \inst2|Mux5~4_combout\ & ( (!\inst2|F9~2_combout\) # (\inst2|Mux5~3_combout\) ) ) ) # ( !\inst2|Add4~13_sumout\ & ( \inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\ & !\inst2|F9~2_combout\) ) ) ) # 
-- ( \inst2|Add4~13_sumout\ & ( !\inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\ & (\inst2|Mux5~5_combout\)) # (\inst2|Mux5~3_combout\ & ((\inst2|Add3~9_sumout\))) ) ) ) # ( !\inst2|Add4~13_sumout\ & ( !\inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\ 
-- & (\inst2|Mux5~5_combout\)) # (\inst2|Mux5~3_combout\ & ((\inst2|Add3~9_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101001011111000010100101111110001000100010001101110111011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux5~3_combout\,
	datab => \inst2|ALT_INV_F9~2_combout\,
	datac => \inst2|ALT_INV_Mux5~5_combout\,
	datad => \inst2|ALT_INV_Add3~9_sumout\,
	datae => \inst2|ALT_INV_Add4~13_sumout\,
	dataf => \inst2|ALT_INV_Mux5~4_combout\,
	combout => \inst2|Mux5~6_combout\);

-- Location: LABCELL_X9_Y4_N0
\inst2|Add2~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add2~1_sumout\ = SUM(( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) $ (!\inst10|A\(0)) ) + ( !VCC ) + ( !VCC ))
-- \inst2|Add2~2\ = CARRY(( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) $ (!\inst10|A\(0)) ) + ( !VCC ) + ( !VCC ))
-- \inst2|Add2~3\ = SHARE((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # (\inst10|A\(0)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011111100111100000000000000000011110000111100",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst10|ALT_INV_A\(0),
	cin => GND,
	sharein => GND,
	sumout => \inst2|Add2~1_sumout\,
	cout => \inst2|Add2~2\,
	shareout => \inst2|Add2~3\);

-- Location: LABCELL_X9_Y4_N3
\inst2|Add2~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add2~5_sumout\ = SUM(( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) $ (\inst10|A\(1)) ) + ( \inst2|Add2~3\ ) + ( \inst2|Add2~2\ ))
-- \inst2|Add2~6\ = CARRY(( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) $ (\inst10|A\(1)) ) + ( \inst2|Add2~3\ ) + ( \inst2|Add2~2\ ))
-- \inst2|Add2~7\ = SHARE((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & \inst10|A\(1)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000010100000101000000000000000001010010110100101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datac => \inst10|ALT_INV_A\(1),
	cin => \inst2|Add2~2\,
	sharein => \inst2|Add2~3\,
	sumout => \inst2|Add2~5_sumout\,
	cout => \inst2|Add2~6\,
	shareout => \inst2|Add2~7\);

-- Location: LABCELL_X9_Y4_N6
\inst2|Add2~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add2~9_sumout\ = SUM(( !\inst10|A\(2) $ (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( \inst2|Add2~7\ ) + ( \inst2|Add2~6\ ))
-- \inst2|Add2~10\ = CARRY(( !\inst10|A\(2) $ (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( \inst2|Add2~7\ ) + ( \inst2|Add2~6\ ))
-- \inst2|Add2~11\ = SHARE((\inst10|A\(2) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011110000000000000000000000001111000000001111",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datac => \inst10|ALT_INV_A\(2),
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	cin => \inst2|Add2~6\,
	sharein => \inst2|Add2~7\,
	sumout => \inst2|Add2~9_sumout\,
	cout => \inst2|Add2~10\,
	shareout => \inst2|Add2~11\);

-- Location: LABCELL_X9_Y4_N9
\inst2|Add2~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add2~13_sumout\ = SUM(( !\inst10|A\(3) $ (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( \inst2|Add2~11\ ) + ( \inst2|Add2~10\ ))
-- \inst2|Add2~14\ = CARRY(( !\inst10|A\(3) $ (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( \inst2|Add2~11\ ) + ( \inst2|Add2~10\ ))
-- \inst2|Add2~15\ = SHARE((\inst10|A\(3) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010101010000000000000000000000001010101001010101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(3),
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	cin => \inst2|Add2~10\,
	sharein => \inst2|Add2~11\,
	sumout => \inst2|Add2~13_sumout\,
	cout => \inst2|Add2~14\,
	shareout => \inst2|Add2~15\);

-- Location: MLABCELL_X6_Y6_N57
\inst2|Mux5~15\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~15_combout\ = ( \inst10|A\(3) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & (((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst|S\(0) & 
-- ((\inst|S\(1)))) # (\inst|S\(0) & ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (!\inst|S\(1)))))) ) ) # ( !\inst10|A\(3) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & 
-- ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ((!\inst|S\(1)))) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (!\inst|S\(0))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & (!\inst|S\(0) $ 
-- (((!\inst|S\(1)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011100101001100101110010100110010110001111101001011000111110100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datad => \inst|ALT_INV_S\(1),
	dataf => \inst10|ALT_INV_A\(3),
	combout => \inst2|Mux5~15_combout\);

-- Location: LABCELL_X7_Y4_N30
\inst2|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add0~1_sumout\ = SUM(( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & \inst10|A\(0)) ) + ( \inst10|A\(0) ) + ( !VCC ))
-- \inst2|Add0~2\ = CARRY(( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & \inst10|A\(0)) ) + ( \inst10|A\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst10|ALT_INV_A\(0),
	cin => GND,
	sumout => \inst2|Add0~1_sumout\,
	cout => \inst2|Add0~2\);

-- Location: LABCELL_X7_Y4_N33
\inst2|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add0~5_sumout\ = SUM(( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & \inst10|A\(1)) ) + ( \inst10|A\(1) ) + ( \inst2|Add0~2\ ))
-- \inst2|Add0~6\ = CARRY(( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & \inst10|A\(1)) ) + ( \inst10|A\(1) ) + ( \inst2|Add0~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datac => \inst10|ALT_INV_A\(1),
	cin => \inst2|Add0~2\,
	sumout => \inst2|Add0~5_sumout\,
	cout => \inst2|Add0~6\);

-- Location: LABCELL_X7_Y4_N36
\inst2|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add0~9_sumout\ = SUM(( \inst10|A\(2) ) + ( (\inst10|A\(2) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( \inst2|Add0~6\ ))
-- \inst2|Add0~10\ = CARRY(( \inst10|A\(2) ) + ( (\inst10|A\(2) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( \inst2|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(2),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	cin => \inst2|Add0~6\,
	sumout => \inst2|Add0~9_sumout\,
	cout => \inst2|Add0~10\);

-- Location: LABCELL_X7_Y4_N39
\inst2|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add0~13_sumout\ = SUM(( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst10|A\(3)) ) + ( \inst10|A\(3) ) + ( \inst2|Add0~10\ ))
-- \inst2|Add0~14\ = CARRY(( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & \inst10|A\(3)) ) + ( \inst10|A\(3) ) + ( \inst2|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datac => \inst10|ALT_INV_A\(3),
	cin => \inst2|Add0~10\,
	sumout => \inst2|Add0~13_sumout\,
	cout => \inst2|Add0~14\);

-- Location: MLABCELL_X6_Y4_N30
\inst2|Add1~14\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add1~14_cout\ = CARRY(( (\inst10|A\(0) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0)) # (\inst10|A\(0)) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(0),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	cin => GND,
	cout => \inst2|Add1~14_cout\);

-- Location: MLABCELL_X6_Y4_N33
\inst2|Add1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add1~1_sumout\ = SUM(( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & \inst10|A\(1)) ) + ( (\inst10|A\(1)) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( \inst2|Add1~14_cout\ ))
-- \inst2|Add1~2\ = CARRY(( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & \inst10|A\(1)) ) + ( (\inst10|A\(1)) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) ) + ( \inst2|Add1~14_cout\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datac => \inst10|ALT_INV_A\(1),
	cin => \inst2|Add1~14_cout\,
	sumout => \inst2|Add1~1_sumout\,
	cout => \inst2|Add1~2\);

-- Location: MLABCELL_X6_Y4_N36
\inst2|Add1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add1~5_sumout\ = SUM(( (\inst10|A\(2) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # (\inst10|A\(2)) ) + ( \inst2|Add1~2\ ))
-- \inst2|Add1~6\ = CARRY(( (\inst10|A\(2) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # (\inst10|A\(2)) ) + ( \inst2|Add1~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(2),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	cin => \inst2|Add1~2\,
	sumout => \inst2|Add1~5_sumout\,
	cout => \inst2|Add1~6\);

-- Location: MLABCELL_X6_Y4_N39
\inst2|Add1~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add1~9_sumout\ = SUM(( (\inst10|A\(3) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (\inst10|A\(3)) ) + ( \inst2|Add1~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(3),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	cin => \inst2|Add1~6\,
	sumout => \inst2|Add1~9_sumout\);

-- Location: MLABCELL_X6_Y6_N15
\inst2|Mux5~11\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~11_combout\ = ( !\inst|S\(1) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & ((((\inst2|Mux5~15_combout\))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & (((!\inst2|Mux5~15_combout\ & ((\inst2|Add0~13_sumout\))) # 
-- (\inst2|Mux5~15_combout\ & (\inst2|Add1~9_sumout\))))) ) ) # ( \inst|S\(1) & ( (\inst2|Mux5~15_combout\ & ((!\inst6|altsyncram_component|auto_generated|q_a\(29)) # (((\inst2|Add2~13_sumout\)) # (\inst|S\(0))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0000000010101111000000001011111101010101101011110000000010111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst2|ALT_INV_Add2~13_sumout\,
	datad => \inst2|ALT_INV_Mux5~15_combout\,
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst2|ALT_INV_Add0~13_sumout\,
	datag => \inst2|ALT_INV_Add1~9_sumout\,
	combout => \inst2|Mux5~11_combout\);

-- Location: LABCELL_X4_Y3_N51
\inst2|Mux5~8\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~8_combout\ = ( \inst|S\(1) & ( (!\inst|S\(0) & \inst2|Mux5~11_combout\) ) ) # ( !\inst|S\(1) & ( (!\inst|S\(0) & (((\inst2|Mux5~11_combout\)))) # (\inst|S\(0) & (!\inst10|A\(3) & 
-- ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100111000001010000010100000101001001110000010100000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(0),
	datab => \inst10|ALT_INV_A\(3),
	datac => \inst2|ALT_INV_Mux5~11_combout\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datae => \inst|ALT_INV_S\(1),
	combout => \inst2|Mux5~8_combout\);

-- Location: LABCELL_X4_Y3_N54
\inst2|Mux5~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~9_combout\ = ( \inst2|Mux5~6_combout\ & ( \inst2|Mux5~8_combout\ & ( ((!\inst|S[3]~DUPLICATE_q\) # (\inst|S\(0))) # (\inst2|Mux5~7_combout\) ) ) ) # ( !\inst2|Mux5~6_combout\ & ( \inst2|Mux5~8_combout\ & ( (!\inst|S[3]~DUPLICATE_q\) # 
-- ((\inst2|Mux5~7_combout\ & !\inst|S\(0))) ) ) ) # ( \inst2|Mux5~6_combout\ & ( !\inst2|Mux5~8_combout\ & ( (\inst|S[3]~DUPLICATE_q\ & ((\inst|S\(0)) # (\inst2|Mux5~7_combout\))) ) ) ) # ( !\inst2|Mux5~6_combout\ & ( !\inst2|Mux5~8_combout\ & ( 
-- (\inst2|Mux5~7_combout\ & (\inst|S[3]~DUPLICATE_q\ & !\inst|S\(0))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000000010000000100110001001111011100110111001101111111011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux5~7_combout\,
	datab => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	datac => \inst|ALT_INV_S\(0),
	datae => \inst2|ALT_INV_Mux5~6_combout\,
	dataf => \inst2|ALT_INV_Mux5~8_combout\,
	combout => \inst2|Mux5~9_combout\);

-- Location: MLABCELL_X6_Y4_N24
\inst2|Mux5~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux5~10_combout\ = ( \inst2|Mux5~0_combout\ & ( \inst2|Mux5~1_combout\ & ( (!\inst2|Mux5~2_combout\ & ((\inst2|Mux5~9_combout\))) # (\inst2|Mux5~2_combout\ & (\inst10|A\(3))) ) ) ) # ( !\inst2|Mux5~0_combout\ & ( \inst2|Mux5~1_combout\ & ( 
-- (!\inst2|Mux5~2_combout\ & (((\inst2|Mux5~9_combout\)))) # (\inst2|Mux5~2_combout\ & (((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3))) # (\inst10|A\(3)))) ) ) ) # ( \inst2|Mux5~0_combout\ & ( !\inst2|Mux5~1_combout\ & ( 
-- (!\inst2|Mux5~2_combout\ & ((\inst2|Mux5~9_combout\))) # (\inst2|Mux5~2_combout\ & (\inst10|A\(3))) ) ) ) # ( !\inst2|Mux5~0_combout\ & ( !\inst2|Mux5~1_combout\ & ( \inst2|Mux5~9_combout\ ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000111010001110100011101001111110001110100011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(3),
	datab => \inst2|ALT_INV_Mux5~2_combout\,
	datac => \inst2|ALT_INV_Mux5~9_combout\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datae => \inst2|ALT_INV_Mux5~0_combout\,
	dataf => \inst2|ALT_INV_Mux5~1_combout\,
	combout => \inst2|Mux5~10_combout\);

-- Location: MLABCELL_X6_Y6_N6
\inst18|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst18|Mux5~0_combout\ = ( \inst6|altsyncram_component|auto_generated|q_a\(29) & ( \inst6|altsyncram_component|auto_generated|q_a\(28) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	dataf => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(28),
	combout => \inst18|Mux5~0_combout\);

-- Location: FF_X6_Y4_N26
\inst10|A[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst2|Mux5~10_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3),
	sload => \inst18|Mux5~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|A\(3));

-- Location: M10K_X5_Y2_N0
\inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0\ : cyclonev_ram_block
-- pragma translate_off
GENERIC MAP (
	mem_init2 => "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init1 => "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init0 => "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000800007000060000500004000030000200001",
	data_interleave_offset_in_bits => 1,
	data_interleave_width_in_bits => 1,
	init_file => "RAM.mif",
	init_file_layout => "port_a",
	logical_ram_name => "RAM:inst5|altsyncram:altsyncram_component|altsyncram_co34:auto_generated|altsyncram_t613:altsyncram1|ALTSYNCRAM",
	mixed_port_feed_through_mode => "dont_care",
	operation_mode => "bidir_dual_port",
	port_a_address_clear => "none",
	port_a_address_width => 8,
	port_a_byte_enable_clock => "none",
	port_a_data_out_clear => "none",
	port_a_data_out_clock => "clock0",
	port_a_data_width => 20,
	port_a_first_address => 0,
	port_a_first_bit_number => 0,
	port_a_last_address => 255,
	port_a_logical_ram_depth => 256,
	port_a_logical_ram_width => 8,
	port_a_read_during_write_mode => "new_data_no_nbe_read",
	port_b_address_clear => "none",
	port_b_address_clock => "clock1",
	port_b_address_width => 8,
	port_b_data_in_clock => "clock1",
	port_b_data_out_clear => "none",
	port_b_data_out_clock => "none",
	port_b_data_width => 20,
	port_b_first_address => 0,
	port_b_first_bit_number => 0,
	port_b_last_address => 255,
	port_b_logical_ram_depth => 256,
	port_b_logical_ram_width => 8,
	port_b_read_during_write_mode => "new_data_no_nbe_read",
	port_b_read_enable_clock => "clock1",
	port_b_write_enable_clock => "clock1",
	ram_block_type => "M20K")
-- pragma translate_on
PORT MAP (
	portawe => \inst18|Mux4~0_combout\,
	portare => \inst18|Mux3~0_combout\,
	portbwe => \inst5|altsyncram_component|auto_generated|mgl_prim2|enable_write~0_combout\,
	portbre => VCC,
	clk0 => \ALT_INV_clk~inputCLKENA0_outclk\,
	clk1 => \altera_internal_jtag~TCKUTAP\,
	portadatain => \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAIN_bus\,
	portbdatain => \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAIN_bus\,
	portaaddr => \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTAADDR_bus\,
	portbaddr => \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBADDR_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	portadataout => \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTADATAOUT_bus\,
	portbdataout => \inst5|altsyncram_component|auto_generated|altsyncram1|ram_block3a0_PORTBDATAOUT_bus\);

-- Location: LABCELL_X2_Y2_N45
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[7]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(7),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[7]~feeder_combout\);

-- Location: FF_X1_Y4_N29
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg[1]~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_shift_cntr_reg\(1));

-- Location: LABCELL_X1_Y4_N36
\inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111100001111000011110000111000001111000011100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\);

-- Location: LABCELL_X1_Y4_N24
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101011111111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][3]~q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\,
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(2),
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(0),
	datae => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_shift_cntr_reg\(1),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg[1]~0_combout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1_combout\);

-- Location: FF_X2_Y2_N47
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[7]~feeder_combout\,
	asdata => \altera_internal_jtag~TDIUTAP\,
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(7));

-- Location: LABCELL_X2_Y2_N42
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[6]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(6),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[6]~feeder_combout\);

-- Location: FF_X2_Y2_N44
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[6]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(7),
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(6));

-- Location: LABCELL_X2_Y2_N51
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[5]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(5),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[5]~feeder_combout\);

-- Location: FF_X2_Y2_N53
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[5]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(6),
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(5));

-- Location: LABCELL_X2_Y2_N48
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[4]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(4),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[4]~feeder_combout\);

-- Location: FF_X2_Y2_N50
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[4]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(5),
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(4));

-- Location: LABCELL_X2_Y2_N9
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[3]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(3),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[3]~feeder_combout\);

-- Location: FF_X2_Y2_N11
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[3]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(4),
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(3));

-- Location: LABCELL_X2_Y2_N12
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(2),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[2]~feeder_combout\);

-- Location: FF_X2_Y2_N14
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[2]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(3),
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(2));

-- Location: LABCELL_X2_Y2_N57
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(1),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~feeder_combout\);

-- Location: FF_X2_Y2_N58
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(2),
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(1));

-- Location: MLABCELL_X8_Y2_N12
\inst2|Add6~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add6~13_sumout\ = SUM(( \inst10|A\(4) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst10|A\(4)) ) + ( \inst2|Add6~10\ ))
-- \inst2|Add6~14\ = CARRY(( \inst10|A\(4) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst10|A\(4)) ) + ( \inst2|Add6~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001100000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(4),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	cin => \inst2|Add6~10\,
	sumout => \inst2|Add6~13_sumout\,
	cout => \inst2|Add6~14\);

-- Location: MLABCELL_X8_Y2_N15
\inst2|Add6~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add6~17_sumout\ = SUM(( \inst10|A[5]~DUPLICATE_q\ ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst10|A[5]~DUPLICATE_q\) ) + ( \inst2|Add6~14\ ))
-- \inst2|Add6~18\ = CARRY(( \inst10|A[5]~DUPLICATE_q\ ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst10|A[5]~DUPLICATE_q\) ) + ( \inst2|Add6~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	cin => \inst2|Add6~14\,
	sumout => \inst2|Add6~17_sumout\,
	cout => \inst2|Add6~18\);

-- Location: MLABCELL_X8_Y2_N18
\inst2|Add6~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add6~21_sumout\ = SUM(( \inst10|A\(6) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # (\inst10|A\(6)) ) + ( \inst2|Add6~18\ ))
-- \inst2|Add6~22\ = CARRY(( \inst10|A\(6) ) + ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # (\inst10|A\(6)) ) + ( \inst2|Add6~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(6),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	cin => \inst2|Add6~18\,
	sumout => \inst2|Add6~21_sumout\,
	cout => \inst2|Add6~22\);

-- Location: MLABCELL_X8_Y2_N21
\inst2|Add6~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add6~25_sumout\ = SUM(( \inst10|A\(7) ) + ( (\inst10|A\(7)) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) ) + ( \inst2|Add6~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101000001010000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datac => \inst10|ALT_INV_A\(7),
	cin => \inst2|Add6~22\,
	sumout => \inst2|Add6~25_sumout\);

-- Location: MLABCELL_X8_Y2_N42
\inst2|Add7~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add7~17_sumout\ = SUM(( \inst10|A\(4) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst10|A\(4)) ) + ( \inst2|Add7~14\ ))
-- \inst2|Add7~18\ = CARRY(( \inst10|A\(4) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst10|A\(4)) ) + ( \inst2|Add7~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(4),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	cin => \inst2|Add7~14\,
	sumout => \inst2|Add7~17_sumout\,
	cout => \inst2|Add7~18\);

-- Location: MLABCELL_X8_Y2_N45
\inst2|Add7~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add7~21_sumout\ = SUM(( \inst10|A[5]~DUPLICATE_q\ ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst10|A[5]~DUPLICATE_q\) ) + ( \inst2|Add7~18\ ))
-- \inst2|Add7~22\ = CARRY(( \inst10|A[5]~DUPLICATE_q\ ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst10|A[5]~DUPLICATE_q\) ) + ( \inst2|Add7~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000001111000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	cin => \inst2|Add7~18\,
	sumout => \inst2|Add7~21_sumout\,
	cout => \inst2|Add7~22\);

-- Location: MLABCELL_X8_Y2_N48
\inst2|Add7~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add7~25_sumout\ = SUM(( \inst10|A\(6) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # (\inst10|A\(6)) ) + ( \inst2|Add7~22\ ))
-- \inst2|Add7~26\ = CARRY(( \inst10|A\(6) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # (\inst10|A\(6)) ) + ( \inst2|Add7~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000001100110000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(6),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	cin => \inst2|Add7~22\,
	sumout => \inst2|Add7~25_sumout\,
	cout => \inst2|Add7~26\);

-- Location: MLABCELL_X8_Y2_N51
\inst2|Add7~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add7~29_sumout\ = SUM(( \inst10|A\(7) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) # (\inst10|A\(7)) ) + ( \inst2|Add7~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datac => \inst10|ALT_INV_A\(7),
	cin => \inst2|Add7~26\,
	sumout => \inst2|Add7~29_sumout\);

-- Location: LABCELL_X9_Y4_N42
\inst2|Mux1~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux1~2_combout\ = ( \inst2|Add7~29_sumout\ & ( \inst|S\(1) ) ) # ( \inst2|Add7~29_sumout\ & ( !\inst|S\(1) & ( (!\inst|S\(0) & (((\inst10|A\(6) & \inst6|altsyncram_component|auto_generated|q_a\(29))))) # (\inst|S\(0) & (\inst2|Add6~25_sumout\)) ) ) 
-- ) # ( !\inst2|Add7~29_sumout\ & ( !\inst|S\(1) & ( (!\inst|S\(0) & (((\inst10|A\(6) & \inst6|altsyncram_component|auto_generated|q_a\(29))))) # (\inst|S\(0) & (\inst2|Add6~25_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100011101000100010001110100000000000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Add6~25_sumout\,
	datab => \inst|ALT_INV_S\(0),
	datac => \inst10|ALT_INV_A\(6),
	datad => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datae => \inst2|ALT_INV_Add7~29_sumout\,
	dataf => \inst|ALT_INV_S\(1),
	combout => \inst2|Mux1~2_combout\);

-- Location: LABCELL_X9_Y2_N42
\inst2|Add3~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add3~13_sumout\ = SUM(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst10|A\(4)) ) + ( \inst10|A\(4) ) + ( \inst2|Add3~10\ ))
-- \inst2|Add3~14\ = CARRY(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst10|A\(4)) ) + ( \inst10|A\(4) ) + ( \inst2|Add3~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst10|ALT_INV_A\(4),
	cin => \inst2|Add3~10\,
	sumout => \inst2|Add3~13_sumout\,
	cout => \inst2|Add3~14\);

-- Location: LABCELL_X9_Y2_N45
\inst2|Add3~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add3~17_sumout\ = SUM(( (\inst10|A[5]~DUPLICATE_q\ & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) ) + ( \inst10|A[5]~DUPLICATE_q\ ) + ( \inst2|Add3~14\ ))
-- \inst2|Add3~18\ = CARRY(( (\inst10|A[5]~DUPLICATE_q\ & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) ) + ( \inst10|A[5]~DUPLICATE_q\ ) + ( \inst2|Add3~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000000000001010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	cin => \inst2|Add3~14\,
	sumout => \inst2|Add3~17_sumout\,
	cout => \inst2|Add3~18\);

-- Location: LABCELL_X9_Y2_N48
\inst2|Add3~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add3~21_sumout\ = SUM(( \inst10|A\(6) ) + ( (\inst10|A\(6) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst2|Add3~18\ ))
-- \inst2|Add3~22\ = CARRY(( \inst10|A\(6) ) + ( (\inst10|A\(6) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst2|Add3~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst10|ALT_INV_A\(6),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	cin => \inst2|Add3~18\,
	sumout => \inst2|Add3~21_sumout\,
	cout => \inst2|Add3~22\);

-- Location: LABCELL_X9_Y2_N51
\inst2|Add3~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add3~25_sumout\ = SUM(( (\inst10|A\(7) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) ) + ( \inst10|A\(7) ) + ( \inst2|Add3~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000000000001010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(7),
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	cin => \inst2|Add3~22\,
	sumout => \inst2|Add3~25_sumout\);

-- Location: LABCELL_X7_Y4_N21
\inst2|F9~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|F9~6_combout\ = ( \inst10|A\(7) & ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) ) ) # ( !\inst10|A\(7) & ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010110101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	dataf => \inst10|ALT_INV_A\(7),
	combout => \inst2|F9~6_combout\);

-- Location: LABCELL_X7_Y2_N12
\inst2|Add5~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add5~13_sumout\ = SUM(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst10|A\(4)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst10|A\(4)) ) + ( \inst2|Add5~10\ ))
-- \inst2|Add5~14\ = CARRY(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst10|A\(4)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # (\inst10|A\(4)) ) + ( \inst2|Add5~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100000011000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst10|ALT_INV_A\(4),
	cin => \inst2|Add5~10\,
	sumout => \inst2|Add5~13_sumout\,
	cout => \inst2|Add5~14\);

-- Location: LABCELL_X7_Y2_N15
\inst2|Add5~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add5~17_sumout\ = SUM(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & \inst10|A[5]~DUPLICATE_q\) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst10|A[5]~DUPLICATE_q\) ) + ( \inst2|Add5~14\ ))
-- \inst2|Add5~18\ = CARRY(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & \inst10|A[5]~DUPLICATE_q\) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst10|A[5]~DUPLICATE_q\) ) + ( \inst2|Add5~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datac => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	cin => \inst2|Add5~14\,
	sumout => \inst2|Add5~17_sumout\,
	cout => \inst2|Add5~18\);

-- Location: LABCELL_X7_Y2_N18
\inst2|Add5~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add5~21_sumout\ = SUM(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & \inst10|A\(6)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # (\inst10|A\(6)) ) + ( \inst2|Add5~18\ ))
-- \inst2|Add5~22\ = CARRY(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & \inst10|A\(6)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) # (\inst10|A\(6)) ) + ( \inst2|Add5~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100000011000000000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datac => \inst10|ALT_INV_A\(6),
	cin => \inst2|Add5~18\,
	sumout => \inst2|Add5~21_sumout\,
	cout => \inst2|Add5~22\);

-- Location: LABCELL_X7_Y2_N21
\inst2|Add5~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add5~25_sumout\ = SUM(( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & \inst10|A\(7)) ) + ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) # (\inst10|A\(7)) ) + ( \inst2|Add5~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000000000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datac => \inst10|ALT_INV_A\(7),
	cin => \inst2|Add5~22\,
	sumout => \inst2|Add5~25_sumout\);

-- Location: LABCELL_X7_Y2_N54
\inst2|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux1~0_combout\ = ( \inst10|A\(7) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & (((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst|S\(0) & 
-- ((\inst2|Add5~25_sumout\))) # (\inst|S\(0) & (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7))))) ) ) # ( !\inst10|A\(7) & ( (!\inst|S\(0) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((\inst2|Add5~25_sumout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100001001100000010000100110000001011010011110000101101001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datad => \inst2|ALT_INV_Add5~25_sumout\,
	dataf => \inst10|ALT_INV_A\(7),
	combout => \inst2|Mux1~0_combout\);

-- Location: LABCELL_X9_Y2_N12
\inst2|Add4~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add4~17_sumout\ = SUM(( \inst10|A\(4) ) + ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) ) + ( \inst2|Add4~14\ ))
-- \inst2|Add4~18\ = CARRY(( \inst10|A\(4) ) + ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) ) + ( \inst2|Add4~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst10|ALT_INV_A\(4),
	cin => \inst2|Add4~14\,
	sumout => \inst2|Add4~17_sumout\,
	cout => \inst2|Add4~18\);

-- Location: LABCELL_X9_Y2_N15
\inst2|Add4~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add4~21_sumout\ = SUM(( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) ) + ( \inst10|A[5]~DUPLICATE_q\ ) + ( \inst2|Add4~18\ ))
-- \inst2|Add4~22\ = CARRY(( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) ) + ( \inst10|A[5]~DUPLICATE_q\ ) + ( \inst2|Add4~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111110000000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	cin => \inst2|Add4~18\,
	sumout => \inst2|Add4~21_sumout\,
	cout => \inst2|Add4~22\);

-- Location: LABCELL_X9_Y2_N18
\inst2|Add4~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add4~25_sumout\ = SUM(( \inst10|A\(6) ) + ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) ) + ( \inst2|Add4~22\ ))
-- \inst2|Add4~26\ = CARRY(( \inst10|A\(6) ) + ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) ) + ( \inst2|Add4~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(6),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	cin => \inst2|Add4~22\,
	sumout => \inst2|Add4~25_sumout\,
	cout => \inst2|Add4~26\);

-- Location: LABCELL_X9_Y2_N21
\inst2|Add4~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add4~29_sumout\ = SUM(( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) ) + ( \inst10|A\(7) ) + ( \inst2|Add4~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111110000000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	dataf => \inst10|ALT_INV_A\(7),
	cin => \inst2|Add4~26\,
	sumout => \inst2|Add4~29_sumout\);

-- Location: MLABCELL_X8_Y2_N27
\inst2|Mux1~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux1~1_combout\ = ( \inst2|Add4~29_sumout\ & ( \inst2|Mux5~4_combout\ & ( (!\inst2|F9~6_combout\) # (\inst2|Mux5~3_combout\) ) ) ) # ( !\inst2|Add4~29_sumout\ & ( \inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\ & !\inst2|F9~6_combout\) ) ) ) # 
-- ( \inst2|Add4~29_sumout\ & ( !\inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\ & ((\inst2|Mux1~0_combout\))) # (\inst2|Mux5~3_combout\ & (\inst2|Add3~25_sumout\)) ) ) ) # ( !\inst2|Add4~29_sumout\ & ( !\inst2|Mux5~4_combout\ & ( 
-- (!\inst2|Mux5~3_combout\ & ((\inst2|Mux1~0_combout\))) # (\inst2|Mux5~3_combout\ & (\inst2|Add3~25_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000111011101000100011101110111000000110000001111001111110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Add3~25_sumout\,
	datab => \inst2|ALT_INV_Mux5~3_combout\,
	datac => \inst2|ALT_INV_F9~6_combout\,
	datad => \inst2|ALT_INV_Mux1~0_combout\,
	datae => \inst2|ALT_INV_Add4~29_sumout\,
	dataf => \inst2|ALT_INV_Mux5~4_combout\,
	combout => \inst2|Mux1~1_combout\);

-- Location: LABCELL_X9_Y4_N12
\inst2|Add2~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add2~17_sumout\ = SUM(( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) $ (\inst10|A\(4)) ) + ( \inst2|Add2~15\ ) + ( \inst2|Add2~14\ ))
-- \inst2|Add2~18\ = CARRY(( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) $ (\inst10|A\(4)) ) + ( \inst2|Add2~15\ ) + ( \inst2|Add2~14\ ))
-- \inst2|Add2~19\ = SHARE((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst10|A\(4)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000001100001111000011",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst10|ALT_INV_A\(4),
	cin => \inst2|Add2~14\,
	sharein => \inst2|Add2~15\,
	sumout => \inst2|Add2~17_sumout\,
	cout => \inst2|Add2~18\,
	shareout => \inst2|Add2~19\);

-- Location: LABCELL_X9_Y4_N15
\inst2|Add2~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add2~21_sumout\ = SUM(( !\inst10|A[5]~DUPLICATE_q\ $ (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) ) + ( \inst2|Add2~19\ ) + ( \inst2|Add2~18\ ))
-- \inst2|Add2~22\ = CARRY(( !\inst10|A[5]~DUPLICATE_q\ $ (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) ) + ( \inst2|Add2~19\ ) + ( \inst2|Add2~18\ ))
-- \inst2|Add2~23\ = SHARE((\inst10|A[5]~DUPLICATE_q\ & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000010100000101000000000000000000001010010110100101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	cin => \inst2|Add2~18\,
	sharein => \inst2|Add2~19\,
	sumout => \inst2|Add2~21_sumout\,
	cout => \inst2|Add2~22\,
	shareout => \inst2|Add2~23\);

-- Location: LABCELL_X9_Y4_N18
\inst2|Add2~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add2~25_sumout\ = SUM(( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) $ (\inst10|A\(6)) ) + ( \inst2|Add2~23\ ) + ( \inst2|Add2~22\ ))
-- \inst2|Add2~26\ = CARRY(( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) $ (\inst10|A\(6)) ) + ( \inst2|Add2~23\ ) + ( \inst2|Add2~22\ ))
-- \inst2|Add2~27\ = SHARE((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & \inst10|A\(6)))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000011000000110000000000000000001100001111000011",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datac => \inst10|ALT_INV_A\(6),
	cin => \inst2|Add2~22\,
	sharein => \inst2|Add2~23\,
	sumout => \inst2|Add2~25_sumout\,
	cout => \inst2|Add2~26\,
	shareout => \inst2|Add2~27\);

-- Location: LABCELL_X9_Y4_N21
\inst2|Add2~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add2~29_sumout\ = SUM(( !\inst10|A\(7) $ (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) ) + ( \inst2|Add2~27\ ) + ( \inst2|Add2~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000001010010110100101",
	shared_arith => "on")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(7),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	cin => \inst2|Add2~26\,
	sharein => \inst2|Add2~27\,
	sumout => \inst2|Add2~29_sumout\);

-- Location: LABCELL_X7_Y4_N42
\inst2|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add0~17_sumout\ = SUM(( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst10|A\(4)) ) + ( \inst10|A\(4) ) + ( \inst2|Add0~14\ ))
-- \inst2|Add0~18\ = CARRY(( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst10|A\(4)) ) + ( \inst10|A\(4) ) + ( \inst2|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst10|ALT_INV_A\(4),
	cin => \inst2|Add0~14\,
	sumout => \inst2|Add0~17_sumout\,
	cout => \inst2|Add0~18\);

-- Location: LABCELL_X7_Y4_N45
\inst2|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add0~21_sumout\ = SUM(( (\inst10|A[5]~DUPLICATE_q\ & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) ) + ( \inst10|A[5]~DUPLICATE_q\ ) + ( \inst2|Add0~18\ ))
-- \inst2|Add0~22\ = CARRY(( (\inst10|A[5]~DUPLICATE_q\ & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) ) + ( \inst10|A[5]~DUPLICATE_q\ ) + ( \inst2|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000101010100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	cin => \inst2|Add0~18\,
	sumout => \inst2|Add0~21_sumout\,
	cout => \inst2|Add0~22\);

-- Location: LABCELL_X7_Y4_N48
\inst2|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add0~25_sumout\ = SUM(( (\inst10|A\(6) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst10|A\(6) ) + ( \inst2|Add0~22\ ))
-- \inst2|Add0~26\ = CARRY(( (\inst10|A\(6) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)) ) + ( \inst10|A\(6) ) + ( \inst2|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110011001100110000000000000000000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst10|ALT_INV_A\(6),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	cin => \inst2|Add0~22\,
	sumout => \inst2|Add0~25_sumout\,
	cout => \inst2|Add0~26\);

-- Location: LABCELL_X7_Y4_N51
\inst2|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Add0~29_sumout\ = SUM(( (\inst10|A\(7) & !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) ) + ( \inst10|A\(7) ) + ( \inst2|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101010101010101000000000000000000101010100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(7),
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	cin => \inst2|Add0~26\,
	sumout => \inst2|Add0~29_sumout\);

-- Location: LABCELL_X9_Y4_N54
\inst2|Mux1~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux1~5_combout\ = ( !\inst|S\(1) & ( (!\inst|S\(0) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst10|A\(7)) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7))))) # 
-- (\inst6|altsyncram_component|auto_generated|q_a\(29) & (((\inst2|Add0~29_sumout\)))))) # (\inst|S\(0) & (!\inst10|A\(7) & (((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7)))))) ) ) # ( \inst|S\(1) & ( (!\inst|S\(0) & 
-- ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & (!\inst10|A\(7) $ (((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7)))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & (((\inst2|Add2~29_sumout\)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1110111010001000010001001000100000101110000011000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(7),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst2|ALT_INV_Add2~29_sumout\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datag => \inst2|ALT_INV_Add0~29_sumout\,
	combout => \inst2|Mux1~5_combout\);

-- Location: LABCELL_X11_Y6_N36
\inst2|Mux1~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux1~3_combout\ = ( \inst2|Mux1~5_combout\ & ( (!\inst|S[3]~DUPLICATE_q\) # ((!\inst|S\(0) & (\inst2|Mux1~2_combout\)) # (\inst|S\(0) & ((\inst2|Mux1~1_combout\)))) ) ) # ( !\inst2|Mux1~5_combout\ & ( (\inst|S[3]~DUPLICATE_q\ & ((!\inst|S\(0) & 
-- (\inst2|Mux1~2_combout\)) # (\inst|S\(0) & ((\inst2|Mux1~1_combout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000010011000000100001001111001110110111111100111011011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(0),
	datab => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	datac => \inst2|ALT_INV_Mux1~2_combout\,
	datad => \inst2|ALT_INV_Mux1~1_combout\,
	dataf => \inst2|ALT_INV_Mux1~5_combout\,
	combout => \inst2|Mux1~3_combout\);

-- Location: LABCELL_X11_Y6_N54
\inst2|Mux1~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux1~4_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( \inst2|Mux5~0_combout\ & ( (!\inst2|Mux5~2_combout\ & (\inst2|Mux1~3_combout\)) # (\inst2|Mux5~2_combout\ & ((\inst10|A\(7)))) ) ) ) # ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( \inst2|Mux5~0_combout\ & ( (!\inst2|Mux5~2_combout\ & (\inst2|Mux1~3_combout\)) # (\inst2|Mux5~2_combout\ & ((\inst10|A\(7)))) ) ) ) # ( 
-- \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( !\inst2|Mux5~0_combout\ & ( ((\inst2|Mux5~1_combout\ & \inst2|Mux5~2_combout\)) # (\inst2|Mux1~3_combout\) ) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ( 
-- !\inst2|Mux5~0_combout\ & ( (!\inst2|Mux5~1_combout\ & (((\inst2|Mux1~3_combout\)))) # (\inst2|Mux5~1_combout\ & ((!\inst2|Mux5~2_combout\ & (\inst2|Mux1~3_combout\)) # (\inst2|Mux5~2_combout\ & ((\inst10|A\(7)))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111000011111000111110001111100001100001111110000110000111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux5~1_combout\,
	datab => \inst2|ALT_INV_Mux5~2_combout\,
	datac => \inst2|ALT_INV_Mux1~3_combout\,
	datad => \inst10|ALT_INV_A\(7),
	datae => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	dataf => \inst2|ALT_INV_Mux5~0_combout\,
	combout => \inst2|Mux1~4_combout\);

-- Location: FF_X11_Y6_N56
\inst10|A[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst2|Mux1~4_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7),
	sload => \inst18|Mux5~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|A\(7));

-- Location: LABCELL_X9_Y4_N24
\inst2|Mux2~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux2~5_combout\ = ( !\inst|S\(1) & ( (!\inst|S\(0) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst10|A\(6)) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6))))) # 
-- (\inst6|altsyncram_component|auto_generated|q_a\(29) & (((\inst2|Add0~25_sumout\)))))) # (\inst|S\(0) & (!\inst10|A\(6) & (((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)))))) ) ) # ( \inst|S\(1) & ( (!\inst|S\(0) & 
-- ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & (!\inst10|A\(6) $ (((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & (((\inst2|Add2~25_sumout\)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1110111010001000010001001000100000101110000011000000110000001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(6),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst2|ALT_INV_Add2~25_sumout\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datag => \inst2|ALT_INV_Add0~25_sumout\,
	combout => \inst2|Mux2~5_combout\);

-- Location: LABCELL_X9_Y2_N54
\inst2|Mux2~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux2~2_combout\ = ( \inst2|Add7~25_sumout\ & ( \inst10|A[5]~DUPLICATE_q\ & ( ((!\inst|S\(0) & (\inst6|altsyncram_component|auto_generated|q_a\(29))) # (\inst|S\(0) & ((\inst2|Add6~21_sumout\)))) # (\inst|S\(1)) ) ) ) # ( !\inst2|Add7~25_sumout\ & ( 
-- \inst10|A[5]~DUPLICATE_q\ & ( (!\inst|S\(1) & ((!\inst|S\(0) & (\inst6|altsyncram_component|auto_generated|q_a\(29))) # (\inst|S\(0) & ((\inst2|Add6~21_sumout\))))) ) ) ) # ( \inst2|Add7~25_sumout\ & ( !\inst10|A[5]~DUPLICATE_q\ & ( ((\inst|S\(0) & 
-- \inst2|Add6~21_sumout\)) # (\inst|S\(1)) ) ) ) # ( !\inst2|Add7~25_sumout\ & ( !\inst10|A[5]~DUPLICATE_q\ & ( (!\inst|S\(1) & (\inst|S\(0) & \inst2|Add6~21_sumout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000100010010101010111011100001000001010100101110101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(1),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datad => \inst2|ALT_INV_Add6~21_sumout\,
	datae => \inst2|ALT_INV_Add7~25_sumout\,
	dataf => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	combout => \inst2|Mux2~2_combout\);

-- Location: LABCELL_X7_Y2_N57
\inst2|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux2~0_combout\ = ( \inst10|A\(6) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & (((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst|S\(0) & 
-- (\inst2|Add5~21_sumout\)) # (\inst|S\(0) & ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)))))) ) ) # ( !\inst10|A\(6) & ( (!\inst|S\(0) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & 
-- ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6)))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & (\inst2|Add5~21_sumout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010010001100000001001000110000000100101111110000010010111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst2|ALT_INV_Add5~21_sumout\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	dataf => \inst10|ALT_INV_A\(6),
	combout => \inst2|Mux2~0_combout\);

-- Location: LABCELL_X10_Y2_N18
\inst2|F9~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|F9~5_combout\ = ( \inst10|A\(6) & ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) ) ) # ( !\inst10|A\(6) & ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111100001111000000001111000011111111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datae => \inst10|ALT_INV_A\(6),
	combout => \inst2|F9~5_combout\);

-- Location: LABCELL_X10_Y2_N3
\inst2|Mux2~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux2~1_combout\ = ( \inst2|Add3~21_sumout\ & ( \inst2|F9~5_combout\ & ( (!\inst2|Mux5~4_combout\ & (((\inst2|Mux5~3_combout\)) # (\inst2|Mux2~0_combout\))) # (\inst2|Mux5~4_combout\ & (((\inst2|Add4~25_sumout\ & \inst2|Mux5~3_combout\)))) ) ) ) # ( 
-- !\inst2|Add3~21_sumout\ & ( \inst2|F9~5_combout\ & ( (!\inst2|Mux5~4_combout\ & (\inst2|Mux2~0_combout\ & ((!\inst2|Mux5~3_combout\)))) # (\inst2|Mux5~4_combout\ & (((\inst2|Add4~25_sumout\ & \inst2|Mux5~3_combout\)))) ) ) ) # ( \inst2|Add3~21_sumout\ & ( 
-- !\inst2|F9~5_combout\ & ( (!\inst2|Mux5~4_combout\ & (((\inst2|Mux5~3_combout\)) # (\inst2|Mux2~0_combout\))) # (\inst2|Mux5~4_combout\ & (((!\inst2|Mux5~3_combout\) # (\inst2|Add4~25_sumout\)))) ) ) ) # ( !\inst2|Add3~21_sumout\ & ( !\inst2|F9~5_combout\ 
-- & ( (!\inst2|Mux5~4_combout\ & (\inst2|Mux2~0_combout\ & ((!\inst2|Mux5~3_combout\)))) # (\inst2|Mux5~4_combout\ & (((!\inst2|Mux5~3_combout\) # (\inst2|Add4~25_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111011100000011011101111100111101000100000000110100010011001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux2~0_combout\,
	datab => \inst2|ALT_INV_Mux5~4_combout\,
	datac => \inst2|ALT_INV_Add4~25_sumout\,
	datad => \inst2|ALT_INV_Mux5~3_combout\,
	datae => \inst2|ALT_INV_Add3~21_sumout\,
	dataf => \inst2|ALT_INV_F9~5_combout\,
	combout => \inst2|Mux2~1_combout\);

-- Location: LABCELL_X11_Y6_N15
\inst2|Mux2~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux2~3_combout\ = ( \inst2|Mux2~1_combout\ & ( (!\inst|S[3]~DUPLICATE_q\ & (((\inst2|Mux2~5_combout\)))) # (\inst|S[3]~DUPLICATE_q\ & (((\inst2|Mux2~2_combout\)) # (\inst|S\(0)))) ) ) # ( !\inst2|Mux2~1_combout\ & ( (!\inst|S[3]~DUPLICATE_q\ & 
-- (((\inst2|Mux2~5_combout\)))) # (\inst|S[3]~DUPLICATE_q\ & (!\inst|S\(0) & ((\inst2|Mux2~2_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000101110000011000010111000011101001111110001110100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(0),
	datab => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	datac => \inst2|ALT_INV_Mux2~5_combout\,
	datad => \inst2|ALT_INV_Mux2~2_combout\,
	dataf => \inst2|ALT_INV_Mux2~1_combout\,
	combout => \inst2|Mux2~3_combout\);

-- Location: LABCELL_X11_Y6_N24
\inst2|Mux2~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux2~4_combout\ = ( \inst10|A\(6) & ( \inst2|Mux5~0_combout\ & ( (\inst2|Mux2~3_combout\) # (\inst2|Mux5~2_combout\) ) ) ) # ( !\inst10|A\(6) & ( \inst2|Mux5~0_combout\ & ( (!\inst2|Mux5~2_combout\ & \inst2|Mux2~3_combout\) ) ) ) # ( \inst10|A\(6) 
-- & ( !\inst2|Mux5~0_combout\ & ( ((\inst2|Mux5~2_combout\ & \inst2|Mux5~1_combout\)) # (\inst2|Mux2~3_combout\) ) ) ) # ( !\inst10|A\(6) & ( !\inst2|Mux5~0_combout\ & ( (!\inst2|Mux5~2_combout\ & (((\inst2|Mux2~3_combout\)))) # (\inst2|Mux5~2_combout\ & 
-- ((!\inst2|Mux5~1_combout\ & ((\inst2|Mux2~3_combout\))) # (\inst2|Mux5~1_combout\ & (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000111111101000000111111111100000000110011000011001111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	datab => \inst2|ALT_INV_Mux5~2_combout\,
	datac => \inst2|ALT_INV_Mux5~1_combout\,
	datad => \inst2|ALT_INV_Mux2~3_combout\,
	datae => \inst10|ALT_INV_A\(6),
	dataf => \inst2|ALT_INV_Mux5~0_combout\,
	combout => \inst2|Mux2~4_combout\);

-- Location: FF_X11_Y6_N26
\inst10|A[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst2|Mux2~4_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6),
	sload => \inst18|Mux5~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|A\(6));

-- Location: LABCELL_X7_Y2_N30
\inst2|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux3~0_combout\ = ( \inst2|Add5~17_sumout\ & ( (!\inst|S\(0) & (((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))) # (\inst6|altsyncram_component|auto_generated|q_a\(29)))) # (\inst|S\(0) & 
-- (((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & \inst10|A[5]~DUPLICATE_q\)))) ) ) # ( !\inst2|Add5~17_sumout\ & ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ((!\inst|S\(0) & 
-- (!\inst6|altsyncram_component|auto_generated|q_a\(29))) # (\inst|S\(0) & ((\inst10|A[5]~DUPLICATE_q\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000001011000010000000101101001100010011110100110001001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	dataf => \inst2|ALT_INV_Add5~17_sumout\,
	combout => \inst2|Mux3~0_combout\);

-- Location: LABCELL_X7_Y2_N39
\inst2|F9~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|F9~4_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ( !\inst10|A[5]~DUPLICATE_q\ ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ( \inst10|A[5]~DUPLICATE_q\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111100001111000000001111000011111111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	datae => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	combout => \inst2|F9~4_combout\);

-- Location: MLABCELL_X6_Y2_N30
\inst2|Mux3~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux3~1_combout\ = ( \inst2|Add4~21_sumout\ & ( \inst2|Mux5~4_combout\ & ( (!\inst2|F9~4_combout\) # (\inst2|Mux5~3_combout\) ) ) ) # ( !\inst2|Add4~21_sumout\ & ( \inst2|Mux5~4_combout\ & ( (!\inst2|F9~4_combout\ & !\inst2|Mux5~3_combout\) ) ) ) # 
-- ( \inst2|Add4~21_sumout\ & ( !\inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\ & (\inst2|Mux3~0_combout\)) # (\inst2|Mux5~3_combout\ & ((\inst2|Add3~17_sumout\))) ) ) ) # ( !\inst2|Add4~21_sumout\ & ( !\inst2|Mux5~4_combout\ & ( 
-- (!\inst2|Mux5~3_combout\ & (\inst2|Mux3~0_combout\)) # (\inst2|Mux5~3_combout\ & ((\inst2|Add3~17_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010100110011010101010011001111110000000000001111000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux3~0_combout\,
	datab => \inst2|ALT_INV_Add3~17_sumout\,
	datac => \inst2|ALT_INV_F9~4_combout\,
	datad => \inst2|ALT_INV_Mux5~3_combout\,
	datae => \inst2|ALT_INV_Add4~21_sumout\,
	dataf => \inst2|ALT_INV_Mux5~4_combout\,
	combout => \inst2|Mux3~1_combout\);

-- Location: LABCELL_X7_Y4_N0
\inst2|Mux3~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux3~5_combout\ = ( !\inst|S\(1) & ( (!\inst|S\(0) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & (((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (!\inst10|A[5]~DUPLICATE_q\)))) # 
-- (\inst6|altsyncram_component|auto_generated|q_a\(29) & (\inst2|Add0~21_sumout\)))) # (\inst|S\(0) & ((((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & !\inst10|A[5]~DUPLICATE_q\))))) ) ) # ( \inst|S\(1) & ( (!\inst|S\(0) & 
-- ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) $ (!\inst10|A[5]~DUPLICATE_q\)))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & (\inst2|Add2~21_sumout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1101111110001010000000101000101010001010000000101000101000000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(0),
	datab => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datac => \inst2|ALT_INV_Add2~21_sumout\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	datag => \inst2|ALT_INV_Add0~21_sumout\,
	combout => \inst2|Mux3~5_combout\);

-- Location: MLABCELL_X6_Y2_N12
\inst2|Mux3~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux3~2_combout\ = ( \inst2|Add7~21_sumout\ & ( \inst2|Add6~17_sumout\ & ( (((\inst6|altsyncram_component|auto_generated|q_a\(29) & \inst10|A\(4))) # (\inst|S\(1))) # (\inst|S\(0)) ) ) ) # ( !\inst2|Add7~21_sumout\ & ( \inst2|Add6~17_sumout\ & ( 
-- (!\inst|S\(1) & (((\inst6|altsyncram_component|auto_generated|q_a\(29) & \inst10|A\(4))) # (\inst|S\(0)))) ) ) ) # ( \inst2|Add7~21_sumout\ & ( !\inst2|Add6~17_sumout\ & ( ((\inst6|altsyncram_component|auto_generated|q_a\(29) & (\inst10|A\(4) & 
-- !\inst|S\(0)))) # (\inst|S\(1)) ) ) ) # ( !\inst2|Add7~21_sumout\ & ( !\inst2|Add6~17_sumout\ & ( (\inst6|altsyncram_component|auto_generated|q_a\(29) & (\inst10|A\(4) & (!\inst|S\(0) & !\inst|S\(1)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000000000000000100001111111100011111000000000001111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst10|ALT_INV_A\(4),
	datac => \inst|ALT_INV_S\(0),
	datad => \inst|ALT_INV_S\(1),
	datae => \inst2|ALT_INV_Add7~21_sumout\,
	dataf => \inst2|ALT_INV_Add6~17_sumout\,
	combout => \inst2|Mux3~2_combout\);

-- Location: MLABCELL_X6_Y2_N45
\inst2|Mux3~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux3~3_combout\ = ( \inst2|Mux3~2_combout\ & ( (!\inst|S[3]~DUPLICATE_q\ & (((\inst2|Mux3~5_combout\)))) # (\inst|S[3]~DUPLICATE_q\ & ((!\inst|S\(0)) # ((\inst2|Mux3~1_combout\)))) ) ) # ( !\inst2|Mux3~2_combout\ & ( (!\inst|S[3]~DUPLICATE_q\ & 
-- (((\inst2|Mux3~5_combout\)))) # (\inst|S[3]~DUPLICATE_q\ & (\inst|S\(0) & (\inst2|Mux3~1_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000110101011000000011010101101000101111011110100010111101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	datab => \inst|ALT_INV_S\(0),
	datac => \inst2|ALT_INV_Mux3~1_combout\,
	datad => \inst2|ALT_INV_Mux3~5_combout\,
	dataf => \inst2|ALT_INV_Mux3~2_combout\,
	combout => \inst2|Mux3~3_combout\);

-- Location: FF_X11_Y6_N35
\inst10|A[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst10|A[5]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5),
	sload => \inst18|Mux5~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|A\(5));

-- Location: LABCELL_X11_Y6_N0
\inst2|Mux3~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux3~4_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ( \inst10|A\(5) & ( ((\inst2|Mux5~2_combout\ & ((\inst2|Mux5~0_combout\) # (\inst2|Mux5~1_combout\)))) # (\inst2|Mux3~3_combout\) ) ) ) # ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ( \inst10|A\(5) & ( ((\inst2|Mux5~2_combout\ & ((\inst2|Mux5~0_combout\) # (\inst2|Mux5~1_combout\)))) # (\inst2|Mux3~3_combout\) ) ) ) # ( 
-- \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ( !\inst10|A\(5) & ( (!\inst2|Mux5~2_combout\ & (((\inst2|Mux3~3_combout\)))) # (\inst2|Mux5~2_combout\ & (!\inst2|Mux5~0_combout\ & ((\inst2|Mux3~3_combout\) # (\inst2|Mux5~1_combout\)))) ) 
-- ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & ( !\inst10|A\(5) & ( (\inst2|Mux3~3_combout\ & ((!\inst2|Mux5~2_combout\) # ((!\inst2|Mux5~1_combout\ & !\inst2|Mux5~0_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001000000011110100110000001111011111110000111101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux5~1_combout\,
	datab => \inst2|ALT_INV_Mux5~0_combout\,
	datac => \inst2|ALT_INV_Mux3~3_combout\,
	datad => \inst2|ALT_INV_Mux5~2_combout\,
	datae => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst10|ALT_INV_A\(5),
	combout => \inst2|Mux3~4_combout\);

-- Location: LABCELL_X11_Y6_N33
\inst10|A[5]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst10|A[5]~feeder_combout\ = \inst2|Mux3~4_combout\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux3~4_combout\,
	combout => \inst10|A[5]~feeder_combout\);

-- Location: FF_X11_Y6_N34
\inst10|A[5]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst10|A[5]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5),
	sload => \inst18|Mux5~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|A[5]~DUPLICATE_q\);

-- Location: LABCELL_X9_Y2_N24
\inst2|Mux4~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux4~2_combout\ = ( \inst2|Add7~17_sumout\ & ( \inst|S\(1) ) ) # ( \inst2|Add7~17_sumout\ & ( !\inst|S\(1) & ( (!\inst|S\(0) & (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((\inst10|A\(3))))) # (\inst|S\(0) & (((\inst2|Add6~13_sumout\)))) 
-- ) ) ) # ( !\inst2|Add7~17_sumout\ & ( !\inst|S\(1) & ( (!\inst|S\(0) & (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((\inst10|A\(3))))) # (\inst|S\(0) & (((\inst2|Add6~13_sumout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001101000111000000110100011100000000000000001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst2|ALT_INV_Add6~13_sumout\,
	datad => \inst10|ALT_INV_A\(3),
	datae => \inst2|ALT_INV_Add7~17_sumout\,
	dataf => \inst|ALT_INV_S\(1),
	combout => \inst2|Mux4~2_combout\);

-- Location: LABCELL_X7_Y2_N33
\inst2|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux4~0_combout\ = ( \inst10|A\(4) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & (((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst|S\(0) & 
-- (\inst2|Add5~13_sumout\)) # (\inst|S\(0) & ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)))))) ) ) # ( !\inst10|A\(4) & ( (!\inst|S\(0) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & 
-- ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & (\inst2|Add5~13_sumout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010010001100000001001000110000000100101111110000010010111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst2|ALT_INV_Add5~13_sumout\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	dataf => \inst10|ALT_INV_A\(4),
	combout => \inst2|Mux4~0_combout\);

-- Location: MLABCELL_X6_Y2_N0
\inst2|F9~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|F9~3_combout\ = ( \inst10|A\(4) & ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) ) ) # ( !\inst10|A\(4) & ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011110011001100110000110011001100111100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datae => \inst10|ALT_INV_A\(4),
	combout => \inst2|F9~3_combout\);

-- Location: MLABCELL_X6_Y2_N6
\inst2|Mux4~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux4~1_combout\ = ( \inst2|F9~3_combout\ & ( \inst2|Mux5~4_combout\ & ( (\inst2|Add4~17_sumout\ & \inst2|Mux5~3_combout\) ) ) ) # ( !\inst2|F9~3_combout\ & ( \inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\) # (\inst2|Add4~17_sumout\) ) ) ) # ( 
-- \inst2|F9~3_combout\ & ( !\inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\ & (\inst2|Mux4~0_combout\)) # (\inst2|Mux5~3_combout\ & ((\inst2|Add3~13_sumout\))) ) ) ) # ( !\inst2|F9~3_combout\ & ( !\inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\ & 
-- (\inst2|Mux4~0_combout\)) # (\inst2|Mux5~3_combout\ & ((\inst2|Add3~13_sumout\))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010100110011010101010011001111111111000011110000000000001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux4~0_combout\,
	datab => \inst2|ALT_INV_Add3~13_sumout\,
	datac => \inst2|ALT_INV_Add4~17_sumout\,
	datad => \inst2|ALT_INV_Mux5~3_combout\,
	datae => \inst2|ALT_INV_F9~3_combout\,
	dataf => \inst2|ALT_INV_Mux5~4_combout\,
	combout => \inst2|Mux4~1_combout\);

-- Location: MLABCELL_X6_Y2_N24
\inst2|Mux4~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux4~5_combout\ = ( !\inst|S\(1) & ( (!\inst|S\(0) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst10|A\(4)) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))) # 
-- (\inst6|altsyncram_component|auto_generated|q_a\(29) & (((\inst2|Add0~17_sumout\)))))) # (\inst|S\(0) & (((!\inst10|A\(4) & ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))))) ) ) # ( \inst|S\(1) & ( (!\inst|S\(0) & 
-- ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & (!\inst10|A\(4) $ (((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & (((\inst2|Add2~17_sumout\)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1010111111001100001001110000000010001101000000001000110100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst10|ALT_INV_A\(4),
	datac => \inst2|ALT_INV_Add2~17_sumout\,
	datad => \inst|ALT_INV_S\(0),
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datag => \inst2|ALT_INV_Add0~17_sumout\,
	combout => \inst2|Mux4~5_combout\);

-- Location: MLABCELL_X6_Y2_N39
\inst2|Mux4~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux4~3_combout\ = ( \inst|S\(0) & ( (!\inst|S[3]~DUPLICATE_q\ & ((\inst2|Mux4~5_combout\))) # (\inst|S[3]~DUPLICATE_q\ & (\inst2|Mux4~1_combout\)) ) ) # ( !\inst|S\(0) & ( (!\inst|S[3]~DUPLICATE_q\ & ((\inst2|Mux4~5_combout\))) # 
-- (\inst|S[3]~DUPLICATE_q\ & (\inst2|Mux4~2_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000110111011000100011011101100000101101011110000010110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	datab => \inst2|ALT_INV_Mux4~2_combout\,
	datac => \inst2|ALT_INV_Mux4~1_combout\,
	datad => \inst2|ALT_INV_Mux4~5_combout\,
	dataf => \inst|ALT_INV_S\(0),
	combout => \inst2|Mux4~3_combout\);

-- Location: LABCELL_X11_Y6_N18
\inst2|Mux4~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux4~4_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ( \inst2|Mux5~2_combout\ & ( (!\inst2|Mux5~0_combout\ & (((\inst2|Mux4~3_combout\)) # (\inst2|Mux5~1_combout\))) # (\inst2|Mux5~0_combout\ & (((\inst10|A\(4))))) ) 
-- ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ( \inst2|Mux5~2_combout\ & ( (!\inst2|Mux5~1_combout\ & ((!\inst2|Mux5~0_combout\ & (\inst2|Mux4~3_combout\)) # (\inst2|Mux5~0_combout\ & ((\inst10|A\(4)))))) # 
-- (\inst2|Mux5~1_combout\ & (((\inst10|A\(4))))) ) ) ) # ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ( !\inst2|Mux5~2_combout\ & ( \inst2|Mux4~3_combout\ ) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ( 
-- !\inst2|Mux5~2_combout\ & ( \inst2|Mux4~3_combout\ ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001000011111110100110001111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux5~1_combout\,
	datab => \inst2|ALT_INV_Mux5~0_combout\,
	datac => \inst2|ALT_INV_Mux4~3_combout\,
	datad => \inst10|ALT_INV_A\(4),
	datae => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	dataf => \inst2|ALT_INV_Mux5~2_combout\,
	combout => \inst2|Mux4~4_combout\);

-- Location: LABCELL_X11_Y6_N39
\inst10|A[4]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst10|A[4]~feeder_combout\ = ( \inst2|Mux4~4_combout\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst2|ALT_INV_Mux4~4_combout\,
	combout => \inst10|A[4]~feeder_combout\);

-- Location: FF_X11_Y6_N40
\inst10|A[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst10|A[4]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4),
	sload => \inst18|Mux5~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|A\(4));

-- Location: LABCELL_X7_Y2_N45
\inst2|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux6~0_combout\ = ( \inst2|Add5~5_sumout\ & ( (!\inst|S\(0) & (((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2))) # (\inst6|altsyncram_component|auto_generated|q_a\(29)))) # (\inst|S\(0) & (((\inst10|A\(2) & 
-- \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2))))) ) ) # ( !\inst2|Add5~5_sumout\ & ( (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ((!\inst|S\(0) & (!\inst6|altsyncram_component|auto_generated|q_a\(29))) # (\inst|S\(0) 
-- & ((\inst10|A\(2)))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010100011000000001010001101010000111100110101000011110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst10|ALT_INV_A\(2),
	datac => \inst|ALT_INV_S\(0),
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	dataf => \inst2|ALT_INV_Add5~5_sumout\,
	combout => \inst2|Mux6~0_combout\);

-- Location: LABCELL_X10_Y4_N3
\inst2|F9~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|F9~1_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( !\inst10|A\(2) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( \inst10|A\(2) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010110101010101010101010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(2),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	combout => \inst2|F9~1_combout\);

-- Location: LABCELL_X10_Y2_N27
\inst2|Mux6~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux6~1_combout\ = ( \inst2|Add4~9_sumout\ & ( \inst2|F9~1_combout\ & ( (!\inst2|Mux5~4_combout\ & ((!\inst2|Mux5~3_combout\ & ((\inst2|Mux6~0_combout\))) # (\inst2|Mux5~3_combout\ & (\inst2|Add3~5_sumout\)))) # (\inst2|Mux5~4_combout\ & 
-- (((\inst2|Mux5~3_combout\)))) ) ) ) # ( !\inst2|Add4~9_sumout\ & ( \inst2|F9~1_combout\ & ( (!\inst2|Mux5~4_combout\ & ((!\inst2|Mux5~3_combout\ & ((\inst2|Mux6~0_combout\))) # (\inst2|Mux5~3_combout\ & (\inst2|Add3~5_sumout\)))) ) ) ) # ( 
-- \inst2|Add4~9_sumout\ & ( !\inst2|F9~1_combout\ & ( ((!\inst2|Mux5~3_combout\ & ((\inst2|Mux6~0_combout\))) # (\inst2|Mux5~3_combout\ & (\inst2|Add3~5_sumout\))) # (\inst2|Mux5~4_combout\) ) ) ) # ( !\inst2|Add4~9_sumout\ & ( !\inst2|F9~1_combout\ & ( 
-- (!\inst2|Mux5~4_combout\ & ((!\inst2|Mux5~3_combout\ & ((\inst2|Mux6~0_combout\))) # (\inst2|Mux5~3_combout\ & (\inst2|Add3~5_sumout\)))) # (\inst2|Mux5~4_combout\ & (((!\inst2|Mux5~3_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011111101000100001111110111011100001100010001000000110001110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Add3~5_sumout\,
	datab => \inst2|ALT_INV_Mux5~4_combout\,
	datac => \inst2|ALT_INV_Mux6~0_combout\,
	datad => \inst2|ALT_INV_Mux5~3_combout\,
	datae => \inst2|ALT_INV_Add4~9_sumout\,
	dataf => \inst2|ALT_INV_F9~1_combout\,
	combout => \inst2|Mux6~1_combout\);

-- Location: MLABCELL_X6_Y4_N18
\inst2|Mux6~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux6~10_combout\ = ( \inst10|A\(2) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & (((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst|S\(0) & 
-- (\inst|S\(1))) # (\inst|S\(0) & ((!\inst|S\(1)) # (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)))))) ) ) # ( !\inst10|A\(2) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & 
-- ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ((!\inst|S\(1)))) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & (!\inst|S\(0))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & (!\inst|S\(0) $ 
-- ((!\inst|S\(1))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100101001100110110010100110011011110000011101101111000001110110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(0),
	datab => \inst|ALT_INV_S\(1),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datad => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	dataf => \inst10|ALT_INV_A\(2),
	combout => \inst2|Mux6~10_combout\);

-- Location: MLABCELL_X6_Y4_N6
\inst2|Mux6~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux6~6_combout\ = ( !\inst|S\(1) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & ((((\inst2|Mux6~10_combout\))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst2|Mux6~10_combout\ & (\inst2|Add0~9_sumout\)) # 
-- (\inst2|Mux6~10_combout\ & (((\inst2|Add1~5_sumout\)))))) ) ) # ( \inst|S\(1) & ( ((\inst2|Mux6~10_combout\ & ((!\inst6|altsyncram_component|auto_generated|q_a\(29)) # ((\inst|S\(0)) # (\inst2|Add2~9_sumout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0001000110101111000000001010111100010001101011110000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst2|ALT_INV_Add0~9_sumout\,
	datac => \inst2|ALT_INV_Add2~9_sumout\,
	datad => \inst2|ALT_INV_Mux6~10_combout\,
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst|ALT_INV_S\(0),
	datag => \inst2|ALT_INV_Add1~5_sumout\,
	combout => \inst2|Mux6~6_combout\);

-- Location: MLABCELL_X6_Y4_N21
\inst2|Mux6~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux6~3_combout\ = ( \inst10|A\(2) & ( (!\inst|S\(0) & \inst2|Mux6~6_combout\) ) ) # ( !\inst10|A\(2) & ( (!\inst|S\(0) & (((\inst2|Mux6~6_combout\)))) # (\inst|S\(0) & (!\inst|S\(1) & 
-- ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100111000001010010011100000101000001010000010100000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(0),
	datab => \inst|ALT_INV_S\(1),
	datac => \inst2|ALT_INV_Mux6~6_combout\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	dataf => \inst10|ALT_INV_A\(2),
	combout => \inst2|Mux6~3_combout\);

-- Location: MLABCELL_X6_Y6_N18
\inst2|Mux6~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux6~2_combout\ = ( \inst6|altsyncram_component|auto_generated|q_a\(29) & ( \inst2|Add7~9_sumout\ & ( ((!\inst|S\(0) & ((\inst10|A\(1)))) # (\inst|S\(0) & (\inst2|Add6~5_sumout\))) # (\inst|S\(1)) ) ) ) # ( 
-- !\inst6|altsyncram_component|auto_generated|q_a\(29) & ( \inst2|Add7~9_sumout\ & ( ((\inst2|Add6~5_sumout\ & \inst|S\(0))) # (\inst|S\(1)) ) ) ) # ( \inst6|altsyncram_component|auto_generated|q_a\(29) & ( !\inst2|Add7~9_sumout\ & ( (!\inst|S\(1) & 
-- ((!\inst|S\(0) & ((\inst10|A\(1)))) # (\inst|S\(0) & (\inst2|Add6~5_sumout\)))) ) ) ) # ( !\inst6|altsyncram_component|auto_generated|q_a\(29) & ( !\inst2|Add7~9_sumout\ & ( (\inst2|Add6~5_sumout\ & (!\inst|S\(1) & \inst|S\(0))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001000100000011000100010000110011011101110011111101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Add6~5_sumout\,
	datab => \inst|ALT_INV_S\(1),
	datac => \inst10|ALT_INV_A\(1),
	datad => \inst|ALT_INV_S\(0),
	datae => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	dataf => \inst2|ALT_INV_Add7~9_sumout\,
	combout => \inst2|Mux6~2_combout\);

-- Location: MLABCELL_X6_Y4_N54
\inst2|Mux6~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux6~4_combout\ = ( \inst2|Mux6~2_combout\ & ( (!\inst|S[3]~DUPLICATE_q\ & (((\inst2|Mux6~3_combout\)))) # (\inst|S[3]~DUPLICATE_q\ & ((!\inst|S\(0)) # ((\inst2|Mux6~1_combout\)))) ) ) # ( !\inst2|Mux6~2_combout\ & ( (!\inst|S[3]~DUPLICATE_q\ & 
-- (((\inst2|Mux6~3_combout\)))) # (\inst|S[3]~DUPLICATE_q\ & (\inst|S\(0) & (\inst2|Mux6~1_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000111001101000000011100110100100011111011110010001111101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(0),
	datab => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	datac => \inst2|ALT_INV_Mux6~1_combout\,
	datad => \inst2|ALT_INV_Mux6~3_combout\,
	dataf => \inst2|ALT_INV_Mux6~2_combout\,
	combout => \inst2|Mux6~4_combout\);

-- Location: MLABCELL_X6_Y4_N42
\inst2|Mux6~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux6~5_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( \inst2|Mux5~1_combout\ & ( (!\inst2|Mux5~2_combout\ & (((\inst2|Mux6~4_combout\)))) # (\inst2|Mux5~2_combout\ & ((!\inst2|Mux5~0_combout\) # ((\inst10|A\(2))))) 
-- ) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( \inst2|Mux5~1_combout\ & ( (!\inst2|Mux5~2_combout\ & ((\inst2|Mux6~4_combout\))) # (\inst2|Mux5~2_combout\ & (\inst10|A\(2))) ) ) ) # ( 
-- \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( !\inst2|Mux5~1_combout\ & ( (!\inst2|Mux5~0_combout\ & (((\inst2|Mux6~4_combout\)))) # (\inst2|Mux5~0_combout\ & ((!\inst2|Mux5~2_combout\ & ((\inst2|Mux6~4_combout\))) # 
-- (\inst2|Mux5~2_combout\ & (\inst10|A\(2))))) ) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( !\inst2|Mux5~1_combout\ & ( (!\inst2|Mux5~0_combout\ & (((\inst2|Mux6~4_combout\)))) # (\inst2|Mux5~0_combout\ & 
-- ((!\inst2|Mux5~2_combout\ & ((\inst2|Mux6~4_combout\))) # (\inst2|Mux5~2_combout\ & (\inst10|A\(2))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100011011000011110001101100001111001100110000111110111011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux5~0_combout\,
	datab => \inst10|ALT_INV_A\(2),
	datac => \inst2|ALT_INV_Mux6~4_combout\,
	datad => \inst2|ALT_INV_Mux5~2_combout\,
	datae => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	dataf => \inst2|ALT_INV_Mux5~1_combout\,
	combout => \inst2|Mux6~5_combout\);

-- Location: FF_X6_Y4_N44
\inst10|A[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst2|Mux6~5_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2),
	sload => \inst18|Mux5~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|A\(2));

-- Location: MLABCELL_X6_Y6_N54
\inst2|Mux7~10\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux7~10_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & (!\inst|S\(0) & (!\inst10|A\(1)))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & 
-- (!\inst|S\(0) $ (((!\inst|S\(1)))))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\inst|S\(1) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29)) # ((\inst|S\(0))))) # (\inst|S\(1) & 
-- (((\inst6|altsyncram_component|auto_generated|q_a\(29) & !\inst|S\(0))) # (\inst10|A\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011101101001111101110110100111110010001110001001001000111000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst10|ALT_INV_A\(1),
	datad => \inst|ALT_INV_S\(1),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	combout => \inst2|Mux7~10_combout\);

-- Location: MLABCELL_X6_Y4_N0
\inst2|Mux7~6\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux7~6_combout\ = ( !\inst|S\(1) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & (\inst2|Mux7~10_combout\)) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst2|Mux7~10_combout\ & (((\inst2|Add0~5_sumout\)))) # 
-- (\inst2|Mux7~10_combout\ & (\inst2|Add1~1_sumout\)))) ) ) # ( \inst|S\(1) & ( (\inst2|Mux7~10_combout\ & ((!\inst6|altsyncram_component|auto_generated|q_a\(29)) # (((\inst|S\(0))) # (\inst2|Add2~5_sumout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0010001101100111001000110010001100100011011001110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst2|ALT_INV_Mux7~10_combout\,
	datac => \inst2|ALT_INV_Add2~5_sumout\,
	datad => \inst2|ALT_INV_Add0~5_sumout\,
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst|ALT_INV_S\(0),
	datag => \inst2|ALT_INV_Add1~1_sumout\,
	combout => \inst2|Mux7~6_combout\);

-- Location: MLABCELL_X6_Y4_N15
\inst2|Mux7~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux7~3_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\inst|S\(0) & \inst2|Mux7~6_combout\) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\inst|S\(0) & (((\inst2|Mux7~6_combout\)))) 
-- # (\inst|S\(0) & (!\inst10|A\(1) & (!\inst|S\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000011101010010000001110101000000000101010100000000010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(0),
	datab => \inst10|ALT_INV_A\(1),
	datac => \inst|ALT_INV_S\(1),
	datad => \inst2|ALT_INV_Mux7~6_combout\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	combout => \inst2|Mux7~3_combout\);

-- Location: LABCELL_X7_Y4_N54
\inst2|Mux7~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux7~2_combout\ = ( \inst|S\(1) & ( \inst10|A\(0) & ( \inst2|Add7~5_sumout\ ) ) ) # ( !\inst|S\(1) & ( \inst10|A\(0) & ( (!\inst|S\(0) & ((\inst6|altsyncram_component|auto_generated|q_a\(29)))) # (\inst|S\(0) & (\inst2|Add6~1_sumout\)) ) ) ) # ( 
-- \inst|S\(1) & ( !\inst10|A\(0) & ( \inst2|Add7~5_sumout\ ) ) ) # ( !\inst|S\(1) & ( !\inst10|A\(0) & ( (\inst2|Add6~1_sumout\ & \inst|S\(0)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001100000011010101010101010100000011111100110101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Add7~5_sumout\,
	datab => \inst2|ALT_INV_Add6~1_sumout\,
	datac => \inst|ALT_INV_S\(0),
	datad => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst10|ALT_INV_A\(0),
	combout => \inst2|Mux7~2_combout\);

-- Location: LABCELL_X10_Y3_N51
\inst2|F9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|F9~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( !\inst10|A\(1) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( \inst10|A\(1) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111100001111000000001111000011111111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst10|ALT_INV_A\(1),
	datae => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	combout => \inst2|F9~0_combout\);

-- Location: LABCELL_X7_Y2_N24
\inst2|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux7~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\inst|S\(0) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29)) # ((\inst2|Add5~1_sumout\)))) # (\inst|S\(0) & (((\inst10|A\(1))))) ) ) # ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (\inst6|altsyncram_component|auto_generated|q_a\(29) & (!\inst|S\(0) & \inst2|Add5~1_sumout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010000000100000001000000010010001100101111111000110010111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datab => \inst|ALT_INV_S\(0),
	datac => \inst2|ALT_INV_Add5~1_sumout\,
	datad => \inst10|ALT_INV_A\(1),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	combout => \inst2|Mux7~0_combout\);

-- Location: LABCELL_X10_Y2_N6
\inst2|Mux7~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux7~1_combout\ = ( \inst2|Add3~1_sumout\ & ( \inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\ & (!\inst2|F9~0_combout\)) # (\inst2|Mux5~3_combout\ & ((\inst2|Add4~5_sumout\))) ) ) ) # ( !\inst2|Add3~1_sumout\ & ( \inst2|Mux5~4_combout\ & ( 
-- (!\inst2|Mux5~3_combout\ & (!\inst2|F9~0_combout\)) # (\inst2|Mux5~3_combout\ & ((\inst2|Add4~5_sumout\))) ) ) ) # ( \inst2|Add3~1_sumout\ & ( !\inst2|Mux5~4_combout\ & ( (\inst2|Mux7~0_combout\) # (\inst2|Mux5~3_combout\) ) ) ) # ( !\inst2|Add3~1_sumout\ 
-- & ( !\inst2|Mux5~4_combout\ & ( (!\inst2|Mux5~3_combout\ & \inst2|Mux7~0_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011110000000011111111111110100011101000111010001110100011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_F9~0_combout\,
	datab => \inst2|ALT_INV_Add4~5_sumout\,
	datac => \inst2|ALT_INV_Mux5~3_combout\,
	datad => \inst2|ALT_INV_Mux7~0_combout\,
	datae => \inst2|ALT_INV_Add3~1_sumout\,
	dataf => \inst2|ALT_INV_Mux5~4_combout\,
	combout => \inst2|Mux7~1_combout\);

-- Location: MLABCELL_X6_Y4_N57
\inst2|Mux7~4\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux7~4_combout\ = ( \inst2|Mux7~1_combout\ & ( (!\inst|S[3]~DUPLICATE_q\ & (((\inst2|Mux7~3_combout\)))) # (\inst|S[3]~DUPLICATE_q\ & (((\inst2|Mux7~2_combout\)) # (\inst|S\(0)))) ) ) # ( !\inst2|Mux7~1_combout\ & ( (!\inst|S[3]~DUPLICATE_q\ & 
-- (((\inst2|Mux7~3_combout\)))) # (\inst|S[3]~DUPLICATE_q\ & (!\inst|S\(0) & ((\inst2|Mux7~2_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000101110000011000010111000011101001111110001110100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_S\(0),
	datab => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	datac => \inst2|ALT_INV_Mux7~3_combout\,
	datad => \inst2|ALT_INV_Mux7~2_combout\,
	dataf => \inst2|ALT_INV_Mux7~1_combout\,
	combout => \inst2|Mux7~4_combout\);

-- Location: MLABCELL_X6_Y4_N48
\inst2|Mux7~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux7~5_combout\ = ( \inst2|Mux7~4_combout\ & ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( ((!\inst2|Mux5~0_combout\) # (!\inst2|Mux5~2_combout\)) # (\inst10|A\(1)) ) ) ) # ( !\inst2|Mux7~4_combout\ & ( 
-- \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (\inst2|Mux5~2_combout\ & ((!\inst2|Mux5~0_combout\ & (\inst2|Mux5~1_combout\)) # (\inst2|Mux5~0_combout\ & ((\inst10|A\(1)))))) ) ) ) # ( \inst2|Mux7~4_combout\ & ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( ((!\inst2|Mux5~2_combout\) # ((!\inst2|Mux5~1_combout\ & !\inst2|Mux5~0_combout\))) # (\inst10|A\(1)) ) ) ) # ( !\inst2|Mux7~4_combout\ & ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (\inst10|A\(1) & (\inst2|Mux5~2_combout\ & ((\inst2|Mux5~0_combout\) # (\inst2|Mux5~1_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000010011111111111011001100000000010100111111111111110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux5~1_combout\,
	datab => \inst10|ALT_INV_A\(1),
	datac => \inst2|ALT_INV_Mux5~0_combout\,
	datad => \inst2|ALT_INV_Mux5~2_combout\,
	datae => \inst2|ALT_INV_Mux7~4_combout\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	combout => \inst2|Mux7~5_combout\);

-- Location: MLABCELL_X6_Y4_N12
\inst10|A[1]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst10|A[1]~feeder_combout\ = ( \inst2|Mux7~5_combout\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst2|ALT_INV_Mux7~5_combout\,
	combout => \inst10|A[1]~feeder_combout\);

-- Location: FF_X6_Y4_N13
\inst10|A[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst10|A[1]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1),
	sload => \inst18|Mux5~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|A\(1));

-- Location: LABCELL_X9_Y4_N51
\inst2|Mux8~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux8~1_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & ( !\inst6|altsyncram_component|auto_generated|q_a\(29) $ (((!\inst|S[3]~DUPLICATE_q\) # (\inst2|Add4~1_sumout\))) ) ) # ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & ( !\inst6|altsyncram_component|auto_generated|q_a\(29) $ (((!\inst|S[3]~DUPLICATE_q\ & (\inst10|A\(0))) # (\inst|S[3]~DUPLICATE_q\ & ((\inst2|Add4~1_sumout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1001100111000011100110011100001100110011110000110011001111000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(0),
	datab => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datac => \inst2|ALT_INV_Add4~1_sumout\,
	datad => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	combout => \inst2|Mux8~1_combout\);

-- Location: LABCELL_X9_Y4_N48
\inst2|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux8~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & ( (!\inst|S\(0) & (((!\inst6|altsyncram_component|auto_generated|q_a\(29)) # (\inst2|Add7~1_sumout\)))) # (\inst|S\(0) & (\inst10|A\(0))) ) ) # ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & ( (!\inst|S\(0) & ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & (\inst10|A\(0))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & ((\inst2|Add7~1_sumout\))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100011100000000010001110000000011001111010101011100111101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(0),
	datab => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datac => \inst2|ALT_INV_Add7~1_sumout\,
	datad => \inst|ALT_INV_S\(0),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	combout => \inst2|Mux8~0_combout\);

-- Location: LABCELL_X9_Y4_N30
\inst2|Mux8~3\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux8~3_combout\ = ( !\inst|S\(1) & ( (!\inst6|altsyncram_component|auto_generated|q_a\(29) & ((!\inst10|A\(0)) # (((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0)))))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & 
-- (((\inst2|Add0~1_sumout\)))) ) ) # ( \inst|S\(1) & ( ((!\inst6|altsyncram_component|auto_generated|q_a\(29) & (((\inst2|Add4~1_sumout\)))) # (\inst6|altsyncram_component|auto_generated|q_a\(29) & (\inst2|Add2~1_sumout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "1100111110001011000000110000001111001111100010111100111111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(0),
	datab => \inst6|altsyncram_component|auto_generated|ALT_INV_q_a\(29),
	datac => \inst2|ALT_INV_Add2~1_sumout\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datae => \inst|ALT_INV_S\(1),
	dataf => \inst2|ALT_INV_Add4~1_sumout\,
	datag => \inst2|ALT_INV_Add0~1_sumout\,
	combout => \inst2|Mux8~3_combout\);

-- Location: LABCELL_X9_Y4_N36
\inst2|Mux8~2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|Mux8~2_combout\ = ( \inst|S[3]~DUPLICATE_q\ & ( \inst2|Mux8~3_combout\ & ( (!\inst|S\(1) & (\inst2|Mux8~1_combout\ & (\inst|S\(0)))) # (\inst|S\(1) & (((\inst2|Mux8~0_combout\)))) ) ) ) # ( !\inst|S[3]~DUPLICATE_q\ & ( \inst2|Mux8~3_combout\ & ( 
-- (!\inst|S\(0)) # ((\inst2|Mux8~1_combout\ & !\inst|S\(1))) ) ) ) # ( \inst|S[3]~DUPLICATE_q\ & ( !\inst2|Mux8~3_combout\ & ( (!\inst|S\(1) & (\inst2|Mux8~1_combout\ & (\inst|S\(0)))) # (\inst|S\(1) & (((\inst2|Mux8~0_combout\)))) ) ) ) # ( 
-- !\inst|S[3]~DUPLICATE_q\ & ( !\inst2|Mux8~3_combout\ & ( (\inst2|Mux8~1_combout\ & (\inst|S\(0) & !\inst|S\(1))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100000000000100010000111111011101110011000001000100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux8~1_combout\,
	datab => \inst|ALT_INV_S\(0),
	datac => \inst2|ALT_INV_Mux8~0_combout\,
	datad => \inst|ALT_INV_S\(1),
	datae => \inst|ALT_INV_S[3]~DUPLICATE_q\,
	dataf => \inst2|ALT_INV_Mux8~3_combout\,
	combout => \inst2|Mux8~2_combout\);

-- Location: FF_X9_Y4_N38
\inst10|A[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk~inputCLKENA0_outclk\,
	d => \inst2|Mux8~2_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0),
	sload => \inst18|Mux5~0_combout\,
	ena => \inst18|Mux13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|A\(0));

-- Location: LABCELL_X2_Y2_N36
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_b\(0),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~feeder_combout\);

-- Location: FF_X2_Y2_N37
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[0]~feeder_combout\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(1),
	sload => \inst5|altsyncram_component|auto_generated|mgl_prim2|process_0~2_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_data_reg\(0));

-- Location: LABCELL_X1_Y5_N33
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|clear_signal\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|clear_signal~combout\);

-- Location: LABCELL_X1_Y5_N0
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001000100010001000100011101000100010001110100010001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~1_combout\);

-- Location: FF_X1_Y5_N41
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~0_combout\,
	sload => VCC,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(0));

-- Location: LABCELL_X1_Y5_N54
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110011001100000011001100110000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_Equal0~0_combout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~2_combout\);

-- Location: FF_X1_Y5_N56
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~2_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(1));

-- Location: LABCELL_X1_Y5_N24
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000001010101010101010101010101000101000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_clear_signal~combout\,
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	datae => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~5_combout\);

-- Location: FF_X1_Y5_N20
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~5_combout\,
	sload => VCC,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(4));

-- Location: LABCELL_X1_Y5_N36
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010101010001000101000100000000000101010100010001000001000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_clear_signal~combout\,
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	datae => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~3_combout\);

-- Location: FF_X1_Y5_N28
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~3_combout\,
	sload => VCC,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(2));

-- Location: LABCELL_X1_Y5_N57
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|Equal0~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000100000000000000010000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|Equal0~0_combout\);

-- Location: LABCELL_X1_Y5_N3
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1110000011100000111000001110000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_Equal0~0_combout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~0_combout\);

-- Location: FF_X1_Y5_N40
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~0_combout\,
	sload => VCC,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[0]~DUPLICATE_q\);

-- Location: LABCELL_X1_Y5_N30
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001010000010100000101000001010001010000000101000101000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_clear_signal~combout\,
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~4_combout\);

-- Location: FF_X1_Y5_N23
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter~4_combout\,
	sload => VCC,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|word_counter\(3));

-- Location: LABCELL_X1_Y5_N12
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000010000010000000001000000010110001100000001011000110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4),
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~0_combout\);

-- Location: LABCELL_X1_Y5_N18
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000001000000100000000100000010000000010000001000000001000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~3_combout\);

-- Location: LABCELL_X1_Y5_N15
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000001000000010100000100000001000000000010101010000000001010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4),
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~5_combout\);

-- Location: LABCELL_X1_Y5_N21
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~7\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000010000000010000001000000000000000100000000000000010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(1),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(2),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(0),
	datad => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(3),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter\(4),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~7_combout\);

-- Location: LABCELL_X1_Y5_N6
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~8\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000001110000000000000111011101110000011101110111000001110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datac => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~7_combout\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~8_combout\);

-- Location: LABCELL_X1_Y5_N51
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001101010011000000110101001100000011111100110000001111110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\);

-- Location: FF_X1_Y5_N7
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~8_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(3));

-- Location: LABCELL_X1_Y5_N9
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111000000000000011100000000000001110111011100000111011101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~5_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(3),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~6_combout\);

-- Location: FF_X1_Y5_N10
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~6_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(2));

-- Location: LABCELL_X1_Y5_N42
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000110000001000000000001111000010101100111110001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datab => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_word_counter[0]~DUPLICATE_q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datae => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~3_combout\,
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(2),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~4_combout\);

-- Location: FF_X1_Y5_N43
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~4_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(1));

-- Location: LABCELL_X1_Y5_N48
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001000000010100000100001011111010011000101111101001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(1),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~1_combout\);

-- Location: FF_X1_Y5_N49
\inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR~1_combout\,
	ena => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR[0]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|WORD_SR\(0));

-- Location: LABCELL_X2_Y4_N12
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(5),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~feeder_combout\);

-- Location: FF_X2_Y4_N13
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][5]~q\);

-- Location: LABCELL_X1_Y4_N45
\inst5|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000001010000010110101111101011111010111110101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	datac => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_bypass_reg_out~q\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~0_combout\);

-- Location: FF_X1_Y4_N50
\inst5|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \inst5|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~0_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst5|altsyncram_component|auto_generated|mgl_prim2|bypass_reg_out~q\);

-- Location: LABCELL_X1_Y4_N48
\inst5|altsyncram_component|auto_generated|mgl_prim2|adapted_tdo~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0001010100010101000011110000111111010101000101010000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_ram_rom_data_reg\(0),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][1]~q\,
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ram_rom_logic_gen:name_gen:info_rom_sr|ALT_INV_WORD_SR\(0),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][5]~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][0]~q\,
	dataf => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_bypass_reg_out~q\,
	datag => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\,
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|adapted_tdo~0_combout\);

-- Location: LABCELL_X1_Y1_N12
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000010100000010100001010000001010000101000000101000010100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~4_combout\);

-- Location: LABCELL_X1_Y1_N3
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000100010000000000010001000001111001011110000111100101111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\);

-- Location: FF_X1_Y1_N29
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~4_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(1));

-- Location: LABCELL_X1_Y1_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010001000101000001000100010100000100010001010000010001000101000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~2_combout\);

-- Location: LABCELL_X1_Y1_N24
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter~2_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~feeder_combout\);

-- Location: FF_X1_Y1_N25
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(2));

-- Location: FF_X1_Y1_N26
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~feeder_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[2]~DUPLICATE_q\);

-- Location: LABCELL_X1_Y1_N42
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001010000010100000101000001010001010000000101000101000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(2),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(3),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~3_combout\);

-- Location: FF_X1_Y1_N34
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~3_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(3));

-- Location: LABCELL_X1_Y1_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001110000000000001111000000000000111100000001000011100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[2]~DUPLICATE_q\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(4),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~5_combout\);

-- Location: FF_X1_Y1_N8
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~5_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(4));

-- Location: LABCELL_X1_Y1_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000100010001000000010001000100010001000100010001000100010001000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(2),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~0_combout\);

-- Location: FF_X1_Y1_N10
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter~0_combout\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|word_counter\(0));

-- Location: LABCELL_X1_Y1_N39
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~2\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000010100000000000001010000000000000101010100000000010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[2]~DUPLICATE_q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(4),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~2_combout\);

-- Location: LABCELL_X1_Y1_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011110000000011111111000000001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(1),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~5_combout\);

-- Location: LABCELL_X1_Y1_N54
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1000000000000000000000000000000011010000010100000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~5_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(4),
	dataf => \ALT_INV_altera_internal_jtag~TDIUTAP\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~6_combout\);

-- Location: LABCELL_X1_Y1_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100110011000100010011001100011111001111110001111100111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_dr_scan_reg~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\);

-- Location: FF_X1_Y1_N55
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~6_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(3));

-- Location: LABCELL_X1_Y1_N21
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010001000000000001000100000000001110111000000000111011100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~2_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~4_combout\);

-- Location: FF_X1_Y1_N22
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~4_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(2));

-- Location: LABCELL_X1_Y1_N18
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010011100000000001001110000000000100111000000000010011100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR~2_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~3_combout\);

-- Location: FF_X1_Y1_N19
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~3_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(1));

-- Location: LABCELL_X1_Y1_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001010000000000000101000000000000010100000010000001110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(0),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_clear_signal~combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(1),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter[2]~DUPLICATE_q\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_word_counter\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~0_combout\);

-- Location: FF_X1_Y1_N50
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR~0_combout\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR[1]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|WORD_SR\(0));

-- Location: LABCELL_X1_Y4_N6
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~6\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "on",
	lut_mask => "0000100000000000000011110000111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datac => \inst5|altsyncram_component|auto_generated|mgl_prim2|ALT_INV_adapted_tdo~0_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datag => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|hub_info_reg|ALT_INV_WORD_SR\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~6_combout\);

-- Location: MLABCELL_X3_Y2_N0
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~3\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111111100000000011111110000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(0),
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(1),
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(8),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~3_combout\);

-- Location: MLABCELL_X3_Y3_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~4\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100000011000000111100001111000011110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_bypass_reg~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(8),
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(4),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(3),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~4_combout\);

-- Location: LABCELL_X1_Y2_N30
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~5\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000101010101010011011101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_hub_info_reg_ena~0_combout\,
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~1_combout\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~2_combout\,
	datad => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~6_combout\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~3_combout\,
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_tdo_mux_out~4_combout\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~5_combout\);

-- Location: FF_X1_Y2_N32
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo_mux_out~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|tdo~q\);

-- Location: LABCELL_X2_Y4_N15
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~feeder\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irsr_reg\(2),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~feeder_combout\);

-- Location: FF_X2_Y4_N17
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	d => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~feeder_combout\,
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][2]~q\);

-- Location: LABCELL_X4_Y4_N12
\inst5|altsyncram_component|auto_generated|mgl_prim2|enable_write~0\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_irf_reg[1][2]~q\,
	datac => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_virtual_ir_scan_reg~q\,
	datae => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|ALT_INV_splitter_nodes_receive_0\(3),
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(5),
	combout => \inst5|altsyncram_component|auto_generated|mgl_prim2|enable_write~0_combout\);

-- Location: IOIBUF_X2_Y0_N58
\B_T_CN_M~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_B_T_CN_M,
	o => \B_T_CN_M~input_o\);

-- Location: LABCELL_X12_Y6_N36
\inst7|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux0~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & 
-- (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) $ (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)))) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001011111001111100101111100111110001111100001111000111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	combout => \inst7|Mux0~0_combout\);

-- Location: LABCELL_X12_Y6_N39
\inst7|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux1~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)))) # 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\B_T_CN_M~input_o\) # 
-- ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) $ (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100000110111111110000011011111111000111011111111100011101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	combout => \inst7|Mux1~0_combout\);

-- Location: LABCELL_X12_Y6_N18
\inst7|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux2~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2))) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2))))) ) ) # ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & 
-- \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110100111100001111010011111000111101011111100011110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	combout => \inst7|Mux2~0_combout\);

-- Location: LABCELL_X12_Y6_N21
\inst7|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux3~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1))) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1))))) ) ) # ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1))) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & 
-- \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100100100111111110010010011111111100000111111111110000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	combout => \inst7|Mux3~0_combout\);

-- Location: LABCELL_X12_Y6_N51
\inst7|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux4~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)) # 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0))))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) & ( (!\B_T_CN_M~input_o\) # ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & 
-- ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3)) # (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100110010111111110011001011111111101000101111111110100010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	combout => \inst7|Mux4~0_combout\);

-- Location: LABCELL_X12_Y6_N48
\inst7|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux5~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)) # 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0))))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & ( (!\B_T_CN_M~input_o\) # ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & 
-- (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) $ (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100100001111111110010000111111111101000101111111110100010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	combout => \inst7|Mux5~0_combout\);

-- Location: LABCELL_X12_Y6_N30
\inst7|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux6~0_combout\ = ( \B_T_CN_M~input_o\ & ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2) $ 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1)))) ) ) ) # ( !\B_T_CN_M~input_o\ & ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) ) ) # ( \B_T_CN_M~input_o\ & ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) & ( (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(1) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(3) $ 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(2)))) ) ) ) # ( !\B_T_CN_M~input_o\ & ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(0) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111100110010000000011111111111111111000100000100010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(3),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(2),
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(1),
	datae => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(0),
	combout => \inst7|Mux6~0_combout\);

-- Location: LABCELL_X7_Y4_N6
\inst7|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux7~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) $ 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) $ (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001011110001111100101111000111111001111100001111100111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	combout => \inst7|Mux7~0_combout\);

-- Location: LABCELL_X7_Y4_N9
\inst7|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux8~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) $ 
-- (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110001111100001111000111110110111111011111011011111101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	combout => \inst7|Mux8~0_combout\);

-- Location: LABCELL_X7_Y4_N27
\inst7|Mux9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux9~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4)) # 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & 
-- (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011111000111100001111100011110100111101011111010011110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	combout => \inst7|Mux9~0_combout\);

-- Location: LABCELL_X7_Y4_N18
\inst7|Mux10~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux10~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) ) # ( 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100100100111111110010010011111111100000111111111110000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	combout => \inst7|Mux10~0_combout\);

-- Location: LABCELL_X7_Y4_N12
\inst7|Mux11~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux11~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # 
-- (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7)) # (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001111110010111100111111001011111010111100101111101011110010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	combout => \inst7|Mux11~0_combout\);

-- Location: LABCELL_X7_Y4_N15
\inst7|Mux12~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux12~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) $ 
-- (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & 
-- ((\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100101010111111110010101011111111000100101111111100010010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	combout => \inst7|Mux12~0_combout\);

-- Location: LABCELL_X7_Y4_N24
\inst7|Mux13~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst7|Mux13~0_combout\ = ( \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- \inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))) # (\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & (!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(4) & 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5)))) ) ) # ( !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(6) & ( (!\B_T_CN_M~input_o\) # ((!\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(7) & 
-- !\inst5|altsyncram_component|auto_generated|altsyncram1|q_a\(5))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111101011110000111110101111000011110100111100101111010011110010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(7),
	datab => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(4),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(5),
	dataf => \inst5|altsyncram_component|auto_generated|altsyncram1|ALT_INV_q_a\(6),
	combout => \inst7|Mux13~0_combout\);

-- Location: LABCELL_X10_Y4_N54
\inst8|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux0~0_combout\ = ( \inst2|Mux6~5_combout\ & ( \inst2|Mux7~5_combout\ & ( !\B_T_CN_M~input_o\ ) ) ) # ( !\inst2|Mux6~5_combout\ & ( \inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst2|Mux8~2_combout\ & \inst2|Mux5~10_combout\)) ) ) ) # ( 
-- \inst2|Mux6~5_combout\ & ( !\inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # (!\inst2|Mux8~2_combout\ $ (\inst2|Mux5~10_combout\)) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( !\inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst2|Mux8~2_combout\ & 
-- !\inst2|Mux5~10_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101110011011100111011011110110111001101110011011100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux8~2_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst2|ALT_INV_Mux5~10_combout\,
	datae => \inst2|ALT_INV_Mux6~5_combout\,
	dataf => \inst2|ALT_INV_Mux7~5_combout\,
	combout => \inst8|Mux0~0_combout\);

-- Location: LABCELL_X10_Y4_N51
\inst8|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux1~0_combout\ = ( \inst2|Mux6~5_combout\ & ( \inst2|Mux8~2_combout\ & ( (!\B_T_CN_M~input_o\) # (!\inst2|Mux5~10_combout\ $ (\inst2|Mux7~5_combout\)) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( \inst2|Mux8~2_combout\ & ( (!\B_T_CN_M~input_o\) # 
-- ((\inst2|Mux5~10_combout\ & \inst2|Mux7~5_combout\)) ) ) ) # ( \inst2|Mux6~5_combout\ & ( !\inst2|Mux8~2_combout\ & ( ((!\B_T_CN_M~input_o\) # (\inst2|Mux7~5_combout\)) # (\inst2|Mux5~10_combout\) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( 
-- !\inst2|Mux8~2_combout\ & ( !\B_T_CN_M~input_o\ ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000011110000111101111111011111110001111100011111100111111001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux5~10_combout\,
	datab => \inst2|ALT_INV_Mux7~5_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datae => \inst2|ALT_INV_Mux6~5_combout\,
	dataf => \inst2|ALT_INV_Mux8~2_combout\,
	combout => \inst8|Mux1~0_combout\);

-- Location: LABCELL_X10_Y4_N42
\inst8|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux2~0_combout\ = ( \inst2|Mux6~5_combout\ & ( \inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # (\inst2|Mux5~10_combout\) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( \inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux8~2_combout\ & 
-- !\inst2|Mux5~10_combout\)) ) ) ) # ( \inst2|Mux6~5_combout\ & ( !\inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux8~2_combout\ & \inst2|Mux5~10_combout\)) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( !\inst2|Mux7~5_combout\ & ( !\B_T_CN_M~input_o\ 
-- ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110011001100110011101100111011101100111011001100111111001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux8~2_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst2|ALT_INV_Mux5~10_combout\,
	datae => \inst2|ALT_INV_Mux6~5_combout\,
	dataf => \inst2|ALT_INV_Mux7~5_combout\,
	combout => \inst8|Mux2~0_combout\);

-- Location: LABCELL_X10_Y4_N15
\inst8|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux3~0_combout\ = ( \inst2|Mux6~5_combout\ & ( \inst2|Mux8~2_combout\ & ( (!\B_T_CN_M~input_o\) # (\inst2|Mux7~5_combout\) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( \inst2|Mux8~2_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux5~10_combout\ & 
-- !\inst2|Mux7~5_combout\)) ) ) ) # ( \inst2|Mux6~5_combout\ & ( !\inst2|Mux8~2_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux5~10_combout\ & !\inst2|Mux7~5_combout\)) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( !\inst2|Mux8~2_combout\ & ( 
-- (!\B_T_CN_M~input_o\) # ((\inst2|Mux5~10_combout\ & \inst2|Mux7~5_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000111110001111110001111100011111000111110001111001111110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux5~10_combout\,
	datab => \inst2|ALT_INV_Mux7~5_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datae => \inst2|ALT_INV_Mux6~5_combout\,
	dataf => \inst2|ALT_INV_Mux8~2_combout\,
	combout => \inst8|Mux3~0_combout\);

-- Location: LABCELL_X10_Y4_N30
\inst8|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux4~0_combout\ = ( \inst2|Mux6~5_combout\ & ( \inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst2|Mux8~2_combout\ & !\inst2|Mux5~10_combout\)) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( \inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # 
-- ((\inst2|Mux8~2_combout\ & !\inst2|Mux5~10_combout\)) ) ) ) # ( \inst2|Mux6~5_combout\ & ( !\inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # (!\inst2|Mux5~10_combout\) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( !\inst2|Mux7~5_combout\ & ( 
-- (!\B_T_CN_M~input_o\) # (\inst2|Mux8~2_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101110111011101111111001111110011011100110111001101110011011100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux8~2_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst2|ALT_INV_Mux5~10_combout\,
	datae => \inst2|ALT_INV_Mux6~5_combout\,
	dataf => \inst2|ALT_INV_Mux7~5_combout\,
	combout => \inst8|Mux4~0_combout\);

-- Location: LABCELL_X10_Y4_N39
\inst8|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux5~0_combout\ = ( \inst2|Mux6~5_combout\ & ( \inst2|Mux8~2_combout\ & ( (!\B_T_CN_M~input_o\) # (!\inst2|Mux5~10_combout\ $ (!\inst2|Mux7~5_combout\)) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( \inst2|Mux8~2_combout\ & ( (!\inst2|Mux5~10_combout\) # 
-- (!\B_T_CN_M~input_o\) ) ) ) # ( \inst2|Mux6~5_combout\ & ( !\inst2|Mux8~2_combout\ & ( !\B_T_CN_M~input_o\ ) ) ) # ( !\inst2|Mux6~5_combout\ & ( !\inst2|Mux8~2_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux5~10_combout\ & \inst2|Mux7~5_combout\)) ) ) 
-- )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001011110010111100001111000011111010111110101111011011110110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux5~10_combout\,
	datab => \inst2|ALT_INV_Mux7~5_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datae => \inst2|ALT_INV_Mux6~5_combout\,
	dataf => \inst2|ALT_INV_Mux8~2_combout\,
	combout => \inst8|Mux5~0_combout\);

-- Location: LABCELL_X10_Y4_N6
\inst8|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux6~0_combout\ = ( \inst2|Mux6~5_combout\ & ( \inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst2|Mux8~2_combout\ & !\inst2|Mux5~10_combout\)) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( \inst2|Mux7~5_combout\ & ( !\B_T_CN_M~input_o\ ) ) ) # ( 
-- \inst2|Mux6~5_combout\ & ( !\inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux8~2_combout\ & \inst2|Mux5~10_combout\)) ) ) ) # ( !\inst2|Mux6~5_combout\ & ( !\inst2|Mux7~5_combout\ & ( (!\B_T_CN_M~input_o\) # (!\inst2|Mux5~10_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111110011111100110011101100111011001100110011001101110011011100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux8~2_combout\,
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst2|ALT_INV_Mux5~10_combout\,
	datae => \inst2|ALT_INV_Mux6~5_combout\,
	dataf => \inst2|ALT_INV_Mux7~5_combout\,
	combout => \inst8|Mux6~0_combout\);

-- Location: LABCELL_X11_Y6_N6
\inst8|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux7~0_combout\ = ( \inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux3~4_combout\ & (!\inst2|Mux2~4_combout\ $ (\inst2|Mux1~4_combout\))) # (\inst2|Mux3~4_combout\ & (!\inst2|Mux2~4_combout\ & \inst2|Mux1~4_combout\))) ) ) # ( 
-- !\inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux3~4_combout\ & (\inst2|Mux2~4_combout\ & !\inst2|Mux1~4_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001011110000111100101111000011111000111101101111100011110110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux3~4_combout\,
	datab => \inst2|ALT_INV_Mux2~4_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst2|ALT_INV_Mux1~4_combout\,
	dataf => \inst2|ALT_INV_Mux4~4_combout\,
	combout => \inst8|Mux7~0_combout\);

-- Location: LABCELL_X11_Y6_N9
\inst8|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux8~0_combout\ = ( \inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux3~4_combout\ & (\inst2|Mux2~4_combout\ & !\inst2|Mux1~4_combout\)) # (\inst2|Mux3~4_combout\ & ((\inst2|Mux1~4_combout\)))) ) ) # ( !\inst2|Mux4~4_combout\ & ( 
-- (!\B_T_CN_M~input_o\) # ((\inst2|Mux2~4_combout\ & ((\inst2|Mux1~4_combout\) # (\inst2|Mux3~4_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111000111110011111100011111001111110010111101011111001011110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux3~4_combout\,
	datab => \inst2|ALT_INV_Mux2~4_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst2|ALT_INV_Mux1~4_combout\,
	dataf => \inst2|ALT_INV_Mux4~4_combout\,
	combout => \inst8|Mux8~0_combout\);

-- Location: LABCELL_X11_Y6_N51
\inst8|Mux9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux9~0_combout\ = ( \inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst2|Mux3~4_combout\ & (\inst2|Mux2~4_combout\ & \inst2|Mux1~4_combout\))) ) ) # ( !\inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux2~4_combout\ & 
-- (\inst2|Mux3~4_combout\ & !\inst2|Mux1~4_combout\)) # (\inst2|Mux2~4_combout\ & ((\inst2|Mux1~4_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111010011110011111101001111001111110000111100011111000011110001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux3~4_combout\,
	datab => \inst2|ALT_INV_Mux2~4_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst2|ALT_INV_Mux1~4_combout\,
	dataf => \inst2|ALT_INV_Mux4~4_combout\,
	combout => \inst8|Mux9~0_combout\);

-- Location: LABCELL_X11_Y6_N45
\inst8|Mux10~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux10~0_combout\ = ( \inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux3~4_combout\ & (!\inst2|Mux2~4_combout\ & !\inst2|Mux1~4_combout\)) # (\inst2|Mux3~4_combout\ & (\inst2|Mux2~4_combout\))) ) ) # ( !\inst2|Mux4~4_combout\ & ( 
-- (!\B_T_CN_M~input_o\) # ((!\inst2|Mux3~4_combout\ & (\inst2|Mux2~4_combout\ & !\inst2|Mux1~4_combout\)) # (\inst2|Mux3~4_combout\ & (!\inst2|Mux2~4_combout\ & \inst2|Mux1~4_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001011110100111100101111010011111001111100011111100111110001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux3~4_combout\,
	datab => \inst2|ALT_INV_Mux2~4_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst2|ALT_INV_Mux1~4_combout\,
	dataf => \inst2|ALT_INV_Mux4~4_combout\,
	combout => \inst8|Mux10~0_combout\);

-- Location: LABCELL_X11_Y6_N30
\inst8|Mux11~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux11~0_combout\ = ( \inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux1~4_combout\) # ((!\inst2|Mux3~4_combout\ & !\inst2|Mux2~4_combout\))) ) ) # ( !\inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux3~4_combout\ & 
-- (\inst2|Mux2~4_combout\ & !\inst2|Mux1~4_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001011110000111100101111000011111111111110001111111111111000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux3~4_combout\,
	datab => \inst2|ALT_INV_Mux2~4_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst2|ALT_INV_Mux1~4_combout\,
	dataf => \inst2|ALT_INV_Mux4~4_combout\,
	combout => \inst8|Mux11~0_combout\);

-- Location: LABCELL_X11_Y6_N42
\inst8|Mux12~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux12~0_combout\ = ( \inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # (!\inst2|Mux1~4_combout\ $ (((!\inst2|Mux3~4_combout\ & \inst2|Mux2~4_combout\)))) ) ) # ( !\inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((\inst2|Mux3~4_combout\ & 
-- (!\inst2|Mux2~4_combout\ & !\inst2|Mux1~4_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111010011110000111101001111000011111101111100101111110111110010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux3~4_combout\,
	datab => \inst2|ALT_INV_Mux2~4_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst2|ALT_INV_Mux1~4_combout\,
	dataf => \inst2|ALT_INV_Mux4~4_combout\,
	combout => \inst8|Mux12~0_combout\);

-- Location: LABCELL_X11_Y6_N48
\inst8|Mux13~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux13~0_combout\ = ( \inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux1~4_combout\ & (!\inst2|Mux3~4_combout\ $ (\inst2|Mux2~4_combout\)))) ) ) # ( !\inst2|Mux4~4_combout\ & ( (!\B_T_CN_M~input_o\) # ((!\inst2|Mux3~4_combout\ & 
-- (!\inst2|Mux2~4_combout\ $ (\inst2|Mux1~4_combout\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111100011110010111110001111001011111001111100001111100111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_Mux3~4_combout\,
	datab => \inst2|ALT_INV_Mux2~4_combout\,
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst2|ALT_INV_Mux1~4_combout\,
	dataf => \inst2|ALT_INV_Mux4~4_combout\,
	combout => \inst8|Mux13~0_combout\);

-- Location: LABCELL_X12_Y6_N0
\inst9|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux0~0_combout\ = ( \inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(1) & (!\inst10|A\(2) $ (\inst10|A\(3)))) # (\inst10|A\(1) & (!\inst10|A\(2) & \inst10|A\(3)))) ) ) # ( !\inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(1) & 
-- (\inst10|A\(2) & !\inst10|A\(3)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111001011110000111100101111000011111000111101101111100011110110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datab => \inst10|ALT_INV_A\(2),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst10|ALT_INV_A\(3),
	dataf => \inst10|ALT_INV_A\(0),
	combout => \inst9|Mux0~0_combout\);

-- Location: LABCELL_X12_Y6_N3
\inst9|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux1~0_combout\ = ( \inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(1) & (\inst10|A\(2) & !\inst10|A\(3))) # (\inst10|A\(1) & ((\inst10|A\(3))))) ) ) # ( !\inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # ((\inst10|A\(2) & ((\inst10|A\(3)) # 
-- (\inst10|A\(1))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100010011111111110001001111111111001001011111111100100101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datab => \inst10|ALT_INV_A\(2),
	datac => \inst10|ALT_INV_A\(3),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst10|ALT_INV_A\(0),
	combout => \inst9|Mux1~0_combout\);

-- Location: LABCELL_X12_Y6_N42
\inst9|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux2~0_combout\ = ( \inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # ((\inst10|A\(1) & (\inst10|A\(2) & \inst10|A\(3)))) ) ) # ( !\inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(2) & (\inst10|A\(1) & !\inst10|A\(3))) # (\inst10|A\(2) & 
-- ((\inst10|A\(3))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111010011110011111101001111001111110000111100011111000011110001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datab => \inst10|ALT_INV_A\(2),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst10|ALT_INV_A\(3),
	dataf => \inst10|ALT_INV_A\(0),
	combout => \inst9|Mux2~0_combout\);

-- Location: MLABCELL_X8_Y2_N54
\inst9|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux3~0_combout\ = ( \inst10|A\(0) & ( \inst10|A\(3) & ( (!\B_T_CN_M~input_o\) # ((\inst10|A\(2) & \inst10|A\(1))) ) ) ) # ( !\inst10|A\(0) & ( \inst10|A\(3) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(2) & \inst10|A\(1))) ) ) ) # ( \inst10|A\(0) & ( 
-- !\inst10|A\(3) & ( (!\B_T_CN_M~input_o\) # (!\inst10|A\(2) $ (\inst10|A\(1))) ) ) ) # ( !\inst10|A\(0) & ( !\inst10|A\(3) & ( (!\B_T_CN_M~input_o\) # ((\inst10|A\(2) & !\inst10|A\(1))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1101110011011100111011011110110111001110110011101100110111001101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(2),
	datab => \ALT_INV_B_T_CN_M~input_o\,
	datac => \inst10|ALT_INV_A\(1),
	datae => \inst10|ALT_INV_A\(0),
	dataf => \inst10|ALT_INV_A\(3),
	combout => \inst9|Mux3~0_combout\);

-- Location: LABCELL_X12_Y6_N27
\inst9|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux4~0_combout\ = ( \inst10|A\(0) & ( (!\inst10|A\(3)) # ((!\B_T_CN_M~input_o\) # ((!\inst10|A\(1) & !\inst10|A\(2)))) ) ) # ( !\inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(1) & (\inst10|A\(2) & !\inst10|A\(3)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111100100000111111110010000011111111111110001111111111111000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datab => \inst10|ALT_INV_A\(2),
	datac => \inst10|ALT_INV_A\(3),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst10|ALT_INV_A\(0),
	combout => \inst9|Mux4~0_combout\);

-- Location: LABCELL_X12_Y6_N45
\inst9|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux5~0_combout\ = ( \inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # (!\inst10|A\(3) $ (((!\inst10|A\(1) & \inst10|A\(2))))) ) ) # ( !\inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # ((\inst10|A\(1) & (!\inst10|A\(2) & !\inst10|A\(3)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111101000000111111110100000011111111110100101111111111010010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datab => \inst10|ALT_INV_A\(2),
	datac => \inst10|ALT_INV_A\(3),
	datad => \ALT_INV_B_T_CN_M~input_o\,
	dataf => \inst10|ALT_INV_A\(0),
	combout => \inst9|Mux5~0_combout\);

-- Location: LABCELL_X12_Y6_N24
\inst9|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux6~0_combout\ = ( \inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(3) & (!\inst10|A\(1) $ (\inst10|A\(2))))) ) ) # ( !\inst10|A\(0) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(1) & (!\inst10|A\(2) $ (\inst10|A\(3))))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111100011110010111110001111001011111001111100001111100111110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(1),
	datab => \inst10|ALT_INV_A\(2),
	datac => \ALT_INV_B_T_CN_M~input_o\,
	datad => \inst10|ALT_INV_A\(3),
	dataf => \inst10|ALT_INV_A\(0),
	combout => \inst9|Mux6~0_combout\);

-- Location: LABCELL_X12_Y6_N9
\inst9|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux7~0_combout\ = ( \inst10|A\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(6) & (!\inst10|A\(7) $ (\inst10|A[5]~DUPLICATE_q\))) # (\inst10|A\(6) & (\inst10|A\(7) & !\inst10|A[5]~DUPLICATE_q\))) ) ) # ( !\inst10|A\(4) & ( (!\B_T_CN_M~input_o\) # 
-- ((\inst10|A\(6) & (!\inst10|A\(7) & !\inst10|A[5]~DUPLICATE_q\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011101010101010101110101010101011101011101011101110101110101110",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst10|ALT_INV_A\(6),
	datac => \inst10|ALT_INV_A\(7),
	datad => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	dataf => \inst10|ALT_INV_A\(4),
	combout => \inst9|Mux7~0_combout\);

-- Location: LABCELL_X12_Y6_N12
\inst9|Mux8~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux8~0_combout\ = ( \inst10|A\(7) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(4) & (\inst10|A\(6))) # (\inst10|A\(4) & ((\inst10|A[5]~DUPLICATE_q\)))) ) ) # ( !\inst10|A\(7) & ( (!\B_T_CN_M~input_o\) # ((\inst10|A\(6) & (!\inst10|A\(4) $ 
-- (!\inst10|A[5]~DUPLICATE_q\)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101110111010101010111011101010111010101111111011101010111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst10|ALT_INV_A\(6),
	datac => \inst10|ALT_INV_A\(4),
	datad => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	dataf => \inst10|ALT_INV_A\(7),
	combout => \inst9|Mux8~0_combout\);

-- Location: LABCELL_X12_Y6_N15
\inst9|Mux9~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux9~0_combout\ = ( \inst10|A\(4) & ( (!\B_T_CN_M~input_o\) # ((\inst10|A\(6) & (\inst10|A\(7) & \inst10|A[5]~DUPLICATE_q\))) ) ) # ( !\inst10|A\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(6) & (!\inst10|A\(7) & \inst10|A[5]~DUPLICATE_q\)) # 
-- (\inst10|A\(6) & (\inst10|A\(7)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101111101011101010111110101110101010101010111010101010101011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst10|ALT_INV_A\(6),
	datac => \inst10|ALT_INV_A\(7),
	datad => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	dataf => \inst10|ALT_INV_A\(4),
	combout => \inst9|Mux9~0_combout\);

-- Location: LABCELL_X12_Y6_N57
\inst9|Mux10~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux10~0_combout\ = ( \inst10|A\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(6) & (!\inst10|A\(7) & !\inst10|A[5]~DUPLICATE_q\)) # (\inst10|A\(6) & ((\inst10|A[5]~DUPLICATE_q\)))) ) ) # ( !\inst10|A\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(6) 
-- & (\inst10|A\(7) & \inst10|A[5]~DUPLICATE_q\)) # (\inst10|A\(6) & (!\inst10|A\(7) & !\inst10|A[5]~DUPLICATE_q\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011101010101110101110101010111011101010101110111110101010111011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst10|ALT_INV_A\(6),
	datac => \inst10|ALT_INV_A\(7),
	datad => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	dataf => \inst10|ALT_INV_A\(4),
	combout => \inst9|Mux10~0_combout\);

-- Location: LABCELL_X12_Y6_N6
\inst9|Mux11~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux11~0_combout\ = ( \inst10|A\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(7)) # ((!\inst10|A\(6) & !\inst10|A[5]~DUPLICATE_q\))) ) ) # ( !\inst10|A\(4) & ( (!\B_T_CN_M~input_o\) # ((\inst10|A\(6) & (!\inst10|A\(7) & !\inst10|A[5]~DUPLICATE_q\))) 
-- ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1011101010101010101110101010101011111110111110101111111011111010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst10|ALT_INV_A\(6),
	datac => \inst10|ALT_INV_A\(7),
	datad => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	dataf => \inst10|ALT_INV_A\(4),
	combout => \inst9|Mux11~0_combout\);

-- Location: LABCELL_X12_Y6_N54
\inst9|Mux12~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux12~0_combout\ = ( \inst10|A\(4) & ( (!\B_T_CN_M~input_o\) # (!\inst10|A\(7) $ (((\inst10|A\(6) & !\inst10|A[5]~DUPLICATE_q\)))) ) ) # ( !\inst10|A\(4) & ( (!\B_T_CN_M~input_o\) # ((!\inst10|A\(6) & (!\inst10|A\(7) & \inst10|A[5]~DUPLICATE_q\))) 
-- ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1010101011101010101010101110101011101011111110101110101111111010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \ALT_INV_B_T_CN_M~input_o\,
	datab => \inst10|ALT_INV_A\(6),
	datac => \inst10|ALT_INV_A\(7),
	datad => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	dataf => \inst10|ALT_INV_A\(4),
	combout => \inst9|Mux12~0_combout\);

-- Location: MLABCELL_X8_Y5_N27
\inst9|Mux13~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux13~0_combout\ = ( \B_T_CN_M~input_o\ & ( (!\inst10|A\(4) & (!\inst10|A[5]~DUPLICATE_q\ & (!\inst10|A\(7) $ (\inst10|A\(6))))) # (\inst10|A\(4) & (!\inst10|A\(7) & (!\inst10|A[5]~DUPLICATE_q\ $ (\inst10|A\(6))))) ) ) # ( !\B_T_CN_M~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111110001000010000101000100001000010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|ALT_INV_A\(7),
	datab => \inst10|ALT_INV_A[5]~DUPLICATE_q\,
	datac => \inst10|ALT_INV_A\(4),
	datad => \inst10|ALT_INV_A\(6),
	dataf => \ALT_INV_B_T_CN_M~input_o\,
	combout => \inst9|Mux13~0_combout\);

-- Location: FF_X2_Y4_N32
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(6),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][6]~q\);

-- Location: FF_X2_Y4_N35
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \altera_internal_jtag~TCKUTAP\,
	asdata => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irsr_reg\(7),
	clrn => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	sload => VCC,
	ena => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|irf_reg[1][7]~q\);

-- Location: LABCELL_X50_Y16_N0
\auto_hub|~GND\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;

-- Location: LABCELL_X2_Y4_N45
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~_wirecell\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111100000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|ALT_INV_clr_reg~q\,
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|clr_reg~_wirecell_combout\);

-- Location: LABCELL_X4_Y2_N48
\auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[0]~_wirecell\ : cyclonev_lcell_comb
-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1100110011001100110011001100110011001100110011001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|ALT_INV_state\(0),
	combout => \auto_hub|instrumentation_fabric_with_node_gen:fabric_gen_new_way:with_jtag_input_gen:instrumentation_fabric|instrumentation_fabric|alt_sld_fab|sldfabric|jtag_hub_gen:real_sld_jtag_hub|shadow_jsm|state[0]~_wirecell_combout\);

-- Location: LABCELL_X43_Y21_N3
\~QUARTUS_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;
END structure;


