library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity clk_gen is
  port (
    clk50   : in  std_logic;   -- CLOCK_50
    sw9     : in  std_logic;   -- SW[9]：1=快(50MHz)，0=慢
    clk_cpu : out std_logic
  );
end entity;

architecture rtl of clk_gen is
  signal div_cnt  : unsigned(25 downto 0) := (others => '0');
  signal clk_slow : std_logic;
begin
  process(clk50)
  begin
    if rising_edge(clk50) then
      div_cnt <= div_cnt + 1;
    end if;
  end process;

  clk_slow <= std_logic(div_cnt(25));

  clk_cpu <= clk50 when sw9 = '1' else clk_slow;
end architecture;
