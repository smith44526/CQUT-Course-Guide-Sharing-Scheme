library ieee;
use ieee.std_logic_1164.all;

entity disp8_to_hex2 is
  port (
    x      : in  std_logic_vector(7 downto 0);
    hex_lo : out std_logic_vector(6 downto 0);
    hex_hi : out std_logic_vector(6 downto 0)
  );
end entity;

architecture rtl of disp8_to_hex2 is
begin
  u_lo: entity work.hex7seg
    port map(hex => x(3 downto 0), seg => hex_lo);

  u_hi: entity work.hex7seg
    port map(hex => x(7 downto 4), seg => hex_hi);
end architecture;
