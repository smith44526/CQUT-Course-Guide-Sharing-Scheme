inst_rom_inst : inst_rom PORT MAP (
		address	 => address_sig,
		clock	 => clock_sig,
		q	 => q_sig
	);
