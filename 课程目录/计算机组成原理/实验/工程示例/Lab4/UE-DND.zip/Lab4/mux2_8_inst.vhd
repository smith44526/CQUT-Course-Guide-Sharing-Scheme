mux2_8_inst : mux2_8 PORT MAP (
		data0x	 => data0x_sig,
		data1x	 => data1x_sig,
		sel	 => sel_sig,
		result	 => result_sig
	);
