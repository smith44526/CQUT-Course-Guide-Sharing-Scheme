library ieee;
use ieee.std_logic_1164.all;

entity ac8 is
  port(
    clk    : in  std_logic;
    rst    : in  std_logic;
    ld_ac  : in  std_logic;
    din    : in  std_logic_vector(7 downto 0);
    ac_out : out std_logic_vector(7 downto 0)
  );
end entity;

architecture rtl of ac8 is
  signal ac_r : std_logic_vector(7 downto 0) := (others => '0');
begin
  ac_out <= ac_r;

  process(clk, rst)
  begin
    if rst = '1' then
      ac_r <= (others => '0');
    elsif falling_edge(clk) then
      if ld_ac = '1' then
        ac_r <= din;
      end if;
    end if;
  end process;
end architecture;
