library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity alu8 is
  port(
    a      : in  std_logic_vector(7 downto 0);
    b      : in  std_logic_vector(7 downto 0);
    alu_op : in  std_logic_vector(2 downto 0);
    f      : out std_logic_vector(7 downto 0)
  );
end entity;

architecture rtl of alu8 is
begin
  process(a, b, alu_op)
    variable ua, ub : unsigned(7 downto 0);
    variable r      : unsigned(7 downto 0);
  begin
    ua := unsigned(a);
    ub := unsigned(b);
    case alu_op is
      when "000" => f <= a;
      when "001" => f <= b;
      when "010" => r := ua + ub; f <= std_logic_vector(r);
      when "011" => r := ua - ub; f <= std_logic_vector(r);
      when "100" => f <= a and b;
      when "101" => f <= a or  b;
      when others => f <= (others => '0');
    end case;
  end process;
end architecture;
