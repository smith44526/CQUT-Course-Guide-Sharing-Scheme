library ieee;
use ieee.std_logic_1164.all;

entity controller_hw is
  port(
    op       : in  std_logic_vector(3 downto 0);

    ld_pc    : out std_logic;
    incr_pc  : out std_logic;

    ld_ac    : out std_logic;
    ram_wren : out std_logic;
    alu_op   : out std_logic_vector(2 downto 0);

    disp_sel : out std_logic
  );
end entity;

architecture rtl of controller_hw is
begin
  process(op)
  begin
    ld_pc    <= '0';
    incr_pc  <= '1';
    ld_ac    <= '0';
    ram_wren <= '0';
    alu_op   <= "000";
    disp_sel <= '0';

    case op is
      when "0000" => -- NOP
        null;

      when "0001" => -- JMP ADDR  => PC <- ADDR
        ld_pc   <= '1';

      when "0010" => -- SUB ADDR  => AC <- AC - Mem[ADDR]
        ld_ac  <= '1';
        alu_op <= "011";

      when "0011" => -- LAD ADDR  => AC <- Mem[ADDR]
        ld_ac  <= '1';
        alu_op <= "001"; -- pass B

      when "0100" => -- AND ADDR  => AC <- AC AND Mem[ADDR]
        ld_ac  <= '1';
        alu_op <= "100";

      when "0101" => -- OR ADDR   => AC <- AC OR Mem[ADDR]
        ld_ac  <= '1';
        alu_op <= "101";

      when "0110" => -- ADD ADDR  => AC <- AC + Mem[ADDR]
        ld_ac  <= '1';
        alu_op <= "010";

      when "0111" => -- STD ADDR  => Mem[ADDR] <- AC
        ram_wren <= '1';
        -- AC不变

      when others =>
        null;
    end case;
  end process;
end architecture;
