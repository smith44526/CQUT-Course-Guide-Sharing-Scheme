library ieee;
use ieee.std_logic_1164.all;

package cpu_pkg is
  constant OP_NOP : std_logic_vector(3 downto 0) := "0000";
  constant OP_JMP : std_logic_vector(3 downto 0) := "0001";
  constant OP_SUB : std_logic_vector(3 downto 0) := "0010";
  constant OP_LAD : std_logic_vector(3 downto 0) := "0011";
  constant OP_AND : std_logic_vector(3 downto 0) := "0100";
  constant OP_OR  : std_logic_vector(3 downto 0) := "0101";
  constant OP_ADD : std_logic_vector(3 downto 0) := "0110";
  constant OP_STD : std_logic_vector(3 downto 0) := "0111";
end package;

package body cpu_pkg is
end package body;
