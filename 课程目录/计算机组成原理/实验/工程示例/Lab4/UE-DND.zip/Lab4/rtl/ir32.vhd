library ieee;
use ieee.std_logic_1164.all;

entity ir32 is
  port (
    clk   : in  std_logic;
    reset : in  std_logic;
    d     : in  std_logic_vector(31 downto 0);
    q     : out std_logic_vector(31 downto 0)
  );
end entity;

architecture rtl of ir32 is
  signal r : std_logic_vector(31 downto 0) := (others => '0');
begin
  process(reset, clk)
  begin
    if reset = '1' then
      r <= (others => '0');
    elsif falling_edge(clk) then
      r <= d;
    end if;
  end process;

  q <= r;
end architecture;
