library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity pc8 is
  port(
    clk     : in  std_logic;
    rst     : in  std_logic;
    ld_pc   : in  std_logic;
    incr_pc : in  std_logic;
    din     : in  std_logic_vector(7 downto 0);
    pc_out  : out std_logic_vector(7 downto 0)
  );
end entity;

architecture rtl of pc8 is
  signal pc_r : std_logic_vector(7 downto 0) := (others => '0');
begin
  pc_out <= pc_r;

  process(clk, rst)
  begin
    if rst = '1' then
      pc_r <= (others => '0');
    elsif rising_edge(clk) then
      if ld_pc = '1' then
        pc_r <= din;
      elsif incr_pc = '1' then
        pc_r <= std_logic_vector(unsigned(pc_r) + 1);
      else
        pc_r <= pc_r;
      end if;
    end if;
  end process;
end architecture;
