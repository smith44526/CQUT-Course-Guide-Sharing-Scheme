-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 20.1.1 Build 720 11/11/2020 SJ Lite Edition"

-- DATE "12/14/2025 17:48:38"

-- 
-- Device: Altera 5CSEMA5F31C6 Package FBGA896
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY ALTERA_LNSIM;
LIBRARY CYCLONEV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE ALTERA_LNSIM.ALTERA_LNSIM_COMPONENTS.ALL;
USE CYCLONEV.CYCLONEV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	cpu_top IS
    PORT (
	HEX0 : OUT std_logic_vector(6 DOWNTO 0);
	CLOCK_50 : IN std_logic;
	SW : IN std_logic_vector(9 DOWNTO 9);
	KEY : IN std_logic_vector(0 DOWNTO 0);
	HEX1 : OUT std_logic_vector(6 DOWNTO 0);
	HEX2 : OUT std_logic_vector(6 DOWNTO 0);
	HEX3 : OUT std_logic_vector(6 DOWNTO 0);
	HEX4 : OUT std_logic_vector(6 DOWNTO 0);
	HEX5 : OUT std_logic_vector(6 DOWNTO 0);
	LEDR : OUT std_logic_vector(9 DOWNTO 0)
	);
END cpu_top;

-- Design Ports Information
-- HEX0[6]	=>  Location: PIN_AH28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX0[5]	=>  Location: PIN_AG28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX0[4]	=>  Location: PIN_AF28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX0[3]	=>  Location: PIN_AG27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX0[2]	=>  Location: PIN_AE28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX0[1]	=>  Location: PIN_AE27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX0[0]	=>  Location: PIN_AE26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX1[6]	=>  Location: PIN_AD27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX1[5]	=>  Location: PIN_AF30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX1[4]	=>  Location: PIN_AF29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX1[3]	=>  Location: PIN_AG30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX1[2]	=>  Location: PIN_AH30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX1[1]	=>  Location: PIN_AH29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX1[0]	=>  Location: PIN_AJ29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX2[6]	=>  Location: PIN_AC30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX2[5]	=>  Location: PIN_AC29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX2[4]	=>  Location: PIN_AD30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX2[3]	=>  Location: PIN_AC28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX2[2]	=>  Location: PIN_AD29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX2[1]	=>  Location: PIN_AE29,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX2[0]	=>  Location: PIN_AB23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX3[6]	=>  Location: PIN_AB22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX3[5]	=>  Location: PIN_AB25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX3[4]	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX3[3]	=>  Location: PIN_AC25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX3[2]	=>  Location: PIN_AD25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX3[1]	=>  Location: PIN_AC27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX3[0]	=>  Location: PIN_AD26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX4[6]	=>  Location: PIN_W25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX4[5]	=>  Location: PIN_V23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX4[4]	=>  Location: PIN_W24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX4[3]	=>  Location: PIN_W22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX4[2]	=>  Location: PIN_Y24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX4[1]	=>  Location: PIN_Y23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX4[0]	=>  Location: PIN_AA24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX5[6]	=>  Location: PIN_AA25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX5[5]	=>  Location: PIN_AA26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX5[4]	=>  Location: PIN_AB26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX5[3]	=>  Location: PIN_AB27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX5[2]	=>  Location: PIN_Y27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX5[1]	=>  Location: PIN_AA28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HEX5[0]	=>  Location: PIN_V25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LEDR[9]	=>  Location: PIN_Y21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LEDR[8]	=>  Location: PIN_W21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LEDR[7]	=>  Location: PIN_W20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LEDR[6]	=>  Location: PIN_Y19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LEDR[5]	=>  Location: PIN_W19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LEDR[4]	=>  Location: PIN_W17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LEDR[3]	=>  Location: PIN_V18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LEDR[2]	=>  Location: PIN_V17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LEDR[1]	=>  Location: PIN_W16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LEDR[0]	=>  Location: PIN_V16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- KEY[0]	=>  Location: PIN_AA14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CLOCK_50	=>  Location: PIN_AF14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- SW[9]	=>  Location: PIN_AE12,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF cpu_top IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_HEX0 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_CLOCK_50 : std_logic;
SIGNAL ww_SW : std_logic_vector(9 DOWNTO 9);
SIGNAL ww_KEY : std_logic_vector(0 DOWNTO 0);
SIGNAL ww_HEX1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_HEX2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_HEX3 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_HEX4 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_HEX5 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_LEDR : std_logic_vector(9 DOWNTO 0);
SIGNAL \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAIN_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\ : std_logic_vector(19 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \SW[9]~input_o\ : std_logic;
SIGNAL \CLOCK_50~input_o\ : std_logic;
SIGNAL \CLOCK_50~inputCLKENA0_outclk\ : std_logic;
SIGNAL \inst15|div_cnt[0]~0_combout\ : std_logic;
SIGNAL \inst15|Add0~97_sumout\ : std_logic;
SIGNAL \inst15|div_cnt[1]~feeder_combout\ : std_logic;
SIGNAL \inst15|Add0~98\ : std_logic;
SIGNAL \inst15|Add0~93_sumout\ : std_logic;
SIGNAL \inst15|Add0~94\ : std_logic;
SIGNAL \inst15|Add0~89_sumout\ : std_logic;
SIGNAL \inst15|Add0~90\ : std_logic;
SIGNAL \inst15|Add0~85_sumout\ : std_logic;
SIGNAL \inst15|Add0~86\ : std_logic;
SIGNAL \inst15|Add0~81_sumout\ : std_logic;
SIGNAL \inst15|Add0~82\ : std_logic;
SIGNAL \inst15|Add0~77_sumout\ : std_logic;
SIGNAL \inst15|Add0~78\ : std_logic;
SIGNAL \inst15|Add0~73_sumout\ : std_logic;
SIGNAL \inst15|Add0~74\ : std_logic;
SIGNAL \inst15|Add0~69_sumout\ : std_logic;
SIGNAL \inst15|Add0~70\ : std_logic;
SIGNAL \inst15|Add0~65_sumout\ : std_logic;
SIGNAL \inst15|Add0~66\ : std_logic;
SIGNAL \inst15|Add0~61_sumout\ : std_logic;
SIGNAL \inst15|Add0~62\ : std_logic;
SIGNAL \inst15|Add0~57_sumout\ : std_logic;
SIGNAL \inst15|Add0~58\ : std_logic;
SIGNAL \inst15|Add0~53_sumout\ : std_logic;
SIGNAL \inst15|Add0~54\ : std_logic;
SIGNAL \inst15|Add0~49_sumout\ : std_logic;
SIGNAL \inst15|Add0~50\ : std_logic;
SIGNAL \inst15|Add0~45_sumout\ : std_logic;
SIGNAL \inst15|Add0~46\ : std_logic;
SIGNAL \inst15|Add0~41_sumout\ : std_logic;
SIGNAL \inst15|Add0~42\ : std_logic;
SIGNAL \inst15|Add0~37_sumout\ : std_logic;
SIGNAL \inst15|Add0~38\ : std_logic;
SIGNAL \inst15|Add0~33_sumout\ : std_logic;
SIGNAL \inst15|Add0~34\ : std_logic;
SIGNAL \inst15|Add0~29_sumout\ : std_logic;
SIGNAL \inst15|Add0~30\ : std_logic;
SIGNAL \inst15|Add0~25_sumout\ : std_logic;
SIGNAL \inst15|Add0~26\ : std_logic;
SIGNAL \inst15|Add0~21_sumout\ : std_logic;
SIGNAL \inst15|Add0~22\ : std_logic;
SIGNAL \inst15|Add0~17_sumout\ : std_logic;
SIGNAL \inst15|Add0~18\ : std_logic;
SIGNAL \inst15|Add0~13_sumout\ : std_logic;
SIGNAL \inst15|Add0~14\ : std_logic;
SIGNAL \inst15|Add0~9_sumout\ : std_logic;
SIGNAL \inst15|Add0~10\ : std_logic;
SIGNAL \inst15|Add0~5_sumout\ : std_logic;
SIGNAL \inst15|Add0~6\ : std_logic;
SIGNAL \inst15|Add0~1_sumout\ : std_logic;
SIGNAL \inst15|clk_cpu~combout\ : std_logic;
SIGNAL \KEY[0]~input_o\ : std_logic;
SIGNAL \inst|Add0~29_sumout\ : std_logic;
SIGNAL \inst|pc_r[0]~feeder_combout\ : std_logic;
SIGNAL \inst|Add0~30\ : std_logic;
SIGNAL \inst|Add0~25_sumout\ : std_logic;
SIGNAL \inst|pc_r[1]~feeder_combout\ : std_logic;
SIGNAL \inst|Add0~26\ : std_logic;
SIGNAL \inst|Add0~21_sumout\ : std_logic;
SIGNAL \inst|pc_r[2]~feeder_combout\ : std_logic;
SIGNAL \inst|Add0~22\ : std_logic;
SIGNAL \inst|Add0~18\ : std_logic;
SIGNAL \inst|Add0~13_sumout\ : std_logic;
SIGNAL \inst|pc_r[4]~feeder_combout\ : std_logic;
SIGNAL \inst|Add0~14\ : std_logic;
SIGNAL \inst|Add0~9_sumout\ : std_logic;
SIGNAL \inst|pc_r[5]~feeder_combout\ : std_logic;
SIGNAL \inst3|Mux0~0_combout\ : std_logic;
SIGNAL \inst|pc_r[7]~DUPLICATE_q\ : std_logic;
SIGNAL \inst|Add0~10\ : std_logic;
SIGNAL \inst|Add0~6\ : std_logic;
SIGNAL \inst|Add0~1_sumout\ : std_logic;
SIGNAL \inst|pc_r[7]~feeder_combout\ : std_logic;
SIGNAL \inst|pc_r[6]~DUPLICATE_q\ : std_logic;
SIGNAL \inst|Add0~5_sumout\ : std_logic;
SIGNAL \inst|pc_r[6]~feeder_combout\ : std_logic;
SIGNAL \inst|Add0~17_sumout\ : std_logic;
SIGNAL \inst|pc_r[3]~feeder_combout\ : std_logic;
SIGNAL \inst|pc_r[3]~DUPLICATE_q\ : std_logic;
SIGNAL \inst3|Mux4~0_combout\ : std_logic;
SIGNAL \inst5|Mux4~0_combout\ : std_logic;
SIGNAL \inst3|Mux2~0_combout\ : std_logic;
SIGNAL \inst3|Mux5~0_combout\ : std_logic;
SIGNAL \inst5|Add0~34_cout\ : std_logic;
SIGNAL \inst5|Add0~2\ : std_logic;
SIGNAL \inst5|Add0~6\ : std_logic;
SIGNAL \inst5|Add0~10\ : std_logic;
SIGNAL \inst5|Add0~14\ : std_logic;
SIGNAL \inst5|Add0~18\ : std_logic;
SIGNAL \inst5|Add0~22\ : std_logic;
SIGNAL \inst5|Add0~26\ : std_logic;
SIGNAL \inst5|Add0~29_sumout\ : std_logic;
SIGNAL \inst5|Mux0~0_combout\ : std_logic;
SIGNAL \inst3|Mux1~0_combout\ : std_logic;
SIGNAL \inst5|Add0~25_sumout\ : std_logic;
SIGNAL \inst5|Mux1~0_combout\ : std_logic;
SIGNAL \inst5|Add0~21_sumout\ : std_logic;
SIGNAL \inst5|Mux2~0_combout\ : std_logic;
SIGNAL \inst5|Add0~17_sumout\ : std_logic;
SIGNAL \inst5|Mux3~0_combout\ : std_logic;
SIGNAL \inst5|Add0~13_sumout\ : std_logic;
SIGNAL \inst5|Mux4~1_combout\ : std_logic;
SIGNAL \inst5|Add0~9_sumout\ : std_logic;
SIGNAL \inst5|Mux5~0_combout\ : std_logic;
SIGNAL \inst7|ac_r[2]~DUPLICATE_q\ : std_logic;
SIGNAL \inst5|Add0~5_sumout\ : std_logic;
SIGNAL \inst5|Mux6~0_combout\ : std_logic;
SIGNAL \inst5|Add0~1_sumout\ : std_logic;
SIGNAL \inst5|Mux7~0_combout\ : std_logic;
SIGNAL \inst11|Mux0~0_combout\ : std_logic;
SIGNAL \inst11|Mux1~0_combout\ : std_logic;
SIGNAL \inst11|Mux2~0_combout\ : std_logic;
SIGNAL \inst11|Mux3~0_combout\ : std_logic;
SIGNAL \inst11|Mux4~0_combout\ : std_logic;
SIGNAL \inst11|Mux5~0_combout\ : std_logic;
SIGNAL \inst11|Mux6~0_combout\ : std_logic;
SIGNAL \inst8|Mux0~0_combout\ : std_logic;
SIGNAL \inst8|Mux1~0_combout\ : std_logic;
SIGNAL \inst8|Mux2~0_combout\ : std_logic;
SIGNAL \inst8|Mux3~0_combout\ : std_logic;
SIGNAL \inst8|Mux4~0_combout\ : std_logic;
SIGNAL \inst8|Mux5~0_combout\ : std_logic;
SIGNAL \inst8|Mux6~0_combout\ : std_logic;
SIGNAL \inst9|Mux0~0_combout\ : std_logic;
SIGNAL \inst9|Mux1~0_combout\ : std_logic;
SIGNAL \inst9|Mux2~0_combout\ : std_logic;
SIGNAL \inst9|Mux3~0_combout\ : std_logic;
SIGNAL \inst9|Mux4~0_combout\ : std_logic;
SIGNAL \inst9|Mux5~0_combout\ : std_logic;
SIGNAL \inst9|Mux6~0_combout\ : std_logic;
SIGNAL \inst10|Mux0~0_combout\ : std_logic;
SIGNAL \inst10|Mux1~0_combout\ : std_logic;
SIGNAL \inst10|Mux2~0_combout\ : std_logic;
SIGNAL \inst10|Mux3~0_combout\ : std_logic;
SIGNAL \inst10|Mux4~0_combout\ : std_logic;
SIGNAL \inst10|Mux5~0_combout\ : std_logic;
SIGNAL \inst10|Mux6~0_combout\ : std_logic;
SIGNAL \inst12|Mux0~0_combout\ : std_logic;
SIGNAL \inst12|Mux1~0_combout\ : std_logic;
SIGNAL \inst12|Mux2~0_combout\ : std_logic;
SIGNAL \inst12|Mux3~0_combout\ : std_logic;
SIGNAL \inst12|Mux4~0_combout\ : std_logic;
SIGNAL \inst12|Mux5~0_combout\ : std_logic;
SIGNAL \inst12|Mux6~0_combout\ : std_logic;
SIGNAL \inst13|Mux0~0_combout\ : std_logic;
SIGNAL \inst13|Mux1~0_combout\ : std_logic;
SIGNAL \inst13|Mux2~0_combout\ : std_logic;
SIGNAL \inst13|Mux3~0_combout\ : std_logic;
SIGNAL \inst13|Mux4~0_combout\ : std_logic;
SIGNAL \inst13|Mux5~0_combout\ : std_logic;
SIGNAL \inst13|Mux6~0_combout\ : std_logic;
SIGNAL \inst4|altsyncram_component|auto_generated|q_a\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst|pc_r\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst2|r\ : std_logic_vector(31 DOWNTO 0);
SIGNAL \inst7|ac_r\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst15|div_cnt\ : std_logic_vector(25 DOWNTO 0);
SIGNAL \inst7|ALT_INV_ac_r[2]~DUPLICATE_q\ : std_logic;
SIGNAL \inst|ALT_INV_pc_r[6]~DUPLICATE_q\ : std_logic;
SIGNAL \inst|ALT_INV_pc_r[7]~DUPLICATE_q\ : std_logic;
SIGNAL \ALT_INV_SW[9]~input_o\ : std_logic;
SIGNAL \ALT_INV_CLOCK_50~input_o\ : std_logic;
SIGNAL \ALT_INV_KEY[0]~input_o\ : std_logic;
SIGNAL \inst15|ALT_INV_div_cnt\ : std_logic_vector(25 DOWNTO 0);
SIGNAL \inst15|ALT_INV_clk_cpu~combout\ : std_logic;
SIGNAL \inst13|ALT_INV_Mux0~0_combout\ : std_logic;
SIGNAL \inst5|ALT_INV_Mux0~0_combout\ : std_logic;
SIGNAL \inst5|ALT_INV_Mux1~0_combout\ : std_logic;
SIGNAL \inst5|ALT_INV_Mux2~0_combout\ : std_logic;
SIGNAL \inst5|ALT_INV_Mux3~0_combout\ : std_logic;
SIGNAL \inst12|ALT_INV_Mux0~0_combout\ : std_logic;
SIGNAL \inst5|ALT_INV_Mux4~1_combout\ : std_logic;
SIGNAL \inst5|ALT_INV_Mux5~0_combout\ : std_logic;
SIGNAL \inst5|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \inst5|ALT_INV_Mux7~0_combout\ : std_logic;
SIGNAL \inst5|ALT_INV_Mux4~0_combout\ : std_logic;
SIGNAL \inst3|ALT_INV_Mux4~0_combout\ : std_logic;
SIGNAL \inst3|ALT_INV_Mux2~0_combout\ : std_logic;
SIGNAL \inst10|ALT_INV_Mux0~0_combout\ : std_logic;
SIGNAL \inst9|ALT_INV_Mux0~0_combout\ : std_logic;
SIGNAL \inst8|ALT_INV_Mux0~0_combout\ : std_logic;
SIGNAL \inst7|ALT_INV_ac_r\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \inst11|ALT_INV_Mux0~0_combout\ : std_logic;
SIGNAL \inst15|ALT_INV_Add0~97_sumout\ : std_logic;
SIGNAL \inst2|ALT_INV_r\ : std_logic_vector(31 DOWNTO 28);
SIGNAL \inst|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \inst|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \inst|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \inst|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \inst|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \inst|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \inst|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \inst|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \inst|ALT_INV_pc_r\ : std_logic_vector(5 DOWNTO 0);
SIGNAL \inst5|ALT_INV_Add0~29_sumout\ : std_logic;
SIGNAL \inst5|ALT_INV_Add0~25_sumout\ : std_logic;
SIGNAL \inst5|ALT_INV_Add0~21_sumout\ : std_logic;
SIGNAL \inst5|ALT_INV_Add0~17_sumout\ : std_logic;
SIGNAL \inst5|ALT_INV_Add0~13_sumout\ : std_logic;
SIGNAL \inst5|ALT_INV_Add0~9_sumout\ : std_logic;
SIGNAL \inst5|ALT_INV_Add0~5_sumout\ : std_logic;
SIGNAL \inst5|ALT_INV_Add0~1_sumout\ : std_logic;
SIGNAL \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\ : std_logic_vector(7 DOWNTO 0);

BEGIN

HEX0 <= ww_HEX0;
ww_CLOCK_50 <= CLOCK_50;
ww_SW <= SW;
ww_KEY <= KEY;
HEX1 <= ww_HEX1;
HEX2 <= ww_HEX2;
HEX3 <= ww_HEX3;
HEX4 <= ww_HEX4;
HEX5 <= ww_HEX5;
LEDR <= ww_LEDR;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAIN_bus\ <= (gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & \inst7|ac_r\(7) & \inst7|ac_r\(6) & \inst7|ac_r\(5) & \inst7|ac_r\(4) & \inst7|ac_r\(3) & 
\inst7|ac_r[2]~DUPLICATE_q\ & \inst7|ac_r\(1) & \inst7|ac_r\(0));

\inst4|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\ <= (\inst2|r\(7) & \inst2|r\(6) & \inst2|r\(5) & \inst2|r\(4) & \inst2|r\(3) & \inst2|r\(2) & \inst2|r\(1) & \inst2|r\(0));

\inst4|altsyncram_component|auto_generated|q_a\(0) <= \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(0);
\inst4|altsyncram_component|auto_generated|q_a\(1) <= \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(1);
\inst4|altsyncram_component|auto_generated|q_a\(2) <= \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(2);
\inst4|altsyncram_component|auto_generated|q_a\(3) <= \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(3);
\inst4|altsyncram_component|auto_generated|q_a\(4) <= \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(4);
\inst4|altsyncram_component|auto_generated|q_a\(5) <= \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(5);
\inst4|altsyncram_component|auto_generated|q_a\(6) <= \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(6);
\inst4|altsyncram_component|auto_generated|q_a\(7) <= \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(7);

\inst1|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\ <= (\inst|pc_r\(7) & \inst|pc_r\(6) & \inst|pc_r\(5) & \inst|pc_r\(4) & \inst|pc_r[3]~DUPLICATE_q\ & \inst|pc_r\(2) & \inst|pc_r\(1) & \inst|pc_r\(0));

\inst2|r\(0) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(0);
\inst2|r\(1) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(1);
\inst2|r\(2) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(2);
\inst2|r\(3) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(3);
\inst2|r\(4) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(4);
\inst2|r\(5) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(5);
\inst2|r\(6) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(6);
\inst2|r\(7) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(7);
\inst2|r\(28) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(8);
\inst2|r\(29) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(9);
\inst2|r\(30) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(10);
\inst2|r\(31) <= \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(11);
\inst7|ALT_INV_ac_r[2]~DUPLICATE_q\ <= NOT \inst7|ac_r[2]~DUPLICATE_q\;
\inst|ALT_INV_pc_r[6]~DUPLICATE_q\ <= NOT \inst|pc_r[6]~DUPLICATE_q\;
\inst|ALT_INV_pc_r[7]~DUPLICATE_q\ <= NOT \inst|pc_r[7]~DUPLICATE_q\;
\ALT_INV_SW[9]~input_o\ <= NOT \SW[9]~input_o\;
\ALT_INV_CLOCK_50~input_o\ <= NOT \CLOCK_50~input_o\;
\ALT_INV_KEY[0]~input_o\ <= NOT \KEY[0]~input_o\;
\inst15|ALT_INV_div_cnt\(0) <= NOT \inst15|div_cnt\(0);
\inst15|ALT_INV_div_cnt\(1) <= NOT \inst15|div_cnt\(1);
\inst15|ALT_INV_div_cnt\(2) <= NOT \inst15|div_cnt\(2);
\inst15|ALT_INV_div_cnt\(3) <= NOT \inst15|div_cnt\(3);
\inst15|ALT_INV_div_cnt\(4) <= NOT \inst15|div_cnt\(4);
\inst15|ALT_INV_div_cnt\(5) <= NOT \inst15|div_cnt\(5);
\inst15|ALT_INV_div_cnt\(6) <= NOT \inst15|div_cnt\(6);
\inst15|ALT_INV_div_cnt\(7) <= NOT \inst15|div_cnt\(7);
\inst15|ALT_INV_div_cnt\(8) <= NOT \inst15|div_cnt\(8);
\inst15|ALT_INV_div_cnt\(9) <= NOT \inst15|div_cnt\(9);
\inst15|ALT_INV_div_cnt\(10) <= NOT \inst15|div_cnt\(10);
\inst15|ALT_INV_div_cnt\(11) <= NOT \inst15|div_cnt\(11);
\inst15|ALT_INV_div_cnt\(12) <= NOT \inst15|div_cnt\(12);
\inst15|ALT_INV_div_cnt\(13) <= NOT \inst15|div_cnt\(13);
\inst15|ALT_INV_div_cnt\(14) <= NOT \inst15|div_cnt\(14);
\inst15|ALT_INV_div_cnt\(15) <= NOT \inst15|div_cnt\(15);
\inst15|ALT_INV_div_cnt\(16) <= NOT \inst15|div_cnt\(16);
\inst15|ALT_INV_div_cnt\(17) <= NOT \inst15|div_cnt\(17);
\inst15|ALT_INV_div_cnt\(18) <= NOT \inst15|div_cnt\(18);
\inst15|ALT_INV_div_cnt\(19) <= NOT \inst15|div_cnt\(19);
\inst15|ALT_INV_div_cnt\(20) <= NOT \inst15|div_cnt\(20);
\inst15|ALT_INV_div_cnt\(21) <= NOT \inst15|div_cnt\(21);
\inst15|ALT_INV_div_cnt\(22) <= NOT \inst15|div_cnt\(22);
\inst15|ALT_INV_div_cnt\(23) <= NOT \inst15|div_cnt\(23);
\inst15|ALT_INV_div_cnt\(24) <= NOT \inst15|div_cnt\(24);
\inst15|ALT_INV_clk_cpu~combout\ <= NOT \inst15|clk_cpu~combout\;
\inst15|ALT_INV_div_cnt\(25) <= NOT \inst15|div_cnt\(25);
\inst13|ALT_INV_Mux0~0_combout\ <= NOT \inst13|Mux0~0_combout\;
\inst5|ALT_INV_Mux0~0_combout\ <= NOT \inst5|Mux0~0_combout\;
\inst5|ALT_INV_Mux1~0_combout\ <= NOT \inst5|Mux1~0_combout\;
\inst5|ALT_INV_Mux2~0_combout\ <= NOT \inst5|Mux2~0_combout\;
\inst5|ALT_INV_Mux3~0_combout\ <= NOT \inst5|Mux3~0_combout\;
\inst12|ALT_INV_Mux0~0_combout\ <= NOT \inst12|Mux0~0_combout\;
\inst5|ALT_INV_Mux4~1_combout\ <= NOT \inst5|Mux4~1_combout\;
\inst5|ALT_INV_Mux5~0_combout\ <= NOT \inst5|Mux5~0_combout\;
\inst5|ALT_INV_Mux6~0_combout\ <= NOT \inst5|Mux6~0_combout\;
\inst5|ALT_INV_Mux7~0_combout\ <= NOT \inst5|Mux7~0_combout\;
\inst5|ALT_INV_Mux4~0_combout\ <= NOT \inst5|Mux4~0_combout\;
\inst3|ALT_INV_Mux4~0_combout\ <= NOT \inst3|Mux4~0_combout\;
\inst3|ALT_INV_Mux2~0_combout\ <= NOT \inst3|Mux2~0_combout\;
\inst10|ALT_INV_Mux0~0_combout\ <= NOT \inst10|Mux0~0_combout\;
\inst9|ALT_INV_Mux0~0_combout\ <= NOT \inst9|Mux0~0_combout\;
\inst8|ALT_INV_Mux0~0_combout\ <= NOT \inst8|Mux0~0_combout\;
\inst7|ALT_INV_ac_r\(7) <= NOT \inst7|ac_r\(7);
\inst7|ALT_INV_ac_r\(6) <= NOT \inst7|ac_r\(6);
\inst7|ALT_INV_ac_r\(5) <= NOT \inst7|ac_r\(5);
\inst7|ALT_INV_ac_r\(4) <= NOT \inst7|ac_r\(4);
\inst11|ALT_INV_Mux0~0_combout\ <= NOT \inst11|Mux0~0_combout\;
\inst7|ALT_INV_ac_r\(3) <= NOT \inst7|ac_r\(3);
\inst7|ALT_INV_ac_r\(2) <= NOT \inst7|ac_r\(2);
\inst7|ALT_INV_ac_r\(1) <= NOT \inst7|ac_r\(1);
\inst7|ALT_INV_ac_r\(0) <= NOT \inst7|ac_r\(0);
\inst15|ALT_INV_Add0~97_sumout\ <= NOT \inst15|Add0~97_sumout\;
\inst2|ALT_INV_r\(28) <= NOT \inst2|r\(28);
\inst2|ALT_INV_r\(29) <= NOT \inst2|r\(29);
\inst2|ALT_INV_r\(30) <= NOT \inst2|r\(30);
\inst2|ALT_INV_r\(31) <= NOT \inst2|r\(31);
\inst|ALT_INV_Add0~29_sumout\ <= NOT \inst|Add0~29_sumout\;
\inst|ALT_INV_Add0~25_sumout\ <= NOT \inst|Add0~25_sumout\;
\inst|ALT_INV_Add0~21_sumout\ <= NOT \inst|Add0~21_sumout\;
\inst|ALT_INV_Add0~17_sumout\ <= NOT \inst|Add0~17_sumout\;
\inst|ALT_INV_Add0~13_sumout\ <= NOT \inst|Add0~13_sumout\;
\inst|ALT_INV_Add0~9_sumout\ <= NOT \inst|Add0~9_sumout\;
\inst|ALT_INV_Add0~5_sumout\ <= NOT \inst|Add0~5_sumout\;
\inst|ALT_INV_Add0~1_sumout\ <= NOT \inst|Add0~1_sumout\;
\inst|ALT_INV_pc_r\(0) <= NOT \inst|pc_r\(0);
\inst|ALT_INV_pc_r\(1) <= NOT \inst|pc_r\(1);
\inst|ALT_INV_pc_r\(2) <= NOT \inst|pc_r\(2);
\inst|ALT_INV_pc_r\(3) <= NOT \inst|pc_r\(3);
\inst|ALT_INV_pc_r\(4) <= NOT \inst|pc_r\(4);
\inst|ALT_INV_pc_r\(5) <= NOT \inst|pc_r\(5);
\inst5|ALT_INV_Add0~29_sumout\ <= NOT \inst5|Add0~29_sumout\;
\inst5|ALT_INV_Add0~25_sumout\ <= NOT \inst5|Add0~25_sumout\;
\inst5|ALT_INV_Add0~21_sumout\ <= NOT \inst5|Add0~21_sumout\;
\inst5|ALT_INV_Add0~17_sumout\ <= NOT \inst5|Add0~17_sumout\;
\inst5|ALT_INV_Add0~13_sumout\ <= NOT \inst5|Add0~13_sumout\;
\inst5|ALT_INV_Add0~9_sumout\ <= NOT \inst5|Add0~9_sumout\;
\inst5|ALT_INV_Add0~5_sumout\ <= NOT \inst5|Add0~5_sumout\;
\inst5|ALT_INV_Add0~1_sumout\ <= NOT \inst5|Add0~1_sumout\;
\inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(1) <= NOT \inst4|altsyncram_component|auto_generated|q_a\(1);
\inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(2) <= NOT \inst4|altsyncram_component|auto_generated|q_a\(2);
\inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(3) <= NOT \inst4|altsyncram_component|auto_generated|q_a\(3);
\inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(4) <= NOT \inst4|altsyncram_component|auto_generated|q_a\(4);
\inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(5) <= NOT \inst4|altsyncram_component|auto_generated|q_a\(5);
\inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(6) <= NOT \inst4|altsyncram_component|auto_generated|q_a\(6);
\inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(7) <= NOT \inst4|altsyncram_component|auto_generated|q_a\(7);
\inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(0) <= NOT \inst4|altsyncram_component|auto_generated|q_a\(0);

-- Location: IOOBUF_X89_Y4_N96
\HEX0[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|ALT_INV_Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX0(6));

-- Location: IOOBUF_X89_Y13_N39
\HEX0[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX0(5));

-- Location: IOOBUF_X89_Y13_N56
\HEX0[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX0(4));

-- Location: IOOBUF_X89_Y4_N79
\HEX0[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX0(3));

-- Location: IOOBUF_X89_Y11_N96
\HEX0[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX0(2));

-- Location: IOOBUF_X89_Y11_N79
\HEX0[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX0(1));

-- Location: IOOBUF_X89_Y8_N39
\HEX0[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX0(0));

-- Location: IOOBUF_X89_Y8_N56
\HEX1[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|ALT_INV_Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX1(6));

-- Location: IOOBUF_X89_Y15_N56
\HEX1[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX1(5));

-- Location: IOOBUF_X89_Y15_N39
\HEX1[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX1(4));

-- Location: IOOBUF_X89_Y16_N56
\HEX1[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX1(3));

-- Location: IOOBUF_X89_Y16_N39
\HEX1[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX1(2));

-- Location: IOOBUF_X89_Y6_N56
\HEX1[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX1(1));

-- Location: IOOBUF_X89_Y6_N39
\HEX1[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX1(0));

-- Location: IOOBUF_X89_Y25_N56
\HEX2[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|ALT_INV_Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX2(6));

-- Location: IOOBUF_X89_Y20_N96
\HEX2[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX2(5));

-- Location: IOOBUF_X89_Y25_N39
\HEX2[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX2(4));

-- Location: IOOBUF_X89_Y20_N79
\HEX2[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX2(3));

-- Location: IOOBUF_X89_Y23_N56
\HEX2[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX2(2));

-- Location: IOOBUF_X89_Y23_N39
\HEX2[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX2(1));

-- Location: IOOBUF_X89_Y9_N22
\HEX2[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX2(0));

-- Location: IOOBUF_X89_Y9_N5
\HEX3[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst10|ALT_INV_Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX3(6));

-- Location: IOOBUF_X89_Y11_N62
\HEX3[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst10|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX3(5));

-- Location: IOOBUF_X89_Y21_N39
\HEX3[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst10|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX3(4));

-- Location: IOOBUF_X89_Y4_N62
\HEX3[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst10|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX3(3));

-- Location: IOOBUF_X89_Y4_N45
\HEX3[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst10|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX3(2));

-- Location: IOOBUF_X89_Y16_N22
\HEX3[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst10|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX3(1));

-- Location: IOOBUF_X89_Y16_N5
\HEX3[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst10|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX3(0));

-- Location: IOOBUF_X89_Y20_N45
\HEX4[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst12|ALT_INV_Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX4(6));

-- Location: IOOBUF_X89_Y15_N5
\HEX4[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst12|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX4(5));

-- Location: IOOBUF_X89_Y15_N22
\HEX4[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst12|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX4(4));

-- Location: IOOBUF_X89_Y8_N22
\HEX4[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst12|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX4(3));

-- Location: IOOBUF_X89_Y13_N22
\HEX4[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst12|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX4(2));

-- Location: IOOBUF_X89_Y13_N5
\HEX4[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst12|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX4(1));

-- Location: IOOBUF_X89_Y11_N45
\HEX4[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst12|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX4(0));

-- Location: IOOBUF_X89_Y9_N39
\HEX5[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|ALT_INV_Mux0~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX5(6));

-- Location: IOOBUF_X89_Y23_N5
\HEX5[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|Mux1~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX5(5));

-- Location: IOOBUF_X89_Y9_N56
\HEX5[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|Mux2~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX5(4));

-- Location: IOOBUF_X89_Y23_N22
\HEX5[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|Mux3~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX5(3));

-- Location: IOOBUF_X89_Y25_N22
\HEX5[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|Mux4~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX5(2));

-- Location: IOOBUF_X89_Y21_N56
\HEX5[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|Mux5~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX5(1));

-- Location: IOOBUF_X89_Y20_N62
\HEX5[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|Mux6~0_combout\,
	devoe => ww_devoe,
	o => ww_HEX5(0));

-- Location: IOOBUF_X89_Y6_N22
\LEDR[9]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|r\(29),
	devoe => ww_devoe,
	o => ww_LEDR(9));

-- Location: IOOBUF_X89_Y8_N5
\LEDR[8]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|r\(28),
	devoe => ww_devoe,
	o => ww_LEDR(8));

-- Location: IOOBUF_X89_Y6_N5
\LEDR[7]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|pc_r\(7),
	devoe => ww_devoe,
	o => ww_LEDR(7));

-- Location: IOOBUF_X84_Y0_N2
\LEDR[6]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|pc_r\(6),
	devoe => ww_devoe,
	o => ww_LEDR(6));

-- Location: IOOBUF_X80_Y0_N19
\LEDR[5]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|pc_r\(5),
	devoe => ww_devoe,
	o => ww_LEDR(5));

-- Location: IOOBUF_X60_Y0_N19
\LEDR[4]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|pc_r\(4),
	devoe => ww_devoe,
	o => ww_LEDR(4));

-- Location: IOOBUF_X80_Y0_N2
\LEDR[3]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|pc_r[3]~DUPLICATE_q\,
	devoe => ww_devoe,
	o => ww_LEDR(3));

-- Location: IOOBUF_X60_Y0_N2
\LEDR[2]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|pc_r\(2),
	devoe => ww_devoe,
	o => ww_LEDR(2));

-- Location: IOOBUF_X52_Y0_N19
\LEDR[1]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|pc_r\(1),
	devoe => ww_devoe,
	o => ww_LEDR(1));

-- Location: IOOBUF_X52_Y0_N2
\LEDR[0]~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|pc_r\(0),
	devoe => ww_devoe,
	o => ww_LEDR(0));

-- Location: IOIBUF_X2_Y0_N58
\SW[9]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(9),
	o => \SW[9]~input_o\);

-- Location: IOIBUF_X32_Y0_N1
\CLOCK_50~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLOCK_50,
	o => \CLOCK_50~input_o\);

-- Location: CLKCTRL_G6
\CLOCK_50~inputCLKENA0\ : cyclonev_clkena
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	disable_mode => "low",
	ena_register_mode => "always enabled",
	ena_register_power_up => "high",
	test_syn => "high")
-- pragma translate_on
PORT MAP (
	inclk => \CLOCK_50~input_o\,
	outclk => \CLOCK_50~inputCLKENA0_outclk\);

-- Location: LABCELL_X77_Y8_N21
\inst15|div_cnt[0]~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|div_cnt[0]~0_combout\ = ( !\inst15|div_cnt\(0) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111000000000000000011111111111111110000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datae => \inst15|ALT_INV_div_cnt\(0),
	combout => \inst15|div_cnt[0]~0_combout\);

-- Location: FF_X77_Y8_N23
\inst15|div_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|div_cnt[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(0));

-- Location: LABCELL_X77_Y8_N30
\inst15|Add0~97\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~97_sumout\ = SUM(( \inst15|div_cnt\(1) ) + ( \inst15|div_cnt\(0) ) + ( !VCC ))
-- \inst15|Add0~98\ = CARRY(( \inst15|div_cnt\(1) ) + ( \inst15|div_cnt\(0) ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst15|ALT_INV_div_cnt\(0),
	datad => \inst15|ALT_INV_div_cnt\(1),
	cin => GND,
	sumout => \inst15|Add0~97_sumout\,
	cout => \inst15|Add0~98\);

-- Location: LABCELL_X77_Y8_N0
\inst15|div_cnt[1]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|div_cnt[1]~feeder_combout\ = \inst15|Add0~97_sumout\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_Add0~97_sumout\,
	combout => \inst15|div_cnt[1]~feeder_combout\);

-- Location: FF_X77_Y8_N2
\inst15|div_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|div_cnt[1]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(1));

-- Location: LABCELL_X77_Y8_N33
\inst15|Add0~93\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~93_sumout\ = SUM(( \inst15|div_cnt\(2) ) + ( GND ) + ( \inst15|Add0~98\ ))
-- \inst15|Add0~94\ = CARRY(( \inst15|div_cnt\(2) ) + ( GND ) + ( \inst15|Add0~98\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst15|ALT_INV_div_cnt\(2),
	cin => \inst15|Add0~98\,
	sumout => \inst15|Add0~93_sumout\,
	cout => \inst15|Add0~94\);

-- Location: FF_X77_Y8_N35
\inst15|div_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~93_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(2));

-- Location: LABCELL_X77_Y8_N36
\inst15|Add0~89\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~89_sumout\ = SUM(( \inst15|div_cnt\(3) ) + ( GND ) + ( \inst15|Add0~94\ ))
-- \inst15|Add0~90\ = CARRY(( \inst15|div_cnt\(3) ) + ( GND ) + ( \inst15|Add0~94\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst15|ALT_INV_div_cnt\(3),
	cin => \inst15|Add0~94\,
	sumout => \inst15|Add0~89_sumout\,
	cout => \inst15|Add0~90\);

-- Location: FF_X77_Y8_N38
\inst15|div_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~89_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(3));

-- Location: LABCELL_X77_Y8_N39
\inst15|Add0~85\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~85_sumout\ = SUM(( \inst15|div_cnt\(4) ) + ( GND ) + ( \inst15|Add0~90\ ))
-- \inst15|Add0~86\ = CARRY(( \inst15|div_cnt\(4) ) + ( GND ) + ( \inst15|Add0~90\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst15|ALT_INV_div_cnt\(4),
	cin => \inst15|Add0~90\,
	sumout => \inst15|Add0~85_sumout\,
	cout => \inst15|Add0~86\);

-- Location: FF_X77_Y8_N40
\inst15|div_cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~85_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(4));

-- Location: LABCELL_X77_Y8_N42
\inst15|Add0~81\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~81_sumout\ = SUM(( \inst15|div_cnt\(5) ) + ( GND ) + ( \inst15|Add0~86\ ))
-- \inst15|Add0~82\ = CARRY(( \inst15|div_cnt\(5) ) + ( GND ) + ( \inst15|Add0~86\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_div_cnt\(5),
	cin => \inst15|Add0~86\,
	sumout => \inst15|Add0~81_sumout\,
	cout => \inst15|Add0~82\);

-- Location: FF_X77_Y8_N44
\inst15|div_cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~81_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(5));

-- Location: LABCELL_X77_Y8_N45
\inst15|Add0~77\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~77_sumout\ = SUM(( \inst15|div_cnt\(6) ) + ( GND ) + ( \inst15|Add0~82\ ))
-- \inst15|Add0~78\ = CARRY(( \inst15|div_cnt\(6) ) + ( GND ) + ( \inst15|Add0~82\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst15|ALT_INV_div_cnt\(6),
	cin => \inst15|Add0~82\,
	sumout => \inst15|Add0~77_sumout\,
	cout => \inst15|Add0~78\);

-- Location: FF_X77_Y8_N46
\inst15|div_cnt[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~77_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(6));

-- Location: LABCELL_X77_Y8_N48
\inst15|Add0~73\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~73_sumout\ = SUM(( \inst15|div_cnt\(7) ) + ( GND ) + ( \inst15|Add0~78\ ))
-- \inst15|Add0~74\ = CARRY(( \inst15|div_cnt\(7) ) + ( GND ) + ( \inst15|Add0~78\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_div_cnt\(7),
	cin => \inst15|Add0~78\,
	sumout => \inst15|Add0~73_sumout\,
	cout => \inst15|Add0~74\);

-- Location: FF_X77_Y8_N49
\inst15|div_cnt[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~73_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(7));

-- Location: LABCELL_X77_Y8_N51
\inst15|Add0~69\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~69_sumout\ = SUM(( \inst15|div_cnt\(8) ) + ( GND ) + ( \inst15|Add0~74\ ))
-- \inst15|Add0~70\ = CARRY(( \inst15|div_cnt\(8) ) + ( GND ) + ( \inst15|Add0~74\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst15|ALT_INV_div_cnt\(8),
	cin => \inst15|Add0~74\,
	sumout => \inst15|Add0~69_sumout\,
	cout => \inst15|Add0~70\);

-- Location: FF_X77_Y8_N53
\inst15|div_cnt[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~69_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(8));

-- Location: LABCELL_X77_Y8_N54
\inst15|Add0~65\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~65_sumout\ = SUM(( \inst15|div_cnt\(9) ) + ( GND ) + ( \inst15|Add0~70\ ))
-- \inst15|Add0~66\ = CARRY(( \inst15|div_cnt\(9) ) + ( GND ) + ( \inst15|Add0~70\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst15|ALT_INV_div_cnt\(9),
	cin => \inst15|Add0~70\,
	sumout => \inst15|Add0~65_sumout\,
	cout => \inst15|Add0~66\);

-- Location: FF_X77_Y8_N56
\inst15|div_cnt[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~65_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(9));

-- Location: LABCELL_X77_Y8_N57
\inst15|Add0~61\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~61_sumout\ = SUM(( \inst15|div_cnt\(10) ) + ( GND ) + ( \inst15|Add0~66\ ))
-- \inst15|Add0~62\ = CARRY(( \inst15|div_cnt\(10) ) + ( GND ) + ( \inst15|Add0~66\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_div_cnt\(10),
	cin => \inst15|Add0~66\,
	sumout => \inst15|Add0~61_sumout\,
	cout => \inst15|Add0~62\);

-- Location: FF_X77_Y8_N59
\inst15|div_cnt[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~61_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(10));

-- Location: LABCELL_X77_Y7_N0
\inst15|Add0~57\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~57_sumout\ = SUM(( \inst15|div_cnt\(11) ) + ( GND ) + ( \inst15|Add0~62\ ))
-- \inst15|Add0~58\ = CARRY(( \inst15|div_cnt\(11) ) + ( GND ) + ( \inst15|Add0~62\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst15|ALT_INV_div_cnt\(11),
	cin => \inst15|Add0~62\,
	sumout => \inst15|Add0~57_sumout\,
	cout => \inst15|Add0~58\);

-- Location: FF_X77_Y7_N1
\inst15|div_cnt[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~57_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(11));

-- Location: LABCELL_X77_Y7_N3
\inst15|Add0~53\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~53_sumout\ = SUM(( \inst15|div_cnt\(12) ) + ( GND ) + ( \inst15|Add0~58\ ))
-- \inst15|Add0~54\ = CARRY(( \inst15|div_cnt\(12) ) + ( GND ) + ( \inst15|Add0~58\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst15|ALT_INV_div_cnt\(12),
	cin => \inst15|Add0~58\,
	sumout => \inst15|Add0~53_sumout\,
	cout => \inst15|Add0~54\);

-- Location: FF_X77_Y7_N5
\inst15|div_cnt[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~53_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(12));

-- Location: LABCELL_X77_Y7_N6
\inst15|Add0~49\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~49_sumout\ = SUM(( \inst15|div_cnt\(13) ) + ( GND ) + ( \inst15|Add0~54\ ))
-- \inst15|Add0~50\ = CARRY(( \inst15|div_cnt\(13) ) + ( GND ) + ( \inst15|Add0~54\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_div_cnt\(13),
	cin => \inst15|Add0~54\,
	sumout => \inst15|Add0~49_sumout\,
	cout => \inst15|Add0~50\);

-- Location: FF_X77_Y7_N8
\inst15|div_cnt[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~49_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(13));

-- Location: LABCELL_X77_Y7_N9
\inst15|Add0~45\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~45_sumout\ = SUM(( \inst15|div_cnt\(14) ) + ( GND ) + ( \inst15|Add0~50\ ))
-- \inst15|Add0~46\ = CARRY(( \inst15|div_cnt\(14) ) + ( GND ) + ( \inst15|Add0~50\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst15|ALT_INV_div_cnt\(14),
	cin => \inst15|Add0~50\,
	sumout => \inst15|Add0~45_sumout\,
	cout => \inst15|Add0~46\);

-- Location: FF_X77_Y7_N10
\inst15|div_cnt[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~45_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(14));

-- Location: LABCELL_X77_Y7_N12
\inst15|Add0~41\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~41_sumout\ = SUM(( \inst15|div_cnt\(15) ) + ( GND ) + ( \inst15|Add0~46\ ))
-- \inst15|Add0~42\ = CARRY(( \inst15|div_cnt\(15) ) + ( GND ) + ( \inst15|Add0~46\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_div_cnt\(15),
	cin => \inst15|Add0~46\,
	sumout => \inst15|Add0~41_sumout\,
	cout => \inst15|Add0~42\);

-- Location: FF_X77_Y7_N14
\inst15|div_cnt[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~41_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(15));

-- Location: LABCELL_X77_Y7_N15
\inst15|Add0~37\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~37_sumout\ = SUM(( \inst15|div_cnt\(16) ) + ( GND ) + ( \inst15|Add0~42\ ))
-- \inst15|Add0~38\ = CARRY(( \inst15|div_cnt\(16) ) + ( GND ) + ( \inst15|Add0~42\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst15|ALT_INV_div_cnt\(16),
	cin => \inst15|Add0~42\,
	sumout => \inst15|Add0~37_sumout\,
	cout => \inst15|Add0~38\);

-- Location: FF_X77_Y7_N16
\inst15|div_cnt[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~37_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(16));

-- Location: LABCELL_X77_Y7_N18
\inst15|Add0~33\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~33_sumout\ = SUM(( \inst15|div_cnt\(17) ) + ( GND ) + ( \inst15|Add0~38\ ))
-- \inst15|Add0~34\ = CARRY(( \inst15|div_cnt\(17) ) + ( GND ) + ( \inst15|Add0~38\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_div_cnt\(17),
	cin => \inst15|Add0~38\,
	sumout => \inst15|Add0~33_sumout\,
	cout => \inst15|Add0~34\);

-- Location: FF_X77_Y7_N19
\inst15|div_cnt[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~33_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(17));

-- Location: LABCELL_X77_Y7_N21
\inst15|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~29_sumout\ = SUM(( \inst15|div_cnt\(18) ) + ( GND ) + ( \inst15|Add0~34\ ))
-- \inst15|Add0~30\ = CARRY(( \inst15|div_cnt\(18) ) + ( GND ) + ( \inst15|Add0~34\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst15|ALT_INV_div_cnt\(18),
	cin => \inst15|Add0~34\,
	sumout => \inst15|Add0~29_sumout\,
	cout => \inst15|Add0~30\);

-- Location: FF_X77_Y7_N23
\inst15|div_cnt[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~29_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(18));

-- Location: LABCELL_X77_Y7_N24
\inst15|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~25_sumout\ = SUM(( \inst15|div_cnt\(19) ) + ( GND ) + ( \inst15|Add0~30\ ))
-- \inst15|Add0~26\ = CARRY(( \inst15|div_cnt\(19) ) + ( GND ) + ( \inst15|Add0~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_div_cnt\(19),
	cin => \inst15|Add0~30\,
	sumout => \inst15|Add0~25_sumout\,
	cout => \inst15|Add0~26\);

-- Location: FF_X77_Y7_N25
\inst15|div_cnt[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~25_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(19));

-- Location: LABCELL_X77_Y7_N27
\inst15|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~21_sumout\ = SUM(( \inst15|div_cnt\(20) ) + ( GND ) + ( \inst15|Add0~26\ ))
-- \inst15|Add0~22\ = CARRY(( \inst15|div_cnt\(20) ) + ( GND ) + ( \inst15|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst15|ALT_INV_div_cnt\(20),
	cin => \inst15|Add0~26\,
	sumout => \inst15|Add0~21_sumout\,
	cout => \inst15|Add0~22\);

-- Location: FF_X77_Y7_N29
\inst15|div_cnt[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~21_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(20));

-- Location: LABCELL_X77_Y7_N30
\inst15|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~17_sumout\ = SUM(( \inst15|div_cnt\(21) ) + ( GND ) + ( \inst15|Add0~22\ ))
-- \inst15|Add0~18\ = CARRY(( \inst15|div_cnt\(21) ) + ( GND ) + ( \inst15|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_div_cnt\(21),
	cin => \inst15|Add0~22\,
	sumout => \inst15|Add0~17_sumout\,
	cout => \inst15|Add0~18\);

-- Location: FF_X77_Y7_N32
\inst15|div_cnt[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~17_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(21));

-- Location: LABCELL_X77_Y7_N33
\inst15|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~13_sumout\ = SUM(( \inst15|div_cnt\(22) ) + ( GND ) + ( \inst15|Add0~18\ ))
-- \inst15|Add0~14\ = CARRY(( \inst15|div_cnt\(22) ) + ( GND ) + ( \inst15|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst15|ALT_INV_div_cnt\(22),
	cin => \inst15|Add0~18\,
	sumout => \inst15|Add0~13_sumout\,
	cout => \inst15|Add0~14\);

-- Location: FF_X77_Y7_N35
\inst15|div_cnt[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~13_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(22));

-- Location: LABCELL_X77_Y7_N36
\inst15|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~9_sumout\ = SUM(( \inst15|div_cnt\(23) ) + ( GND ) + ( \inst15|Add0~14\ ))
-- \inst15|Add0~10\ = CARRY(( \inst15|div_cnt\(23) ) + ( GND ) + ( \inst15|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst15|ALT_INV_div_cnt\(23),
	cin => \inst15|Add0~14\,
	sumout => \inst15|Add0~9_sumout\,
	cout => \inst15|Add0~10\);

-- Location: FF_X77_Y7_N38
\inst15|div_cnt[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~9_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(23));

-- Location: LABCELL_X77_Y7_N39
\inst15|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~5_sumout\ = SUM(( \inst15|div_cnt\(24) ) + ( GND ) + ( \inst15|Add0~10\ ))
-- \inst15|Add0~6\ = CARRY(( \inst15|div_cnt\(24) ) + ( GND ) + ( \inst15|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_div_cnt\(24),
	cin => \inst15|Add0~10\,
	sumout => \inst15|Add0~5_sumout\,
	cout => \inst15|Add0~6\);

-- Location: FF_X77_Y7_N40
\inst15|div_cnt[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~5_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(24));

-- Location: LABCELL_X77_Y7_N42
\inst15|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|Add0~1_sumout\ = SUM(( \inst15|div_cnt\(25) ) + ( GND ) + ( \inst15|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst15|ALT_INV_div_cnt\(25),
	cin => \inst15|Add0~6\,
	sumout => \inst15|Add0~1_sumout\);

-- Location: FF_X77_Y7_N44
\inst15|div_cnt[25]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLOCK_50~inputCLKENA0_outclk\,
	d => \inst15|Add0~1_sumout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst15|div_cnt\(25));

-- Location: LABCELL_X77_Y7_N54
\inst15|clk_cpu\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst15|clk_cpu~combout\ = LCELL(( \CLOCK_50~input_o\ & ( \inst15|div_cnt\(25) ) ) # ( !\CLOCK_50~input_o\ & ( \inst15|div_cnt\(25) & ( !\SW[9]~input_o\ ) ) ) # ( \CLOCK_50~input_o\ & ( !\inst15|div_cnt\(25) & ( \SW[9]~input_o\ ) ) ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000001100110011001111001100110011001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_SW[9]~input_o\,
	datae => \ALT_INV_CLOCK_50~input_o\,
	dataf => \inst15|ALT_INV_div_cnt\(25),
	combout => \inst15|clk_cpu~combout\);

-- Location: IOIBUF_X36_Y0_N1
\KEY[0]~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_KEY(0),
	o => \KEY[0]~input_o\);

-- Location: MLABCELL_X78_Y7_N30
\inst|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|Add0~29_sumout\ = SUM(( \inst|pc_r\(0) ) + ( VCC ) + ( !VCC ))
-- \inst|Add0~30\ = CARRY(( \inst|pc_r\(0) ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst|ALT_INV_pc_r\(0),
	cin => GND,
	sumout => \inst|Add0~29_sumout\,
	cout => \inst|Add0~30\);

-- Location: MLABCELL_X78_Y7_N12
\inst|pc_r[0]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|pc_r[0]~feeder_combout\ = ( \inst|Add0~29_sumout\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst|ALT_INV_Add0~29_sumout\,
	combout => \inst|pc_r[0]~feeder_combout\);

-- Location: MLABCELL_X78_Y7_N33
\inst|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|Add0~25_sumout\ = SUM(( \inst|pc_r\(1) ) + ( GND ) + ( \inst|Add0~30\ ))
-- \inst|Add0~26\ = CARRY(( \inst|pc_r\(1) ) + ( GND ) + ( \inst|Add0~30\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst|ALT_INV_pc_r\(1),
	cin => \inst|Add0~30\,
	sumout => \inst|Add0~25_sumout\,
	cout => \inst|Add0~26\);

-- Location: MLABCELL_X78_Y7_N24
\inst|pc_r[1]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|pc_r[1]~feeder_combout\ = \inst|Add0~25_sumout\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst|ALT_INV_Add0~25_sumout\,
	combout => \inst|pc_r[1]~feeder_combout\);

-- Location: MLABCELL_X78_Y7_N36
\inst|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|Add0~21_sumout\ = SUM(( \inst|pc_r\(2) ) + ( GND ) + ( \inst|Add0~26\ ))
-- \inst|Add0~22\ = CARRY(( \inst|pc_r\(2) ) + ( GND ) + ( \inst|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst|ALT_INV_pc_r\(2),
	cin => \inst|Add0~26\,
	sumout => \inst|Add0~21_sumout\,
	cout => \inst|Add0~22\);

-- Location: MLABCELL_X78_Y7_N54
\inst|pc_r[2]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|pc_r[2]~feeder_combout\ = \inst|Add0~21_sumout\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst|ALT_INV_Add0~21_sumout\,
	combout => \inst|pc_r[2]~feeder_combout\);

-- Location: MLABCELL_X78_Y7_N39
\inst|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|Add0~17_sumout\ = SUM(( \inst|pc_r\(3) ) + ( GND ) + ( \inst|Add0~22\ ))
-- \inst|Add0~18\ = CARRY(( \inst|pc_r\(3) ) + ( GND ) + ( \inst|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_pc_r\(3),
	cin => \inst|Add0~22\,
	sumout => \inst|Add0~17_sumout\,
	cout => \inst|Add0~18\);

-- Location: MLABCELL_X78_Y7_N42
\inst|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|Add0~13_sumout\ = SUM(( \inst|pc_r\(4) ) + ( GND ) + ( \inst|Add0~18\ ))
-- \inst|Add0~14\ = CARRY(( \inst|pc_r\(4) ) + ( GND ) + ( \inst|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst|ALT_INV_pc_r\(4),
	cin => \inst|Add0~18\,
	sumout => \inst|Add0~13_sumout\,
	cout => \inst|Add0~14\);

-- Location: MLABCELL_X78_Y7_N18
\inst|pc_r[4]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|pc_r[4]~feeder_combout\ = \inst|Add0~13_sumout\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011001100110011001100110011001100110011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst|ALT_INV_Add0~13_sumout\,
	combout => \inst|pc_r[4]~feeder_combout\);

-- Location: MLABCELL_X78_Y7_N45
\inst|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|Add0~9_sumout\ = SUM(( \inst|pc_r\(5) ) + ( GND ) + ( \inst|Add0~14\ ))
-- \inst|Add0~10\ = CARRY(( \inst|pc_r\(5) ) + ( GND ) + ( \inst|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_pc_r\(5),
	cin => \inst|Add0~14\,
	sumout => \inst|Add0~9_sumout\,
	cout => \inst|Add0~10\);

-- Location: MLABCELL_X78_Y7_N27
\inst|pc_r[5]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|pc_r[5]~feeder_combout\ = \inst|Add0~9_sumout\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst|ALT_INV_Add0~9_sumout\,
	combout => \inst|pc_r[5]~feeder_combout\);

-- Location: M10K_X76_Y7_N0
\inst1|altsyncram_component|auto_generated|ram_block1a0\ : cyclonev_ram_block
-- pragma translate_off
GENERIC MAP (
	mem_init2 => "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init1 => "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init0 => "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000106005110041000211007120061100310",
	data_interleave_offset_in_bits => 1,
	data_interleave_width_in_bits => 1,
	init_file => "./mif/inst_rom.mif",
	init_file_layout => "port_a",
	logical_ram_name => "inst_rom:inst1|altsyncram:altsyncram_component|altsyncram_oq24:auto_generated|ALTSYNCRAM",
	operation_mode => "rom",
	port_a_address_clear => "none",
	port_a_address_width => 8,
	port_a_byte_enable_clock => "none",
	port_a_data_out_clear => "clear0",
	port_a_data_out_clock => "clock1",
	port_a_data_width => 20,
	port_a_first_address => 0,
	port_a_first_bit_number => 0,
	port_a_last_address => 255,
	port_a_logical_ram_depth => 256,
	port_a_logical_ram_width => 32,
	port_a_read_during_write_mode => "new_data_no_nbe_read",
	port_a_write_enable_clock => "none",
	port_b_address_width => 8,
	port_b_data_width => 20,
	ram_block_type => "M20K")
-- pragma translate_on
PORT MAP (
	portare => VCC,
	clk0 => \inst15|clk_cpu~combout\,
	clk1 => \inst15|ALT_INV_clk_cpu~combout\,
	clr0 => \ALT_INV_KEY[0]~input_o\,
	portaaddr => \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	portadataout => \inst1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\);

-- Location: MLABCELL_X78_Y7_N0
\inst3|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst3|Mux0~0_combout\ = ( !\inst2|r\(30) & ( !\inst2|r\(31) & ( (!\inst2|r\(29) & \inst2|r\(28)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011110000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|ALT_INV_r\(29),
	datad => \inst2|ALT_INV_r\(28),
	datae => \inst2|ALT_INV_r\(30),
	dataf => \inst2|ALT_INV_r\(31),
	combout => \inst3|Mux0~0_combout\);

-- Location: FF_X78_Y7_N17
\inst|pc_r[7]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[7]~feeder_combout\,
	asdata => \inst2|r\(7),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r[7]~DUPLICATE_q\);

-- Location: MLABCELL_X78_Y7_N48
\inst|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|Add0~5_sumout\ = SUM(( \inst|pc_r[6]~DUPLICATE_q\ ) + ( GND ) + ( \inst|Add0~10\ ))
-- \inst|Add0~6\ = CARRY(( \inst|pc_r[6]~DUPLICATE_q\ ) + ( GND ) + ( \inst|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000011001100110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst|ALT_INV_pc_r[6]~DUPLICATE_q\,
	cin => \inst|Add0~10\,
	sumout => \inst|Add0~5_sumout\,
	cout => \inst|Add0~6\);

-- Location: MLABCELL_X78_Y7_N51
\inst|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|Add0~1_sumout\ = SUM(( \inst|pc_r[7]~DUPLICATE_q\ ) + ( GND ) + ( \inst|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111111111111100000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst|ALT_INV_pc_r[7]~DUPLICATE_q\,
	cin => \inst|Add0~6\,
	sumout => \inst|Add0~1_sumout\);

-- Location: MLABCELL_X78_Y7_N15
\inst|pc_r[7]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|pc_r[7]~feeder_combout\ = ( \inst|Add0~1_sumout\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000011111111111111111111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataf => \inst|ALT_INV_Add0~1_sumout\,
	combout => \inst|pc_r[7]~feeder_combout\);

-- Location: FF_X78_Y7_N16
\inst|pc_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[7]~feeder_combout\,
	asdata => \inst2|r\(7),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r\(7));

-- Location: FF_X78_Y7_N59
\inst|pc_r[6]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[6]~feeder_combout\,
	asdata => \inst2|r\(6),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r[6]~DUPLICATE_q\);

-- Location: MLABCELL_X78_Y7_N57
\inst|pc_r[6]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|pc_r[6]~feeder_combout\ = \inst|Add0~5_sumout\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101010101010101010101010101010101010101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst|ALT_INV_Add0~5_sumout\,
	combout => \inst|pc_r[6]~feeder_combout\);

-- Location: FF_X78_Y7_N58
\inst|pc_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[6]~feeder_combout\,
	asdata => \inst2|r\(6),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r\(6));

-- Location: FF_X78_Y7_N29
\inst|pc_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[5]~feeder_combout\,
	asdata => \inst2|r\(5),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r\(5));

-- Location: FF_X78_Y7_N19
\inst|pc_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[4]~feeder_combout\,
	asdata => \inst2|r\(4),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r\(4));

-- Location: FF_X78_Y7_N23
\inst|pc_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[3]~feeder_combout\,
	asdata => \inst2|r\(3),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r\(3));

-- Location: MLABCELL_X78_Y7_N21
\inst|pc_r[3]~feeder\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|pc_r[3]~feeder_combout\ = \inst|Add0~17_sumout\

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111000011110000111100001111000011110000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst|ALT_INV_Add0~17_sumout\,
	combout => \inst|pc_r[3]~feeder_combout\);

-- Location: FF_X78_Y7_N22
\inst|pc_r[3]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[3]~feeder_combout\,
	asdata => \inst2|r\(3),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r[3]~DUPLICATE_q\);

-- Location: FF_X78_Y7_N56
\inst|pc_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[2]~feeder_combout\,
	asdata => \inst2|r\(2),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r\(2));

-- Location: FF_X78_Y7_N25
\inst|pc_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[1]~feeder_combout\,
	asdata => \inst2|r\(1),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r\(1));

-- Location: FF_X78_Y7_N14
\inst|pc_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|clk_cpu~combout\,
	d => \inst|pc_r[0]~feeder_combout\,
	asdata => \inst2|r\(0),
	clrn => \KEY[0]~input_o\,
	sload => \inst3|Mux0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|pc_r\(0));

-- Location: LABCELL_X75_Y7_N9
\inst3|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst3|Mux4~0_combout\ = ( \inst2|r\(28) & ( !\inst2|r\(31) & ( !\inst2|r\(30) $ (!\inst2|r\(29)) ) ) ) # ( !\inst2|r\(28) & ( !\inst2|r\(31) & ( (!\inst2|r\(30) & \inst2|r\(29)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011110000000011111111000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|ALT_INV_r\(30),
	datad => \inst2|ALT_INV_r\(29),
	datae => \inst2|ALT_INV_r\(28),
	dataf => \inst2|ALT_INV_r\(31),
	combout => \inst3|Mux4~0_combout\);

-- Location: LABCELL_X75_Y7_N0
\inst5|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux4~0_combout\ = ( !\inst2|r\(31) & ( (\inst2|r\(29) & !\inst2|r\(28)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100000000000011110000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst2|ALT_INV_r\(29),
	datad => \inst2|ALT_INV_r\(28),
	dataf => \inst2|ALT_INV_r\(31),
	combout => \inst5|Mux4~0_combout\);

-- Location: LABCELL_X75_Y7_N24
\inst3|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst3|Mux2~0_combout\ = ( !\inst2|r\(29) & ( !\inst2|r\(31) & ( \inst2|r\(30) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001100110011000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst2|ALT_INV_r\(30),
	datae => \inst2|ALT_INV_r\(29),
	dataf => \inst2|ALT_INV_r\(31),
	combout => \inst3|Mux2~0_combout\);

-- Location: LABCELL_X75_Y7_N18
\inst3|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst3|Mux5~0_combout\ = ( \inst2|r\(28) & ( \inst2|r\(30) & ( (!\inst2|r\(31) & \inst2|r\(29)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000101000001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_r\(31),
	datac => \inst2|ALT_INV_r\(29),
	datae => \inst2|ALT_INV_r\(28),
	dataf => \inst2|ALT_INV_r\(30),
	combout => \inst3|Mux5~0_combout\);

-- Location: M10K_X76_Y8_N0
\inst4|altsyncram_component|auto_generated|ram_block1a0\ : cyclonev_ram_block
-- pragma translate_off
GENERIC MAP (
	mem_init2 => "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init1 => "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init0 => "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000030000500000000000000000000000000000000000000000000000000000000000000000000000000000000",
	data_interleave_offset_in_bits => 1,
	data_interleave_width_in_bits => 1,
	init_file => "./mif/data_ram.mif",
	init_file_layout => "port_a",
	logical_ram_name => "data_ram:inst4|altsyncram:altsyncram_component|altsyncram_fr24:auto_generated|ALTSYNCRAM",
	operation_mode => "single_port",
	port_a_address_clear => "none",
	port_a_address_width => 8,
	port_a_byte_enable_clock => "none",
	port_a_data_out_clear => "none",
	port_a_data_out_clock => "none",
	port_a_data_width => 20,
	port_a_first_address => 0,
	port_a_first_bit_number => 0,
	port_a_last_address => 255,
	port_a_logical_ram_depth => 256,
	port_a_logical_ram_width => 8,
	port_a_read_during_write_mode => "new_data_no_nbe_read",
	port_b_address_width => 8,
	port_b_data_width => 20,
	ram_block_type => "M20K")
-- pragma translate_on
PORT MAP (
	portawe => \inst3|Mux5~0_combout\,
	portare => VCC,
	clk0 => \inst15|clk_cpu~combout\,
	portadatain => \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAIN_bus\,
	portaaddr => \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	portadataout => \inst4|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\);

-- Location: LABCELL_X75_Y8_N0
\inst5|Add0~34\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Add0~34_cout\ = CARRY(( \inst3|Mux4~0_combout\ ) + ( VCC ) + ( !VCC ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \inst3|ALT_INV_Mux4~0_combout\,
	cin => GND,
	cout => \inst5|Add0~34_cout\);

-- Location: LABCELL_X75_Y8_N3
\inst5|Add0~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Add0~1_sumout\ = SUM(( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(0)) ) + ( \inst7|ac_r\(0) ) + ( \inst5|Add0~34_cout\ ))
-- \inst5|Add0~2\ = CARRY(( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(0)) ) + ( \inst7|ac_r\(0) ) + ( \inst5|Add0~34_cout\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000101010110101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|ALT_INV_Mux4~0_combout\,
	datac => \inst7|ALT_INV_ac_r\(0),
	datad => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	cin => \inst5|Add0~34_cout\,
	sumout => \inst5|Add0~1_sumout\,
	cout => \inst5|Add0~2\);

-- Location: LABCELL_X75_Y8_N6
\inst5|Add0~5\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Add0~5_sumout\ = SUM(( !\inst4|altsyncram_component|auto_generated|q_a\(1) $ (!\inst3|Mux4~0_combout\) ) + ( \inst7|ac_r\(1) ) + ( \inst5|Add0~2\ ))
-- \inst5|Add0~6\ = CARRY(( !\inst4|altsyncram_component|auto_generated|q_a\(1) $ (!\inst3|Mux4~0_combout\) ) + ( \inst7|ac_r\(1) ) + ( \inst5|Add0~2\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111111110000000000000000000000000011110000111100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datac => \inst3|ALT_INV_Mux4~0_combout\,
	dataf => \inst7|ALT_INV_ac_r\(1),
	cin => \inst5|Add0~2\,
	sumout => \inst5|Add0~5_sumout\,
	cout => \inst5|Add0~6\);

-- Location: LABCELL_X75_Y8_N9
\inst5|Add0~9\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Add0~9_sumout\ = SUM(( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst7|ac_r[2]~DUPLICATE_q\ ) + ( \inst5|Add0~6\ ))
-- \inst5|Add0~10\ = CARRY(( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(2)) ) + ( \inst7|ac_r[2]~DUPLICATE_q\ ) + ( \inst5|Add0~6\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000111100001111000000000000000000000101010110101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|ALT_INV_Mux4~0_combout\,
	datac => \inst7|ALT_INV_ac_r[2]~DUPLICATE_q\,
	datad => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	cin => \inst5|Add0~6\,
	sumout => \inst5|Add0~9_sumout\,
	cout => \inst5|Add0~10\);

-- Location: LABCELL_X75_Y8_N12
\inst5|Add0~13\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Add0~13_sumout\ = SUM(( \inst7|ac_r\(3) ) + ( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst5|Add0~10\ ))
-- \inst5|Add0~14\ = CARRY(( \inst7|ac_r\(3) ) + ( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(3)) ) + ( \inst5|Add0~10\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101001011010010100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|ALT_INV_Mux4~0_combout\,
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datad => \inst7|ALT_INV_ac_r\(3),
	cin => \inst5|Add0~10\,
	sumout => \inst5|Add0~13_sumout\,
	cout => \inst5|Add0~14\);

-- Location: LABCELL_X75_Y8_N15
\inst5|Add0~17\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Add0~17_sumout\ = SUM(( \inst7|ac_r\(4) ) + ( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst5|Add0~14\ ))
-- \inst5|Add0~18\ = CARRY(( \inst7|ac_r\(4) ) + ( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(4)) ) + ( \inst5|Add0~14\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101001011010010100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|ALT_INV_Mux4~0_combout\,
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datad => \inst7|ALT_INV_ac_r\(4),
	cin => \inst5|Add0~14\,
	sumout => \inst5|Add0~17_sumout\,
	cout => \inst5|Add0~18\);

-- Location: LABCELL_X75_Y8_N18
\inst5|Add0~21\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Add0~21_sumout\ = SUM(( \inst7|ac_r\(5) ) + ( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst5|Add0~18\ ))
-- \inst5|Add0~22\ = CARRY(( \inst7|ac_r\(5) ) + ( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(5)) ) + ( \inst5|Add0~18\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101001011010010100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|ALT_INV_Mux4~0_combout\,
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datad => \inst7|ALT_INV_ac_r\(5),
	cin => \inst5|Add0~18\,
	sumout => \inst5|Add0~21_sumout\,
	cout => \inst5|Add0~22\);

-- Location: LABCELL_X75_Y8_N21
\inst5|Add0~25\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Add0~25_sumout\ = SUM(( \inst7|ac_r\(6) ) + ( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(6)) ) + ( \inst5|Add0~22\ ))
-- \inst5|Add0~26\ = CARRY(( \inst7|ac_r\(6) ) + ( !\inst3|Mux4~0_combout\ $ (!\inst4|altsyncram_component|auto_generated|q_a\(6)) ) + ( \inst5|Add0~22\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101001011010010100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|ALT_INV_Mux4~0_combout\,
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datad => \inst7|ALT_INV_ac_r\(6),
	cin => \inst5|Add0~22\,
	sumout => \inst5|Add0~25_sumout\,
	cout => \inst5|Add0~26\);

-- Location: LABCELL_X75_Y8_N24
\inst5|Add0~29\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Add0~29_sumout\ = SUM(( \inst7|ac_r\(7) ) + ( !\inst4|altsyncram_component|auto_generated|q_a\(7) $ (!\inst3|Mux4~0_combout\) ) + ( \inst5|Add0~26\ ))

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101001011010010100000000000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	datac => \inst3|ALT_INV_Mux4~0_combout\,
	datad => \inst7|ALT_INV_ac_r\(7),
	cin => \inst5|Add0~26\,
	sumout => \inst5|Add0~29_sumout\);

-- Location: LABCELL_X75_Y8_N42
\inst5|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux0~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(7) & ( \inst5|Add0~29_sumout\ & ( ((\inst7|ac_r\(7)) # (\inst3|Mux4~0_combout\)) # (\inst5|Mux4~0_combout\) ) ) ) # ( !\inst4|altsyncram_component|auto_generated|q_a\(7) & ( 
-- \inst5|Add0~29_sumout\ & ( ((\inst7|ac_r\(7) & (!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)))) # (\inst5|Mux4~0_combout\) ) ) ) # ( \inst4|altsyncram_component|auto_generated|q_a\(7) & ( !\inst5|Add0~29_sumout\ & ( (!\inst5|Mux4~0_combout\ & 
-- ((\inst7|ac_r\(7)) # (\inst3|Mux4~0_combout\))) ) ) ) # ( !\inst4|altsyncram_component|auto_generated|q_a\(7) & ( !\inst5|Add0~29_sumout\ & ( (!\inst5|Mux4~0_combout\ & (\inst7|ac_r\(7) & (!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000010001010100010101001011101010101110111111101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux4~0_combout\,
	datab => \inst3|ALT_INV_Mux4~0_combout\,
	datac => \inst7|ALT_INV_ac_r\(7),
	datad => \inst3|ALT_INV_Mux2~0_combout\,
	datae => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst5|ALT_INV_Add0~29_sumout\,
	combout => \inst5|Mux0~0_combout\);

-- Location: LABCELL_X75_Y7_N15
\inst3|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst3|Mux1~0_combout\ = ( !\inst2|r\(31) & ( (!\inst2|r\(29) & (\inst2|r\(30))) # (\inst2|r\(29) & ((!\inst2|r\(30)) # (!\inst2|r\(28)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101111101011010010111110101101000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|ALT_INV_r\(29),
	datac => \inst2|ALT_INV_r\(30),
	datad => \inst2|ALT_INV_r\(28),
	dataf => \inst2|ALT_INV_r\(31),
	combout => \inst3|Mux1~0_combout\);

-- Location: FF_X75_Y8_N26
\inst7|ac_r[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|ALT_INV_clk_cpu~combout\,
	asdata => \inst5|Mux0~0_combout\,
	clrn => \KEY[0]~input_o\,
	sload => VCC,
	ena => \inst3|Mux1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst7|ac_r\(7));

-- Location: LABCELL_X75_Y8_N54
\inst5|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux1~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(6) & ( \inst5|Add0~25_sumout\ & ( ((\inst3|Mux4~0_combout\) # (\inst7|ac_r\(6))) # (\inst5|Mux4~0_combout\) ) ) ) # ( !\inst4|altsyncram_component|auto_generated|q_a\(6) & ( 
-- \inst5|Add0~25_sumout\ & ( ((\inst7|ac_r\(6) & (!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)))) # (\inst5|Mux4~0_combout\) ) ) ) # ( \inst4|altsyncram_component|auto_generated|q_a\(6) & ( !\inst5|Add0~25_sumout\ & ( (!\inst5|Mux4~0_combout\ & 
-- ((\inst3|Mux4~0_combout\) # (\inst7|ac_r\(6)))) ) ) ) # ( !\inst4|altsyncram_component|auto_generated|q_a\(6) & ( !\inst5|Add0~25_sumout\ & ( (!\inst5|Mux4~0_combout\ & (\inst7|ac_r\(6) & (!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010000000000010001010100010101001110101010101110111111101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux4~0_combout\,
	datab => \inst7|ALT_INV_ac_r\(6),
	datac => \inst3|ALT_INV_Mux4~0_combout\,
	datad => \inst3|ALT_INV_Mux2~0_combout\,
	datae => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	dataf => \inst5|ALT_INV_Add0~25_sumout\,
	combout => \inst5|Mux1~0_combout\);

-- Location: FF_X75_Y8_N23
\inst7|ac_r[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|ALT_INV_clk_cpu~combout\,
	asdata => \inst5|Mux1~0_combout\,
	clrn => \KEY[0]~input_o\,
	sload => VCC,
	ena => \inst3|Mux1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst7|ac_r\(6));

-- Location: LABCELL_X75_Y8_N48
\inst5|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux2~0_combout\ = ( \inst7|ac_r\(5) & ( \inst5|Add0~21_sumout\ & ( ((!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)) # (\inst4|altsyncram_component|auto_generated|q_a\(5))) # (\inst5|Mux4~0_combout\) ) ) ) # ( !\inst7|ac_r\(5) & ( 
-- \inst5|Add0~21_sumout\ & ( ((\inst3|Mux4~0_combout\ & \inst4|altsyncram_component|auto_generated|q_a\(5))) # (\inst5|Mux4~0_combout\) ) ) ) # ( \inst7|ac_r\(5) & ( !\inst5|Add0~21_sumout\ & ( (!\inst5|Mux4~0_combout\ & ((!\inst3|Mux4~0_combout\ $ 
-- (\inst3|Mux2~0_combout\)) # (\inst4|altsyncram_component|auto_generated|q_a\(5)))) ) ) ) # ( !\inst7|ac_r\(5) & ( !\inst5|Add0~21_sumout\ & ( (!\inst5|Mux4~0_combout\ & (\inst3|Mux4~0_combout\ & \inst4|altsyncram_component|auto_generated|q_a\(5))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000000010100010100010101001010111010101111101111101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux4~0_combout\,
	datab => \inst3|ALT_INV_Mux4~0_combout\,
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datad => \inst3|ALT_INV_Mux2~0_combout\,
	datae => \inst7|ALT_INV_ac_r\(5),
	dataf => \inst5|ALT_INV_Add0~21_sumout\,
	combout => \inst5|Mux2~0_combout\);

-- Location: FF_X75_Y8_N20
\inst7|ac_r[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|ALT_INV_clk_cpu~combout\,
	asdata => \inst5|Mux2~0_combout\,
	clrn => \KEY[0]~input_o\,
	sload => VCC,
	ena => \inst3|Mux1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst7|ac_r\(5));

-- Location: LABCELL_X75_Y8_N36
\inst5|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux3~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(4) & ( \inst5|Add0~17_sumout\ & ( ((\inst7|ac_r\(4)) # (\inst3|Mux4~0_combout\)) # (\inst5|Mux4~0_combout\) ) ) ) # ( !\inst4|altsyncram_component|auto_generated|q_a\(4) & ( 
-- \inst5|Add0~17_sumout\ & ( ((\inst7|ac_r\(4) & (!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)))) # (\inst5|Mux4~0_combout\) ) ) ) # ( \inst4|altsyncram_component|auto_generated|q_a\(4) & ( !\inst5|Add0~17_sumout\ & ( (!\inst5|Mux4~0_combout\ & 
-- ((\inst7|ac_r\(4)) # (\inst3|Mux4~0_combout\))) ) ) ) # ( !\inst4|altsyncram_component|auto_generated|q_a\(4) & ( !\inst5|Add0~17_sumout\ & ( (!\inst5|Mux4~0_combout\ & (\inst7|ac_r\(4) & (!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000000010001010100010101001011101010101110111111101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux4~0_combout\,
	datab => \inst3|ALT_INV_Mux4~0_combout\,
	datac => \inst7|ALT_INV_ac_r\(4),
	datad => \inst3|ALT_INV_Mux2~0_combout\,
	datae => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	dataf => \inst5|ALT_INV_Add0~17_sumout\,
	combout => \inst5|Mux3~0_combout\);

-- Location: FF_X75_Y8_N17
\inst7|ac_r[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|ALT_INV_clk_cpu~combout\,
	asdata => \inst5|Mux3~0_combout\,
	clrn => \KEY[0]~input_o\,
	sload => VCC,
	ena => \inst3|Mux1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst7|ac_r\(4));

-- Location: LABCELL_X75_Y8_N30
\inst5|Mux4~1\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux4~1_combout\ = ( \inst7|ac_r\(3) & ( \inst5|Add0~13_sumout\ & ( ((!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)) # (\inst4|altsyncram_component|auto_generated|q_a\(3))) # (\inst5|Mux4~0_combout\) ) ) ) # ( !\inst7|ac_r\(3) & ( 
-- \inst5|Add0~13_sumout\ & ( ((\inst3|Mux4~0_combout\ & \inst4|altsyncram_component|auto_generated|q_a\(3))) # (\inst5|Mux4~0_combout\) ) ) ) # ( \inst7|ac_r\(3) & ( !\inst5|Add0~13_sumout\ & ( (!\inst5|Mux4~0_combout\ & ((!\inst3|Mux4~0_combout\ $ 
-- (\inst3|Mux2~0_combout\)) # (\inst4|altsyncram_component|auto_generated|q_a\(3)))) ) ) ) # ( !\inst7|ac_r\(3) & ( !\inst5|Add0~13_sumout\ & ( (!\inst5|Mux4~0_combout\ & (\inst3|Mux4~0_combout\ & \inst4|altsyncram_component|auto_generated|q_a\(3))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001000000010100010100010101001010111010101111101111101111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux4~0_combout\,
	datab => \inst3|ALT_INV_Mux4~0_combout\,
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datad => \inst3|ALT_INV_Mux2~0_combout\,
	datae => \inst7|ALT_INV_ac_r\(3),
	dataf => \inst5|ALT_INV_Add0~13_sumout\,
	combout => \inst5|Mux4~1_combout\);

-- Location: FF_X75_Y8_N14
\inst7|ac_r[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|ALT_INV_clk_cpu~combout\,
	asdata => \inst5|Mux4~1_combout\,
	clrn => \KEY[0]~input_o\,
	sload => VCC,
	ena => \inst3|Mux1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst7|ac_r\(3));

-- Location: FF_X74_Y8_N5
\inst7|ac_r[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|ALT_INV_clk_cpu~combout\,
	asdata => \inst5|Mux5~0_combout\,
	clrn => \KEY[0]~input_o\,
	sload => VCC,
	ena => \inst3|Mux1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst7|ac_r\(2));

-- Location: LABCELL_X74_Y8_N0
\inst5|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux5~0_combout\ = ( \inst3|Mux4~0_combout\ & ( \inst5|Add0~9_sumout\ & ( (((\inst3|Mux2~0_combout\ & \inst7|ac_r\(2))) # (\inst5|Mux4~0_combout\)) # (\inst4|altsyncram_component|auto_generated|q_a\(2)) ) ) ) # ( !\inst3|Mux4~0_combout\ & ( 
-- \inst5|Add0~9_sumout\ & ( ((\inst7|ac_r\(2) & ((!\inst3|Mux2~0_combout\) # (\inst4|altsyncram_component|auto_generated|q_a\(2))))) # (\inst5|Mux4~0_combout\) ) ) ) # ( \inst3|Mux4~0_combout\ & ( !\inst5|Add0~9_sumout\ & ( (!\inst5|Mux4~0_combout\ & 
-- (((\inst3|Mux2~0_combout\ & \inst7|ac_r\(2))) # (\inst4|altsyncram_component|auto_generated|q_a\(2)))) ) ) ) # ( !\inst3|Mux4~0_combout\ & ( !\inst5|Add0~9_sumout\ & ( (\inst7|ac_r\(2) & (!\inst5|Mux4~0_combout\ & ((!\inst3|Mux2~0_combout\) # 
-- (\inst4|altsyncram_component|auto_generated|q_a\(2))))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101100000000001101110000000000001011111111110011011111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|ALT_INV_Mux2~0_combout\,
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datac => \inst7|ALT_INV_ac_r\(2),
	datad => \inst5|ALT_INV_Mux4~0_combout\,
	datae => \inst3|ALT_INV_Mux4~0_combout\,
	dataf => \inst5|ALT_INV_Add0~9_sumout\,
	combout => \inst5|Mux5~0_combout\);

-- Location: FF_X74_Y8_N4
\inst7|ac_r[2]~DUPLICATE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|ALT_INV_clk_cpu~combout\,
	asdata => \inst5|Mux5~0_combout\,
	clrn => \KEY[0]~input_o\,
	sload => VCC,
	ena => \inst3|Mux1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst7|ac_r[2]~DUPLICATE_q\);

-- Location: LABCELL_X74_Y8_N36
\inst5|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux6~0_combout\ = ( \inst5|Add0~5_sumout\ & ( \inst7|ac_r\(1) & ( ((!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)) # (\inst5|Mux4~0_combout\)) # (\inst4|altsyncram_component|auto_generated|q_a\(1)) ) ) ) # ( !\inst5|Add0~5_sumout\ & ( 
-- \inst7|ac_r\(1) & ( (!\inst5|Mux4~0_combout\ & ((!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)) # (\inst4|altsyncram_component|auto_generated|q_a\(1)))) ) ) ) # ( \inst5|Add0~5_sumout\ & ( !\inst7|ac_r\(1) & ( ((\inst3|Mux4~0_combout\ & 
-- \inst4|altsyncram_component|auto_generated|q_a\(1))) # (\inst5|Mux4~0_combout\) ) ) ) # ( !\inst5|Add0~5_sumout\ & ( !\inst7|ac_r\(1) & ( (\inst3|Mux4~0_combout\ & (\inst4|altsyncram_component|auto_generated|q_a\(1) & !\inst5|Mux4~0_combout\)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100000000000100011111111110110111000000001011011111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|ALT_INV_Mux4~0_combout\,
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	datac => \inst3|ALT_INV_Mux2~0_combout\,
	datad => \inst5|ALT_INV_Mux4~0_combout\,
	datae => \inst5|ALT_INV_Add0~5_sumout\,
	dataf => \inst7|ALT_INV_ac_r\(1),
	combout => \inst5|Mux6~0_combout\);

-- Location: FF_X74_Y8_N40
\inst7|ac_r[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|ALT_INV_clk_cpu~combout\,
	asdata => \inst5|Mux6~0_combout\,
	clrn => \KEY[0]~input_o\,
	sload => VCC,
	ena => \inst3|Mux1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst7|ac_r\(1));

-- Location: LABCELL_X74_Y8_N54
\inst5|Mux7~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst5|Mux7~0_combout\ = ( \inst5|Add0~1_sumout\ & ( \inst7|ac_r\(0) & ( ((!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)) # (\inst4|altsyncram_component|auto_generated|q_a\(0))) # (\inst5|Mux4~0_combout\) ) ) ) # ( !\inst5|Add0~1_sumout\ & ( 
-- \inst7|ac_r\(0) & ( (!\inst5|Mux4~0_combout\ & ((!\inst3|Mux4~0_combout\ $ (\inst3|Mux2~0_combout\)) # (\inst4|altsyncram_component|auto_generated|q_a\(0)))) ) ) ) # ( \inst5|Add0~1_sumout\ & ( !\inst7|ac_r\(0) & ( ((\inst3|Mux4~0_combout\ & 
-- \inst4|altsyncram_component|auto_generated|q_a\(0))) # (\inst5|Mux4~0_combout\) ) ) ) # ( !\inst5|Add0~1_sumout\ & ( !\inst7|ac_r\(0) & ( (\inst3|Mux4~0_combout\ & (!\inst5|Mux4~0_combout\ & \inst4|altsyncram_component|auto_generated|q_a\(0))) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000001000100001100110111011110000100110011001011011111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst3|ALT_INV_Mux4~0_combout\,
	datab => \inst5|ALT_INV_Mux4~0_combout\,
	datac => \inst3|ALT_INV_Mux2~0_combout\,
	datad => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datae => \inst5|ALT_INV_Add0~1_sumout\,
	dataf => \inst7|ALT_INV_ac_r\(0),
	combout => \inst5|Mux7~0_combout\);

-- Location: FF_X74_Y8_N58
\inst7|ac_r[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \inst15|ALT_INV_clk_cpu~combout\,
	asdata => \inst5|Mux7~0_combout\,
	clrn => \KEY[0]~input_o\,
	sload => VCC,
	ena => \inst3|Mux1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst7|ac_r\(0));

-- Location: LABCELL_X74_Y8_N21
\inst11|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst11|Mux0~0_combout\ = ( \inst7|ac_r\(3) & ( ((!\inst7|ac_r[2]~DUPLICATE_q\) # (\inst7|ac_r\(1))) # (\inst7|ac_r\(0)) ) ) # ( !\inst7|ac_r\(3) & ( (!\inst7|ac_r[2]~DUPLICATE_q\ & ((\inst7|ac_r\(1)))) # (\inst7|ac_r[2]~DUPLICATE_q\ & ((!\inst7|ac_r\(0)) 
-- # (!\inst7|ac_r\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011111000111110001111100011111011011111110111111101111111011111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(0),
	datab => \inst7|ALT_INV_ac_r[2]~DUPLICATE_q\,
	datac => \inst7|ALT_INV_ac_r\(1),
	dataf => \inst7|ALT_INV_ac_r\(3),
	combout => \inst11|Mux0~0_combout\);

-- Location: LABCELL_X74_Y8_N45
\inst11|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst11|Mux1~0_combout\ = ( \inst7|ac_r\(3) & ( (\inst7|ac_r\(0) & (\inst7|ac_r[2]~DUPLICATE_q\ & !\inst7|ac_r\(1))) ) ) # ( !\inst7|ac_r\(3) & ( (!\inst7|ac_r\(0) & (!\inst7|ac_r[2]~DUPLICATE_q\ & \inst7|ac_r\(1))) # (\inst7|ac_r\(0) & 
-- ((!\inst7|ac_r[2]~DUPLICATE_q\) # (\inst7|ac_r\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000011110101010100001111010100000101000000000000010100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(0),
	datac => \inst7|ALT_INV_ac_r[2]~DUPLICATE_q\,
	datad => \inst7|ALT_INV_ac_r\(1),
	dataf => \inst7|ALT_INV_ac_r\(3),
	combout => \inst11|Mux1~0_combout\);

-- Location: LABCELL_X74_Y8_N18
\inst11|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst11|Mux2~0_combout\ = ( \inst7|ac_r\(3) & ( (\inst7|ac_r\(0) & (!\inst7|ac_r[2]~DUPLICATE_q\ & !\inst7|ac_r\(1))) ) ) # ( !\inst7|ac_r\(3) & ( ((\inst7|ac_r[2]~DUPLICATE_q\ & !\inst7|ac_r\(1))) # (\inst7|ac_r\(0)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111010101110101011101010111010101000000010000000100000001000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(0),
	datab => \inst7|ALT_INV_ac_r[2]~DUPLICATE_q\,
	datac => \inst7|ALT_INV_ac_r\(1),
	dataf => \inst7|ALT_INV_ac_r\(3),
	combout => \inst11|Mux2~0_combout\);

-- Location: LABCELL_X74_Y8_N12
\inst11|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst11|Mux3~0_combout\ = ( \inst7|ac_r\(3) & ( (\inst7|ac_r\(1) & (!\inst7|ac_r\(0) $ (\inst7|ac_r\(2)))) ) ) # ( !\inst7|ac_r\(3) & ( (!\inst7|ac_r\(1) & (!\inst7|ac_r\(0) $ (!\inst7|ac_r\(2)))) # (\inst7|ac_r\(1) & (\inst7|ac_r\(0) & \inst7|ac_r\(2))) 
-- ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101010100101000010101010010101010000000001010101000000000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(1),
	datac => \inst7|ALT_INV_ac_r\(0),
	datad => \inst7|ALT_INV_ac_r\(2),
	dataf => \inst7|ALT_INV_ac_r\(3),
	combout => \inst11|Mux3~0_combout\);

-- Location: LABCELL_X74_Y8_N15
\inst11|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst11|Mux4~0_combout\ = ( \inst7|ac_r\(0) & ( (\inst7|ac_r\(1) & (\inst7|ac_r\(3) & \inst7|ac_r[2]~DUPLICATE_q\)) ) ) # ( !\inst7|ac_r\(0) & ( (!\inst7|ac_r\(3) & (\inst7|ac_r\(1) & !\inst7|ac_r[2]~DUPLICATE_q\)) # (\inst7|ac_r\(3) & 
-- ((\inst7|ac_r[2]~DUPLICATE_q\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100001101000011010000110100001100000001000000010000000100000001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(1),
	datab => \inst7|ALT_INV_ac_r\(3),
	datac => \inst7|ALT_INV_ac_r[2]~DUPLICATE_q\,
	dataf => \inst7|ALT_INV_ac_r\(0),
	combout => \inst11|Mux4~0_combout\);

-- Location: LABCELL_X74_Y8_N24
\inst11|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst11|Mux5~0_combout\ = ( \inst7|ac_r\(3) & ( (!\inst7|ac_r\(0) & (\inst7|ac_r[2]~DUPLICATE_q\)) # (\inst7|ac_r\(0) & ((\inst7|ac_r\(1)))) ) ) # ( !\inst7|ac_r\(3) & ( (\inst7|ac_r[2]~DUPLICATE_q\ & (!\inst7|ac_r\(0) $ (!\inst7|ac_r\(1)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001001000010010000100100001001000100111001001110010011100100111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(0),
	datab => \inst7|ALT_INV_ac_r[2]~DUPLICATE_q\,
	datac => \inst7|ALT_INV_ac_r\(1),
	dataf => \inst7|ALT_INV_ac_r\(3),
	combout => \inst11|Mux5~0_combout\);

-- Location: LABCELL_X74_Y8_N27
\inst11|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst11|Mux6~0_combout\ = ( \inst7|ac_r\(3) & ( (\inst7|ac_r\(0) & (!\inst7|ac_r[2]~DUPLICATE_q\ $ (!\inst7|ac_r\(1)))) ) ) # ( !\inst7|ac_r\(3) & ( (!\inst7|ac_r\(1) & (!\inst7|ac_r\(0) $ (!\inst7|ac_r[2]~DUPLICATE_q\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110000001100000011000000110000000010100000101000001010000010100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(0),
	datab => \inst7|ALT_INV_ac_r[2]~DUPLICATE_q\,
	datac => \inst7|ALT_INV_ac_r\(1),
	dataf => \inst7|ALT_INV_ac_r\(3),
	combout => \inst11|Mux6~0_combout\);

-- Location: MLABCELL_X84_Y10_N15
\inst8|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux0~0_combout\ = ( \inst7|ac_r\(6) & ( \inst7|ac_r\(5) & ( (!\inst7|ac_r\(4)) # (\inst7|ac_r\(7)) ) ) ) # ( !\inst7|ac_r\(6) & ( \inst7|ac_r\(5) ) ) # ( \inst7|ac_r\(6) & ( !\inst7|ac_r\(5) & ( (!\inst7|ac_r\(7)) # (\inst7|ac_r\(4)) ) ) ) # ( 
-- !\inst7|ac_r\(6) & ( !\inst7|ac_r\(5) & ( \inst7|ac_r\(7) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011111111111111110101010111111111111111111010101011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(4),
	datad => \inst7|ALT_INV_ac_r\(7),
	datae => \inst7|ALT_INV_ac_r\(6),
	dataf => \inst7|ALT_INV_ac_r\(5),
	combout => \inst8|Mux0~0_combout\);

-- Location: MLABCELL_X84_Y10_N18
\inst8|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux1~0_combout\ = ( \inst7|ac_r\(4) & ( \inst7|ac_r\(5) & ( !\inst7|ac_r\(7) ) ) ) # ( !\inst7|ac_r\(4) & ( \inst7|ac_r\(5) & ( (!\inst7|ac_r\(7) & !\inst7|ac_r\(6)) ) ) ) # ( \inst7|ac_r\(4) & ( !\inst7|ac_r\(5) & ( !\inst7|ac_r\(7) $ 
-- (\inst7|ac_r\(6)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000101001011010010110100000101000001010101010101010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(7),
	datac => \inst7|ALT_INV_ac_r\(6),
	datae => \inst7|ALT_INV_ac_r\(4),
	dataf => \inst7|ALT_INV_ac_r\(5),
	combout => \inst8|Mux1~0_combout\);

-- Location: MLABCELL_X84_Y10_N39
\inst8|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux2~0_combout\ = ( \inst7|ac_r\(6) & ( \inst7|ac_r\(5) & ( (\inst7|ac_r\(4) & !\inst7|ac_r\(7)) ) ) ) # ( !\inst7|ac_r\(6) & ( \inst7|ac_r\(5) & ( (\inst7|ac_r\(4) & !\inst7|ac_r\(7)) ) ) ) # ( \inst7|ac_r\(6) & ( !\inst7|ac_r\(5) & ( 
-- !\inst7|ac_r\(7) ) ) ) # ( !\inst7|ac_r\(6) & ( !\inst7|ac_r\(5) & ( \inst7|ac_r\(4) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101010101111111110000000001010101000000000101010100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(4),
	datad => \inst7|ALT_INV_ac_r\(7),
	datae => \inst7|ALT_INV_ac_r\(6),
	dataf => \inst7|ALT_INV_ac_r\(5),
	combout => \inst8|Mux2~0_combout\);

-- Location: MLABCELL_X84_Y10_N42
\inst8|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux3~0_combout\ = ( \inst7|ac_r\(4) & ( \inst7|ac_r\(5) & ( \inst7|ac_r\(6) ) ) ) # ( !\inst7|ac_r\(4) & ( \inst7|ac_r\(5) & ( (\inst7|ac_r\(7) & !\inst7|ac_r\(6)) ) ) ) # ( \inst7|ac_r\(4) & ( !\inst7|ac_r\(5) & ( (!\inst7|ac_r\(7) & 
-- !\inst7|ac_r\(6)) ) ) ) # ( !\inst7|ac_r\(4) & ( !\inst7|ac_r\(5) & ( (!\inst7|ac_r\(7) & \inst7|ac_r\(6)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001010101000001010000001010000010100000000111100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(7),
	datac => \inst7|ALT_INV_ac_r\(6),
	datae => \inst7|ALT_INV_ac_r\(4),
	dataf => \inst7|ALT_INV_ac_r\(5),
	combout => \inst8|Mux3~0_combout\);

-- Location: MLABCELL_X84_Y10_N51
\inst8|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux4~0_combout\ = ( \inst7|ac_r\(6) & ( \inst7|ac_r\(5) & ( \inst7|ac_r\(7) ) ) ) # ( !\inst7|ac_r\(6) & ( \inst7|ac_r\(5) & ( (!\inst7|ac_r\(4) & !\inst7|ac_r\(7)) ) ) ) # ( \inst7|ac_r\(6) & ( !\inst7|ac_r\(5) & ( (!\inst7|ac_r\(4) & 
-- \inst7|ac_r\(7)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000001010101010101010000000000000000011111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(4),
	datad => \inst7|ALT_INV_ac_r\(7),
	datae => \inst7|ALT_INV_ac_r\(6),
	dataf => \inst7|ALT_INV_ac_r\(5),
	combout => \inst8|Mux4~0_combout\);

-- Location: MLABCELL_X84_Y10_N54
\inst8|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux5~0_combout\ = ( \inst7|ac_r\(4) & ( \inst7|ac_r\(5) & ( \inst7|ac_r\(7) ) ) ) # ( !\inst7|ac_r\(4) & ( \inst7|ac_r\(5) & ( \inst7|ac_r\(6) ) ) ) # ( \inst7|ac_r\(4) & ( !\inst7|ac_r\(5) & ( (!\inst7|ac_r\(7) & \inst7|ac_r\(6)) ) ) ) # ( 
-- !\inst7|ac_r\(4) & ( !\inst7|ac_r\(5) & ( (\inst7|ac_r\(7) & \inst7|ac_r\(6)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000010100000101000010100000101000001111000011110101010101010101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(7),
	datac => \inst7|ALT_INV_ac_r\(6),
	datae => \inst7|ALT_INV_ac_r\(4),
	dataf => \inst7|ALT_INV_ac_r\(5),
	combout => \inst8|Mux5~0_combout\);

-- Location: MLABCELL_X84_Y10_N24
\inst8|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst8|Mux6~0_combout\ = ( \inst7|ac_r\(4) & ( \inst7|ac_r\(5) & ( (\inst7|ac_r\(7) & !\inst7|ac_r\(6)) ) ) ) # ( \inst7|ac_r\(4) & ( !\inst7|ac_r\(5) & ( !\inst7|ac_r\(7) $ (\inst7|ac_r\(6)) ) ) ) # ( !\inst7|ac_r\(4) & ( !\inst7|ac_r\(5) & ( 
-- (!\inst7|ac_r\(7) & \inst7|ac_r\(6)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001010101001011010010100000000000000000101000001010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst7|ALT_INV_ac_r\(7),
	datac => \inst7|ALT_INV_ac_r\(6),
	datae => \inst7|ALT_INV_ac_r\(4),
	dataf => \inst7|ALT_INV_ac_r\(5),
	combout => \inst8|Mux6~0_combout\);

-- Location: LABCELL_X74_Y8_N9
\inst9|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux0~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(2) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(3) & ((!\inst4|altsyncram_component|auto_generated|q_a\(0)) # (!\inst4|altsyncram_component|auto_generated|q_a\(1)))) # 
-- (\inst4|altsyncram_component|auto_generated|q_a\(3) & ((\inst4|altsyncram_component|auto_generated|q_a\(1)) # (\inst4|altsyncram_component|auto_generated|q_a\(0)))) ) ) # ( !\inst4|altsyncram_component|auto_generated|q_a\(2) & ( 
-- (\inst4|altsyncram_component|auto_generated|q_a\(1)) # (\inst4|altsyncram_component|auto_generated|q_a\(3)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101111101011111010111110101111110111101101111011011110110111101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	combout => \inst9|Mux0~0_combout\);

-- Location: LABCELL_X74_Y8_N30
\inst9|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux1~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(3) & ((!\inst4|altsyncram_component|auto_generated|q_a\(2)) # (\inst4|altsyncram_component|auto_generated|q_a\(0)))) ) ) # 
-- ( !\inst4|altsyncram_component|auto_generated|q_a\(1) & ( (\inst4|altsyncram_component|auto_generated|q_a\(0) & (!\inst4|altsyncram_component|auto_generated|q_a\(2) $ (\inst4|altsyncram_component|auto_generated|q_a\(3)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000000000011001100000000001111110011000000001111001100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datad => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst9|Mux1~0_combout\);

-- Location: LABCELL_X74_Y8_N33
\inst9|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux2~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(1) & ( (\inst4|altsyncram_component|auto_generated|q_a\(0) & !\inst4|altsyncram_component|auto_generated|q_a\(3)) ) ) # ( !\inst4|altsyncram_component|auto_generated|q_a\(1) & ( 
-- (!\inst4|altsyncram_component|auto_generated|q_a\(2) & (\inst4|altsyncram_component|auto_generated|q_a\(0))) # (\inst4|altsyncram_component|auto_generated|q_a\(2) & ((!\inst4|altsyncram_component|auto_generated|q_a\(3)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101111100001010010111110000101000001111000000000000111100000000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datad => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst9|Mux2~0_combout\);

-- Location: LABCELL_X74_Y8_N48
\inst9|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux3~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(0) & (\inst4|altsyncram_component|auto_generated|q_a\(3) & !\inst4|altsyncram_component|auto_generated|q_a\(2))) # 
-- (\inst4|altsyncram_component|auto_generated|q_a\(0) & ((\inst4|altsyncram_component|auto_generated|q_a\(2)))) ) ) # ( !\inst4|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(3) & 
-- (!\inst4|altsyncram_component|auto_generated|q_a\(0) $ (!\inst4|altsyncram_component|auto_generated|q_a\(2)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010100000101000001010000010100001000011010000110100001101000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst9|Mux3~0_combout\);

-- Location: LABCELL_X74_Y8_N51
\inst9|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux4~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(2) & ( (\inst4|altsyncram_component|auto_generated|q_a\(3) & ((!\inst4|altsyncram_component|auto_generated|q_a\(0)) # (\inst4|altsyncram_component|auto_generated|q_a\(1)))) ) ) # ( 
-- !\inst4|altsyncram_component|auto_generated|q_a\(2) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(3) & (!\inst4|altsyncram_component|auto_generated|q_a\(0) & \inst4|altsyncram_component|auto_generated|q_a\(1))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000100000001000000010000000100001000101010001010100010101000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	combout => \inst9|Mux4~0_combout\);

-- Location: LABCELL_X74_Y8_N42
\inst9|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux5~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(0) & (\inst4|altsyncram_component|auto_generated|q_a\(2))) # (\inst4|altsyncram_component|auto_generated|q_a\(0) & 
-- ((\inst4|altsyncram_component|auto_generated|q_a\(3)))) ) ) # ( !\inst4|altsyncram_component|auto_generated|q_a\(1) & ( (\inst4|altsyncram_component|auto_generated|q_a\(2) & (!\inst4|altsyncram_component|auto_generated|q_a\(3) $ 
-- (!\inst4|altsyncram_component|auto_generated|q_a\(0)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000001100110000000000110011000000110011000011110011001100001111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datad => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst9|Mux5~0_combout\);

-- Location: LABCELL_X74_Y8_N6
\inst9|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst9|Mux6~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(1) & ( (\inst4|altsyncram_component|auto_generated|q_a\(3) & (\inst4|altsyncram_component|auto_generated|q_a\(0) & !\inst4|altsyncram_component|auto_generated|q_a\(2))) ) ) # ( 
-- !\inst4|altsyncram_component|auto_generated|q_a\(1) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(3) & (!\inst4|altsyncram_component|auto_generated|q_a\(0) $ (!\inst4|altsyncram_component|auto_generated|q_a\(2)))) # 
-- (\inst4|altsyncram_component|auto_generated|q_a\(3) & (\inst4|altsyncram_component|auto_generated|q_a\(0) & \inst4|altsyncram_component|auto_generated|q_a\(2))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010100100101001001010010010100100010000000100000001000000010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(3),
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(0),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(2),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(1),
	combout => \inst9|Mux6~0_combout\);

-- Location: MLABCELL_X84_Y12_N48
\inst10|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst10|Mux0~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(7) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(6)) # ((\inst4|altsyncram_component|auto_generated|q_a\(5)) # (\inst4|altsyncram_component|auto_generated|q_a\(4))) ) ) # 
-- ( !\inst4|altsyncram_component|auto_generated|q_a\(7) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(6) & ((\inst4|altsyncram_component|auto_generated|q_a\(5)))) # (\inst4|altsyncram_component|auto_generated|q_a\(6) & 
-- ((!\inst4|altsyncram_component|auto_generated|q_a\(4)) # (!\inst4|altsyncram_component|auto_generated|q_a\(5)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101111001011110101111111011111101011110010111101011111110111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datae => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	combout => \inst10|Mux0~0_combout\);

-- Location: MLABCELL_X84_Y12_N6
\inst10|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst10|Mux1~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(7) & ( (\inst4|altsyncram_component|auto_generated|q_a\(6) & (\inst4|altsyncram_component|auto_generated|q_a\(4) & !\inst4|altsyncram_component|auto_generated|q_a\(5))) ) ) # ( 
-- !\inst4|altsyncram_component|auto_generated|q_a\(7) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(6) & ((\inst4|altsyncram_component|auto_generated|q_a\(5)) # (\inst4|altsyncram_component|auto_generated|q_a\(4)))) # 
-- (\inst4|altsyncram_component|auto_generated|q_a\(6) & (\inst4|altsyncram_component|auto_generated|q_a\(4) & \inst4|altsyncram_component|auto_generated|q_a\(5))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0010101100101011000100000001000000101011001010110001000000010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datae => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	combout => \inst10|Mux1~0_combout\);

-- Location: MLABCELL_X84_Y12_N0
\inst10|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst10|Mux2~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(7) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(6) & (\inst4|altsyncram_component|auto_generated|q_a\(4) & !\inst4|altsyncram_component|auto_generated|q_a\(5))) ) ) # ( 
-- !\inst4|altsyncram_component|auto_generated|q_a\(7) & ( ((\inst4|altsyncram_component|auto_generated|q_a\(6) & !\inst4|altsyncram_component|auto_generated|q_a\(5))) # (\inst4|altsyncram_component|auto_generated|q_a\(4)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0111001101110011001000000010000001110011011100110010000000100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datae => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	combout => \inst10|Mux2~0_combout\);

-- Location: MLABCELL_X84_Y12_N57
\inst10|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst10|Mux3~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(7) & ( \inst4|altsyncram_component|auto_generated|q_a\(6) & ( (\inst4|altsyncram_component|auto_generated|q_a\(5) & \inst4|altsyncram_component|auto_generated|q_a\(4)) ) ) ) # ( 
-- !\inst4|altsyncram_component|auto_generated|q_a\(7) & ( \inst4|altsyncram_component|auto_generated|q_a\(6) & ( !\inst4|altsyncram_component|auto_generated|q_a\(5) $ (\inst4|altsyncram_component|auto_generated|q_a\(4)) ) ) ) # ( 
-- \inst4|altsyncram_component|auto_generated|q_a\(7) & ( !\inst4|altsyncram_component|auto_generated|q_a\(6) & ( (\inst4|altsyncram_component|auto_generated|q_a\(5) & !\inst4|altsyncram_component|auto_generated|q_a\(4)) ) ) ) # ( 
-- !\inst4|altsyncram_component|auto_generated|q_a\(7) & ( !\inst4|altsyncram_component|auto_generated|q_a\(6) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(5) & \inst4|altsyncram_component|auto_generated|q_a\(4)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001010010100000101000010100101101001010000010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datae => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	combout => \inst10|Mux3~0_combout\);

-- Location: MLABCELL_X84_Y12_N27
\inst10|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst10|Mux4~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(7) & ( \inst4|altsyncram_component|auto_generated|q_a\(6) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(4)) # (\inst4|altsyncram_component|auto_generated|q_a\(5)) ) ) ) # 
-- ( !\inst4|altsyncram_component|auto_generated|q_a\(7) & ( !\inst4|altsyncram_component|auto_generated|q_a\(6) & ( (\inst4|altsyncram_component|auto_generated|q_a\(5) & !\inst4|altsyncram_component|auto_generated|q_a\(4)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000001010000000000000000000000000000000000001111010111110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datae => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	combout => \inst10|Mux4~0_combout\);

-- Location: MLABCELL_X84_Y12_N45
\inst10|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst10|Mux5~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(7) & ( \inst4|altsyncram_component|auto_generated|q_a\(6) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(4)) # (\inst4|altsyncram_component|auto_generated|q_a\(5)) ) ) ) # 
-- ( !\inst4|altsyncram_component|auto_generated|q_a\(7) & ( \inst4|altsyncram_component|auto_generated|q_a\(6) & ( !\inst4|altsyncram_component|auto_generated|q_a\(5) $ (!\inst4|altsyncram_component|auto_generated|q_a\(4)) ) ) ) # ( 
-- \inst4|altsyncram_component|auto_generated|q_a\(7) & ( !\inst4|altsyncram_component|auto_generated|q_a\(6) & ( (\inst4|altsyncram_component|auto_generated|q_a\(5) & \inst4|altsyncram_component|auto_generated|q_a\(4)) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000001010000010101011010010110101111010111110101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datae => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	combout => \inst10|Mux5~0_combout\);

-- Location: MLABCELL_X84_Y12_N12
\inst10|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst10|Mux6~0_combout\ = ( \inst4|altsyncram_component|auto_generated|q_a\(6) & ( (!\inst4|altsyncram_component|auto_generated|q_a\(5) & (!\inst4|altsyncram_component|auto_generated|q_a\(4) $ (\inst4|altsyncram_component|auto_generated|q_a\(7)))) ) ) # ( 
-- !\inst4|altsyncram_component|auto_generated|q_a\(6) & ( (\inst4|altsyncram_component|auto_generated|q_a\(4) & (!\inst4|altsyncram_component|auto_generated|q_a\(5) $ (\inst4|altsyncram_component|auto_generated|q_a\(7)))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000000000011001100000000001111000000001100001100000000110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(4),
	datac => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(5),
	datad => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(7),
	dataf => \inst4|altsyncram_component|auto_generated|ALT_INV_q_a\(6),
	combout => \inst10|Mux6~0_combout\);

-- Location: MLABCELL_X84_Y12_N30
\inst12|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst12|Mux0~0_combout\ = ( \inst5|Mux5~0_combout\ & ( (!\inst5|Mux4~1_combout\ & ((!\inst5|Mux7~0_combout\) # (!\inst5|Mux6~0_combout\))) # (\inst5|Mux4~1_combout\ & ((\inst5|Mux6~0_combout\) # (\inst5|Mux7~0_combout\))) ) ) # ( !\inst5|Mux5~0_combout\ & 
-- ( (\inst5|Mux6~0_combout\) # (\inst5|Mux4~1_combout\) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011001111111111001100111111111111001111111100111100111111110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|ALT_INV_Mux4~1_combout\,
	datac => \inst5|ALT_INV_Mux7~0_combout\,
	datad => \inst5|ALT_INV_Mux6~0_combout\,
	dataf => \inst5|ALT_INV_Mux5~0_combout\,
	combout => \inst12|Mux0~0_combout\);

-- Location: MLABCELL_X84_Y12_N33
\inst12|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst12|Mux1~0_combout\ = ( \inst5|Mux5~0_combout\ & ( (\inst5|Mux7~0_combout\ & (!\inst5|Mux4~1_combout\ $ (!\inst5|Mux6~0_combout\))) ) ) # ( !\inst5|Mux5~0_combout\ & ( (!\inst5|Mux4~1_combout\ & ((\inst5|Mux6~0_combout\) # (\inst5|Mux7~0_combout\))) ) 
-- )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100110001001100010011000100110000010100000101000001010000010100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux7~0_combout\,
	datab => \inst5|ALT_INV_Mux4~1_combout\,
	datac => \inst5|ALT_INV_Mux6~0_combout\,
	dataf => \inst5|ALT_INV_Mux5~0_combout\,
	combout => \inst12|Mux1~0_combout\);

-- Location: MLABCELL_X84_Y12_N36
\inst12|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst12|Mux2~0_combout\ = ( \inst5|Mux5~0_combout\ & ( (!\inst5|Mux4~1_combout\ & ((!\inst5|Mux6~0_combout\) # (\inst5|Mux7~0_combout\))) ) ) # ( !\inst5|Mux5~0_combout\ & ( (\inst5|Mux7~0_combout\ & ((!\inst5|Mux4~1_combout\) # 
-- (!\inst5|Mux6~0_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101010101000100010101010100010011001100010001001100110001000100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux7~0_combout\,
	datab => \inst5|ALT_INV_Mux4~1_combout\,
	datad => \inst5|ALT_INV_Mux6~0_combout\,
	dataf => \inst5|ALT_INV_Mux5~0_combout\,
	combout => \inst12|Mux2~0_combout\);

-- Location: MLABCELL_X84_Y12_N15
\inst12|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst12|Mux3~0_combout\ = ( \inst5|Mux5~0_combout\ & ( (!\inst5|Mux7~0_combout\ & (!\inst5|Mux6~0_combout\ & !\inst5|Mux4~1_combout\)) # (\inst5|Mux7~0_combout\ & (\inst5|Mux6~0_combout\)) ) ) # ( !\inst5|Mux5~0_combout\ & ( (!\inst5|Mux7~0_combout\ & 
-- (\inst5|Mux6~0_combout\ & \inst5|Mux4~1_combout\)) # (\inst5|Mux7~0_combout\ & (!\inst5|Mux6~0_combout\ & !\inst5|Mux4~1_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000000001010010100000000101010100101000001011010010100000101",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux7~0_combout\,
	datac => \inst5|ALT_INV_Mux6~0_combout\,
	datad => \inst5|ALT_INV_Mux4~1_combout\,
	dataf => \inst5|ALT_INV_Mux5~0_combout\,
	combout => \inst12|Mux3~0_combout\);

-- Location: MLABCELL_X84_Y12_N18
\inst12|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst12|Mux4~0_combout\ = ( \inst5|Mux5~0_combout\ & ( (\inst5|Mux4~1_combout\ & ((!\inst5|Mux7~0_combout\) # (\inst5|Mux6~0_combout\))) ) ) # ( !\inst5|Mux5~0_combout\ & ( (!\inst5|Mux4~1_combout\ & (!\inst5|Mux7~0_combout\ & \inst5|Mux6~0_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000011000000000000001100000000110000001100110011000000110011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|ALT_INV_Mux4~1_combout\,
	datac => \inst5|ALT_INV_Mux7~0_combout\,
	datad => \inst5|ALT_INV_Mux6~0_combout\,
	dataf => \inst5|ALT_INV_Mux5~0_combout\,
	combout => \inst12|Mux4~0_combout\);

-- Location: MLABCELL_X84_Y12_N21
\inst12|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst12|Mux5~0_combout\ = ( \inst5|Mux5~0_combout\ & ( (!\inst5|Mux7~0_combout\ & ((\inst5|Mux6~0_combout\) # (\inst5|Mux4~1_combout\))) # (\inst5|Mux7~0_combout\ & (!\inst5|Mux4~1_combout\ $ (\inst5|Mux6~0_combout\))) ) ) # ( !\inst5|Mux5~0_combout\ & ( 
-- (\inst5|Mux7~0_combout\ & (\inst5|Mux4~1_combout\ & \inst5|Mux6~0_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000100000001000000010000000101101011011010110110101101101011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux7~0_combout\,
	datab => \inst5|ALT_INV_Mux4~1_combout\,
	datac => \inst5|ALT_INV_Mux6~0_combout\,
	dataf => \inst5|ALT_INV_Mux5~0_combout\,
	combout => \inst12|Mux5~0_combout\);

-- Location: MLABCELL_X84_Y12_N39
\inst12|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst12|Mux6~0_combout\ = ( \inst5|Mux5~0_combout\ & ( (!\inst5|Mux6~0_combout\ & (!\inst5|Mux7~0_combout\ $ (\inst5|Mux4~1_combout\))) ) ) # ( !\inst5|Mux5~0_combout\ & ( (\inst5|Mux7~0_combout\ & (!\inst5|Mux4~1_combout\ $ (\inst5|Mux6~0_combout\))) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0100000101000001010000010100000110010000100100001001000010010000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux7~0_combout\,
	datab => \inst5|ALT_INV_Mux4~1_combout\,
	datac => \inst5|ALT_INV_Mux6~0_combout\,
	dataf => \inst5|ALT_INV_Mux5~0_combout\,
	combout => \inst12|Mux6~0_combout\);

-- Location: LABCELL_X75_Y7_N54
\inst13|Mux0~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst13|Mux0~0_combout\ = ( \inst5|Mux0~0_combout\ & ( \inst5|Mux3~0_combout\ ) ) # ( !\inst5|Mux0~0_combout\ & ( \inst5|Mux3~0_combout\ & ( !\inst5|Mux1~0_combout\ $ (!\inst5|Mux2~0_combout\) ) ) ) # ( \inst5|Mux0~0_combout\ & ( !\inst5|Mux3~0_combout\ & 
-- ( (!\inst5|Mux1~0_combout\) # (\inst5|Mux2~0_combout\) ) ) ) # ( !\inst5|Mux0~0_combout\ & ( !\inst5|Mux3~0_combout\ & ( (\inst5|Mux2~0_combout\) # (\inst5|Mux1~0_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011111100111111110011111100111100111100001111001111111111111111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|ALT_INV_Mux1~0_combout\,
	datac => \inst5|ALT_INV_Mux2~0_combout\,
	datae => \inst5|ALT_INV_Mux0~0_combout\,
	dataf => \inst5|ALT_INV_Mux3~0_combout\,
	combout => \inst13|Mux0~0_combout\);

-- Location: LABCELL_X75_Y7_N3
\inst13|Mux1~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst13|Mux1~0_combout\ = ( \inst5|Mux3~0_combout\ & ( !\inst5|Mux0~0_combout\ $ (((!\inst5|Mux2~0_combout\ & \inst5|Mux1~0_combout\))) ) ) # ( !\inst5|Mux3~0_combout\ & ( (\inst5|Mux2~0_combout\ & (!\inst5|Mux1~0_combout\ & !\inst5|Mux0~0_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0101000000000000010100000000000011110101000010101111010100001010",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux2~0_combout\,
	datac => \inst5|ALT_INV_Mux1~0_combout\,
	datad => \inst5|ALT_INV_Mux0~0_combout\,
	dataf => \inst5|ALT_INV_Mux3~0_combout\,
	combout => \inst13|Mux1~0_combout\);

-- Location: LABCELL_X75_Y7_N36
\inst13|Mux2~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst13|Mux2~0_combout\ = ( \inst5|Mux0~0_combout\ & ( \inst5|Mux3~0_combout\ & ( (!\inst5|Mux2~0_combout\ & !\inst5|Mux1~0_combout\) ) ) ) # ( !\inst5|Mux0~0_combout\ & ( \inst5|Mux3~0_combout\ ) ) # ( !\inst5|Mux0~0_combout\ & ( !\inst5|Mux3~0_combout\ 
-- & ( (!\inst5|Mux2~0_combout\ & \inst5|Mux1~0_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000101000001010000000000000000011111111111111111010000010100000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux2~0_combout\,
	datac => \inst5|ALT_INV_Mux1~0_combout\,
	datae => \inst5|ALT_INV_Mux0~0_combout\,
	dataf => \inst5|ALT_INV_Mux3~0_combout\,
	combout => \inst13|Mux2~0_combout\);

-- Location: LABCELL_X75_Y7_N45
\inst13|Mux3~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst13|Mux3~0_combout\ = ( \inst5|Mux0~0_combout\ & ( \inst5|Mux2~0_combout\ & ( !\inst5|Mux3~0_combout\ $ (\inst5|Mux1~0_combout\) ) ) ) # ( !\inst5|Mux0~0_combout\ & ( \inst5|Mux2~0_combout\ & ( (\inst5|Mux3~0_combout\ & \inst5|Mux1~0_combout\) ) ) ) # 
-- ( !\inst5|Mux0~0_combout\ & ( !\inst5|Mux2~0_combout\ & ( !\inst5|Mux3~0_combout\ $ (!\inst5|Mux1~0_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0110011001100110000000000000000000010001000100011001100110011001",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux3~0_combout\,
	datab => \inst5|ALT_INV_Mux1~0_combout\,
	datae => \inst5|ALT_INV_Mux0~0_combout\,
	dataf => \inst5|ALT_INV_Mux2~0_combout\,
	combout => \inst13|Mux3~0_combout\);

-- Location: LABCELL_X75_Y7_N48
\inst13|Mux4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst13|Mux4~0_combout\ = ( \inst5|Mux0~0_combout\ & ( \inst5|Mux3~0_combout\ & ( (\inst5|Mux1~0_combout\ & \inst5|Mux2~0_combout\) ) ) ) # ( \inst5|Mux0~0_combout\ & ( !\inst5|Mux3~0_combout\ & ( \inst5|Mux1~0_combout\ ) ) ) # ( !\inst5|Mux0~0_combout\ & 
-- ( !\inst5|Mux3~0_combout\ & ( (!\inst5|Mux1~0_combout\ & \inst5|Mux2~0_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000110000001100001100110011001100000000000000000000001100000011",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|ALT_INV_Mux1~0_combout\,
	datac => \inst5|ALT_INV_Mux2~0_combout\,
	datae => \inst5|ALT_INV_Mux0~0_combout\,
	dataf => \inst5|ALT_INV_Mux3~0_combout\,
	combout => \inst13|Mux4~0_combout\);

-- Location: LABCELL_X75_Y7_N33
\inst13|Mux5~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst13|Mux5~0_combout\ = ( \inst5|Mux0~0_combout\ & ( \inst5|Mux2~0_combout\ & ( (\inst5|Mux1~0_combout\) # (\inst5|Mux3~0_combout\) ) ) ) # ( !\inst5|Mux0~0_combout\ & ( \inst5|Mux2~0_combout\ & ( (!\inst5|Mux3~0_combout\ & \inst5|Mux1~0_combout\) ) ) ) 
-- # ( \inst5|Mux0~0_combout\ & ( !\inst5|Mux2~0_combout\ & ( (!\inst5|Mux3~0_combout\ & \inst5|Mux1~0_combout\) ) ) ) # ( !\inst5|Mux0~0_combout\ & ( !\inst5|Mux2~0_combout\ & ( (\inst5|Mux3~0_combout\ & \inst5|Mux1~0_combout\) ) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0001000100010001001000100010001000100010001000100111011101110111",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	dataa => \inst5|ALT_INV_Mux3~0_combout\,
	datab => \inst5|ALT_INV_Mux1~0_combout\,
	datae => \inst5|ALT_INV_Mux0~0_combout\,
	dataf => \inst5|ALT_INV_Mux2~0_combout\,
	combout => \inst13|Mux5~0_combout\);

-- Location: LABCELL_X75_Y7_N12
\inst13|Mux6~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst13|Mux6~0_combout\ = ( \inst5|Mux3~0_combout\ & ( (!\inst5|Mux1~0_combout\ & (!\inst5|Mux2~0_combout\ $ (\inst5|Mux0~0_combout\))) # (\inst5|Mux1~0_combout\ & (!\inst5|Mux2~0_combout\ & \inst5|Mux0~0_combout\)) ) ) # ( !\inst5|Mux3~0_combout\ & ( 
-- (\inst5|Mux1~0_combout\ & (!\inst5|Mux2~0_combout\ & !\inst5|Mux0~0_combout\)) ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0011000000000000001100000000000011000000001111001100000000111100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \inst5|ALT_INV_Mux1~0_combout\,
	datac => \inst5|ALT_INV_Mux2~0_combout\,
	datad => \inst5|ALT_INV_Mux0~0_combout\,
	dataf => \inst5|ALT_INV_Mux3~0_combout\,
	combout => \inst13|Mux6~0_combout\);

-- Location: MLABCELL_X72_Y33_N3
\~QUARTUS_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;
END structure;


