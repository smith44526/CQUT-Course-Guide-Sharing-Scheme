transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {Z:/lab/rtl/pc8.vhd}
vcom -93 -work work {Z:/lab/rtl/ir32.vhd}
vcom -93 -work work {Z:/lab/rtl/hex7seg.vhd}
vcom -93 -work work {Z:/lab/rtl/controller_hw.vhd}
vcom -93 -work work {Z:/lab/rtl/alu8.vhd}
vcom -93 -work work {Z:/lab/rtl/ac8.vhd}
vcom -93 -work work {Z:/lab/inst_rom.vhd}
vcom -93 -work work {Z:/lab/mux2_8.vhd}
vcom -93 -work work {Z:/lab/data_ram.vhd}
vcom -93 -work work {Z:/lab/clk_gen.vhd}

